# SIDARTHE Model with RK2 Method

import numpy as np
import matplotlib.pyplot as plt

# Define model parameters
alpha = 0.57  # rate of transmission from susceptible to infected
beta = 0.011  # rate of transmission from susceptible to diagnosed
gamma = 0.456  # rate of transmission from susceptible to ailing
sigma = 0.011  # rate of transmission from susceptible to recognized
lambda_ = 0.171  # rate of transmission from susceptible to threatened
kappa = 0.171  # rate of transmission from susceptible to healed
mu = 0.456  # rate of transmission from susceptible to extinct

# Define the rate of transitions between compartments
nu = 0.034  # diagnosed to ailing
rho = 0.034  # diagnosed to recognized
xi = 0.017  # diagnosed to threatened
zeta = 0.017  # diagnosed to healed
eta = 0.017  # diagnosed to extinct

tau = 0.017  # ailing to recognized
omega = 0.017  # ailing to threatened
sigma = 0.017  # ailing to healed

# Initial conditions
S0 = 0.99  # Initial susceptible population
I0 = 0.01  # Initial infected population
D0 = 0.0   # Initial diagnosed population
A0 = 0.0   # Initial ailing population
R0 = 0.0   # Initial recognized population
T0 = 0.0   # Initial threatened population
H0 = 0.0   # Initial healed population
E0 = 0.0   # Initial extinct population

# Time parameters
T = 100  # Total time
dt = 0.1  # Time step
n = int(T / dt)  # Number of time steps

def sidarthe_derivatives(S, I, D, A, R, T, H, E):
    dSdt = -alpha * S * I - beta * S * D - gamma * S * A - sigma * S * R - lambda_ * S * T
    dIdt = alpha * S * I - kappa * I - mu * I
    dDdt = beta * S * D + kappa * I - (nu + rho + xi + zeta + eta) * D
    dAdt = gamma * S * A + nu * D - (tau + omega + sigma) * A
    dRdt = sigma * S * R + rho * D + tau * A
    dTdt = lambda_ * S * T + xi * D + omega * A
    dHdt = zeta * D + sigma * A
    dEdt = eta * D
    return dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt

# Initialize arrays to store results
S = np.zeros(n)
I = np.zeros(n)
D = np.zeros(n)
A = np.zeros(n)
R = np.zeros(n)
T = np.zeros(n)
H = np.zeros(n)
E = np.zeros(n)

time = np.linspace(0, T, n)

# Set initial conditions
S[0] = S0
I[0] = I0
D[0] = D0
A[0] = A0
R[0] = R0
T[0] = T0
H[0] = H0
E[0] = E0

# Runge-Kutta 2nd Order Method
for i in range(1, n):
    S1, I1, D1, A1, R1, T1, H1, E1 = sidarthe_derivatives(S[i-1], I[i-1], D[i-1], A[i-1], R[i-1], T[i-1], H[i-1], E[i-1])
    S_half = S[i-1] + dt/2 * S1
    I_half = I[i-1] + dt/2 * I1
    D_half = D[i-1] + dt/2 * D1
    A_half = A[i-1] + dt/2 * A1
    R_half = R[i-1] + dt/2 * R1
    T_half = T[i-1] + dt/2 * T1
    H_half = H[i-1] + dt/2 * H1
    E_half = E[i-1] + dt/2 * E1
    S2, I2, D2, A2, R2, T2, H2, E2 = sidarthe_derivatives(S_half, I_half, D_half, A_half, R_half, T_half, H_half, E_half)
    S[i] = S[i-1] + dt * S2
    I[i] = I[i-1] + dt * I2
    D[i] = D[i-1] + dt * D2
    A[i] = A[i-1] + dt * A2
    R[i] = R[i-1] + dt * R2
    T[i] = T[i-1] + dt * T2
    H[i] = H[i-1] + dt * H2
    E[i] = E[i-1] + dt * E2

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(time, S, label='Susceptible')
plt.plot(time, I, label='Infected')
plt.plot(time, D, label='Diagnosed')
plt.plot(time, A, label='Ailing')
plt.plot(time, R, label='Recognized')
plt.plot(time, T, label='Threatened')
plt.plot(time, H, label='Healed')
plt.plot(time, E, label='Extinct')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.title('SIDARTHE Model Simulation')
plt.grid(True)
plt.show()

