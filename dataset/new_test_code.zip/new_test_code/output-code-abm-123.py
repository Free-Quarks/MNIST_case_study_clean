# Agent-Based Model to Simulate COVID-19 with Age Stratification

import random
import numpy as np
import matplotlib.pyplot as plt

# Constants
POPULATION_SIZE = 1000
INITIAL_INFECTED = 10
SIMULATION_DAYS = 160
AGE_GROUPS = ['0-19', '20-39', '40-59', '60+']
INFECTION_PROBABILITY = 0.03
RECOVERY_DAYS = 14

# Define Age Group Probabilities
AGE_GROUP_PROBABILITY = {
    '0-19': 0.25,
    '20-39': 0.35,
    '40-59': 0.25,
    '60+': 0.15
}

# Define Recovery Rates by Age Group
RECOVERY_RATE = {
    '0-19': 0.99,
    '20-39': 0.95,
    '40-59': 0.90,
    '60+': 0.80
}

class Agent:
    def __init__(self, age_group):
        self.age_group = age_group
        self.is_infected = False
        self.days_infected = 0

    def infect(self):
        self.is_infected = True
        self.days_infected = 0

    def recover(self):
        self.is_infected = False
        self.days_infected = 0

    def update(self):
        if self.is_infected:
            self.days_infected += 1
            if self.days_infected > RECOVERY_DAYS:
                if random.random() < RECOVERY_RATE[self.age_group]:
                    self.recover()

class Population:
    def __init__(self):
        self.agents = []
        for age_group, probability in AGE_GROUP_PROBABILITY.items():
            count = int(probability * POPULATION_SIZE)
            for _ in range(count):
                self.agents.append(Agent(age_group))
        # Infect initial agents
        for _ in range(INITIAL_INFECTED):
            agent = random.choice(self.agents)
            agent.infect()

    def step(self):
        # Update each agent
        for agent in self.agents:
            agent.update()
        # Process infections
        for agent in self.agents:
            if agent.is_infected:
                for _ in range(10):
                    other_agent = random.choice(self.agents)
                    if not other_agent.is_infected:
                        if random.random() < INFECTION_PROBABILITY:
                            other_agent.infect()

    def count_infected(self):
        return sum(agent.is_infected for agent in self.agents)

# Run the simulation
population = Population()
num_infected = []
for day in range(SIMULATION_DAYS):
    population.step()
    num_infected.append(population.count_infected())

# Plot results
plt.plot(num_infected)
plt.xlabel('Day')
plt.ylabel('Number of Infected Individuals')
plt.title('COVID-19 Simulation with Age Stratification')
plt.show()
