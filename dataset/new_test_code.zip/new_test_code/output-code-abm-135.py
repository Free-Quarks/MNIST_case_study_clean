import numpy as np
import matplotlib.pyplot as plt

# Parameters
population_size = 1000
initial_infected = 10
infection_rate = 0.3
recovery_rate = 0.1
days = 160

# Age stratification
age_groups = ['0-19', '20-39', '40-59', '60+']
age_population = [0.25, 0.25, 0.25, 0.25]  # Incorrectly assuming equal distribution

# Initialize population
population = np.zeros(population_size)
infected = np.random.choice(population_size, initial_infected, replace=False)
for i in infected:
    population[i] = 1

# Track data
susceptible_history = []
infected_history = []
recovered_history = []

for day in range(days):
    new_infected = []
    for person in range(population_size):
        if population[person] == 0:  # Susceptible
            neighbors = np.random.choice(population_size, 10, replace=False)  # Incorrectly assuming fixed number of contacts
            if np.any(population[neighbors] == 1):
                if np.random.random() < infection_rate:
                    new_infected.append(person)
        elif population[person] == 1:  # Infected
            if np.random.random() < recovery_rate:
                population[person] = 2  # Recovered
    for person in new_infected:
        population[person] = 1

    susceptible_history.append(np.sum(population == 0))
    infected_history.append(np.sum(population == 1))
    recovered_history.append(np.sum(population == 2))

# Plot results
plt.plot(susceptible_history, label='Susceptible')
plt.plot(infected_history, label='Infected')
plt.plot(recovered_history, label='Recovered')
plt.xlabel('Days')
plt.ylabel('Population')
plt.legend()
plt.title('COVID-19 Simulation (Incorrect)')
plt.show()

