import numpy as np
import matplotlib.pyplot as plt

# SEIRHD Model Parameters
beta = 0.3    # infection rate
sigma = 1/5.2 # incubation rate
gamma = 1/2.9 # recovery rate
mu = 0.01     # disease-induced death rate
nu = 0.005    # hospitalization rate
eta = 0.1     # rate of recovery from hospital

# Initial conditions
S0 = 999   # initial susceptible population
E0 = 1     # initial exposed population
I0 = 0     # initial infected population
R0 = 0     # initial recovered population
H0 = 0     # initial hospitalized population
D0 = 0     # initial deceased population

# Time variables
t_max = 160
n_steps = 160

# SEIRHD model differential equations
def seirhd_deriv(y, t, beta, sigma, gamma, mu, nu, eta):
    S, E, I, R, H, D = y
    dS_dt = -beta * S * I
    dE_dt = beta * S * I - sigma * E
    dI_dt = sigma * E - gamma * I - mu * I - nu * I
    dR_dt = gamma * I + eta * H
    dH_dt = nu * I - eta * H
    dD_dt = mu * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt, dH_dt, dD_dt])

# Runge-Kutta 2nd order method (RK2)
def rk2_step(f, y, t, dt, *args):
    k1 = f(y, t, *args)
    k2 = f(y + dt/2 * k1, t + dt/2, *args)
    return y + dt * k2

# Time points
t = np.linspace(0, t_max, n_steps)
dt = t[1] - t[0]

# Initial state vector
y0 = np.array([S0, E0, I0, R0, H0, D0])

# Integrate the SEIRHD equations over the time grid, t.
solution = np.zeros((n_steps, 6))
solution[0] = y0

for i in range(1, n_steps):
    solution[i] = rk2_step(seirhd_deriv, solution[i-1], t[i-1], dt, beta, sigma, gamma, mu, nu, eta)

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(t, solution[:, 0], label='Susceptible (S)')
plt.plot(t, solution[:, 1], label='Exposed (E)')
plt.plot(t, solution[:, 2], label='Infected (I)')
plt.plot(t, solution[:, 3], label='Recovered (R)')
plt.plot(t, solution[:, 4], label='Hospitalized (H)')
plt.plot(t, solution[:, 5], label='Deceased (D)')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.title('SEIRHD Model Simulation using RK2')
plt.grid()
plt.show()
