# Import necessary libraries
import networkx as nx
import random

# Initialize a network graph
G = nx.erdos_renyi_graph(100, 0.05)

# Define initial parameters
initial_infected = 5
transmission_probability = 0.1

# Assign sex attribute to nodes
for node in G.nodes:
    G.nodes[node]['sex'] = 'male' if random.random() < 0.5 else 'female'

# Initialize infection status
for node in G.nodes:
    G.nodes[node]['status'] = 'infected' if initial_infected > 0 else 'susceptible'
    initial_infected -= 1 if G.nodes[node]['status'] == 'infected' else 0

# Define simulation function
def simulate_infection(G, steps):
    for _ in range(steps):
        new_infections = []
        for node in G.nodes:
            if G.nodes[node]['status'] == 'infected':
                for neighbor in G.neighbors(node):
                    if G.nodes[neighbor]['status'] == 'susceptible' and random.random() < transmission_probability:
                        new_infections.append(neighbor)
        for node in new_infections:
            G.nodes[node]['status'] = 'infected'

# Run the simulation
simulate_infection(G, 10)

# Output the final statuses
infection_status = {node: G.nodes[node]['status'] for node in G.nodes}
print(infection_status)
