# SEIR Model with RK4
import numpy as np
import matplotlib.pyplot as plt

def seir_deriv(y, t, beta, sigma, gamma):
    S, E, I, R = y
    N = S + E + I + R
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I
    dRdt = gamma * I
    return np.array([dSdt, dEdt, dIdt, dRdt])

def rk4_step(f, y, t, dt, *args):
    k1 = f(y, t, *args)
    k2 = f(y + dt/2 * k1, t + dt/2, *args)
    k3 = f(y + dt/2 * k2, t + dt/2, *args)
    k4 = f(y + dt * k3, t + dt, *args)
    return y + dt/6 * (k1 + 2*k2 + 2*k3 + k4)

def simulate_seir(S0, E0, I0, R0, beta, sigma, gamma, days, dt):
    t = np.arange(0, days, dt)
    y = np.zeros((len(t), 4))
    y[0] = [S0, E0, I0, R0]
    for i in range(1, len(t)):
        y[i] = rk4_step(seir_deriv, y[i-1], t[i-1], dt, beta, sigma, gamma)
    return t, y

# Parameters
S0 = 999.0  # Initial susceptible population
E0 = 1.0    # Initial exposed population
I0 = 0.0    # Initial infected population
R0 = 0.0    # Initial recovered population
beta = 0.3  # Infection rate
sigma = 1/5.2  # Rate of progression from exposed to infected
gamma = 1/2.9  # Recovery rate

# Simulation
days = 160
dt = 1.0

# Run simulation
t, y = simulate_seir(S0, E0, I0, R0, beta, sigma, gamma, days, dt)

# Plot results
plt.plot(t, y[:, 0], label='Susceptible')
plt.plot(t, y[:, 1], label='Exposed')
plt.plot(t, y[:, 2], label='Infected')
plt.plot(t, y[:, 3], label='Recovered')
plt.xlabel('Days')
plt.ylabel('Population')
plt.legend()
plt.show()
