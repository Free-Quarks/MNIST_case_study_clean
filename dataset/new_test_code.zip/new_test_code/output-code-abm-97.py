import random

class Person:
    def __init__(self, age, health_status):
        self.age = age
        self.health_status = health_status
        self.infected = False
        self.days_infected = 0

class CovidSimulation:
    def __init__(self, population_size):
        self.population = self.create_population(population_size)
        self.day = 0

    def create_population(self, size):
        population = []
        for _ in range(size):
            age = random.choice(['child', 'adult', 'senior'])
            health_status = random.choice(['healthy', 'compromised'])
            population.append(Person(age, health_status))
        return population

    def simulate_day(self):
        for person in self.population:
            if person.infected:
                person.days_infected += 1
                if person.days_infected > 14:
                    person.infected = False
            else:
                if random.random() < 0.01:  # 1% chance of infection per day
                    person.infected = True
        self.day += 1

    def run_simulation(self, days):
        for _ in range(days):
            self.simulate_day()

# Example usage
simulation = CovidSimulation(population_size=100)
simulation.run_simulation(days=30)
for person in simulation.population:
    print(f'Age: {person.age}, Health: {person.health_status}, Infected: {person.infected}, Days Infected: {person.days_infected}')

