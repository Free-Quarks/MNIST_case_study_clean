# SIR Model using Runge-Kutta 3rd Order (RK3) Method
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
gamma = 0.1 # Recovery rate
S0 = 0.99  # Initial susceptible population
I0 = 0.01  # Initial infected population
R0 = 0.0   # Initial recovered population

# Time parameters
T = 160  # Total time
dt = 0.1 # Time step

# Initialize arrays
N = int(T/dt)
t = np.linspace(0, T, N)
S = np.zeros(N)
I = np.zeros(N)
R = np.zeros(N)

# Initial conditions
S[0] = S0
I[0] = I0
R[0] = R0

# SIR model differential equations
def dS_dt(S, I):
    return -beta * S * I

def dI_dt(S, I):
    return beta * S * I - gamma * I

def dR_dt(I):
    return gamma * I

# Runge-Kutta 3rd Order Method
for n in range(N-1):
    k1_S = dS_dt(S[n], I[n])
    k1_I = dI_dt(S[n], I[n])
    k1_R = dR_dt(I[n])

    k2_S = dS_dt(S[n] + 0.5*dt*k1_S, I[n] + 0.5*dt*k1_I)
    k2_I = dI_dt(S[n] + 0.5*dt*k1_S, I[n] + 0.5*dt*k1_I)
    k2_R = dR_dt(I[n] + 0.5*dt*k1_I)

    k3_S = dS_dt(S[n] - dt*k1_S + 2*dt*k2_S, I[n] - dt*k1_I + 2*dt*k2_I)
    k3_I = dI_dt(S[n] - dt*k1_S + 2*dt*k2_S, I[n] - dt*k1_I + 2*dt*k2_I)
    k3_R = dR_dt(I[n] - dt*k1_I + 2*dt*k2_I)

    S[n+1] = S[n] + (dt/6)*(k1_S + 4*k2_S + k3_S)
    I[n+1] = I[n] + (dt/6)*(k1_I + 4*k2_I + k3_I)
    R[n+1] = R[n] + (dt/6)*(k1_R + 4*k2_R + k3_R)

# Plot results
plt.figure(figsize=(10,6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.title('SIR Model using RK3')
plt.grid(True)
plt.show()

