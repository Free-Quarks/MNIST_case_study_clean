# SEIRHD Model with RK3 Integration in Python

import numpy as np
import matplotlib.pyplot as plt

class SEIRHDModel:
    def __init__(self, beta, sigma, gamma, delta, mu, population):
        self.beta = beta      # Infection rate
        self.sigma = sigma    # Inverse of incubation period
        self.gamma = gamma    # Recovery rate
        self.delta = delta    # Death rate
        self.mu = mu          # Hospitalization rate
        self.population = population

    def derivatives(self, y, t):
        S, E, I, R, H, D = y
        N = self.population
        dSdt = -self.beta * S * I / N
        dEdt = self.beta * S * I / N - self.sigma * E
        dIdt = self.sigma * E - (self.gamma + self.delta + self.mu) * I
        dRdt = self.gamma * I
        dHdt = self.mu * I
        dDdt = self.delta * I
        return np.array([dSdt, dEdt, dIdt, dRdt, dHdt, dDdt])

    def rk3_step(self, y, t, dt):
        k1 = self.derivatives(y, t)
        k2 = self.derivatives(y + dt * k1 / 2, t + dt / 2)
        k3 = self.derivatives(y - dt * k1 + 2 * dt * k2, t + dt)
        return y + (dt / 6) * (k1 + 4 * k2 + k3)

    def run_simulation(self, initial_conditions, t_max, dt):
        t = np.arange(0, t_max, dt)
        y = np.zeros((len(t), len(initial_conditions)))
        y[0, :] = initial_conditions
        for i in range(1, len(t)):
            y[i, :] = self.rk3_step(y[i-1, :], t[i-1], dt)
        return t, y

# Model parameters
beta = 0.3   # Infection rate
sigma = 1/5.2   # Incubation rate (1/incubation period)
gamma = 1/12.39   # Recovery rate (1/infectious period)
delta = 0.005   # Death rate
mu = 0.05   # Hospitalization rate
population = 1e6   # Total population

# Initial conditions (S, E, I, R, H, D)
S0 = population - 1
E0 = 1
I0 = 0
R0 = 0
H0 = 0
D0 = 0
initial_conditions = [S0, E0, I0, R0, H0, D0]

t_max = 160  # Total time in days
dt = 0.1  # Time step

# Run the model
model = SEIRHDModel(beta, sigma, gamma, delta, mu, population)
t, y = model.run_simulation(initial_conditions, t_max, dt)

# Plotting the results
plt.figure(figsize=(10,6))
plt.plot(t, y[:, 0], label='Susceptible')
plt.plot(t, y[:, 1], label='Exposed')
plt.plot(t, y[:, 2], label='Infected')
plt.plot(t, y[:, 3], label='Recovered')
plt.plot(t, y[:, 4], label='Hospitalized')
plt.plot(t, y[:, 5], label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.title('SEIRHD Model Simulation')
plt.show()
