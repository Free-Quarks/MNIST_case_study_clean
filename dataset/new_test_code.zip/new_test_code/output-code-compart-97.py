#!/usr/bin/env python
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt
import json

# SEIRHD model differential equations.
def deriv(y, t, N, beta, sigma, gamma, delta, alpha):
    S, E, I, R, H, D = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - delta * I
    dRdt = gamma * I
    dHdt = delta * I - alpha * H
    dDdt = alpha * H
    return dSdt, dEdt, dIdt, dRdt, dHdt, dDdt

# Initial number of infected and exposed individuals, everyone else is susceptible to infection initially.
N = 1000
I0, E0, R0, H0, D0 = 1, 0, 0, 0, 0
S0 = N - I0 - E0 - R0 - H0 - D0

# Contact rate, incubation period, infectious period, hospitalization rate, hospital mortality rate
beta, sigma, gamma, delta, alpha = 0.3, 1/5.2, 1/2.9, 0.1, 0.01

# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# Initial conditions vector
y0 = S0, E0, I0, R0, H0, D0

# Integrate the SEIRHD equations over the time grid, t.
ret = odeint(deriv, y0, t, args=(N, beta, sigma, gamma, delta, alpha))
S, E, I, R, H, D = ret.T

# Plot the data on three separate curves for S(t), E(t), I(t), R(t), H(t), D(t)
fig = plt.figure(facecolor='w')
ax = fig.add_subplot(111, facecolor='#dddddd', axisbelow=True)
ax.plot(t, S, 'b', alpha=0.5, lw=2, label='Susceptible')
ax.plot(t, E, 'y', alpha=0.5, lw=2, label='Exposed')
ax.plot(t, I, 'r', alpha=0.5, lw=2, label='Infected')
ax.plot(t, R, 'g', alpha=0.5, lw=2, label='Recovered')
ax.plot(t, H, 'c', alpha=0.5, lw=2, label='Hospitalized')
ax.plot(t, D, 'k', alpha=0.5, lw=2, label='Deceased')
ax.set_xlabel('Time /days')
ax.set_ylabel('Number')
ax.set_ylim(0, N)
ax.legend()
ax.grid(b=True, which='major', c='w', lw=2, ls='-')
plt.title('SEIRHD Model')
plt.show()

