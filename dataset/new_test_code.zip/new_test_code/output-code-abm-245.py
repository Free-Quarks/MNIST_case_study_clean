import numpy as np
import networkx as nx
import matplotlib.pyplot as plt

class CovidSimulation:
    def __init__(self, population_size, initial_infected, transmission_rate, recovery_rate, stratification_levels):
        self.population_size = population_size
        self.initial_infected = initial_infected
        self.transmission_rate = transmission_rate
        self.recovery_rate = recovery_rate
        self.stratification_levels = stratification_levels
        self.network = nx.erdos_renyi_graph(n=population_size, p=0.05)
        self.status = {i: 'S' for i in range(population_size)}  # S = Susceptible, I = Infected, R = Recovered
        self.stratification = {i: np.random.choice(stratification_levels) for i in range(population_size)}
        self.initialize_infection()

    def initialize_infection(self):
        initial_infected_nodes = np.random.choice(self.population_size, self.initial_infected, replace=False)
        for node in initial_infected_nodes:
            self.status[node] = 'I'

    def step(self):
        new_status = self.status.copy()
        for node in self.network.nodes:
            if self.status[node] == 'I':
                for neighbor in self.network.neighbors(node):
                    if self.status[neighbor] == 'S':
                        if np.random.rand() < self.transmission_rate / (self.stratification[node] + 1):
                            new_status[neighbor] = 'I'
                if np.random.rand() < self.recovery_rate:
                    new_status[node] = 'R'
        self.status = new_status

    def run(self, steps):
        for _ in range(steps):
            self.step()
            self.plot_network()

    def plot_network(self):
        color_map = {'S': 'blue', 'I': 'red', 'R': 'green'}
        colors = [color_map[self.status[node]] for node in self.network.nodes]
        plt.figure(figsize=(8, 8))
        nx.draw(self.network, node_color=colors, with_labels=True)
        plt.show()

if __name__ == '__main__':
    simulation = CovidSimulation(
        population_size=100,
        initial_infected=5,
        transmission_rate=0.2,
        recovery_rate=0.1,
        stratification_levels=[0, 1, 2]  # Example: 0 = low risk, 1 = medium risk, 2 = high risk
    )
    simulation.run(steps=10)

