import random

class Person:
    def __init__(self, age_group):
        self.age_group = age_group
        self.infected = False
        self.days_infected = 0

class CovidSimulation:
    def __init__(self, population_size, age_distribution, infection_rate, recovery_days):
        self.population_size = population_size
        self.age_distribution = age_distribution
        self.infection_rate = infection_rate
        self.recovery_days = recovery_days
        self.population = self.initialize_population()

    def initialize_population(self):
        population = []
        for age_group, proportion in self.age_distribution.items():
            num_people = int(self.population_size * proportion)
            for _ in range(num_people):
                population.append(Person(age_group))
        return population

    def infect_random_person(self):
        person = random.choice(self.population)
        person.infected = True

    def step(self):
        new_infections = 0
        for person in self.population:
            if person.infected:
                person.days_infected += 1
                if person.days_infected >= self.recovery_days:
                    person.infected = False
                    person.days_infected = 0
                else:
                    for other_person in self.population:
                        if not other_person.infected and random.random() < self.infection_rate:
                            other_person.infected = True
                            new_infections += 1
        return new_infections

    def run_simulation(self, steps):
        self.infect_random_person()
        for _ in range(steps):
            new_infections = self.step()
            print(f"New infections this step: {new_infections}")

# Example usage
if __name__ == "__main__":
    age_distribution = {
        '0-19': 0.25,
        '20-39': 0.35,
        '40-59': 0.25,
        '60+': 0.15
    }
    population_size = 1000
    infection_rate = 0.01
    recovery_days = 14

    simulation = CovidSimulation(population_size, age_distribution, infection_rate, recovery_days)
    simulation.run_simulation(steps=30)
