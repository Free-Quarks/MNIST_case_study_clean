# Network model to simulate COVID-19 spread including vaccination
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt

class CovidSimulation:
    def __init__(self, population_size, initial_infected, infection_probability, recovery_probability, vaccination_rate):
        self.population_size = population_size
        self.initial_infected = initial_infected
        self.infection_probability = infection_probability
        self.recovery_probability = recovery_probability
        self.vaccination_rate = vaccination_rate
        self.G = nx.erdos_renyi_graph(n=population_size, p=0.1)
        self.statuses = ['S'] * population_size
        self.vaccinate_population()
        self.initialize_infected()
        self.history = []

    def vaccinate_population(self):
        vaccinated_count = int(self.vaccination_rate * self.population_size)
        vaccinated_nodes = np.random.choice(self.population_size, vaccinated_count, replace=False)
        for node in vaccinated_nodes:
            self.statuses[node] = 'V'

    def initialize_infected(self):
        infected_nodes = np.random.choice(self.population_size, self.initial_infected, replace=False)
        for node in infected_nodes:
            self.statuses[node] = 'I'

    def step(self):
        new_statuses = self.statuses.copy()
        for node in range(self.population_size):
            if self.statuses[node] == 'I':
                # Attempt to infect neighbors
                for neighbor in self.G.neighbors(node):
                    if self.statuses[neighbor] == 'S':
                        if np.random.rand() < self.infection_probability:
                            new_statuses[neighbor] = 'I'
                # Attempt to recover
                if np.random.rand() < self.recovery_probability:
                    new_statuses[node] = 'R'
        self.statuses = new_statuses
        self.history.append(self.statuses.copy())

    def run(self, steps):
        for _ in range(steps):
            self.step()

    def plot(self):
        S = [status.count('S') for status in self.history]
        I = [status.count('I') for status in self.history]
        R = [status.count('R') for status in self.history]
        V = [status.count('V') for status in self.history]
        plt.plot(S, label='Susceptible')
        plt.plot(I, label='Infected')
        plt.plot(R, label='Recovered')
        plt.plot(V, label='Vaccinated')
        plt.legend()
        plt.xlabel('Time step')
        plt.ylabel('Number of individuals')
        plt.show()

if __name__ == '__main__':
    population_size = 1000
    initial_infected = 10
    infection_probability = 0.05
    recovery_probability = 0.01
    vaccination_rate = 0.6

    simulation = CovidSimulation(population_size, initial_infected, infection_probability, recovery_probability, vaccination_rate)
    simulation.run(steps=100)
    simulation.plot()
