# Import necessary libraries
import numpy as np
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt

# Define age groups
age_groups = {
    '0-17': {'size': 100, 'transmission_rate': 0.05},
    '18-49': {'size': 200, 'transmission_rate': 0.1},
    '50-64': {'size': 150, 'transmission_rate': 0.15},
    '65+': {'size': 50, 'transmission_rate': 0.2}
}

# Initialize the network
G = nx.Graph()

# Add nodes with age group attribute
node_id = 0
for age_group, properties in age_groups.items():
    for _ in range(properties['size']):
        G.add_node(node_id, age_group=age_group, infected=False)
        node_id += 1

# Define connections (edges) between nodes
for node in G.nodes():
    age_group = G.nodes[node]['age_group']
    size = age_groups[age_group]['size']
    connection_probability = 0.05
    for target_node in np.random.choice(G.nodes(), size=int(size * connection_probability)):
        if node != target_node:
            G.add_edge(node, target_node)

# Function to simulate infection spread
def spread_infection(G, initial_infected=1, steps=10):
    # Randomly infect initial nodes
    initial_nodes = np.random.choice(G.nodes(), initial_infected, replace=False)
    for node in initial_nodes:
        G.nodes[node]['infected'] = True

    infection_counts = [initial_infected]

    for step in range(steps):
        new_infections = []
        for node in G.nodes():
            if G.nodes[node]['infected']:
                for neighbor in G.neighbors(node):
                    if not G.nodes[neighbor]['infected']:
                        transmission_rate = age_groups[G.nodes[neighbor]['age_group']]['transmission_rate']
                        if np.random.random() < transmission_rate:
                            new_infections.append(neighbor)

        for node in new_infections:
            G.nodes[node]['infected'] = True
        infection_counts.append(len(new_infections))

    return infection_counts

# Simulate infection spread
infection_counts = spread_infection(G, initial_infected=5, steps=30)

# Plot results
plt.plot(infection_counts)
plt.xlabel('Time Step')
plt.ylabel('Number of New Infections')
plt.title('COVID-19 Infection Spread Simulation')
plt.show()
