import numpy as np
from scipy.integrate import solve_ivp

# Define the SEIRHD model

def seirhd_model(t, y, beta, sigma, gamma, delta, alpha, rho):
    S, E, I, R, H, D = y
    N = S + E + I + R + H + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - delta * I - alpha * I
    dRdt = gamma * I
    dHdt = delta * I - rho * H
    dDdt = alpha * I + rho * H
    return [dSdt, dEdt, dIdt, dRdt, dHdt, dDdt]

# Runge-Kutta 4th order method implementation

def rk4_step(func, t, y, dt, *args):
    k1 = func(t, y, *args)
    k2 = func(t + dt / 2, y + dt / 2 * np.array(k1), *args)
    k3 = func(t + dt / 2, y + dt / 2 * np.array(k2), *args)
    k4 = func(t + dt, y + dt * np.array(k3), *args)
    return y + dt / 6 * (np.array(k1) + 2 * np.array(k2) + 2 * np.array(k3) + np.array(k4))

# Initial conditions and parameters
S0, E0, I0, R0, H0, D0 = 999, 1, 0, 0, 0, 0
y0 = [S0, E0, I0, R0, H0, D0]
beta = 0.3
sigma = 1/5.2
gamma = 1/12.39
delta = 0.1
alpha = 0.02
rho = 0.05
t0 = 0
t_end = 160
dt = 1

# Time points
t_points = np.arange(t0, t_end, dt)

# Storage for results
y_results = np.zeros((len(t_points), len(y0)))
y_results[0, :] = y0

t = t0

# Main loop
for i in range(1, len(t_points)):
    y_results[i, :] = rk4_step(seirhd_model, t, y_results[i-1, :], dt, beta, sigma, gamma, delta, alpha, rho)
    t += dt

# Print results
def print_results():
    print("t\tS\tE\tI\tR\tH\tD")
    for i in range(len(t_points)):
        print(f"{t_points[i]}\t{y_results[i, 0]:.2f}\t{y_results[i, 1]:.2f}\t{y_results[i, 2]:.2f}\t{y_results[i, 3]:.2f}\t{y_results[i, 4]:.2f}\t{y_results[i, 5]:.2f}")

print_results()
