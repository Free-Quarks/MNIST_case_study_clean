# SIDARTHE model simulation using RK3

import numpy as np
from scipy.integrate import solve_ivp

# Parameters for the SIDARTHE model
beta = 0.57
sigma = 0.011
zeta = 0.456
delta = 0.011
alpha = 0.171
eta = 0.370
rho = 0.034
kappa = 0.017
tau = 0.125
lambda_param = 0.034
gamma = 0.017

# Initial conditions
S0 = 0.99
I0 = 0.01
D0 = 0.0
A0 = 0.0
R0 = 0.0
T0 = 0.0
H0 = 0.0
E0 = 0.0

# Simulation time
t_span = [0, 160]
t_eval = np.linspace(t_span[0], t_span[1], 1000)

# SIDARTHE model equations
def sidarthe(t, y):
    S, I, D, A, R, T, H, E = y
    dSdt = -beta * S * (I + D + A + R + T + H + E)
    dIdt = beta * S * (I + D + A + R + T + H + E) - sigma * I - zeta * I - delta * I
    dDdt = sigma * I - alpha * D - eta * D
    dAdt = zeta * I - rho * A - kappa * A
    dRdt = delta * I + alpha * D - tau * R - lambda_param * R
    dTdt = eta * D + rho * A - gamma * T - tau * T
    dHdt = kappa * A + lambda_param * R - gamma * H
    dEdt = tau * R + tau * T + gamma * H
    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Initial values
initial_conditions = [S0, I0, D0, A0, R0, T0, H0, E0]

# Solve the model using RK3 method
solution = solve_ivp(sidarthe, t_span, initial_conditions, t_eval=t_eval, method='RK23')

# Extract the results
S, I, D, A, R, T, H, E = solution.y

# Output the results
import matplotlib.pyplot as plt
plt.plot(t_eval, S, label='Susceptible')
plt.plot(t_eval, I, label='Infected')
plt.plot(t_eval, D, label='Diagnosed')
plt.plot(t_eval, A, label='Ailing')
plt.plot(t_eval, R, label='Recognized')
plt.plot(t_eval, T, label='Threatened')
plt.plot(t_eval, H, label='Healed')
plt.plot(t_eval, E, label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of Population')
plt.legend()
plt.title('SIDARTHE Model Simulation')
plt.show()

