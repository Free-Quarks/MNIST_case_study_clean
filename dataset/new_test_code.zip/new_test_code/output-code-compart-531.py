import numpy as np
import matplotlib.pyplot as plt

# Define the SEIR model parameters
beta = 0.3    # Infection rate
sigma = 1/5.2 # Rate of progression from exposed to infectious
gamma = 1/2.9 # Recovery rate

# Initial conditions
S0 = 0.99   # Initial proportion of susceptible individuals
E0 = 0.01   # Initial proportion of exposed individuals
I0 = 0.0    # Initial proportion of infected individuals
R0 = 0.0    # Initial proportion of recovered individuals

# Simulation parameters
T = 160    # Total time in days
dt = 0.1   # Time step

# Time array
t = np.arange(0, T, dt)

# Initialize arrays to store the results
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

# Set initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# Euler method to solve the SEIR model
for i in range(1, len(t)):
    S[i] = S[i-1] - dt * beta * S[i-1] * I[i-1]
    E[i] = E[i-1] + dt * (beta * S[i-1] * I[i-1] - sigma * E[i-1])
    I[i] = I[i-1] + dt * (sigma * E[i-1] - gamma * I[i-1])
    R[i] = R[i-1] + dt * gamma * I[i-1]

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of Population')
plt.title('SEIR Model Simulation')
plt.legend()
plt.grid(True)
plt.show()
