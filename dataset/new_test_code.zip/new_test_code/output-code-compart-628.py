# SIR Model using RK2 (Runge-Kutta 2nd Order)
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # infection rate
gamma = 0.1  # recovery rate
S0 = 0.99  # initial susceptible population
I0 = 0.01  # initial infected population
R0 = 0.0  # initial recovered population

# Time parameters
T = 160  # total time
dt = 0.1  # time step

# Initialize arrays
num_steps = int(T / dt)
t = np.linspace(0, T, num_steps)
S = np.zeros(num_steps)
I = np.zeros(num_steps)
R = np.zeros(num_steps)

# Initial conditions
S[0] = S0
I[0] = I0
R[0] = R0

# SIR model equations
def sir_model(S, I, R, beta, gamma):
    dS_dt = -beta * S * I
    dI_dt = beta * S * I - gamma * I
    dR_dt = gamma * I
    return dS_dt, dI_dt, dR_dt

# RK2 integration
for step in range(1, num_steps):
    dS1, dI1, dR1 = sir_model(S[step-1], I[step-1], R[step-1], beta, gamma)
    S_half = S[step-1] + 0.5 * dt * dS1
    I_half = I[step-1] + 0.5 * dt * dI1
    R_half = R[step-1] + 0.5 * dt * dR1
    dS2, dI2, dR2 = sir_model(S_half, I_half, R_half, beta, gamma)
    S[step] = S[step-1] + dt * dS2
    I[step] = I[step-1] + dt * dI2
    R[step] = R[step-1] + dt * dR2

# Plotting results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.title('SIR Model using RK2')
plt.legend()
plt.grid()
plt.show()

