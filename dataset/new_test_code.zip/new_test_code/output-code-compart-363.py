# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model
class SEIRD:
    def __init__(self, beta, gamma, delta, alpha, rho, N, I0, E0, R0, D0):
        self.beta = beta  # infection rate
        self.gamma = gamma  # recovery rate
        self.delta = delta  # incubation rate
        self.alpha = alpha  # mortality rate
        self.rho = rho  # removal rate
        self.N = N  # total population
        self.I0 = I0  # initial number of infected individuals
        self.E0 = E0  # initial number of exposed individuals
        self.R0 = R0  # initial number of recovered individuals
        self.D0 = D0  # initial number of deceased individuals
        self.S0 = N - I0 - E0 - R0 - D0  # initial number of susceptible individuals

    def deriv(self, t, S, E, I, R, D):
        dSdt = -self.beta * S * I / self.N
        dEdt = self.beta * S * I / self.N - self.delta * E
        dIdt = self.delta * E - self.gamma * I - self.alpha * I
        dRdt = self.gamma * I
        dDdt = self.alpha * I
        return dSdt, dEdt, dIdt, dRdt, dDdt

    def runge_kutta_2(self, S, E, I, R, D, t, dt):
        k1_S, k1_E, k1_I, k1_R, k1_D = self.deriv(t, S, E, I, R, D)
        k2_S, k2_E, k2_I, k2_R, k2_D = self.deriv(t + 0.5 * dt, 
                                                  S + 0.5 * k1_S * dt, 
                                                  E + 0.5 * k1_E * dt, 
                                                  I + 0.5 * k1_I * dt, 
                                                  R + 0.5 * k1_R * dt, 
                                                  D + 0.5 * k1_D * dt)
        S += k2_S * dt
        E += k2_E * dt
        I += k2_I * dt
        R += k2_R * dt
        D += k2_D * dt
        return S, E, I, R, D

    def simulate(self, T, dt):
        t = np.arange(0, T, dt)
        S, E, I, R, D = self.S0, self.E0, self.I0, self.R0, self.D0
        S_list, E_list, I_list, R_list, D_list = [], [], [], [], []
        for time in t:
            S, E, I, R, D = self.runge_kutta_2(S, E, I, R, D, time, dt)
            S_list.append(S)
            E_list.append(E)
            I_list.append(I)
            R_list.append(R)
            D_list.append(D)
        return t, np.array(S_list), np.array(E_list), np.array(I_list), np.array(R_list), np.array(D_list)

# Parameters
beta = 0.3
gamma = 0.1
delta = 0.1
alpha = 0.01
rho = 0.02
N = 1000000
I0 = 1
E0 = 1
R0 = 0
D0 = 0
T = 160  # total time in days
dt = 1  # time step

# Create SEIRD model instance
model = SEIRD(beta, gamma, delta, alpha, rho, N, I0, E0, R0, D0)

# Simulate the model
results = model.simulate(T, dt)

# Plot the results
t, S, E, I, R, D = results
plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', label='Susceptible')
plt.plot(t, E, 'y', label='Exposed')
plt.plot(t, I, 'r', label='Infected')
plt.plot(t, R, 'g', label='Recovered')
plt.plot(t, D, 'k', label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.title('SEIRD Model Simulation')
plt.grid(True)
plt.show()
