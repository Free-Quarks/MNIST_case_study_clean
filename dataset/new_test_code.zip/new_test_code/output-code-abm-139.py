import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

class Individual:
    def __init__(self, age):
        self.age = age
        self.status = 'S'  # Susceptible

class COVIDSimulation:
    def __init__(self, population_size, age_distribution):
        self.population_size = population_size
        self.age_distribution = age_distribution
        self.population = self.initialize_population()
        self.time_step = 0

    def initialize_population(self):
        population = []
        for age, proportion in self.age_distribution.items():
            num_individuals = int(self.population_size * proportion)
            for _ in range(num_individuals):
                population.append(Individual(age))
        np.random.shuffle(population)
        return population

    def step(self, transmission_rate, recovery_rate):
        new_infections = []
        for individual in self.population:
            if individual.status == 'I':  # Infected
                if np.random.rand() < recovery_rate:
                    individual.status = 'R'  # Recovered
                else:
                    for other in self.population:
                        if other.status == 'S' and np.random.rand() < transmission_rate:
                            new_infections.append(other)
        for individual in new_infections:
            individual.status = 'I'
        self.time_step += 1

    def run(self, steps, transmission_rate, recovery_rate):
        history = []
        for _ in range(steps):
            self.step(transmission_rate, recovery_rate)
            status_counts = {'S': 0, 'I': 0, 'R': 0}
            for individual in self.population:
                status_counts[individual.status] += 1
            history.append(status_counts)
        return history

# Parameters
total_population = 1000
age_distribution = {'child': 0.2, 'adult': 0.6, 'elderly': 0.2}
transmission_rate = 0.05
recovery_rate = 0.01
steps = 100

# Running the simulation
simulation = COVIDSimulation(total_population, age_distribution)
history = simulation.run(steps, transmission_rate, recovery_rate)

# Convert history to DataFrame and plot
history_df = pd.DataFrame(history)
history_df.plot()
plt.xlabel('Time Step')
plt.ylabel('Number of Individuals')
plt.title('COVID-19 Simulation')
plt.show()
