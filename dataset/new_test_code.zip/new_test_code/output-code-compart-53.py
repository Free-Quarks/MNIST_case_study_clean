# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Define the SIR model differential equations
def sir_model(S, I, R, beta, gamma):
    dS_dt = -beta * S * I
    dI_dt = beta * S * I - gamma * I
    dR_dt = gamma * I
    return dS_dt, dI_dt, dR_dt

# Define the Runge-Kutta 2nd order method
def rk2_step(S, I, R, beta, gamma, dt):
    dS1, dI1, dR1 = sir_model(S, I, R, beta, gamma)
    S1 = S + dS1 * dt
    I1 = I + dI1 * dt
    R1 = R + dR1 * dt
    dS2, dI2, dR2 = sir_model(S1, I1, R1, beta, gamma)
    S_new = S + 0.5 * (dS1 + dS2) * dt
    I_new = I + 0.5 * (dI1 + dI2) * dt
    R_new = R + 0.5 * (dR1 + dR2) * dt
    return S_new, I_new, R_new

# Simulation parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
S0 = 0.99  # Initial proportion of susceptible individuals
I0 = 0.01  # Initial proportion of infected individuals
R0 = 0.0  # Initial proportion of recovered individuals
t_max = 160  # Maximum time
dt = 0.1  # Time step

# Time points
num_steps = int(t_max / dt)
t = np.linspace(0, t_max, num_steps)

# Initialize arrays to store the results
S = np.zeros(num_steps)
I = np.zeros(num_steps)
R = np.zeros(num_steps)

# Set initial conditions
S[0] = S0
I[0] = I0
R[0] = R0

# Time integration using RK2
for step in range(1, num_steps):
    S[step], I[step], R[step] = rk2_step(S[step-1], I[step-1], R[step-1], beta, gamma, dt)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.title('SIR Model Simulation using RK2 Method')
plt.legend()
plt.grid()
plt.show()
