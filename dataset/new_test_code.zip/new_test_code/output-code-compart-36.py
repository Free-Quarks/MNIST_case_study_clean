# SEIRD Model using Euler's Method
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3    # Transmission rate
sigma = 0.1   # Rate of progression from exposed to infectious
gamma = 0.1   # Recovery rate
mu = 0.01     # Mortality rate
N = 1000      # Total population

# Initial conditions
S0 = 999      # Initial susceptible individuals
E0 = 1        # Initial exposed individuals
I0 = 0        # Initial infectious individuals
R0 = 0        # Initial recovered individuals
D0 = 0        # Initial deceased individuals

# Time parameters
t_max = 160   # Total time
dt = 1        # Time step

# Arrays to hold the results
t = np.arange(0, t_max, dt)
S = np.zeros_like(t)
E = np.zeros_like(t)
I = np.zeros_like(t)
R = np.zeros_like(t)
D = np.zeros_like(t)

# Initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
D[0] = D0

# Euler's method to solve the ODEs
for i in range(1, len(t)):
    S[i] = S[i-1] - (beta * S[i-1] * I[i-1] / N) * dt
    E[i] = E[i-1] + (beta * S[i-1] * I[i-1] / N - sigma * E[i-1]) * dt
    I[i] = I[i-1] + (sigma * E[i-1] - gamma * I[i-1] - mu * I[i-1]) * dt
    R[i] = R[i-1] + (gamma * I[i-1]) * dt
    D[i] = D[i-1] + (mu * I[i-1]) * dt

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.title('SEIRD Model Simulation')
plt.grid(True)
plt.show()
