# SEIR Model with RK4 (Runge-Kutta 4th Order) Implementation in Python

import numpy as np
import matplotlib.pyplot as plt

# SEIR model parameters
beta = 0.3  # infection rate
sigma = 1/5.2  # incubation rate (1/average incubation period)
gamma = 1/2.9  # recovery rate (1/average infectious period)

# Initial conditions
S0 = 0.99  # initial proportion of susceptible individuals
E0 = 0.01  # initial proportion of exposed individuals
I0 = 0.0  # initial proportion of infectious individuals
R0 = 0.0  # initial proportion of recovered individuals

# Time parameters
T = 160  # total time in days
dt = 0.1  # time step size

# SEIR model differential equations
def seir_derivatives(y, t, beta, sigma, gamma):
    S, E, I, R = y
    dSdt = -beta * S * I
    dEdt = beta * S * I - sigma * E
    dIdt = sigma * E - gamma * I
    dRdt = gamma * I
    return np.array([dSdt, dEdt, dIdt, dRdt])

# Runge-Kutta 4th order method

def rk4_step(derivatives, y, t, dt, *args):
    k1 = derivatives(y, t, *args)
    k2 = derivatives(y + 0.5 * dt * k1, t + 0.5 * dt, *args)
    k3 = derivatives(y + 0.5 * dt * k2, t + 0.5 * dt, *args)
    k4 = derivatives(y + dt * k3, t + dt, *args)
    return y + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)

# Time array
num_steps = int(T / dt)
t = np.linspace(0, T, num_steps)

# Initialize arrays to store results
S = np.zeros(num_steps)
E = np.zeros(num_steps)
I = np.zeros(num_steps)
R = np.zeros(num_steps)

# Initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# Time integration using RK4
for step in range(1, num_steps):
    y = np.array([S[step - 1], E[step - 1], I[step - 1], R[step - 1]])
    y_next = rk4_step(seir_derivatives, y, t[step - 1], dt, beta, sigma, gamma)
    S[step], E[step], I[step], R[step] = y_next

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of population')
plt.legend()
plt.title('SEIR Model Simulation using RK4')
plt.grid(True)
plt.show()
