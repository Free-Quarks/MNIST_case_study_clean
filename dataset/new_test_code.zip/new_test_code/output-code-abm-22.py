import random
import networkx as nx
import matplotlib.pyplot as plt

class Person:
    def __init__(self, id, vaccinated=False):
        self.id = id
        self.infected = False
        self.recovered = False
        self.vaccinated = vaccinated
    
    def __repr__(self):
        return f'Person({self.id}, Infected={self.infected}, Recovered={self.recovered}, Vaccinated={self.vaccinated})'

class CovidSimulation:
    def __init__(self, population_size, initial_infected, vaccination_rate, transmission_prob, recovery_prob):
        self.population_size = population_size
        self.initial_infected = initial_infected
        self.vaccination_rate = vaccination_rate
        self.transmission_prob = transmission_prob
        self.recovery_prob = recovery_prob
        self.population = [Person(id) for id in range(population_size)]
        self.network = nx.erdos_renyi_graph(population_size, 0.1)
        self.vaccinate_population()
        self.infect_initial_population()

    def vaccinate_population(self):
        num_vaccinated = int(self.population_size * self.vaccination_rate)
        vaccinated_people = random.sample(self.population, num_vaccinated)
        for person in vaccinated_people:
            person.vaccinated = True

    def infect_initial_population(self):
        initial_infected_people = random.sample([p for p in self.population if not p.vaccinated], self.initial_infected)
        for person in initial_infected_people:
            person.infected = True

    def step(self):
        new_infections = []
        recoveries = []

        for person in self.population:
            if person.infected and not person.recovered:
                neighbors = list(self.network.neighbors(person.id))
                for neighbor_id in neighbors:
                    neighbor = self.population[neighbor_id]
                    if not neighbor.infected and not neighbor.recovered and not neighbor.vaccinated:
                        if random.random() < self.transmission_prob:
                            new_infections.append(neighbor)
                if random.random() < self.recovery_prob:
                    recoveries.append(person)

        for person in new_infections:
            person.infected = True
        for person in recoveries:
            person.infected = False
            person.recovered = True

    def run_simulation(self, steps):
        for _ in range(steps):
            self.step()

    def plot_network(self):
        color_map = []
        for person in self.population:
            if person.infected:
                color_map.append('red')
            elif person.recovered:
                color_map.append('green')
            elif person.vaccinated:
                color_map.append('blue')
            else:
                color_map.append('gray')
        nx.draw(self.network, node_color=color_map, with_labels=True)
        plt.show()

if __name__ == '__main__':
    simulation = CovidSimulation(population_size=100, 
                                 initial_infected=5, 
                                 vaccination_rate=0.7, 
                                 transmission_prob=0.1, 
                                 recovery_prob=0.05)
    simulation.run_simulation(steps=50)
    simulation.plot_network()
