# Agent-based model to simulate COVID-19 with stratification by sex

import random

class Person:
    def __init__(self, sex):
        self.sex = sex
        self.infected = False
        self.days_infected = 0
        self.recovered = False

    def infect(self):
        if not self.infected and not self.recovered:
            self.infected = True
            self.days_infected = 1

    def progress_disease(self):
        if self.infected:
            self.days_infected += 1
            if self.days_infected > 14:  # Assume 14 days for recovery or death
                self.infected = False
                self.recovered = True


class Population:
    def __init__(self, size):
        self.people = [Person(sex=random.choice(['male', 'female'])) for _ in range(size)]
        self.day = 0

    def simulate_day(self):
        # Each person has a 5% chance to infect another person each day
        for person in self.people:
            if person.infected:
                for other_person in self.people:
                    if not other_person.infected and not other_person.recovered:
                        if random.random() < 0.05:
                            other_person.infect()
            person.progress_disease()
        self.day += 1

    def summary(self):
        males = [p for p in self.people if p.sex == 'male']
        females = [p for p in self.people if p.sex == 'female']
        summary = {
            'day': self.day,
            'total': len(self.people),
            'infected': len([p for p in self.people if p.infected]),
            'recovered': len([p for p in self.people if p.recovered]),
            'male': {
                'total': len(males),
                'infected': len([p for p in males if p.infected]),
                'recovered': len([p for p in males if p.recovered]),
            },
            'female': {
                'total': len(females),
                'infected': len([p for p in females if p.infected]),
                'recovered': len([p for p in females if p.recovered]),
            }
        }
        return summary


# Example usage:
population = Population(size=100)
# Infect a single person to start the epidemic
population.people[0].infect()

# Simulate for 30 days
for _ in range(30):
    population.simulate_day()
    print(population.summary())

