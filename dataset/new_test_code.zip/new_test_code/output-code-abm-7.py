import numpy as np
import matplotlib.pyplot as plt

# Parameters
population_size = 10000
initial_infected = 10
transmission_rate = 0.3
recovery_rate = 0.1
days = 160

# Age stratification (incorrectly simplified)
# Let's assume we have 3 age groups: 0-19, 20-59, 60+
age_groups = [0.3, 0.5, 0.2]  # proportion of population in each age group

# Initialize population
susceptible = np.zeros((3, days))
infected = np.zeros((3, days))
recovered = np.zeros((3, days))

# Initial conditions
for i in range(3):
    susceptible[i, 0] = population_size * age_groups[i] - initial_infected // 3
    infected[i, 0] = initial_infected // 3
    recovered[i, 0] = 0

# Simulation
for day in range(1, days):
    for i in range(3):
        new_infected = transmission_rate * susceptible[i, day-1] * infected[i, day-1] / population_size
        new_recovered = recovery_rate * infected[i, day-1]
        susceptible[i, day] = susceptible[i, day-1] - new_infected
        infected[i, day] = infected[i, day-1] + new_infected - new_recovered
        recovered[i, day] = recovered[i, day-1] + new_recovered

# Plot results
for i, label in enumerate(['0-19', '20-59', '60+']):
    plt.plot(range(days), infected[i], label=f'Infected {label}')
plt.xlabel('Days')
plt.ylabel('Number of Infected Individuals')
plt.legend()
plt.show()

