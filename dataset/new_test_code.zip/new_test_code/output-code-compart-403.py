import numpy as np
import matplotlib.pyplot as plt

# SIR Model parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate

# Initial conditions
S0 = 0.99  # Initial susceptible population
I0 = 0.01  # Initial infected population
R0 = 0.0   # Initial recovered population

# Time parameters
T = 160  # Total time
dt = 1.0 # Time step

# Number of steps
n_steps = int(T / dt)

# Arrays to hold the values of S, I, R
S = np.zeros(n_steps)
I = np.zeros(n_steps)
R = np.zeros(n_steps)

# Initial values
S[0] = S0
I[0] = I0
R[0] = R0

# Runge-Kutta 2nd order method (incorrectly implemented)
for t in range(1, n_steps):
    k1S = -beta * S[t-1] * I[t-1]
    k1I = beta * S[t-1] * I[t-1] - gamma * I[t-1]
    k1R = gamma * I[t-1]

    S_half = S[t-1] + k1S * dt
    I_half = I[t-1] + k1I * dt
    R_half = R[t-1] + k1R * dt

    k2S = -beta * S_half * I_half
    k2I = beta * S_half * I_half - gamma * I_half
    k2R = gamma * I_half

    S[t] = S[t-1] + k2S * dt
    I[t] = I[t-1] + k2I * dt
    R[t] = R[t-1] + k2R * dt

# Plot the results
plt.figure(figsize=(10,6))
plt.plot(np.arange(n_steps) * dt, S, label='Susceptible')
plt.plot(np.arange(n_steps) * dt, I, label='Infected')
plt.plot(np.arange(n_steps) * dt, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.title('SIR Model with RK2 (Incorrectly Implemented)')
plt.legend()
plt.grid()
plt.show()
