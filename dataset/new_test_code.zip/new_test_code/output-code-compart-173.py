# SEIRHD model using RK2
import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.3    # Infection rate
sigma = 1/5.2 # Rate of progression from exposed to infectious
gamma = 1/2.3 # Recovery rate
mu = 0.01    # Mortality rate
rho = 0.02   # Hospitalization rate
alpha = 0.1  # Rate of hospitalization to death

# Initial conditions
S0 = 0.99   # Susceptible
E0 = 0.01   # Exposed
I0 = 0.0    # Infectious
R0 = 0.0    # Recovered
H0 = 0.0    # Hospitalized
D0 = 0.0    # Deceased

# Time parameters
T = 160     # Total time
dt = 1.0    # Time step

# Initialize arrays
S = [S0]
E = [E0]
I = [I0]
R = [R0]
H = [H0]
D = [D0]
t = np.arange(0, T, dt)

# Runge-Kutta 2 (RK2) method for SEIRHD model
def rk2_step(S, E, I, R, H, D, dt):
    N = S + E + I + R + H + D
    k1_S = -beta * S * I / N
    k1_E = beta * S * I / N - sigma * E
    k1_I = sigma * E - gamma * I - rho * I
    k1_R = gamma * I
    k1_H = rho * I - alpha * H
    k1_D = mu * I + alpha * H

    S_temp = S + k1_S * dt
    E_temp = E + k1_E * dt
    I_temp = I + k1_I * dt
    R_temp = R + k1_R * dt
    H_temp = H + k1_H * dt
    D_temp = D + k1_D * dt

    k2_S = -beta * S_temp * I_temp / N
    k2_E = beta * S_temp * I_temp / N - sigma * E_temp
    k2_I = sigma * E_temp - gamma * I_temp - rho * I_temp
    k2_R = gamma * I_temp
    k2_H = rho * I_temp - alpha * H_temp
    k2_D = mu * I_temp + alpha * H_temp

    S_next = S + (k1_S + k2_S) / 2 * dt
    E_next = E + (k1_E + k2_E) / 2 * dt
    I_next = I + (k1_I + k2_I) / 2 * dt
    R_next = R + (k1_R + k2_R) / 2 * dt
    H_next = H + (k1_H + k2_H) / 2 * dt
    D_next = D + (k1_D + k2_D) / 2 * dt

    return S_next, E_next, I_next, R_next, H_next, D_next

# Run simulation
for _ in t[:-1]:
    S_next, E_next, I_next, R_next, H_next, D_next = rk2_step(S[-1], E[-1], I[-1], R[-1], H[-1], D[-1], dt)
    S.append(S_next)
    E.append(E_next)
    I.append(I_next)
    R.append(R_next)
    H.append(H_next)
    D.append(D_next)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.plot(t, H, label='Hospitalized')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIRHD Model using RK2 Method')
plt.grid(True)
plt.show()
