import networkx as nx
import random

# Parameters
num_nodes = 100
prob_infected_initial = 0.05
transmission_rate = 0.1
recovery_rate = 0.05

# Create a random graph
G = nx.erdos_renyi_graph(num_nodes, 0.1)

# Initialize node attributes
for node in G.nodes:
    G.nodes[node]['status'] = 'S' if random.random() > prob_infected_initial else 'I'
    G.nodes[node]['sex'] = 'M' if random.random() > 0.5 else 'F'

# Simulation parameters
num_steps = 50

# Simulation
for step in range(num_steps):
    new_statuses = {}
    for node in G.nodes:
        if G.nodes[node]['status'] == 'I':
            for neighbor in G.neighbors(node):
                if G.nodes[neighbor]['status'] == 'S' and random.random() < transmission_rate:
                    new_statuses[neighbor] = 'I'
            if random.random() < recovery_rate:
                new_statuses[node] = 'R'
    for node, status in new_statuses.items():
        G.nodes[node]['status'] = status

# Output final states
final_states = {node: G.nodes[node]['status'] for node in G.nodes}
print(final_states)

