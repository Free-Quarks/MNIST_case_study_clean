import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import random

# Parameters
population_size = 1000
initial_infected = 10
transmission_prob = 0.05
recovery_prob = 0.01
simulation_steps = 100

# Stratification: Age groups
age_groups = {'child': 0.2, 'adult': 0.6, 'elderly': 0.2}
age_distribution = []
for age_group, proportion in age_groups.items():
    age_distribution.extend([age_group] * int(proportion * population_size))
random.shuffle(age_distribution)

# Initialize population
G = nx.erdos_renyi_graph(population_size, 0.1)
for i in range(population_size):
    G.nodes[i]['state'] = 'S'  # Susceptible
    G.nodes[i]['age_group'] = age_distribution[i]

# Infect initial individuals
initial_infected_nodes = random.sample(G.nodes(), initial_infected)
for node in initial_infected_nodes:
    G.nodes[node]['state'] = 'I'  # Infected

# Simulation
states_over_time = []
for step in range(simulation_steps):
    new_states = dict(G.nodes(data='state'))
    for node in G.nodes():
        if G.nodes[node]['state'] == 'I':
            # Try to infect neighbors
            neighbors = list(G.neighbors(node))
            for neighbor in neighbors:
                if G.nodes[neighbor]['state'] == 'S':
                    if random.random() < transmission_prob:
                        new_states[neighbor] = 'I'
            # Try to recover
            if random.random() < recovery_prob:
                new_states[node] = 'R'  # Recovered
    nx.set_node_attributes(G, new_states, 'state')
    states_over_time.append(new_states)

# Visualization
color_map = {'S': 'blue', 'I': 'red', 'R': 'green'}
plt.figure(figsize=(12, 8))
for step in range(0, simulation_steps, 10):  # Plot every 10th step
    plt.subplot(2, 5, step // 10 + 1)
    node_colors = [color_map[G.nodes[node]['state']] for node in G.nodes()]
    nx.draw(G, node_color=node_colors, with_labels=False, node_size=50)
    plt.title(f'Step {step}')
plt.tight_layout()
plt.show()

