# Agent-Based Model to Simulate COVID-19 with Age Stratification

import random

class Person:
    def __init__(self, age_group):
        self.age_group = age_group
        self.infected = False
        self.days_infected = 0

    def infect(self):
        if not self.infected:
            self.infected = True
            self.days_infected = 1

    def recover_or_die(self, recovery_rate, mortality_rate):
        if self.infected and self.days_infected >= 14:
            if random.random() < recovery_rate[self.age_group]:
                self.infected = False
                self.days_infected = 0
            elif random.random() < mortality_rate[self.age_group]:
                return 'dead'
        elif self.infected:
            self.days_infected += 1
        return 'alive'


def simulate_day(population, transmission_rate, recovery_rate, mortality_rate):
    new_infections = []
    for person in population:
        if person.infected:
            for other in population:
                if not other.infected and person.age_group == other.age_group and random.random() < transmission_rate[person.age_group]:
                    new_infections.append(other)
    for person in new_infections:
        person.infect()
    population = [person for person in population if person.recover_or_die(recovery_rate, mortality_rate) == 'alive']
    return population


def run_simulation(days, initial_infected, population_size, age_distribution, transmission_rate, recovery_rate, mortality_rate):
    population = []
    for age_group, proportion in age_distribution.items():
        num_people = int(proportion * population_size)
        for _ in range(num_people):
            population.append(Person(age_group))
    for _ in range(initial_infected):
        random.choice(population).infect()
    for day in range(days):
        population = simulate_day(population, transmission_rate, recovery_rate, mortality_rate)
        print(f"Day {day + 1}: {sum(person.infected for person in population)} infected, {len(population)} total population")

# Example parameters
age_distribution = {'0-19': 0.25, '20-39': 0.35, '40-59': 0.25, '60+': 0.15}
transmission_rate = {'0-19': 0.03, '20-39': 0.05, '40-59': 0.04, '60+': 0.02}
recovery_rate = {'0-19': 0.99, '20-39': 0.95, '40-59': 0.90, '60+': 0.85}
mortality_rate = {'0-19': 0.0001, '20-39': 0.001, '40-59': 0.005, '60+': 0.02}

run_simulation(days=30, initial_infected=10, population_size=1000, age_distribution=age_distribution, 
               transmission_rate=transmission_rate, recovery_rate=recovery_rate, mortality_rate=mortality_rate)

