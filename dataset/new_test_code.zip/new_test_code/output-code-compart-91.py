# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Define the SIDARTHE model parameters
params = {
    'alpha': 0.57,  # Rate of transmission from S to I
    'beta': 0.011,  # Rate of transmission from I to D
    'gamma': 0.456,  # Rate of detection from I to R
    'delta': 0.011,  # Rate of transmission from I to A
    'epsilon': 0.171,  # Rate of transmission from D to T
    'theta': 0.370,  # Rate of transmission from A to R
    'zeta': 0.125,  # Rate of transmission from I to H
    'eta': 0.034,  # Rate of transmission from A to H
    'mu': 0.017,  # Mortality rate from T
    'nu': 0.027,  # Recovery rate from T
    'tau': 0.045,  # Recovery rate from H
    'lambda': 0.017  # Mortality rate from H
}

# Initial populations
init_values = [
    0.99,  # S: Susceptible
    0.01,  # I: Infected
    0.0,   # D: Diagnosed
    0.0,   # A: Ailing
    0.0,   # R: Recognized
    0.0,   # T: Threatened
    0.0,   # H: Healed
    0.0    # E: Extinct
]

# Time parameters
T = 100  # Total time
dt = 1   # Time step

# Euler method for numerical integration
def euler_step(y, f, dt):
    return y + dt * f(y)

# SIDARTHE model equations
def sidarthe_derivatives(values):
    S, I, D, A, R, T, H, E = values
    N = S + I + D + A + R + T + H + E

    dS = -params['alpha'] * S * I / N - params['beta'] * S * D / N - params['gamma'] * S * A / N
    dI = params['alpha'] * S * I / N - params['delta'] * I - params['epsilon'] * I - params['zeta'] * I
    dD = params['delta'] * I - params['eta'] * D - params['theta'] * D
    dA = params['epsilon'] * I - params['eta'] * A - params['theta'] * A - params['lambda'] * A
    dR = params['gamma'] * S * A / N + params['theta'] * D + params['theta'] * A - params['mu'] * R - params['nu'] * R
    dT = params['eta'] * A + params['eta'] * D - params['nu'] * T - params['tau'] * T
    dH = params['nu'] * T + params['tau'] * T
    dE = params['mu'] * R + params['lambda'] * A

    return np.array([dS, dI, dD, dA, dR, dT, dH, dE])

# Simulation
values = np.array(init_values)
results = [values]
for t in range(T):
    values = euler_step(values, sidarthe_derivatives, dt)
    results.append(values)

results = np.array(results)

# Plotting the results
plt.figure(figsize=(10, 8))
labels = ['S', 'I', 'D', 'A', 'R', 'T', 'H', 'E']
for i in range(results.shape[1]):
    plt.plot(results[:, i], label=labels[i])
plt.legend()
plt.xlabel('Time')
plt.ylabel('Population Proportion')
plt.title('SIDARTHE Model Simulation')
plt.grid(True)
plt.show()
