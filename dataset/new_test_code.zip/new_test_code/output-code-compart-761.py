# SEIRD Model using Euler's Method

import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Rate of progression from exposed to infected
gamma = 0.05  # Recovery rate
mu = 0.01  # Mortality rate
N = 1000  # Total population

dt = 0.1  # Time step
t_max = 160  # Maximum time

# Initial conditions
S0 = 999  # Initial susceptible individuals
E0 = 1    # Initial exposed individuals
I0 = 0    # Initial infected individuals
R0 = 0    # Initial recovered individuals
D0 = 0    # Initial deceased individuals

# Time points
T = np.arange(0, t_max, dt)

# Initialize arrays
S = np.zeros(len(T))
E = np.zeros(len(T))
I = np.zeros(len(T))
R = np.zeros(len(T))
D = np.zeros(len(T))

# Set initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
D[0] = D0

# Euler method
for t in range(1, len(T)):
    S[t] = S[t-1] - (beta * S[t-1] * I[t-1] / N) * dt
    E[t] = E[t-1] + (beta * S[t-1] * I[t-1] / N - sigma * E[t-1]) * dt
    I[t] = I[t-1] + (sigma * E[t-1] - gamma * I[t-1] - mu * I[t-1]) * dt
    R[t] = R[t-1] + (gamma * I[t-1]) * dt
    D[t] = D[t-1] + (mu * I[t-1]) * dt

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(T, S, label='Susceptible')
plt.plot(T, E, label='Exposed')
plt.plot(T, I, label='Infected')
plt.plot(T, R, label='Recovered')
plt.plot(T, D, label='Deceased')
plt.xlabel('Time')
plt.ylabel('Number of individuals')
plt.title('SEIRD Model')
plt.legend()
plt.grid()
plt.show()
