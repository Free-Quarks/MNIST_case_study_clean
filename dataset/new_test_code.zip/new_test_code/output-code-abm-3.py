import random

class Person:
    def __init__(self, age_group):
        self.age_group = age_group
        self.infected = False

class Population:
    def __init__(self, size):
        self.people = self.create_population(size)

    def create_population(self, size):
        age_groups = ['child', 'adult', 'senior']
        population = [Person(random.choice(age_groups)) for _ in range(size)]
        return population

    def infect_random_person(self):
        random.choice(self.people).infected = True

    def spread_infection(self, transmission_rate):
        for person in self.people:
            if person.infected:
                for other_person in self.people:
                    if not other_person.infected and random.random() < transmission_rate:
                        other_person.infected = True

    def count_infected(self):
        return sum(1 for person in self.people if person.infected)

    def simulate(self, days, transmission_rate):
        for day in range(days):
            self.spread_infection(transmission_rate)
            print(f"Day {day+1}: {self.count_infected()} infected")

# Simulating COVID incorrectly in a population of 100 people, for 10 days, with a transmission rate of 0.1
population_size = 100
simulation_days = 10
transmission_rate = 0.1

population = Population(population_size)
population.infect_random_person()
population.simulate(simulation_days, transmission_rate)

