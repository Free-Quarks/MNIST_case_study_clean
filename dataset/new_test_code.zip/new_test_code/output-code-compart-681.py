# SEIR Model with Euler's Method
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Inverse of incubation period
gamma = 1/12.39  # Recovery rate

# Initial conditions
S0 = 0.99  # Initial proportion of susceptible individuals
E0 = 0.01  # Initial proportion of exposed individuals
I0 = 0.0  # Initial proportion of infectious individuals
R0 = 0.0  # Initial proportion of recovered individuals

# Time parameters
T = 160  # Total time in days
dt = 0.1  # Time step
n_steps = int(T / dt)  # Number of time steps

# Initialize arrays to store results
S = np.zeros(n_steps)
E = np.zeros(n_steps)
I = np.zeros(n_steps)
R = np.zeros(n_steps)

# Set initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# Euler's method to solve the SEIR model
for t in range(1, n_steps):
    dS = -beta * S[t-1] * I[t-1] * dt
    dE = (beta * S[t-1] * I[t-1] - sigma * E[t-1]) * dt
    dI = (sigma * E[t-1] - gamma * I[t-1]) * dt
    dR = gamma * I[t-1] * dt
    
    S[t] = S[t-1] + dS
    E[t] = E[t-1] + dE
    I[t] = I[t-1] + dI
    R[t] = R[t-1] + dR

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(np.linspace(0, T, n_steps), S, label='Susceptible')
plt.plot(np.linspace(0, T, n_steps), E, label='Exposed')
plt.plot(np.linspace(0, T, n_steps), I, label='Infectious')
plt.plot(np.linspace(0, T, n_steps), R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of Population')
plt.legend()
plt.title('SEIR Model Simulation')
plt.grid(True)
plt.show()

