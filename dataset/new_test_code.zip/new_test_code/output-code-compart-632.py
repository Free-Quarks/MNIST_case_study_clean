
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# SEIR Model
# S: Susceptible
# E: Exposed
# I: Infectious
# R: Recovered

def seir_model(y, t, N, beta, sigma, gamma):
    S, E, I, R = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I
    dRdt = gamma * I
    return dSdt, dEdt, dIdt, dRdt

# Initial number of individuals in each compartment
N = 1000
I0 = 1
E0 = 0
R0 = 0
S0 = N - I0 - E0 - R0

# Contact rate, incubation rate, recovery rate
beta = 0.3
sigma = 1/5.2
gamma = 1/14

# Initial conditions vector
y0 = S0, E0, I0, R0

# Time points (in days)
t = np.linspace(0, 160, 160)

# Integrate the SEIR equations over the time grid t
ret = odeint(seir_model, y0, t, args=(N, beta, sigma, gamma))
S, E, I, R = ret.T

# Plot the data
fig = plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, label='Infectious')
plt.plot(t, R, 'g', alpha=0.7, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend(loc='best')
plt.title('SEIR Model')
plt.grid(True)
plt.show()

