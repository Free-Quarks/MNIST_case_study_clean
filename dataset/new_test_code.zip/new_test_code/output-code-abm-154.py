# Agent-based model to simulate COVID-19 with vaccination

import random
import matplotlib.pyplot as plt

class Person:
    def __init__(self, id, vaccinated=False):
        self.id = id
        self.infected = False
        self.recovered = False
        self.vaccinated = vaccinated

    def infect(self):
        if not self.infected and not self.recovered and not self.vaccinated:
            self.infected = True

    def recover(self):
        if self.infected:
            self.infected = False
            self.recovered = True

class Simulation:
    def __init__(self, population_size, initial_infected, vaccination_rate):
        self.population = [Person(i) for i in range(population_size)]
        self.initial_infected = initial_infected
        self.vaccination_rate = vaccination_rate
        self.time_steps = 0
        self.history = {'infected': [], 'recovered': [], 'vaccinated': []}
        self.vaccinate_population()
        self.infect_initial_population()

    def vaccinate_population(self):
        for person in self.population:
            if random.random() < self.vaccination_rate:
                person.vaccinated = True

    def infect_initial_population(self):
        initially_infected = random.sample(self.population, self.initial_infected)
        for person in initially_infected:
            person.infect()

    def step(self):
        for person in self.population:
            if person.infected:
                # Each infected person has a chance to infect others
                for other in self.population:
                    if not other.infected and not other.recovered and not other.vaccinated:
                        if random.random() < 0.05:  # Infection probability
                            other.infect()
                # Infected person has a chance to recover
                if random.random() < 0.1:  # Recovery probability
                    person.recover()
        self.time_steps += 1
        self.record_history()

    def record_history(self):
        infected_count = sum(1 for person in self.population if person.infected)
        recovered_count = sum(1 for person in self.population if person.recovered)
        vaccinated_count = sum(1 for person in self.population if person.vaccinated)
        self.history['infected'].append(infected_count)
        self.history['recovered'].append(recovered_count)
        self.history['vaccinated'].append(vaccinated_count)

    def run(self, steps):
        for _ in range(steps):
            self.step()

    def plot(self):
        plt.plot(self.history['infected'], label='Infected')
        plt.plot(self.history['recovered'], label='Recovered')
        plt.plot(self.history['vaccinated'], label='Vaccinated')
        plt.xlabel('Time Steps')
        plt.ylabel('Number of People')
        plt.legend()
        plt.show()

# Parameters
population_size = 1000
initial_infected = 10
vaccination_rate = 0.7

# Initialize and run simulation
simulation = Simulation(population_size, initial_infected, vaccination_rate)
simulation.run(100)
simulation.plot()
