import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # infection rate
gamma = 0.1  # recovery rate

# Initial conditions
S0 = 0.9  # initial susceptible fraction
I0 = 0.1  # initial infected fraction
R0 = 0.0  # initial recovered fraction

# Time parameters
t_max = 160  # maximum time
dt = 0.1  # time step

# Initialize arrays
t = np.arange(0, t_max, dt)
S = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

# Set initial values
S[0] = S0
I[0] = I0
R[0] = R0

# RK3 function
def RK3_step(S, I, R, beta, gamma, dt):
    # K1
    dS1 = -beta * S * I
    dI1 = beta * S * I - gamma * I
    dR1 = gamma * I

    # K2
    S2 = S + 0.5 * dS1 * dt
    I2 = I + 0.5 * dI1 * dt
    R2 = R + 0.5 * dR1 * dt
    dS2 = -beta * S2 * I2
    dI2 = beta * S2 * I2 - gamma * I2
    dR2 = gamma * I2

    # K3
    S3 = S - dS1 * dt + 2 * dS2 * dt
    I3 = I - dI1 * dt + 2 * dI2 * dt
    R3 = R - dR1 * dt + 2 * dR2 * dt
    dS3 = -beta * S3 * I3
    dI3 = beta * S3 * I3 - gamma * I3
    dR3 = gamma * I3

    # Update values
    S_new = S + (dS1 + 4 * dS2 + dS3) * dt / 6
    I_new = I + (dI1 + 4 * dI2 + dI3) * dt / 6
    R_new = R + (dR1 + 4 * dR2 + dR3) * dt / 6

    return S_new, I_new, R_new

# Time integration
for i in range(1, len(t)):
    S[i], I[i], R[i] = RK3_step(S[i-1], I[i-1], R[i-1], beta, gamma, dt)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Fraction of Population')
plt.legend()
plt.title('SIR Model using RK3')
plt.show()
