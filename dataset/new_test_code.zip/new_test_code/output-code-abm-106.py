import random

class Person:
    def __init__(self, id, vaccinated):
        self.id = id
        self.infected = False
        self.vaccinated = vaccinated

class CovidSimulation:
    def __init__(self, population_size, initial_infected, vaccination_rate, infection_probability):
        self.population_size = population_size
        self.initial_infected = initial_infected
        self.vaccination_rate = vaccination_rate
        self.infection_probability = infection_probability
        self.population = self.create_population()
        self.infect_initial_population()

    def create_population(self):
        population = []
        for i in range(self.population_size):
            vaccinated = random.random() < self.vaccination_rate
            person = Person(i, vaccinated)
            population.append(person)
        return population

    def infect_initial_population(self):
        initially_infected = random.sample(self.population, self.initial_infected)
        for person in initially_infected:
            person.infected = True

    def spread_infection(self):
        new_infections = 0
        for person in self.population:
            if person.infected:
                for other_person in self.population:
                    if not other_person.infected and not other_person.vaccinated:
                        if random.random() < self.infection_probability:
                            other_person.infected = True
                            new_infections += 1
        return new_infections

    def run_simulation(self, days):
        daily_infections = []
        for day in range(days):
            new_infections = self.spread_infection()
            daily_infections.append(new_infections)
        return daily_infections

# Parameters
population_size = 1000
initial_infected = 10
vaccination_rate = 0.7
infection_probability = 0.1
days = 30

# Run Simulation
simulation = CovidSimulation(population_size, initial_infected, vaccination_rate, infection_probability)
daily_infections = simulation.run_simulation(days)

print(daily_infections)
