# SEIRD Model using odeint in Python

import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the model parameters
total_population = 1000
initial_exposed = 1
initial_infected = 1
initial_recovered = 0
initial_deceased = 0
initial_susceptible = total_population - initial_exposed - initial_infected - initial_recovered - initial_deceased

# Contact rate, incubation rate, recovery rate, mortality rate
effective_contact_rate = 0.3
incubation_rate = 1./5
recovery_rate = 1./10
mortality_rate = 0.01

# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# The SEIRD model differential equations.
def deriv(y, t, N, beta, sigma, gamma, mu):
    S, E, I, R, D = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - mu * I
    dRdt = gamma * I
    dDdt = mu * I
    return dSdt, dEdt, dIdt, dRdt, dDdt

# Initial conditions vector
y0 = initial_susceptible, initial_exposed, initial_infected, initial_recovered, initial_deceased

# Integrate the SEIRD equations over the time grid, t.
ret = odeint(deriv, y0, t, args=(total_population, effective_contact_rate, incubation_rate, recovery_rate, mortality_rate))
S, E, I, R, D = ret.T

# Plot the data
fig = plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.plot(t, D, 'k', alpha=0.7, linewidth=2, label='Deceased')
plt.xlabel('Time /days')
plt.ylabel('Number')
plt.legend()
plt.title('SEIRD Model for COVID-19')
plt.show()
