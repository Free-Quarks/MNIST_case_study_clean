# SEIR Model with RK2 Integration in Python
import numpy as np
import matplotlib.pyplot as plt

# Parameters
total_population = 1000
initial_exposed = 1
initial_infected = 0
initial_removed = 0
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
sigma = 0.1  # Rate at which exposed individuals become infectious
dt = 0.1  # Time step
time_steps = 160

# Initial conditions
initial_susceptible = total_population - initial_exposed - initial_infected - initial_removed
S = [initial_susceptible]
E = [initial_exposed]
I = [initial_infected]
R = [initial_removed]
T = [0]

# Runge-Kutta 2nd order method
for t in range(1, time_steps):
    current_S, current_E, current_I, current_R = S[-1], E[-1], I[-1], R[-1]

    k1_S = -beta * current_S * current_I / total_population
    k1_E = beta * current_S * current_I / total_population - sigma * current_E
    k1_I = sigma * current_E - gamma * current_I
    k1_R = gamma * current_I

    mid_S = current_S + k1_S * dt / 2
    mid_E = current_E + k1_E * dt / 2
    mid_I = current_I + k1_I * dt / 2
    mid_R = current_R + k1_R * dt / 2

    k2_S = -beta * mid_S * mid_I / total_population
    k2_E = beta * mid_S * mid_I / total_population - sigma * mid_E
    k2_I = sigma * mid_E - gamma * mid_I
    k2_R = gamma * mid_I

    next_S = current_S + k2_S * dt
    next_E = current_E + k2_E * dt
    next_I = current_I + k2_I * dt
    next_R = current_R + k2_R * dt

    S.append(next_S)
    E.append(next_E)
    I.append(next_I)
    R.append(next_R)
    T.append(t * dt)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(T, S, label='Susceptible')
plt.plot(T, E, label='Exposed')
plt.plot(T, I, label='Infected')
plt.plot(T, R, label='Removed')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.title('SEIR Model with RK2 Integration')
plt.grid()
plt.show()
