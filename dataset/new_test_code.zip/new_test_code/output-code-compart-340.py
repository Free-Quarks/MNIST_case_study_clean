import numpy as np
from scipy.integrate import solve_ivp

# SEIRD Model differential equations
def seird_model(t, y, beta, sigma, gamma, mu):
    S, E, I, R, D = y
    N = S + E + I + R + D
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I - mu * I
    dR_dt = gamma * I
    dD_dt = mu * I
    return [dS_dt, dE_dt, dI_dt, dR_dt, dD_dt]

# Runge-Kutta 4th Order (RK4) Method
def rk4_step(f, t, y, h, *args):
    k1 = h * np.array(f(t, y, *args))
    k2 = h * np.array(f(t + h/2, y + k1/2, *args))
    k3 = h * np.array(f(t + h/2, y + k2/2, *args))
    k4 = h * np.array(f(t + h, y + k3, *args))
    return y + (k1 + 2*k2 + 2*k3 + k4) / 6

# Simulation parameters
t0 = 0
T = 160
h = 1.0
t = np.arange(t0, T + h, h)

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
D0 = 0
initial_conditions = [S0, E0, I0, R0, D0]

# Model parameters
beta = 0.3
sigma = 0.1
gamma = 0.1
mu = 0.01

# Initialize arrays to store results
results = np.zeros((len(t), len(initial_conditions)))
results[0] = initial_conditions

# Simulation loop
for i in range(1, len(t)):
    results[i] = rk4_step(seird_model, t[i-1], results[i-1], h, beta, sigma, gamma, mu)

# Extract results
S, E, I, R, D = results.T

# Print results (or process as needed)
print("Time (days):", t)
print("Susceptible:", S)
print("Exposed:", E)
print("Infected:", I)
print("Recovered:", R)
print("Deceased:", D)
