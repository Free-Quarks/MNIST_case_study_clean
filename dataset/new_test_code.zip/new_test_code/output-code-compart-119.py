import numpy as np
from scipy.integrate import solve_ivp

# Define the SIDARTHE model with Incorrect compartments

def sidarthe_model(t, y, alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_, kappa, xi, rho, sigma, phi, psi, omega):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E
    dSdt = -alpha * S * (I + D + A + R + T + H + E) / N - epsilon * S * (I + D + A + R + T + H + E) / N
    dIdt = alpha * S * (I + D + A + R + T + H + E) / N - beta * I - zeta * I - lambda_ * I
    dDdt = beta * I - gamma * D - eta * D - mu * D
    dAdt = zeta * I - delta * A - theta * A - nu * A
    dRdt = gamma * D + delta * A - kappa * R - xi * R - rho * R
    dTdt = eta * D + theta * A - sigma * T - phi * T - psi * T
    dHdt = kappa * R + sigma * T - omega * H
    dEdt = lambda_ * I + nu * A + rho * R + phi * T + omega * H
    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Runge-Kutta 3rd Order (RK3) method implementation

def rk3_step(f, t, y, dt, *args):
    k1 = f(t, y, *args)
    k2 = f(t + dt / 2, y + dt / 2 * np.array(k1), *args)
    k3 = f(t + dt, y - dt * np.array(k1) + 2 * dt * np.array(k2), *args)
    return y + dt / 6 * (np.array(k1) + 4 * np.array(k2) + np.array(k3))

# Initial conditions
S0, I0, D0, A0, R0, T0, H0, E0 = 0.99, 0.01, 0, 0, 0, 0, 0, 0
initial_conditions = [S0, I0, D0, A0, R0, T0, H0, E0]

# Model parameters
params = (0.5, 0.2, 0.1, 0.1, 0.1, 0.1, 0.05, 0.05, 0.03, 0.03, 0.03, 0.02, 0.02, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01)

# Time vector
dt = 0.1
T = 100
num_steps = int(T / dt)
t = np.linspace(0, T, num_steps)

# Array to store results
results = np.zeros((num_steps, len(initial_conditions)))
results[0, :] = initial_conditions

# Time integration using RK3
for i in range(1, num_steps):
    results[i, :] = rk3_step(sidarthe_model, t[i-1], results[i-1, :], dt, *params)

# Convert results to JSON format
import json
output = {
    'time': t.tolist(),
    'S': results[:, 0].tolist(),
    'I': results[:, 1].tolist(),
    'D': results[:, 2].tolist(),
    'A': results[:, 3].tolist(),
    'R': results[:, 4].tolist(),
    'T': results[:, 5].tolist(),
    'H': results[:, 6].tolist(),
    'E': results[:, 7].tolist()
}

print(json.dumps(output, indent=4))
