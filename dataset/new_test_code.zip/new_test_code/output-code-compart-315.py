# This Python script simulates a SEIRD model using the RK4 method

import numpy as np
import matplotlib.pyplot as plt

# Total population, N.
N = 1000
# Initial number of infected, recovered, deceased, and exposed individuals, I0, R0, D0, E0.
I0, R0, D0, E0 = 1, 0, 0, 0
# Everyone else, S0, is susceptible to infection initially.
S0 = N - I0 - R0 - D0 - E0
# Contact rate, beta, mean recovery rate, gamma, mean incubation rate, sigma, and mean death rate, mu.
beta, gamma, sigma, mu = 0.3, 1./10, 1./5, 0.01

# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# The SEIRD model differential equations.
def deriv(y, t, N, beta, gamma, sigma, mu):
    S, E, I, R, D = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - mu * I
    dRdt = gamma * I
    dDdt = mu * I
    return dSdt, dEdt, dIdt, dRdt, dDdt

# Initial conditions vector
y0 = S0, E0, I0, R0, D0

# Store results
S, E, I, R, D = [S0], [E0], [I0], [R0], [D0]

# RK4 step size
h = t[1] - t[0]

# Implementing RK4 method
for time in t[1:]:
    k1 = np.array(deriv(y0, time, N, beta, gamma, sigma, mu))
    k2 = np.array(deriv(y0 + 0.5 * h * k1, time + 0.5 * h, N, beta, gamma, sigma, mu))
    k3 = np.array(deriv(y0 + 0.5 * h * k2, time + 0.5 * h, N, beta, gamma, sigma, mu))
    k4 = np.array(deriv(y0 + h * k3, time + h, N, beta, gamma, sigma, mu))
    y0 = y0 + (h / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
    S.append(y0[0])
    E.append(y0[1])
    I.append(y0[2])
    R.append(y0[3])
    D.append(y0[4])

# Plot the data
plt.figure(figsize=(10,6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.plot(t, D, 'k', alpha=0.7, linewidth=2, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.grid(True)
plt.title('SEIRD Model using RK4 Method')
plt.show()
