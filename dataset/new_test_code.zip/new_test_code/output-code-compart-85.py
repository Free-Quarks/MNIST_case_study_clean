# SEIR Model using RK4 Method
import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Rate of progression from exposed to infectious
gamma = 0.1  # Recovery rate

# Initial conditions
S0 = 0.99  # Initial susceptible population
E0 = 0.01  # Initial exposed population
I0 = 0.0   # Initial infected population
R0 = 0.0   # Initial recovered population

# Total population, N.
N = S0 + E0 + I0 + R0

# A grid of time points (in days)
t = np.linspace(0, 160, 1000)

# SEIR model differential equations.
def deriv(y, t, N, beta, sigma, gamma):
    S, E, I, R = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I
    dRdt = gamma * I
    return dSdt, dEdt, dIdt, dRdt

# Runge-Kutta 4th order method

def rk4_step(f, y, t, h, *args):
    k1 = np.array(f(y, t, *args))
    k2 = np.array(f(y + 0.5 * h * k1, t + 0.5 * h, *args))
    k3 = np.array(f(y + 0.5 * h * k2, t + 0.5 * h, *args))
    k4 = np.array(f(y + h * k3, t + h, *args))
    return y + (h / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)

# Initial conditions vector
y0 = S0, E0, I0, R0

# Integrate the SEIR equations over the time grid, t.
S, E, I, R = [S0], [E0], [I0], [R0]

for i in range(1, len(t)):
    y = S[-1], E[-1], I[-1], R[-1]
    h = t[i] - t[i - 1]
    y_next = rk4_step(deriv, y, t[i - 1], h, N, beta, sigma, gamma)
    S.append(y_next[0])
    E.append(y_next[1])
    I.append(y_next[2])
    R.append(y_next[3])

# Plot the data
def plot_seir(t, S, E, I, R):
    plt.figure(figsize=(10, 6))
    plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
    plt.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
    plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
    plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
    plt.xlabel('Time (days)')
    plt.ylabel('Fraction of population')
    plt.legend()
    plt.grid(True)
    plt.show()

plot_seir(t, S, E, I, R)

