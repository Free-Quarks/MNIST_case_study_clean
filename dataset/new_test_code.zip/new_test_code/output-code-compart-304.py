import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# SIR model differential equations
def sir_model(t, y, beta, gamma):
    S, I, R = y
    dSdt = -beta * S * I
    dIdt = beta * S * I - gamma * I
    dRdt = gamma * I
    return [dSdt, dIdt, dRdt]

# Runge-Kutta 3rd order method (Incorrectly implemented)
def rk3_step(fun, t, y, dt, *args):
    k1 = fun(t, y, *args)
    k2 = fun(t + dt/2, y + dt*k1/2, *args)
    k3 = fun(t + dt, y + dt*k2, *args)
    return y + dt * (k1 + 4*k2 + k3) / 6  # Incorrect weights for RK3

# Parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
S0, I0, R0 = 0.99, 0.01, 0.0  # Initial conditions

# Time points
t0, tf = 0, 160
dt = 1.0

# Initialize variables
t_values = np.arange(t0, tf + dt, dt)
S, I, R = S0, I0, R0
solution = [[S, I, R]]

# Time integration
for t in t_values[:-1]:
    S, I, R = rk3_step(sir_model, t, [S, I, R], dt, beta, gamma)
    solution.append([S, I, R])

solution = np.array(solution)

# Plot results
plt.plot(t_values, solution[:, 0], label='Susceptible')
plt.plot(t_values, solution[:, 1], label='Infected')
plt.plot(t_values, solution[:, 2], label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.show()
