# SEIRD Model using Runge-Kutta 2nd Order (RK2) Method

import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model equations
def seird_model(y, beta, sigma, gamma, delta):
    S, E, I, R, D = y
    N = S + E + I + R + D
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I - delta * I
    dR_dt = gamma * I
    dD_dt = delta * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt, dD_dt])

# RK2 method implementation
def rk2_step(f, y, t, dt, *args):
    k1 = f(y, *args)
    k2 = f(y + dt * k1, *args)
    return y + (dt / 2) * (k1 + k2)

# Simulation parameters
beta = 0.3    # Infection rate
sigma = 0.1   # Rate of progression from exposed to infectious
gamma = 0.05  # Recovery rate
delta = 0.01  # Mortality rate

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
D0 = 0
initial_conditions = np.array([S0, E0, I0, R0, D0])

t0 = 0  # Initial time
t_end = 160  # End time
dt = 1  # Time step

t_values = np.arange(t0, t_end + dt, dt)

# Storage for results
results = np.zeros((len(t_values), len(initial_conditions)))
results[0] = initial_conditions

y = initial_conditions

# Time-stepping loop
for i in range(1, len(t_values)):
    y = rk2_step(seird_model, y, t_values[i-1], dt, beta, sigma, gamma, delta)
    results[i] = y

# Plotting the results
plt.figure(figsize=(12, 8))
plt.plot(t_values, results[:, 0], label='Susceptible')
plt.plot(t_values, results[:, 1], label='Exposed')
plt.plot(t_values, results[:, 2], label='Infectious')
plt.plot(t_values, results[:, 3], label='Recovered')
plt.plot(t_values, results[:, 4], label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Number of Individuals')
plt.legend()
plt.title('SEIRD Model Simulation using RK2')
plt.grid(True)
plt.show()
