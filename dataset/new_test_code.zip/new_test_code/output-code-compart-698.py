import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Rate of progression from exposed to infectious
gamma = 1/2.9  # Recovery rate
mu_H = 0.05  # Mortality rate in hospitalized individuals
rho = 1/5  # Rate of hospitalization
N = 1000  # Total population

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
H0 = 0
D0 = 0

# Time parameters
t_max = 160
dt = 1.0  # Time step
n_steps = int(t_max / dt)

def SEIRHD_model(y, beta, sigma, gamma, mu_H, rho):
    S, E, I, R, H, D = y
    N = S + E + I + R + H
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I - rho * I
    dR_dt = gamma * I
    dH_dt = rho * I - mu_H * H
    dD_dt = mu_H * H
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt, dH_dt, dD_dt])

# Initialize arrays to store results
S = np.zeros(n_steps)
E = np.zeros(n_steps)
I = np.zeros(n_steps)
R = np.zeros(n_steps)
H = np.zeros(n_steps)
D = np.zeros(n_steps)

# Set initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
H[0] = H0
D[0] = D0

# Time integration using RK2
for t in range(1, n_steps):
    y = np.array([S[t-1], E[t-1], I[t-1], R[t-1], H[t-1], D[t-1]])
    k1 = SEIRHD_model(y, beta, sigma, gamma, mu_H, rho)
    k2 = SEIRHD_model(y + dt * k1 / 2, beta, sigma, gamma, mu_H, rho)
    y_next = y + dt * k2
    S[t], E[t], I[t], R[t], H[t], D[t] = y_next

# Plot results
t = np.linspace(0, t_max, n_steps)
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.plot(t, H, label='Hospitalized')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.grid(True)
plt.title('SEIRHD Model Simulation')
plt.show()
