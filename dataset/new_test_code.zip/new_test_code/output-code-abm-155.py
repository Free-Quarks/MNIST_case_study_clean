import numpy as np
import matplotlib.pyplot as plt

class Agent:
    def __init__(self, age, status='susceptible'):
        self.age = age
        self.status = status

class COVIDSimulation:
    def __init__(self, population_size, age_distribution):
        self.population_size = population_size
        self.age_distribution = age_distribution
        self.population = self.initialize_population()
        self.time_step = 0

    def initialize_population(self):
        population = []
        for age_group, proportion in self.age_distribution.items():
            count = int(self.population_size * proportion)
            for _ in range(count):
                population.append(Agent(age_group))
        np.random.shuffle(population)
        return population

    def introduce_infection(self, initial_infected=1):
        infected_agents = np.random.choice(self.population, initial_infected, replace=False)
        for agent in infected_agents:
            agent.status = 'infected'

    def step(self, transmission_rate=0.1, recovery_rate=0.01):
        new_infections = []
        recoveries = []
        for agent in self.population:
            if agent.status == 'infected':
                if np.random.rand() < recovery_rate:
                    recoveries.append(agent)
                else:
                    for other_agent in self.population:
                        if other_agent.status == 'susceptible' and np.random.rand() < transmission_rate:
                            new_infections.append(other_agent)
        for agent in new_infections:
            agent.status = 'infected'
        for agent in recoveries:
            agent.status = 'recovered'
        self.time_step += 1

    def run(self, steps):
        for _ in range(steps):
            self.step()

    def plot(self):
        statuses = [agent.status for agent in self.population]
        susceptible_count = statuses.count('susceptible')
        infected_count = statuses.count('infected')
        recovered_count = statuses.count('recovered')
        labels = ['Susceptible', 'Infected', 'Recovered']
        counts = [susceptible_count, infected_count, recovered_count]
        plt.bar(labels, counts)
        plt.title(f'COVID Simulation at Time Step {self.time_step}')
        plt.show()

# Parameters
population_size = 1000
age_distribution = {
    '0-19': 0.25,
    '20-39': 0.25,
    '40-59': 0.25,
    '60+': 0.25
}

# Create and run simulation
simulation = COVIDSimulation(population_size, age_distribution)
simulation.introduce_infection(initial_infected=10)
simulation.run(steps=100)
simulation.plot()
