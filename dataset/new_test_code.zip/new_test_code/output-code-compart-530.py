# SIR Model with RK4 Integration
import numpy as np
import matplotlib.pyplot as plt

# Total population, N.
N = 1000
# Initial number of infected and recovered individuals, I0 and R0.
I0, R0 = 1, 0
# Everyone else, S0, is susceptible to infection initially.
S0 = N - I0 - R0
# Contact rate, beta, and mean recovery rate, gamma, (in 1/days).
beta, gamma = 0.3, 1./10
# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# SIR model differential equations.
def deriv(y, t, N, beta, gamma):
    S, I, R = y
    dSdt = -beta * S * I / N
    dIdt = beta * S * I / N - gamma * I
    dRdt = gamma * I
    return dSdt, dIdt, dRdt

# Runge-Kutta 4th Order Method

def rk4(f, y0, t, N, beta, gamma):
    y = np.zeros((len(t), len(y0)))
    y[0] = y0
    h = t[1] - t[0]
    for i in range(1, len(t)):
        k1 = np.array(f(y[i-1], t[i-1], N, beta, gamma))
        k2 = np.array(f(y[i-1] + 0.5*h*k1, t[i-1] + 0.5*h, N, beta, gamma))
        k3 = np.array(f(y[i-1] + 0.5*h*k2, t[i-1] + 0.5*h, N, beta, gamma))
        k4 = np.array(f(y[i-1] + h*k3, t[i-1] + h, N, beta, gamma))
        y[i] = y[i-1] + (h/6)*(k1 + 2*k2 + 2*k3 + k4)
    return y

# Initial conditions vector
y0 = S0, I0, R0

# Integrate the SIR equations over the time grid, t.
ret = rk4(deriv, y0, t, N, beta, gamma)
S, I, R = ret.T

# Plot the data on three separate curves for S(t), I(t) and R(t)
fig = plt.figure(facecolor='w')
ax = fig.add_subplot(111, facecolor='#dddddd', axisbelow=True)
ax.plot(t, S/1000, 'b', alpha=0.5, lw=2, label='Susceptible')
ax.plot(t, I/1000, 'r', alpha=0.5, lw=2, label='Infected')
ax.plot(t, R/1000, 'g', alpha=0.5, lw=2, label='Recovered with immunity')
ax.set_xlabel('Time /days')
ax.set_ylabel('Number (1000s)')
ax.set_ylim(0,1.2)
ax.legend()
plt.show()
