# Import necessary libraries
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SIR model
def sir_model(y, t, beta, gamma):
    S, I, R = y
    dS_dt = -beta * S * I
    dI_dt = beta * S * I - gamma * I
    dR_dt = gamma * I
    return [dS_dt, dI_dt, dR_dt]

# Initial number of infected and recovered individuals, everyone else is susceptible to infection initially.
I0 = 1
R0 = 0
S0 = 999

# Total population, N.
N = S0 + I0 + R0

# Initial conditions vector
initial_conditions = [S0 / N, I0 / N, R0 / N]

# Contact rate, beta, and mean recovery rate, gamma, (in 1/days).
beta = 0.3
gamma = 0.1

# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# Integrate the SIR equations over the time grid, t.
solution = odeint(sir_model, initial_conditions, t, args=(beta, gamma))
S, I, R = solution.T

# Plot the data
plt.figure(figsize=(12, 8))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Fraction of population')
plt.legend()
plt.title('SIR Model')
plt.show()
