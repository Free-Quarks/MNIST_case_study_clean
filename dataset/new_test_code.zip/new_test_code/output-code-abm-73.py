# Agent-based model to simulate COVID-19 with stratification by age groups

import numpy as np
import random

class Person:
    def __init__(self, age, initial_status='susceptible'):
        self.age = age
        self.status = initial_status
        self.days_infected = 0

    def update_status(self):
        if self.status == 'infected':
            self.days_infected += 1
            if self.days_infected > 14:  # Assume recovery after 14 days
                self.status = 'recovered'

class Simulation:
    def __init__(self, num_people, initial_infected, infection_rate, age_distribution):
        self.people = self.initialize_population(num_people, initial_infected, age_distribution)
        self.infection_rate = infection_rate

    def initialize_population(self, num_people, initial_infected, age_distribution):
        population = []
        for _ in range(num_people):
            age = random.choices(list(age_distribution.keys()), weights=age_distribution.values())[0]
            person = Person(age)
            population.append(person)
        for _ in range(initial_infected):
            population[random.randint(0, num_people-1)].status = 'infected'
        return population

    def step(self):
        for person in self.people:
            if person.status == 'infected':
                for other_person in self.people:
                    if other_person.status == 'susceptible' and random.random() < self.infection_rate:
                        other_person.status = 'infected'
                person.update_status()

    def run(self, steps):
        for _ in range(steps):
            self.step()

    def results(self):
        status_counts = {'susceptible': 0, 'infected': 0, 'recovered': 0}
        for person in self.people:
            status_counts[person.status] += 1
        return status_counts

# Example usage
num_people = 1000
initial_infected = 10
infection_rate = 0.05
age_distribution = {'0-19': 0.25, '20-39': 0.35, '40-59': 0.25, '60+': 0.15}
simulation = Simulation(num_people, initial_infected, infection_rate, age_distribution)
simulation.run(steps=50)
print(simulation.results())

