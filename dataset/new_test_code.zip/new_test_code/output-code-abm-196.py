import random

class Individual:
    def __init__(self, sex):
        self.sex = sex
        self.infected = False

    def infect(self):
        self.infected = True

class Population:
    def __init__(self, size):
        self.individuals = [Individual(sex=random.choice(['male', 'female'])) for _ in range(size)]

    def introduce_infection(self, initial_infections):
        for _ in range(initial_infections):
            random.choice(self.individuals).infect()

    def simulate_step(self, infection_rate):
        new_infections = []
        for individual in self.individuals:
            if individual.infected:
                for other in self.individuals:
                    if not other.infected and random.random() < infection_rate:
                        new_infections.append(other)
        for individual in new_infections:
            individual.infect()

    def count_infected(self):
        return sum(1 for individual in self.individuals if individual.infected)

if __name__ == '__main__':
    population_size = 1000
    initial_infections = 5
    infection_rate = 0.1
    steps = 10

    population = Population(population_size)
    population.introduce_infection(initial_infections)

    print(f'Step 0: {population.count_infected()} infected')
    for step in range(1, steps + 1):
        population.simulate_step(infection_rate)
        print(f'Step {step}: {population.count_infected()} infected')

