import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SEIRHD model
def seirhd_model(y, t, N, beta, sigma, gamma, mu, delta, alpha):
    S, E, I, R, H, D = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - mu * I - delta * I
    dRdt = gamma * I
    dHdt = delta * I - alpha * H
    dDdt = mu * I + alpha * H
    return dSdt, dEdt, dIdt, dRdt, dHdt, dDdt

# Initial number of each compartment
N = 1000
I0 = 1
E0 = 0
R0 = 0
S0 = N - I0 - E0 - R0
H0 = 0
D0 = 0

# Initial conditions vector
y0 = S0, E0, I0, R0, H0, D0

# Contact rate, incubation rate, recovery rate, mortality rate, hospitalization rate, and hospital mortality rate
beta = 0.3  # contact rate
sigma = 1/5.2  # incubation rate
gamma = 1/12.39  # recovery rate
mu = 0.02  # mortality rate
delta = 0.05  # hospitalization rate
alpha = 0.01  # hospital mortality rate

# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# Integrate the SEIRHD equations over the time grid, t.
ret = odeint(seirhd_model, y0, t, args=(N, beta, sigma, gamma, mu, delta, alpha))
S, E, I, R, H, D = ret.T

# Plot the data
fig = plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.plot(t, H, 'c', alpha=0.7, linewidth=2, label='Hospitalized')
plt.plot(t, D, 'k', alpha=0.7, linewidth=2, label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Number of people')
plt.legend()
plt.grid(True)
plt.show()
