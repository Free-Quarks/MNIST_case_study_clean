import numpy as np
import matplotlib.pyplot as plt

class Agent:
    def __init__(self, unique_id, vaccinated=False):
        self.unique_id = unique_id
        self.vaccinated = vaccinated
        self.infected = False
        self.recovered = False

class CovidSimulation:
    def __init__(self, num_agents, infection_rate, recovery_rate, vaccination_rate):
        self.num_agents = num_agents
        self.infection_rate = infection_rate
        self.recovery_rate = recovery_rate
        self.vaccination_rate = vaccination_rate
        self.agents = [Agent(i) for i in range(num_agents)]
        self.initialize_vaccination()

    def initialize_vaccination(self):
        num_vaccinated = int(self.vaccination_rate * self.num_agents)
        vaccinated_agents = np.random.choice(self.agents, num_vaccinated, replace=False)
        for agent in vaccinated_agents:
            agent.vaccinated = True

    def step(self):
        new_infections = []
        for agent in self.agents:
            if not agent.infected and not agent.recovered:
                if not agent.vaccinated and np.random.random() < self.infection_rate:
                    new_infections.append(agent)
                elif agent.vaccinated and np.random.random() < (self.infection_rate / 2):  # Assuming vaccination reduces infection rate by half
                    new_infections.append(agent)

        for agent in new_infections:
            agent.infected = True

        for agent in self.agents:
            if agent.infected and np.random.random() < self.recovery_rate:
                agent.infected = False
                agent.recovered = True

    def run(self, steps):
        infected_counts = []
        for _ in range(steps):
            self.step()
            infected_counts.append(sum(agent.infected for agent in self.agents))
        return infected_counts

# Parameters
num_agents = 1000
infection_rate = 0.05
recovery_rate = 0.01
vaccination_rate = 0.7
steps = 100

# Running simulation
simulation = CovidSimulation(num_agents, infection_rate, recovery_rate, vaccination_rate)
infected_counts = simulation.run(steps)

# Plotting results
plt.plot(infected_counts)
plt.xlabel('Time Steps')
plt.ylabel('Infected Count')
plt.title('COVID-19 Simulation with Vaccination')
plt.show()
