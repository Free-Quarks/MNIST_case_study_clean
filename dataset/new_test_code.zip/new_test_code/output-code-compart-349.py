# SEIRHD model with RK3 integration

import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# Parameters
delta = 1/5.2     # Incubation rate (1/incubation period)
kappa = 1/2.3     # Infection rate (1/infectious period)
mu = 0.01        # Mortality rate
rho = 0.1        # Recovery rate
beta = 0.3       # Transmission rate

# SEIRHD model differential equations
def seirhd(t, y):
    S, E, I, R, H, D = y
    N = S + E + I + R + H + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - delta * E
    dIdt = delta * E - (kappa + rho + mu) * I
    dRdt = rho * I
    dHdt = kappa * I
    dDdt = mu * I
    return [dSdt, dEdt, dIdt, dRdt, dHdt, dDdt]

# Initial conditions
N = 1e6
E0 = 1
I0 = 0
R0 = 0
H0 = 0
D0 = 0
S0 = N - E0 - I0 - R0 - H0 - D0
initial_conditions = [S0, E0, I0, R0, H0, D0]

# Time points
T = 160  # Number of days
t_eval = np.linspace(0, T, T)

# Solve the system using RK3 (explicit Runge-Kutta order 3)
solution = solve_ivp(seirhd, [0, T], initial_conditions, t_eval=t_eval, method='RK23')

# Plotting the results
S, E, I, R, H, D = solution.y
plt.figure(figsize=(10, 6))
plt.plot(t_eval, S, label='Susceptible')
plt.plot(t_eval, E, label='Exposed')
plt.plot(t_eval, I, label='Infected')
plt.plot(t_eval, R, label='Recovered')
plt.plot(t_eval, H, label='Hospitalized')
plt.plot(t_eval, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.title('SEIRHD Model Simulation')
plt.legend()
plt.grid()
plt.show()
