import numpy as np
import matplotlib.pyplot as plt

# Define the compartmental model based on SIDARTHE
class SIDARTHEModel:
    def __init__(self, S, I, D, A, R, T, H, E, beta, gamma, delta, alpha, rho, theta, sigma, eta, mu, nu, xi, tau, lam, kappa, N):
        self.S = S
        self.I = I
        self.D = D
        self.A = A
        self.R = R
        self.T = T
        self.H = H
        self.E = E
        self.beta = beta
        self.gamma = gamma
        self.delta = delta
        self.alpha = alpha
        self.rho = rho
        self.theta = theta
        self.sigma = sigma
        self.eta = eta
        self.mu = mu
        self.nu = nu
        self.xi = xi
        self.tau = tau
        self.lam = lam
        self.kappa = kappa
        self.N = N

    def derivatives(self, S, I, D, A, R, T, H, E):
        dSdt = -self.beta * S * I / self.N - self.delta * S * A / self.N
        dIdt = self.beta * S * I / self.N - (self.gamma + self.alpha) * I
        dDdt = self.delta * S * A / self.N - (self.rho + self.alpha) * D
        dAdt = self.alpha * (I + D) - (self.theta + self.sigma) * A
        dRdt = self.gamma * I + self.rho * D + self.theta * A - (self.eta + self.mu) * R
        dTdt = self.sigma * A - (self.nu + self.xi) * T
        dHdt = self.eta * R - (self.tau + self.lam) * H
        dEdt = self.mu * R + self.nu * T + self.tau * H + self.xi * E - self.kappa * E
        return dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt

    def runge_kutta_3(self, h, steps):
        S, I, D, A, R, T, H, E = self.S, self.I, self.D, self.A, self.R, self.T, self.H, self.E
        for _ in range(steps):
            k1 = self.derivatives(S, I, D, A, R, T, H, E)
            k2 = self.derivatives(S + h*k1[0]/2, I + h*k1[1]/2, D + h*k1[2]/2, A + h*k1[3]/2, R + h*k1[4]/2, T + h*k1[5]/2, H + h*k1[6]/2, E + h*k1[7]/2)
            k3 = self.derivatives(S - h*k1[0] + 2*h*k2[0], I - h*k1[1] + 2*h*k2[1], D - h*k1[2] + 2*h*k2[2], A - h*k1[3] + 2*h*k2[3], R - h*k1[4] + 2*h*k2[4], T - h*k1[5] + 2*h*k2[5], H - h*k1[6] + 2*h*k2[6], E - h*k1[7] + 2*h*k2[7])
            S += h * (k1[0] + 4*k2[0] + k3[0]) / 6
            I += h * (k1[1] + 4*k2[1] + k3[1]) / 6
            D += h * (k1[2] + 4*k2[2] + k3[2]) / 6
            A += h * (k1[3] + 4*k2[3] + k3[3]) / 6
            R += h * (k1[4] + 4*k2[4] + k3[4]) / 6
            T += h * (k1[5] + 4*k2[5] + k3[5]) / 6
            H += h * (k1[6] + 4*k2[6] + k3[6]) / 6
            E += h * (k1[7] + 4*k2[7] + k3[7]) / 6
        self.S, self.I, self.D, self.A, self.R, self.T, self.H, self.E = S, I, D, A, R, T, H, E

# Example usage
if __name__ == '__main__':
    model = SIDARTHEModel(
        S=1000, I=1, D=0, A=0, R=0, T=0, H=0, E=0,
        beta=0.2, gamma=0.1, delta=0.05, alpha=0.05,
        rho=0.05, theta=0.05, sigma=0.05, eta=0.05,
        mu=0.02, nu=0.01, xi=0.01, tau=0.01,
        lam=0.01, kappa=0.01, N=1000
    )
    model.runge_kutta_3(h=0.1, steps=100)
    print(f'S: {model.S}, I: {model.I}, D: {model.D}, A: {model.A}, R: {model.R}, T: {model.T}, H: {model.H}, E: {model.E}')

