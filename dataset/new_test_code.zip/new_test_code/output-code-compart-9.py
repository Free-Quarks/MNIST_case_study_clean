# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Define the SEIR model with RK3
class SEIRModelRK3:
    def __init__(self, beta, gamma, sigma, S0, E0, I0, R0, T, dt):
        self.beta = beta  # Infection rate
        self.gamma = gamma  # Recovery rate
        self.sigma = sigma  # Rate of progression from exposed to infected
        self.S0 = S0  # Initial susceptible population
        self.E0 = E0  # Initial exposed population
        self.I0 = I0  # Initial infected population
        self.R0 = R0  # Initial recovered population
        self.T = T  # Total time
        self.dt = dt  # Time step

        self.N = S0 + E0 + I0 + R0  # Total population
        self.times = np.arange(0, T, dt)  # Time array

        # Initialize arrays to store results
        self.S = np.zeros(len(self.times))
        self.E = np.zeros(len(self.times))
        self.I = np.zeros(len(self.times))
        self.R = np.zeros(len(self.times))

    def derivatives(self, S, E, I, R):
        dS = -self.beta * S * I / self.N
        dE = self.beta * S * I / self.N - self.sigma * E
        dI = self.sigma * E - self.gamma * I
        dR = self.gamma * I
        return dS, dE, dI, dR

    def run(self):
        # Initial conditions
        S, E, I, R = self.S0, self.E0, self.I0, self.R0

        for i, t in enumerate(self.times):
            self.S[i] = S
            self.E[i] = E
            self.I[i] = I
            self.R[i] = R

            # Runge-Kutta 3rd Order Integration (Incorrectly implemented)
            k1_S, k1_E, k1_I, k1_R = self.derivatives(S, E, I, R)
            k2_S, k2_E, k2_I, k2_R = self.derivatives(S + 0.5 * k1_S * self.dt, E + 0.5 * k1_E * self.dt, I + 0.5 * k1_I * self.dt, R + 0.5 * k1_R * self.dt)
            k3_S, k3_E, k3_I, k3_R = self.derivatives(S - k1_S * self.dt + 2 * k2_S * self.dt, E - k1_E * self.dt + 2 * k2_E * self.dt, I - k1_I * self.dt + 2 * k2_I * self.dt, R - k1_R * self.dt + 2 * k2_R * self.dt)

            S += (k1_S + 2 * k2_S + k3_S) / 6 * self.dt
            E += (k1_E + 2 * k2_E + k3_E) / 6 * self.dt
            I += (k1_I + 2 * k2_I + k3_I) / 6 * self.dt
            R += (k1_R + 2 * k2_R + k3_R) / 6 * self.dt

        return self.times, self.S, self.E, self.I, self.R

# Example usage
if __name__ == "__main__":
    # Parameters
    beta = 0.3
    gamma = 0.1
    sigma = 0.1
    S0 = 999
    E0 = 1
    I0 = 0
    R0 = 0
    T = 160
    dt = 0.1

    # Create the SEIR model instance
    model = SEIRModelRK3(beta, gamma, sigma, S0, E0, I0, R0, T, dt)
    times, S, E, I, R = model.run()

    # Plot the results
    plt.figure(figsize=(10, 6))
    plt.plot(times, S, label='Susceptible')
    plt.plot(times, E, label='Exposed')
    plt.plot(times, I, label='Infected')
    plt.plot(times, R, label='Recovered')
    plt.xlabel('Time (days)')
    plt.ylabel('Population')
    plt.title('SEIR Model with RK3 (Incorrectly Implemented)')
    plt.legend()
    plt.show()
