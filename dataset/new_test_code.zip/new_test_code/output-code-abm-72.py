import networkx as nx
import random

# Create a new graph
G = nx.Graph()

# Add nodes to the graph, stratified by sex
num_males = 50
num_females = 50

for i in range(num_males):
    G.add_node(f'M{i}', sex='male')
for i in range(num_females):
    G.add_node(f'F{i}', sex='female')

# Add edges to the graph randomly
for i in range(num_males + num_females):
    for j in range(i + 1, num_males + num_females):
        if random.random() < 0.1:  # 10% chance of connection
            G.add_edge(list(G.nodes)[i], list(G.nodes)[j])

# Initialize infection states
for node in G.nodes:
    G.nodes[node]['infected'] = False

# Patient zero
patient_zero = random.choice(list(G.nodes))
G.nodes[patient_zero]['infected'] = True

# Simulate disease spread
num_steps = 10
for step in range(num_steps):
    new_infections = []
    for node in G.nodes:
        if G.nodes[node]['infected']:
            for neighbor in G.neighbors(node):
                if not G.nodes[neighbor]['infected']:
                    if random.random() < 0.2:  # 20% chance of infection
                        new_infections.append(neighbor)
    for node in new_infections:
        G.nodes[node]['infected'] = True

# Output final infection states
for node in G.nodes:
    print(f"{node}: {'Infected' if G.nodes[node]['infected'] else 'Healthy'}")
