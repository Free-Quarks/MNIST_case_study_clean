import random
import matplotlib.pyplot as plt

class Person:
    def __init__(self, sex):
        self.sex = sex
        self.infected = False
        self.days_infected = 0

    def infect(self):
        self.infected = True
        self.days_infected = 0

    def recover_or_die(self):
        if self.infected:
            self.days_infected += 1
            if self.days_infected > 14:
                if random.random() < 0.02:  # 2% mortality rate
                    return 'dead'
                else:
                    self.infected = False
                    self.days_infected = 0
                    return 'recovered'
        return 'none'


class Population:
    def __init__(self, size, initial_infected_ratio):
        self.people = [Person(sex=random.choice(['male', 'female'])) for _ in range(size)]
        self.size = size
        self.initial_infected_ratio = initial_infected_ratio
        self.infect_initial_population()

    def infect_initial_population(self):
        infected_count = int(self.size * self.initial_infected_ratio)
        for person in random.sample(self.people, infected_count):
            person.infect()

    def step(self):
        for person in self.people:
            if person.infected:
                for other_person in random.sample(self.people, 5):  # each infected person interacts with 5 others
                    if not other_person.infected and random.random() < 0.1:  # 10% transmission rate
                        other_person.infect()

        for person in self.people:
            result = person.recover_or_die()
            if result == 'dead':
                self.people.remove(person)

    def count_infected(self):
        return sum(1 for person in self.people if person.infected)

    def count_by_sex(self, sex):
        return sum(1 for person in self.people if person.sex == sex)


# Simulation parameters
population_size = 1000
initial_infected_ratio = 0.01
steps = 100

# Initialize population
population = Population(population_size, initial_infected_ratio)

# Run simulation
infected_counts = []
male_counts = []
female_counts = []

for _ in range(steps):
    population.step()
    infected_counts.append(population.count_infected())
    male_counts.append(population.count_by_sex('male'))
    female_counts.append(population.count_by_sex('female'))

# Plot results
plt.figure(figsize=(12, 6))
plt.plot(infected_counts, label='Infected')
plt.plot(male_counts, label='Male')
plt.plot(female_counts, label='Female')
plt.legend()
plt.title('COVID-19 Simulation')
plt.xlabel('Days')
plt.ylabel('Number of People')
plt.show()
