# SEIR Compartmental Model using Runge-Kutta 3rd Order (RK3) Method

import numpy as np
import matplotlib.pyplot as plt

# Define the SEIR model parameters
beta = 0.3    # infection rate
sigma = 0.1   # incubation rate
gamma = 0.1   # recovery rate

# Initial conditions
S0 = 0.99  # Initial proportion of susceptible individuals
E0 = 0.01  # Initial proportion of exposed individuals
I0 = 0.0   # Initial proportion of infected individuals
R0 = 0.0   # Initial proportion of recovered individuals

# Time parameters
T = 160    # Total time
dt = 0.1   # Time step

# Number of steps
n_steps = int(T / dt)

# Arrays to store results
S = np.zeros(n_steps)
E = np.zeros(n_steps)
I = np.zeros(n_steps)
R = np.zeros(n_steps)
t = np.zeros(n_steps)

# Initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
t[0] = 0

# SEIR model differential equations
def SEIR_derivatives(S, E, I, R, beta, sigma, gamma):
    dS_dt = -beta * S * I
    dE_dt = beta * S * I - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return dS_dt, dE_dt, dI_dt, dR_dt

# Runge-Kutta 3rd Order (RK3) Method
for i in range(1, n_steps):
    t[i] = t[i-1] + dt
    k1_S, k1_E, k1_I, k1_R = SEIR_derivatives(S[i-1], E[i-1], I[i-1], R[i-1], beta, sigma, gamma)
    k2_S, k2_E, k2_I, k2_R = SEIR_derivatives(S[i-1] + 0.5 * dt * k1_S, E[i-1] + 0.5 * dt * k1_E, I[i-1] + 0.5 * dt * k1_I, R[i-1] + 0.5 * dt * k1_R, beta, sigma, gamma)
    k3_S, k3_E, k3_I, k3_R = SEIR_derivatives(S[i-1] - dt * k1_S + 2 * dt * k2_S, E[i-1] - dt * k1_E + 2 * dt * k2_E, I[i-1] - dt * k1_I + 2 * dt * k2_I, R[i-1] - dt * k1_R + 2 * dt * k2_R, beta, sigma, gamma)
    S[i] = S[i-1] + (dt / 6) * (k1_S + 4 * k2_S + k3_S)
    E[i] = E[i-1] + (dt / 6) * (k1_E + 4 * k2_E + k3_E)
    I[i] = I[i-1] + (dt / 6) * (k1_I + 4 * k2_I + k3_I)
    R[i] = R[i-1] + (dt / 6) * (k1_R + 4 * k2_R + k3_R)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.title('SEIR Model using RK3 Method')
plt.legend()
plt.grid()
plt.show()
