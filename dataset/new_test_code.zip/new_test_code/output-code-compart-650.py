import numpy as np

class SEIRHDModel:
    def __init__(self, S0, E0, I0, R0, H0, D0, beta, sigma, gamma, delta, alpha, dt):
        self.S = S0
        self.E = E0
        self.I = I0
        self.R = R0
        self.H = H0
        self.D = D0
        self.beta = beta
        self.sigma = sigma
        self.gamma = gamma
        self.delta = delta
        self.alpha = alpha
        self.dt = dt

    def derivatives(self, S, E, I, R, H, D):
        N = S + E + I + R + H + D
        dS = -self.beta * S * I / N
        dE = self.beta * S * I / N - self.sigma * E
        dI = self.sigma * E - (self.gamma + self.delta + self.alpha) * I
        dR = self.gamma * I
        dH = self.delta * I
        dD = self.alpha * I
        return dS, dE, dI, dR, dH, dD

    def rk4_step(self):
        dt = self.dt

        def rk4_step_single(S, E, I, R, H, D):
            k1 = np.array(self.derivatives(S, E, I, R, H, D)) * dt
            k2 = np.array(self.derivatives(S + k1[0] / 2, E + k1[1] / 2, I + k1[2] / 2, R + k1[3] / 2, H + k1[4] / 2, D + k1[5] / 2)) * dt
            k3 = np.array(self.derivatives(S + k2[0] / 2, E + k2[1] / 2, I + k2[2] / 2, R + k2[3] / 2, H + k2[4] / 2, D + k2[5] / 2)) * dt
            k4 = np.array(self.derivatives(S + k3[0], E + k3[1], I + k3[2], R + k3[3], H + k3[4], D + k3[5])) * dt
            dS, dE, dI, dR, dH, dD = (k1 + 2*k2 + 2*k3 + k4) / 6
            return S + dS, E + dE, I + dI, R + dR, H + dH, D + dD

        self.S, self.E, self.I, self.R, self.H, self.D = rk4_step_single(self.S, self.E, self.I, self.R, self.H, self.D)

    def simulate(self, days):
        results = {'S': [], 'E': [], 'I': [], 'R': [], 'H': [], 'D': []}
        for _ in range(days):
            results['S'].append(self.S)
            results['E'].append(self.E)
            results['I'].append(self.I)
            results['R'].append(self.R)
            results['H'].append(self.H)
            results['D'].append(self.D)
            self.rk4_step()
        return results

# Example usage:
# model = SEIRHDModel(S0=999, E0=1, I0=0, R0=0, H0=0, D0=0, beta=0.3, sigma=0.1, gamma=0.05, delta=0.01, alpha=0.005, dt=1)
# results = model.simulate(days=160)

