import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Transmission rate
sigma = 1/5.2  # Rate of progression from exposed to infectious
gamma = 1/12.9  # Recovery rate
N = 1000  # Total population
I0 = 1  # Initial number of infectious individuals
E0 = 0  # Initial number of exposed individuals
R0 = 0  # Initial number of recovered individuals
S0 = N - I0 - E0 - R0  # Initial number of susceptible individuals

t = 160  # Number of days to simulate
dt = 1  # Time step

# Initialize arrays
S = np.zeros(t)
E = np.zeros(t)
I = np.zeros(t)
R = np.zeros(t)

# Initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# Euler method
for i in range(t - 1):
    dS = -beta * S[i] * I[i] / N * dt
    dE = (beta * S[i] * I[i] / N - sigma * E[i]) * dt
    dI = (sigma * E[i] - gamma * I[i]) * dt
    dR = gamma * I[i] * dt
    S[i + 1] = S[i] + dS
    E[i + 1] = E[i] + dE
    I[i + 1] = I[i] + dI
    R[i + 1] = R[i] + dR

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(S, label='Susceptible')
plt.plot(E, label='Exposed')
plt.plot(I, label='Infectious')
plt.plot(R, label='Recovered')
plt.xlabel('Days')
plt.ylabel('Population')
plt.legend()
plt.title('SEIR Model using Euler Method')
plt.show()
