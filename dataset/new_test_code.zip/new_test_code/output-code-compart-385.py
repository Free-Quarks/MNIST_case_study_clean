import numpy as np
import matplotlib.pyplot as plt

# Define the SEIR model differential equations
def SEIR_model(y, beta, gamma, sigma, N):
    S, E, I, R = y
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt])

# Runge-Kutta 4th Order Method (RK4)
def RK4_step(f, y, t, dt, *args):
    k1 = dt * f(y, *args)
    k2 = dt * f(y + 0.5 * k1, *args)
    k3 = dt * f(y + 0.5 * k2, *args)
    k4 = dt * f(y + k3, *args)
    return y + (k1 + 2 * k2 + 2 * k3 + k4) / 6

# Simulation parameters
days = 160
dt = 1.0
N = 1000  # Total population
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
sigma = 0.1  # Rate of progression from exposed to infectious

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
y0 = np.array([S0, E0, I0, R0])

t = np.linspace(0, days, int(days/dt))

# Initialize result array
results = np.zeros((len(t), 4))
results[0] = y0

# Integrate the SEIR equations over the time grid
y = y0
for i in range(1, len(t)):
    y = RK4_step(SEIR_model, y, t[i], dt, beta, gamma, sigma, N)
    results[i] = y

# Plot the results
plt.figure(figsize=(10, 8))
plt.plot(t, results[:, 0], 'b', label='Susceptible')
plt.plot(t, results[:, 1], 'y', label='Exposed')
plt.plot(t, results[:, 2], 'r', label='Infectious')
plt.plot(t, results[:, 3], 'g', label='Recovered')
plt.xlabel('Days')
plt.ylabel('Number of Individuals')
plt.title('SEIR Model using RK4')
plt.legend()
plt.grid()
plt.show()
