# SEIR Model using Runge-Kutta 3rd Order (RK3)

import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.3  # Transmission rate
sigma = 1/5.2  # Rate at which exposed individuals become infectious (1/Incubation period)
gamma = 1/2.9  # Recovery rate (1/Infectious period)

# Initial number of individuals in each compartment
S0 = 999
E0 = 1
I0 = 0
R0 = 0

# Total population
N = S0 + E0 + I0 + R0

# Time parameters
t_start = 0
t_end = 160
dt = 0.1

# Function to calculate derivatives
def derivatives(S, E, I, R, N, beta, sigma, gamma):
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I
    dRdt = gamma * I
    return dSdt, dEdt, dIdt, dRdt

# RK3 update function
def rk3_step(S, E, I, R, N, beta, sigma, gamma, dt):
    k1S, k1E, k1I, k1R = derivatives(S, E, I, R, N, beta, sigma, gamma)
    k2S, k2E, k2I, k2R = derivatives(S + dt/2 * k1S, E + dt/2 * k1E, I + dt/2 * k1I, R + dt/2 * k1R, N, beta, sigma, gamma)
    k3S, k3E, k3I, k3R = derivatives(S - dt * k1S + 2 * dt * k2S, E - dt * k1E + 2 * dt * k2E, I - dt * k1I + 2 * dt * k2I, R - dt * k1R + 2 * dt * k2R, N, beta, sigma, gamma)
    S_new = S + dt/6 * (k1S + 4 * k2S + k3S)
    E_new = E + dt/6 * (k1E + 4 * k2E + k3E)
    I_new = I + dt/6 * (k1I + 4 * k2I + k3I)
    R_new = R + dt/6 * (k1R + 4 * k2R + k3R)
    return S_new, E_new, I_new, R_new

# Time array
t = np.arange(t_start, t_end, dt)

# Arrays to store compartment values
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

# Initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# Simulation
for i in range(1, len(t)):
    S[i], E[i], I[i], R[i] = rk3_step(S[i-1], E[i-1], I[i-1], R[i-1], N, beta, sigma, gamma, dt)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.title('SEIR Model Simulation using RK3')
plt.grid()
plt.show()
