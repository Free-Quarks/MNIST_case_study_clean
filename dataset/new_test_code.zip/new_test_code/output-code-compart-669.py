# This script simulates the spread of COVID-19 using a SIDARTHE model and the Runge-Kutta 3rd order (RK3) method.

import numpy as np
import matplotlib.pyplot as plt

# Define the SIDARTHE model parameters
parameters = {
    'alpha': 0.57,   # Rate of transmission from susceptible to infected (undetected)
    'beta': 0.011,   # Rate of transmission from susceptible to infected (detected)
    'gamma': 0.456,  # Rate of transmission from susceptible to diagnosed
    'delta': 0.011,  # Rate of transmission from susceptible to ailing
    'epsilon': 0.171,# Rate of transmission from susceptible to recognized
    'zeta': 0.011,   # Rate of transmission from susceptible to threatened
    'eta': 0.456,    # Rate of transmission from susceptible to healed
    'theta': 0.171,  # Rate of transmission from susceptible to extinct
    'lambda': 0.034, # Rate of detection of infected
    'mu': 0.017,     # Rate of detection of diagnosed
    'nu': 0.017,     # Rate of detection of ailing
    'tau': 0.017,    # Rate of detection of recognized
    'kappa': 0.017,  # Rate of detection of threatened
    'xi': 0.017,     # Rate of detection of healed
    'rho': 0.017,    # Rate of detection of extinct
}

# Initial population values
population = {
    'S': 0.99,  # Susceptible
    'I': 0.01,  # Infected (undetected)
    'D': 0.0,   # Infected (detected)
    'A': 0.0,   # Diagnosed
    'R': 0.0,   # Ailing
    'T': 0.0,   # Recognized
    'H': 0.0,   # Healed
    'E': 0.0    # Extinct
}

# Define the system of differential equations for the SIDARTHE model

def sidarthe_model(y, t, params):
    S, I, D, A, R, T, H, E = y
    alpha = params['alpha']
    beta = params['beta']
    gamma = params['gamma']
    delta = params['delta']
    epsilon = params['epsilon']
    zeta = params['zeta']
    eta = params['eta']
    theta = params['theta']
    lambda_ = params['lambda']
    mu = params['mu']
    nu = params['nu']
    tau = params['tau']
    kappa = params['kappa']
    xi = params['xi']
    rho = params['rho']

    dS_dt = -(alpha * I + beta * D + gamma * A + delta * R + epsilon * T + zeta * H + eta * E) * S
    dI_dt = (alpha * I + beta * D + gamma * A + delta * R + epsilon * T + zeta * H + eta * E) * S - (lambda_ + rho) * I
    dD_dt = lambda_ * I - (mu + rho) * D
    dA_dt = mu * D - (nu + rho) * A
    dR_dt = nu * A - (tau + rho) * R
    dT_dt = tau * R - (kappa + rho) * T
    dH_dt = kappa * T - (xi + rho) * H
    dE_dt = xi * H

    return [dS_dt, dI_dt, dD_dt, dA_dt, dR_dt, dT_dt, dH_dt, dE_dt]

# Runge-Kutta 3rd order (RK3) method for solving ODEs

def rk3_step(f, y, t, dt, params):
    k1 = f(y, t, params)
    k2 = f(y + 0.5 * dt * np.array(k1), t + 0.5 * dt, params)
    k3 = f(y + dt * (-k1 + 2 * np.array(k2)), t + dt, params)
    y_next = y + (dt / 6) * (k1 + 4 * k2 + k3)
    return y_next

# Time parameters
t_start = 0.0
t_end = 160.0
dt = 0.1
time_points = np.arange(t_start, t_end, dt)

# Initialize arrays to store the results
y = np.array([population['S'], population['I'], population['D'], population['A'], population['R'], population['T'], population['H'], population['E']])
results = np.empty((len(time_points), len(y)))
results[0] = y

# Time-stepping loop using RK3
for i in range(1, len(time_points)):
    y = rk3_step(sidarthe_model, y, time_points[i-1], dt, parameters)
    results[i] = y

# Plot the results
plt.figure(figsize=(12, 8))
plt.plot(time_points, results[:, 0], label='Susceptible (S)')
plt.plot(time_points, results[:, 1], label='Infected (undetected) (I)')
plt.plot(time_points, results[:, 2], label='Infected (detected) (D)')
plt.plot(time_points, results[:, 3], label='Diagnosed (A)')
plt.plot(time_points, results[:, 4], label='Ailing (R)')
plt.plot(time_points, results[:, 5], label='Recognized (T)')
plt.plot(time_points, results[:, 6], label='Healed (H)')
plt.plot(time_points, results[:, 7], label='Extinct (E)')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of Population')
plt.legend()
plt.title('COVID-19 Spread Simulation using SIDARTHE Model and RK3 Method')
plt.grid()
plt.show()

