import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model derivatives
def SEIRD_derivatives(y, beta, sigma, gamma, delta, N):
    S, E, I, R, D = y
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I - delta * I
    dR_dt = gamma * I
    dD_dt = delta * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt, dD_dt])

# Runge-Kutta 3rd order method
class RK3:
    def __init__(self, f):
        self.f = f

    def step(self, y, t, dt, *args):
        k1 = dt * self.f(y, *args)
        k2 = dt * self.f(y + 0.5 * k1, *args)
        k3 = dt * self.f(y - k1 + 2 * k2, *args)
        return y + (k1 + 4 * k2 + k3) / 6

# Simulation parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Incubation rate
gamma = 1/2.9  # Recovery rate
delta = 0.01  # Death rate
N = 1_000_000  # Population size

# Initial conditions
I0 = 1
E0 = 0
R0 = 0
D0 = 0
S0 = N - I0 - E0 - R0 - D0

# Time parameters
t0 = 0  # initial time
tf = 160  # final time
dt = 0.1  # time step

# Time array
t = np.arange(t0, tf, dt)

# Initialize state variable array
y = np.zeros((len(t), 5))
y[0] = [S0, E0, I0, R0, D0]

# Initialize RK3 solver
rk3_solver = RK3(SEIRD_derivatives)

# Time integration
for i in range(1, len(t)):
    y[i] = rk3_solver.step(y[i-1], t[i-1], dt, beta, sigma, gamma, delta, N)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, y[:, 0], label='Susceptible')
plt.plot(t, y[:, 1], label='Exposed')
plt.plot(t, y[:, 2], label='Infected')
plt.plot(t, y[:, 3], label='Recovered')
plt.plot(t, y[:, 4], label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.title('SEIRD Model Simulation')
plt.legend()
plt.grid()
plt.show()
