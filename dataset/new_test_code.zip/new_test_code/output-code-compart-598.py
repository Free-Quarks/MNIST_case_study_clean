# SEIRHD model using RK2 (Runge-Kutta 2nd Order Method)

import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRHD model
def SEIRHD_model(y, beta, sigma, gamma_I, gamma_H, delta, mu_I, mu_H):
    S, E, I, H, R, D = y
    N = S + E + I + H + R + D
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma_I * I - delta * I - mu_I * I
    dH_dt = delta * I - gamma_H * H - mu_H * H
    dR_dt = gamma_I * I + gamma_H * H
    dD_dt = mu_I * I + mu_H * H
    return np.array([dS_dt, dE_dt, dI_dt, dH_dt, dR_dt, dD_dt])

# Runge-Kutta 2nd Order Method (RK2)
def RK2_step(f, y, t, dt, *args):
    k1 = dt * f(y, *args)
    k2 = dt * f(y + 0.5 * k1, *args)
    return y + k2

# Parameters
beta = 0.3     # Transmission rate
sigma = 0.1    # Rate of progression from exposed to infected
gamma_I = 0.05 # Recovery rate of infected individuals
gamma_H = 0.01 # Recovery rate of hospitalized individuals
delta = 0.02   # Rate of hospitalization
mu_I = 0.01    # Mortality rate of infected individuals
mu_H = 0.02    # Mortality rate of hospitalized individuals

# Initial conditions
S0 = 9999  # Susceptible individuals
E0 = 1    # Exposed individuals
I0 = 0    # Infected individuals
H0 = 0    # Hospitalized individuals
R0 = 0    # Recovered individuals
D0 = 0    # Deceased individuals
y0 = np.array([S0, E0, I0, H0, R0, D0])

# Time parameters
t0 = 0
tf = 160
dt = 1

t = np.arange(t0, tf, dt)
n_steps = len(t)

# Array to store the solutions
solution = np.zeros((n_steps, len(y0)))
solution[0] = y0

# Time-stepping loop
for i in range(1, n_steps):
    solution[i] = RK2_step(SEIRHD_model, solution[i-1], t[i-1], dt, beta, sigma, gamma_I, gamma_H, delta, mu_I, mu_H)

# Plotting the results
plt.figure(figsize=(12, 8))
labels = ['Susceptible', 'Exposed', 'Infected', 'Hospitalized', 'Recovered', 'Deceased']
for i in range(len(labels)):
    plt.plot(t, solution[:, i], label=labels[i])
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.title('SEIRHD Model Simulation')
plt.legend()
plt.grid()
plt.show()
