import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Function to model the SEIRHD dynamics
def seirhd_model(y, t, N, beta, sigma, gamma, delta, alpha, rho):
    S, E, I, R, H, D = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - delta * I
    dRdt = gamma * I
    dHdt = delta * I - alpha * H
    dDdt = alpha * H
    return dSdt, dEdt, dIdt, dRdt, dHdt, dDdt

# Initial conditions
N = 1000000  # Total population
I0 = 1       # Initial number of infected individuals
E0 = 0       # Initial number of exposed individuals
R0 = 0       # Initial number of recovered individuals
H0 = 0       # Initial number of hospitalized individuals
D0 = 0       # Initial number of dead individuals
S0 = N - I0 - E0 - R0 - H0 - D0  # Initial number of susceptible individuals

# Initial condition vector
y0 = S0, E0, I0, R0, H0, D0

# Time grid (in days)
t = np.linspace(0, 160, 160)

# Transmission parameters
beta = 0.3  # Transmission rate
sigma = 1/5.2  # Rate of progression from exposed to infected
gamma = 1/2.9  # Recovery rate for infected individuals
delta = 0.1  # Hospitalization rate for infected individuals
alpha = 0.02  # Death rate for hospitalized individuals
rho = 0.05  # Recovery rate for hospitalized individuals

# Integrate the SEIRHD equations over the time grid, t
ret = odeint(seirhd_model, y0, t, args=(N, beta, sigma, gamma, delta, alpha, rho))
S, E, I, R, H, D = ret.T

# Plot the data
plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.plot(t, H, 'c', alpha=0.7, linewidth=2, label='Hospitalized')
plt.plot(t, D, 'k', alpha=0.7, linewidth=2, label='Dead')
plt.xlabel('Days')
plt.ylabel('Number of Individuals')
plt.title('SEIRHD Model')
plt.legend()
plt.grid(True)
plt.show()
