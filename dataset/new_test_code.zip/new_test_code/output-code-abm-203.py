# Agent-Based Model to Simulate COVID-19 with Age Stratification

import numpy as np
import random

# Define parameters
population_size = 1000
initial_infected = 10
age_groups = {'0-19': 0.24, '20-39': 0.34, '40-59': 0.27, '60+': 0.15}
infection_probability = 0.03
recovery_probability = 0.01
mortality_probability = {'0-19': 0.0001, '20-39': 0.0003, '40-59': 0.006, '60+': 0.06}
days = 160

# Initialize population
population = []
for age_group, proportion in age_groups.items():
    num_individuals = int(proportion * population_size)
    for _ in range(num_individuals):
        population.append({'age_group': age_group, 'infected': False, 'recovered': False, 'dead': False})

# Infect initial individuals
for _ in range(initial_infected):
    individual = random.choice(population)
    individual['infected'] = True

# Simulation
for day in range(days):
    new_infections = []
    new_recoveries = []
    new_deaths = []
    for individual in population:
        if individual['infected'] and not individual['recovered'] and not individual['dead']:
            if random.random() < recovery_probability:
                new_recoveries.append(individual)
            elif random.random() < mortality_probability[individual['age_group']]:
                new_deaths.append(individual)
            else:
                for _ in range(np.random.poisson(5)):
                    contact = random.choice(population)
                    if not contact['infected'] and not contact['recovered'] and not contact['dead'] and random.random() < infection_probability:
                        new_infections.append(contact)

    for individual in new_infections:
        individual['infected'] = True
    for individual in new_recoveries:
        individual['infected'] = False
        individual['recovered'] = True
    for individual in new_deaths:
        individual['infected'] = False
        individual['dead'] = True

# Results
num_infected = sum(1 for ind in population if ind['infected'])
num_recovered = sum(1 for ind in population if ind['recovered'])
num_dead = sum(1 for ind in population if ind['dead'])
num_susceptible = population_size - num_infected - num_recovered - num_dead

print(f"Susceptible: {num_susceptible}")
print(f"Infected: {num_infected}")
print(f"Recovered: {num_recovered}")
print(f"Dead: {num_dead}")
