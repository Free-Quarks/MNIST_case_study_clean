import random

class Person:
    def __init__(self, age, health_status='susceptible'):
        self.age = age
        self.health_status = health_status
        self.days_infected = 0

    def progress_disease(self):
        if self.health_status == 'infected':
            self.days_infected += 1
            if self.days_infected > 14:
                self.health_status = 'recovered'

class Population:
    def __init__(self, size):
        self.people = [Person(random.choice(['child', 'adult', 'senior'])) for _ in range(size)]

    def infect_random_person(self):
        susceptible_people = [p for p in self.people if p.health_status == 'susceptible']
        if susceptible_people:
            random.choice(susceptible_people).health_status = 'infected'

    def progress_disease(self):
        for person in self.people:
            person.progress_disease()

    def spread_infection(self, transmission_rate):
        for person in self.people:
            if person.health_status == 'infected':
                for other_person in self.people:
                    if other_person.health_status == 'susceptible' and random.random() < transmission_rate:
                        other_person.health_status = 'infected'

    def summary(self):
        summary = {'susceptible': 0, 'infected': 0, 'recovered': 0}
        for person in self.people:
            summary[person.health_status] += 1
        return summary

# Simulation parameters
population_size = 1000
transmission_rate = 0.1
initial_infected = 10
num_days = 30

# Initialize the population
population = Population(population_size)
for _ in range(initial_infected):
    population.infect_random_person()

# Run the simulation
for day in range(num_days):
    population.spread_infection(transmission_rate)
    population.progress_disease()
    print(f'Day {day + 1}:', population.summary())

