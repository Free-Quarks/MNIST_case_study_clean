import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3    # infection rate
sigma = 0.1   # incubation rate (1/incubation period)
gamma = 0.05  # recovery rate (1/duration of infectiousness)

# Initial conditions
S0 = 0.99  # initial proportion of susceptible individuals
E0 = 0.01  # initial proportion of exposed individuals
I0 = 0.0   # initial proportion of infectious individuals
R0 = 0.0   # initial proportion of recovered individuals

# Time parameters
T = 160    # total time in days
dt = 0.1   # time step (days)
t = np.arange(0, T, dt)

# Initialize arrays
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

# Set initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# Euler's method to solve the system of differential equations
for i in range(1, len(t)):
    dS = -beta * S[i-1] * I[i-1] * dt
    dE = (beta * S[i-1] * I[i-1] - sigma * E[i-1]) * dt
    dI = (sigma * E[i-1] - gamma * I[i-1]) * dt
    dR = gamma * I[i-1] * dt
    S[i] = S[i-1] + dS
    E[i] = E[i-1] + dE
    I[i] = I[i-1] + dI
    R[i] = R[i-1] + dR

# Plot the results
plt.figure(figsize=(10,6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIR Model Simulation')
plt.grid(True)
plt.show()
