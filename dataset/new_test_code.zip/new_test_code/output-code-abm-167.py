import networkx as nx
import numpy as np
import random

# Parameters
population_size = 1000
initial_infected = 10
age_groups = {'0-19': 0.2, '20-39': 0.3, '40-59': 0.3, '60+': 0.2}
transmission_probability = 0.3
recovery_rate = 0.1
simulation_steps = 100

# Create a random network
G = nx.erdos_renyi_graph(population_size, 0.1)

# Assign ages to nodes
age_distribution = []
for age_group, proportion in age_groups.items():
    count = int(proportion * population_size)
    age_distribution.extend([age_group] * count)

random.shuffle(age_distribution)

for i, node in enumerate(G.nodes()):
    G.nodes[node]['age'] = age_distribution[i]
    G.nodes[node]['state'] = 'S'  # Susceptible

# Infect initial nodes
infected_nodes = random.sample(G.nodes(), initial_infected)
for node in infected_nodes:
    G.nodes[node]['state'] = 'I'  # Infected

# Simulation
for step in range(simulation_steps):
    new_infections = []
    for node in G.nodes():
        if G.nodes[node]['state'] == 'I':
            neighbors = list(G.neighbors(node))
            for neighbor in neighbors:
                if G.nodes[neighbor]['state'] == 'S':
                    if random.random() < transmission_probability:
                        new_infections.append(neighbor)
    for node in new_infections:
        G.nodes[node]['state'] = 'I'

    # Recover infected individuals
    for node in G.nodes():
        if G.nodes[node]['state'] == 'I':
            if random.random() < recovery_rate:
                G.nodes[node]['state'] = 'R'  # Recovered

# Output the final states
final_states = {node: G.nodes[node]['state'] for node in G.nodes()}
print(final_states)
