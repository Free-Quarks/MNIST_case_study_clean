import numpy as np
import matplotlib.pyplot as plt

# Define the SIR model differential equations
def sir_model(y, beta, gamma):
    S, I, R = y
    dS_dt = -beta * S * I
    dI_dt = beta * S * I - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dI_dt, dR_dt])

# Runge-Kutta 4th Order Method
def rk4_step(f, y, h, beta, gamma):
    k1 = h * f(y, beta, gamma)
    k2 = h * f(y + 0.5 * k1, beta, gamma)
    k3 = h * f(y + 0.5 * k2, beta, gamma)
    k4 = h * f(y + k3, beta, gamma)
    return y + (k1 + 2 * k2 + 2 * k3 + k4) / 6

# Initial conditions
S0 = 0.99  # initial susceptible population
I0 = 0.01  # initial infected population
R0 = 0.0   # initial recovered population

# Parameters
beta = 0.3  # infection rate
gamma = 0.1 # recovery rate

# Simulation settings
T = 160  # total time
dt = 1.0  # time step

# Initialize arrays to store results
S = [S0]
I = [I0]
R = [R0]
t = [0]

# Run the simulation
while t[-1] < T:
    y = np.array([S[-1], I[-1], R[-1]])
    y_next = rk4_step(sir_model, y, dt, beta, gamma)
    S.append(y_next[0])
    I.append(y_next[1])
    R.append(y_next[2])
    t.append(t[-1] + dt)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.title('SIR Model Simulation using RK4')
plt.legend()
plt.grid()
plt.show()

