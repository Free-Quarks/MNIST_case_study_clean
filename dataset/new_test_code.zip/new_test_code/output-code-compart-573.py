# SEIRHD Model using Runge-Kutta 2 (RK2) Method

import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3   # Infection rate
sigma = 0.1  # Rate of progression from exposed to infectious
gamma = 0.05 # Recovery rate
mu = 0.01    # Mortality rate
N = 1000     # Total population
I0 = 1       # Initial number of infectious individuals
E0 = 0       # Initial number of exposed individuals
R0 = 0       # Initial number of recovered individuals
H0 = 0       # Initial number of hospitalized individuals
D0 = 0       # Initial number of dead individuals
S0 = N - I0 - E0 - R0 - H0 - D0  # Initial number of susceptible individuals

# Time parameters
t_max = 160  # Maximum time
dt = 0.1    # Time step size

# SEIRHD model differential equations
def deriv(t, S, E, I, R, H, D, beta, sigma, gamma, mu, N):
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - mu * I
    dRdt = gamma * I
    dHdt = gamma * I - mu * I
    dDdt = mu * I
    return dSdt, dEdt, dIdt, dRdt, dHdt, dDdt

# Runge-Kutta 2 (RK2) Method
S, E, I, R, H, D = S0, E0, I0, R0, H0, D0
S_arr, E_arr, I_arr, R_arr, H_arr, D_arr = [S0], [E0], [I0], [R0], [H0], [D0]
t_arr = [0]

t = 0
while t < t_max:
    k1_S, k1_E, k1_I, k1_R, k1_H, k1_D = deriv(t, S, E, I, R, H, D, beta, sigma, gamma, mu, N)
    k2_S, k2_E, k2_I, k2_R, k2_H, k2_D = deriv(t + 0.5 * dt, S + 0.5 * k1_S * dt, E + 0.5 * k1_E * dt, I + 0.5 * k1_I * dt, R + 0.5 * k1_R * dt, H + 0.5 * k1_H * dt, D + 0.5 * k1_D * dt, beta, sigma, gamma, mu, N)

    S += k2_S * dt
    E += k2_E * dt
    I += k2_I * dt
    R += k2_R * dt
    H += k2_H * dt
    D += k2_D * dt

    t += dt

    S_arr.append(S)
    E_arr.append(E)
    I_arr.append(I)
    R_arr.append(R)
    H_arr.append(H)
    D_arr.append(D)
    t_arr.append(t)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t_arr, S_arr, label='Susceptible')
plt.plot(t_arr, E_arr, label='Exposed')
plt.plot(t_arr, I_arr, label='Infectious')
plt.plot(t_arr, R_arr, label='Recovered')
plt.plot(t_arr, H_arr, label='Hospitalized')
plt.plot(t_arr, D_arr, label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.title('SEIRHD Model Simulation')
plt.grid(True)
plt.show()
