import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Transmission rate
sigma = 1/5.2  # Rate of progression from exposed to infectious
gamma = 1/14  # Recovery rate
N = 1000  # Total population
I0 = 1  # Initial number of infectious individuals
E0 = 0  # Initial number of exposed individuals
R0 = 0  # Initial number of recovered individuals
S0 = N - I0 - E0 - R0  # Initial number of susceptible individuals

# Time parameters
t_start = 0
t_end = 160
dt = 1  # Time step

# Initialize arrays
S = [S0]
E = [E0]
I = [I0]
R = [R0]
t = [t_start]

# Runge-Kutta 3rd order (RK3) integration
while t[-1] < t_end:
    S_last, E_last, I_last, R_last = S[-1], E[-1], I[-1], R[-1]
    t_last = t[-1]

    k1_S = -beta * S_last * I_last / N
    k1_E = beta * S_last * I_last / N - sigma * E_last
    k1_I = sigma * E_last - gamma * I_last
    k1_R = gamma * I_last

    S1 = S_last + k1_S * dt
    E1 = E_last + k1_E * dt
    I1 = I_last + k1_I * dt
    R1 = R_last + k1_R * dt

    k2_S = -beta * S1 * I1 / N
    k2_E = beta * S1 * I1 / N - sigma * E1
    k2_I = sigma * E1 - gamma * I1
    k2_R = gamma * I1

    S2 = S_last + k2_S * dt
    E2 = E_last + k2_E * dt
    I2 = I_last + k2_I * dt
    R2 = R_last + k2_R * dt

    k3_S = -beta * S2 * I2 / N
    k3_E = beta * S2 * I2 / N - sigma * E2
    k3_I = sigma * E2 - gamma * I2
    k3_R = gamma * I2

    S_next = S_last + (k1_S + 4 * k2_S + k3_S) * dt / 6
    E_next = E_last + (k1_E + 4 * k2_E + k3_E) * dt / 6
    I_next = I_last + (k1_I + 4 * k2_I + k3_I) * dt / 6
    R_next = R_last + (k1_R + 4 * k2_R + k3_R) * dt / 6

    S.append(S_next)
    E.append(E_next)
    I.append(I_next)
    R.append(R_next)
    t.append(t_last + dt)

# Plot results
plt.figure(figsize=(10,6))
plt.plot(t, S, 'b', label='Susceptible')
plt.plot(t, E, 'y', label='Exposed')
plt.plot(t, I, 'r', label='Infectious')
plt.plot(t, R, 'g', label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.title('SEIR Model')
plt.legend()
plt.grid()
plt.show()
