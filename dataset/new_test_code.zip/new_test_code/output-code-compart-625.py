import numpy as np
from scipy.integrate import solve_ivp

# SEIRHD model parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Incubation rate
gamma = 1/2.9  # Recovery rate
mu = 0.01  # Mortality rate

# Initial conditions
S0 = 990
E0 = 10
I0 = 0
R0 = 0
H0 = 0
D0 = 0

# Time points
t = np.linspace(0, 160, 160)

# SEIRHD model differential equations
def deriv(t, y, beta, sigma, gamma, mu):
    S, E, I, R, H, D = y
    dSdt = -beta * S * I / (S + E + I + R + H + D)
    dEdt = beta * S * I / (S + E + I + R + H + D) - sigma * E
    dIdt = sigma * E - gamma * I - mu * I
    dRdt = gamma * I
    dHdt = mu * I
    dDdt = 0  # Incorrectly setting D death rate to 0
    return dSdt, dEdt, dIdt, dRdt, dHdt, dDdt

# Initial conditions vector
y0 = S0, E0, I0, R0, H0, D0

# Integrate the SEIRHD equations over the time grid, t.
sol = solve_ivp(deriv, [0, 160], y0, args=(beta, sigma, gamma, mu), t_eval=t, method='RK45')

# Extract the solution
S, E, I, R, H, D = sol.y

# Print the results
print('S:', S)
print('E:', E)
print('I:', I)
print('R:', R)
print('H:', H)
print('D:', D)
