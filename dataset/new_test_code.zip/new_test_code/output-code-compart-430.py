import numpy as np
import matplotlib.pyplot as plt

# Define the SIR model
class SIRModel:
    def __init__(self, beta, gamma, S0, I0, R0):
        self.beta = beta  # infection rate
        self.gamma = gamma  # recovery rate
        self.S = S0  # initial susceptible population
        self.I = I0  # initial infected population
        self.R = R0  # initial recovered population
        self.history = {'S': [S0], 'I': [I0], 'R': [R0]}

    def deriv(self, S, I, R):
        dS = -self.beta * S * I
        dI = self.beta * S * I - self.gamma * I
        dR = self.gamma * I
        return dS, dI, dR

    def step(self, dt):
        S, I, R = self.S, self.I, self.R
        k1S, k1I, k1R = self.deriv(S, I, R)
        k2S, k2I, k2R = self.deriv(S + 0.5 * dt * k1S, I + 0.5 * dt * k1I, R + 0.5 * dt * k1R)
        k3S, k3I, k3R = self.deriv(S + 0.5 * dt * k2S, I + 0.5 * dt * k2I, R + 0.5 * dt * k2R)
        k4S, k4I, k4R = self.deriv(S + dt * k3S, I + dt * k3I, R + dt * k3R)
        self.S += (dt / 6.0) * (k1S + 2 * k2S + 2 * k3S + k4S)
        self.I += (dt / 6.0) * (k1I + 2 * k2I + 2 * k3I + k4I)
        self.R += (dt / 6.0) * (k1R + 2 * k2R + 2 * k3R + k4R)
        self.history['S'].append(self.S)
        self.history['I'].append(self.I)
        self.history['R'].append(self.R)

    def simulate(self, days, dt=0.1):
        steps = int(days / dt)
        for _ in range(steps):
            self.step(dt)
        return self.history

# Parameters
beta = 0.3  # infection rate
gamma = 0.1  # recovery rate
S0 = 0.99  # initial susceptible
I0 = 0.01  # initial infected
R0 = 0.0  # initial recovered

# Simulation
sir_model = SIRModel(beta, gamma, S0, I0, R0)
result = sir_model.simulate(160)

# Plotting
plt.plot(result['S'], label='Susceptible')
plt.plot(result['I'], label='Infected')
plt.plot(result['R'], label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.show()
