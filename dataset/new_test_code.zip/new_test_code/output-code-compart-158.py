# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Define the SEIR model differential equations
def SEIR_model(y, beta, sigma, gamma, N):
    S, E, I, R = y
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt])

# Define the Runge-Kutta 2nd Order (RK2) method
def RK2_step(f, y, t, dt, *args):
    k1 = dt * f(y, *args)
    k2 = dt * f(y + 0.5 * k1, *args)
    return y + k2

# Simulation parameters
N = 1000  # Total population
beta = 0.3  # Infection rate
sigma = 1/5.2  # Incubation rate
gamma = 1/2.9  # Recovery rate
initial_conditions = [999, 1, 0, 0]  # Initial number of S, E, I, R
T = 160  # Total time in days
dt = 1  # Time step

# Time array
t = np.arange(0, T, dt)

# Initialize arrays to store the results
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

# Set initial conditions
S[0], E[0], I[0], R[0] = initial_conditions

# Run the simulation using RK2
y = np.array(initial_conditions)
for i in range(1, len(t)):
    y = RK2_step(SEIR_model, y, t[i-1], dt, beta, sigma, gamma, N)
    S[i], E[i], I[i], R[i] = y

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.title('SEIR Model Simulation Using RK2')
plt.legend()
plt.grid()
plt.show()
