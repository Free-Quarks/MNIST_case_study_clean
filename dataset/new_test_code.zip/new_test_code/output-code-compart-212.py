import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SEIRD model

def seird_model(y, t, beta, gamma, delta, alpha):
    S, E, I, R, D = y
    N = S + E + I + R + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - delta * E
    dIdt = delta * E - gamma * I - alpha * I
    dRdt = gamma * I
    dDdt = alpha * I
    return [dSdt, dEdt, dIdt, dRdt, dDdt]

# Initial number of individuals in each compartment
S0 = 999
E0 = 1
I0 = 0
R0 = 0
D0 = 0

# Total population, N.
N = S0 + E0 + I0 + R0 + D0

# Initial conditions vector
y0 = [S0, E0, I0, R0, D0]

# Contact rate, beta, mean recovery rate, gamma, incubation rate, delta, and mortality rate, alpha
beta = 0.3
gamma = 1./14
delta = 1./5.2
alpha = 1./100

# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# Integrate the SEIRD equations over the time grid, t.
ret = odeint(seird_model, y0, t, args=(beta, gamma, delta, alpha))
S, E, I, R, D = ret.T

# Plot the data on three separate curves for S(t), E(t), I(t), R(t), and D(t)
fig = plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linestyle='dashed', label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linestyle='dotted', label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linestyle='solid', label='Infected')
plt.plot(t, R, 'g', alpha=0.7, linestyle='dashdot', label='Recovered')
plt.plot(t, D, 'k', alpha=0.7, linestyle='dotted', label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Number (1000s)')
plt.legend()
plt.title('SEIRD Model Simulation')
plt.grid(True)
plt.show()
