# Incorrect SIDARTHE Model using RK2

import numpy as np
import matplotlib.pyplot as plt

# Define parameters
alpha = 0.5
beta = 0.3
gamma = 0.1
delta = 0.1
epsilon = 0.1
zeta = 0.1
eta = 0.1
theta = 0.1
lambda_ = 0.1
mu = 0.1
nu = 0.1
xi = 0.1
rho = 0.1
sigma = 0.1
tau = 0.1

# Time step
dt = 0.1

# Initial conditions
S0 = 0.99
I0 = 0.01
D0 = 0.0
A0 = 0.0
R0 = 0.0
T0 = 0.0
H0 = 0.0
E0 = 0.0

# Time array
T = 100

# Initialize arrays
S = np.zeros(T)
I = np.zeros(T)
D = np.zeros(T)
A = np.zeros(T)
R = np.zeros(T)
T = np.zeros(T)
H = np.zeros(T)
E = np.zeros(T)

# Set initial values
S[0] = S0
I[0] = I0
D[0] = D0
A[0] = A0
R[0] = R0
T[0] = T0
H[0] = H0
E[0] = E0

# Function to compute derivatives
def derivatives(S, I, D, A, R, T, H, E):
    dSdt = -alpha * S * I - beta * S * D - gamma * S * A
    dIdt = alpha * S * I + beta * S * D + gamma * S * A - delta * I - epsilon * I - eta * I
    dDdt = delta * I - zeta * D - theta * D
    dAdt = epsilon * I - lambda_ * A - mu * A
    dRdt = zeta * D + lambda_ * A + nu * T + xi * H
    dTdt = theta * D - nu * T - sigma * T
    dHdt = mu * A - xi * H - rho * H
    dEdt = sigma * T + rho * H
    return dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt

# Runge-Kutta 2nd order method (RK2)
for t in range(1, len(S)):
    k1_S, k1_I, k1_D, k1_A, k1_R, k1_T, k1_H, k1_E = derivatives(S[t-1], I[t-1], D[t-1], A[t-1], R[t-1], T[t-1], H[t-1], E[t-1])
    k2_S, k2_I, k2_D, k2_A, k2_R, k2_T, k2_H, k2_E = derivatives(S[t-1] + dt * k1_S, I[t-1] + dt * k1_I, D[t-1] + dt * k1_D, A[t-1] + dt * k1_A, R[t-1] + dt * k1_R, T[t-1] + dt * k1_T, H[t-1] + dt * k1_H, E[t-1] + dt * k1_E)
    S[t] = S[t-1] + (dt / 2) * (k1_S + k2_S)
    I[t] = I[t-1] + (dt / 2) * (k1_I + k2_I)
    D[t] = D[t-1] + (dt / 2) * (k1_D + k2_D)
    A[t] = A[t-1] + (dt / 2) * (k1_A + k2_A)
    R[t] = R[t-1] + (dt / 2) * (k1_R + k2_R)
    T[t] = T[t-1] + (dt / 2) * (k1_T + k2_T)
    H[t] = H[t-1] + (dt / 2) * (k1_H + k2_H)
    E[t] = E[t-1] + (dt / 2) * (k1_E + k2_E)

# Plot results
plt.plot(S, label='Susceptible')
plt.plot(I, label='Infected')
plt.plot(D, label='Diagnosed')
plt.plot(A, label='Ailing')
plt.plot(R, label='Recognized')
plt.plot(T, label='Threatened')
plt.plot(H, label='Healed')
plt.plot(E, label='Extinct')
plt.legend()
plt.xlabel('Time')
plt.ylabel('Population Fraction')
plt.title('Incorrect SIDARTHE Model using RK2')
plt.show()

