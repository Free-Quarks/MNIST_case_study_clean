import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SIDARTHE model
# S: Susceptible
# I: Infected (asymptomatic, undetected)
# D: Diagnosed (infected, detected)
# A: Ailing (symptomatic, undetected)
# R: Recognized (symptomatic, detected)
# T: Threatened (with life-threatening symptoms, in ICU)
# H: Healed (recovered)
# E: Extinct (dead)

def deriv(y, t, alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda, kappa, xi, rho, sigma):
    S, I, D, A, R, T, H, E = y
    dSdt = -alpha*S*I - beta*S*D - gamma*S*A - delta*S*R
    dIdt = alpha*S*I + beta*S*D + gamma*S*A + delta*S*R - epsilon*I - theta*I
    dDdt = epsilon*I - zeta*D - eta*D
    dAdt = theta*I - mu*A - nu*A
    dRdt = zeta*D + mu*A - tau*R - lambda*R
    dTdt = nu*A + tau*R - kappa*T - xi*T
    dHdt = lambda*R + kappa*T
    dEdt = xi*T + eta*D + rho*R + sigma*A
    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Initial number of each compartment
S0 = 0.99
I0 = 0.01
D0 = 0.0
A0 = 0.0
R0 = 0.0
T0 = 0.0
H0 = 0.0
E0 = 0.0

# Total population, N.
N = S0 + I0 + D0 + A0 + R0 + T0 + H0 + E0

# Initial conditions vector
y0 = [S0, I0, D0, A0, R0, T0, H0, E0]

# Contact rates
alpha = 0.3
beta = 0.1
gamma = 0.05
delta = 0.05
epsilon = 0.1
theta = 0.1
zeta = 0.1
eta = 0.02
mu = 0.05
nu = 0.05
tau = 0.1
lambda = 0.1
kappa = 0.05
xi = 0.02
rho = 0.01
sigma = 0.01

# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# Integrate the SIDARTHE equations over the time grid, t.
ret = odeint(deriv, y0, t, args=(alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda, kappa, xi, rho, sigma))
S, I, D, A, R, T, H, E = ret.T

# Plot the data
fig = plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, I, 'y', alpha=0.7, linewidth=2, label='Infected undetected')
plt.plot(t, D, 'g', alpha=0.7, linewidth=2, label='Diagnosed')
plt.plot(t, A, 'r', alpha=0.7, linewidth=2, label='Ailing')
plt.plot(t, R, 'c', alpha=0.7, linewidth=2, label='Recognized')
plt.plot(t, T, 'm', alpha=0.7, linewidth=2, label='Threatened')
plt.plot(t, H, 'k', alpha=0.7, linewidth=2, label='Healed')
plt.plot(t, E, 'brown', alpha=0.7, linewidth=2, label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Fraction of population')
plt.title('SIDARTHE model for COVID-19')
plt.legend()
plt.show()
