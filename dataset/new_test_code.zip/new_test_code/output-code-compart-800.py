import numpy as np

# Define the SEIRHD model using RK4
class SEIRHDModel:
    def __init__(self, beta, sigma, gamma, delta, alpha, mu, population):
        self.beta = beta  # Transmission rate
        self.sigma = sigma  # Rate of progression from exposed to infectious
        self.gamma = gamma  # Recovery rate
        self.delta = delta  # Death rate for infected individuals
        self.alpha = alpha  # Rate at which hospitalized individuals recover
        self.mu = mu  # Death rate for hospitalized individuals
        self.population = population  # Total population
        self.S = population - 1  # Susceptible individuals
        self.E = 1  # Exposed individuals
        self.I = 0  # Infectious individuals
        self.H = 0  # Hospitalized individuals
        self.R = 0  # Recovered individuals
        self.D = 0  # Dead individuals

    def derivatives(self, S, E, I, H, R, D):
        N = self.population
        dSdt = -self.beta * S * I / N
        dEdt = self.beta * S * I / N - self.sigma * E
        dIdt = self.sigma * E - (self.gamma + self.delta) * I
        dHdt = self.delta * I - (self.alpha + self.mu) * H
        dRdt = self.gamma * I + self.alpha * H
        dDdt = self.mu * H
        return dSdt, dEdt, dIdt, dHdt, dRdt, dDdt

    def rk4_step(self, h):
        S, E, I, H, R, D = self.S, self.E, self.I, self.H, self.R, self.D
        dS1, dE1, dI1, dH1, dR1, dD1 = self.derivatives(S, E, I, H, R, D)
        dS2, dE2, dI2, dH2, dR2, dD2 = self.derivatives(S + h/2 * dS1, E + h/2 * dE1, I + h/2 * dI1, H + h/2 * dH1, R + h/2 * dR1, D + h/2 * dD1)
        dS3, dE3, dI3, dH3, dR3, dD3 = self.derivatives(S + h/2 * dS2, E + h/2 * dE2, I + h/2 * dI2, H + h/2 * dH2, R + h/2 * dR2, D + h/2 * dD2)
        dS4, dE4, dI4, dH4, dR4, dD4 = self.derivatives(S + h * dS3, E + h * dE3, I + h * dI3, H + h * dH3, R + h * dR3, D + h * dD3)
        self.S += h/6 * (dS1 + 2*dS2 + 2*dS3 + dS4)
        self.E += h/6 * (dE1 + 2*dE2 + 2*dE3 + dE4)
        self.I += h/6 * (dI1 + 2*dI2 + 2*dI3 + dI4)
        self.H += h/6 * (dH1 + 2*dH2 + 2*dH3 + dH4)
        self.R += h/6 * (dR1 + 2*dR2 + 2*dR3 + dR4)
        self.D += h/6 * (dD1 + 2*dD2 + 2*dD3 + dD4)

    def run_simulation(self, days, step_size):
        results = []
        for _ in range(days):
            self.rk4_step(step_size)
            results.append((self.S, self.E, self.I, self.H, self.R, self.D))
        return np.array(results)

if __name__ == "__main__":
    # Parameters
    beta = 0.3  # Transmission rate
    sigma = 1/5.2  # Rate of progression from exposed to infectious
    gamma = 1/2.9  # Recovery rate
    delta = 0.01  # Death rate for infected individuals
    alpha = 1/10  # Rate at which hospitalized individuals recover
    mu = 0.05  # Death rate for hospitalized individuals
    population = 1000000  # Total population
    days = 160  # Simulation period
    step_size = 1  # Step size for RK4

    # Initialize model
    model = SEIRHDModel(beta, sigma, gamma, delta, alpha, mu, population)

    # Run simulation
    results = model.run_simulation(days, step_size)

    # Print results
    for day, (S, E, I, H, R, D) in enumerate(results):
        print(f"Day {day}: S={S:.2f}, E={E:.2f}, I={I:.2f}, H={H:.2f}, R={R:.2f}, D={D:.2f}")
