# Importing necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Define the SIDARTHE model using Euler's method

def sidarthe_model(S0, I0, D0, A0, R0, T0, H0, E0, beta, delta, gamma, alpha, theta, mu, nu, lambda_, days):
    # Initialize arrays to hold the population values for each compartment
    S = np.zeros(days)
    I = np.zeros(days)
    D = np.zeros(days)
    A = np.zeros(days)
    R = np.zeros(days)
    T = np.zeros(days)
    H = np.zeros(days)
    E = np.zeros(days)

    # Set initial values
    S[0] = S0
    I[0] = I0
    D[0] = D0
    A[0] = A0
    R[0] = R0
    T[0] = T0
    H[0] = H0
    E[0] = E0

    # Time step
    dt = 1.0

    # Euler's method to solve the differential equations
    for t in range(1, days):
        S[t] = S[t-1] - dt * (beta * S[t-1] * I[t-1])
        I[t] = I[t-1] + dt * (beta * S[t-1] * I[t-1] - delta * I[t-1] - gamma * I[t-1])
        D[t] = D[t-1] + dt * (delta * I[t-1] - alpha * D[t-1] - theta * D[t-1])
        A[t] = A[t-1] + dt * (gamma * I[t-1] - lambda_ * A[t-1] - mu * A[t-1])
        R[t] = R[t-1] + dt * (alpha * D[t-1] + lambda_ * A[t-1] - nu * R[t-1])
        T[t] = T[t-1] + dt * (theta * D[t-1] + mu * A[t-1] - E[t-1])
        H[t] = H[t-1] + dt * (nu * R[t-1])
        E[t] = E[t-1] + dt * (E[t-1])

    return S, I, D, A, R, T, H, E

# Initial values
S0 = 0.99
I0 = 0.01
D0 = 0.0
A0 = 0.0
R0 = 0.0
T0 = 0.0
H0 = 0.0
E0 = 0.0

# Parameters
beta = 0.5
alpha = 0.1
delta = 0.1
gamma = 0.1
theta = 0.1
mu = 0.1
nu = 0.1
lambda_ = 0.1

# Run the model for 100 days
S, I, D, A, R, T, H, E = sidarthe_model(S0, I0, D0, A0, R0, T0, H0, E0, beta, delta, gamma, alpha, theta, mu, nu, lambda_, 100)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(S, label='Susceptible')
plt.plot(I, label='Infected')
plt.plot(D, label='Diagnosed')
plt.plot(A, label='Ailing')
plt.plot(R, label='Recognized')
plt.plot(T, label='Threatened')
plt.plot(H, label='Healed')
plt.plot(E, label='Extinct')
plt.xlabel('Days')
plt.ylabel('Proportion')
plt.legend()
plt.title('SIDARTHE Model Simulation')
plt.show()
