# Simulate COVID-19 spread with stratification by age using a network model

import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

# Define age groups
age_groups = {
    '0-19': {'population': 1000, 'transmission_rate': 0.1},
    '20-39': {'population': 1500, 'transmission_rate': 0.2},
    '40-59': {'population': 1200, 'transmission_rate': 0.15},
    '60+': {'population': 800, 'transmission_rate': 0.25}
}

# Create a network
G = nx.Graph()

# Add nodes with age group attributes
node_id = 0
for age_group, properties in age_groups.items():
    for _ in range(properties['population']):
        G.add_node(node_id, age_group=age_group, status='susceptible')
        node_id += 1

# Connect nodes randomly
for i in G.nodes():
    for j in G.nodes():
        if i != j and np.random.rand() < 0.05:  # 5% chance of connection
            G.add_edge(i, j)

# Initialize infection
initial_infected = 10
infected_nodes = np.random.choice(G.nodes(), initial_infected, replace=False)
for node in infected_nodes:
    G.nodes[node]['status'] = 'infected'

# Function to simulate one step of the infection spread
def simulate_step(G):
    new_infected = []
    for node in G.nodes():
        if G.nodes[node]['status'] == 'infected':
            for neighbor in G.neighbors(node):
                if G.nodes[neighbor]['status'] == 'susceptible':
                    age_group = G.nodes[neighbor]['age_group']
                    if np.random.rand() < age_groups[age_group]['transmission_rate']:
                        new_infected.append(neighbor)
    for node in new_infected:
        G.nodes[node]['status'] = 'infected'
    return len(new_infected)

# Run the simulation
steps = 50
new_infections_per_step = []
for step in range(steps):
    new_infections = simulate_step(G)
    new_infections_per_step.append(new_infections)
    print(f"Step {step}: {new_infections} new infections")

# Plot the results
plt.figure(figsize=(10, 5))
plt.plot(new_infections_per_step, label='New Infections per Step')
plt.xlabel('Step')
plt.ylabel('New Infections')
plt.title('COVID-19 Simulation with Age Stratification')
plt.legend()
plt.show()
