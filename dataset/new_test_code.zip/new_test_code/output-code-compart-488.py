# SEIRD Compartmental Model using RK2 (Runge-Kutta 2nd Order Method)

import numpy as np
import matplotlib.pyplot as plt

# Define the model parameters
beta = 0.3   # Infection rate
sigma = 0.1  # Rate of progression from exposed to infected
gamma = 0.1  # Recovery rate
mu = 0.01    # Mortality rate

# Initial conditions
S0 = 0.99  # Initial proportion of susceptible individuals
E0 = 0.01  # Initial proportion of exposed individuals
I0 = 0.0   # Initial proportion of infected individuals
R0 = 0.0   # Initial proportion of recovered individuals
D0 = 0.0   # Initial proportion of deceased individuals

# Total population
N = S0 + E0 + I0 + R0 + D0

# Time parameters
t_max = 160  # Total time
dt = 0.1    # Time step

# Define the SEIRD model

def deriv(SEIRD, t, beta, sigma, gamma, mu):
    S, E, I, R, D = SEIRD
    dSdt = -beta * S * I
    dEdt = beta * S * I - sigma * E
    dIdt = sigma * E - gamma * I - mu * I
    dRdt = gamma * I
    dDdt = mu * I
    return np.array([dSdt, dEdt, dIdt, dRdt, dDdt])

# Runge-Kutta 2nd Order Method

def rk2_step(y, t, dt, deriv, *args):
    k1 = deriv(y, t, *args)
    k2 = deriv(y + dt * k1, t + dt, *args)
    return y + (dt / 2) * (k1 + k2)

# Time points
t = np.arange(0, t_max, dt)

# Initialize arrays to store results
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))
D = np.zeros(len(t))

# Initial conditions
SEIRD = np.array([S0, E0, I0, R0, D0])
S[0], E[0], I[0], R[0], D[0] = SEIRD

# Integrate the SEIRD equations over time
for i in range(1, len(t)):
    SEIRD = rk2_step(SEIRD, t[i-1], dt, deriv, beta, sigma, gamma, mu)
    S[i], E[i], I[i], R[i], D[i] = SEIRD

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of Population')
plt.title('SEIRD Model Simulation')
plt.legend()
plt.grid(True)
plt.show()
