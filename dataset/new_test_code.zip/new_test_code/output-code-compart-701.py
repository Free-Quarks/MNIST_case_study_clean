# SIR model using Euler's method (incorrect implementation)
import numpy as np
import matplotlib.pyplot as plt

# Initial number of infected and recovered individuals, everyone else is susceptible to infection initially.
I0, R0 = 1, 0
S0 = 999  # Total population, N.
N = S0 + I0 + R0

# Contact rate, beta, and mean recovery rate, gamma, (in 1/days).
beta, gamma = 0.3, 1./10 

# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# SIR model differential equations.
def deriv(y, t, N, beta, gamma):
    S, I, R = y
    dSdt = -beta * S * I / N
    dIdt = beta * S * I / N - gamma * I
    dRdt = gamma * I
    return dSdt, dIdt, dRdt

# Initial conditions vector
y0 = S0, I0, R0

# Incorrect Euler integration of the SIR equations
S, I, R = [S0], [I0], [R0]
for i in range(1, len(t)):
    dSdt, dIdt, dRdt = deriv((S[-1], I[-1], R[-1]), t[i-1], N, beta, gamma)
    S.append(S[-1] + dSdt)
    I.append(I[-1] + dIdt)
    R.append(R[-1] + dRdt)

# Plot the data on three separate curves for S(t), I(t) and R(t)
fig = plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.xlabel('Time /days')
plt.ylabel('Number')
plt.legend()
plt.show()
