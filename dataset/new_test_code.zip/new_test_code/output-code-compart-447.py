import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SEIRHD model

def seirhd_model(y, t, beta, sigma, gamma, delta, alpha, mu):
    S, E, I, R, H, D = y
    N = S + E + I + R + H + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - delta * I - mu * I
    dRdt = gamma * I
    dHdt = delta * I - alpha * H
    dDdt = mu * I + alpha * H
    return [dSdt, dEdt, dIdt, dRdt, dHdt, dDdt]

# Initial conditions
population = 1000000
initial_infected = 1
initial_exposed = 0
initial_recovered = 0
initial_hospitalized = 0
initial_deaths = 0
initial_susceptible = population - (initial_infected + initial_exposed + initial_recovered + initial_hospitalized + initial_deaths)

# Initial state vector
initial_conditions = [initial_susceptible, initial_exposed, initial_infected, initial_recovered, initial_hospitalized, initial_deaths]

# Parameters
beta = 0.3  # transmission rate
sigma = 1/5.2  # incubation rate
gamma = 1/12.9  # recovery rate
delta = 0.1  # hospitalization rate
alpha = 0.05  # death rate in hospital
mu = 0.02  # death rate outside hospital

# Time points (in days)
days = 160
t = np.linspace(0, days, days)

# Integrate the SEIRHD equations over the time grid
solution = odeint(seirhd_model, initial_conditions, t, args=(beta, sigma, gamma, delta, alpha, mu))
S, E, I, R, H, D = solution.T

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, H, label='Hospitalized')
plt.plot(t, D, label='Deaths')
plt.xlabel('Days')
plt.ylabel('Number of Individuals')
plt.title('SEIRHD Model')
plt.legend()
plt.grid()
plt.show()
