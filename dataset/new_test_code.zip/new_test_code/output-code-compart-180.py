# SIR Model with RK4 Integration
import numpy as np
import matplotlib.pyplot as plt

# Define the SIR model differential equations
def sir_model(y, beta, gamma):
    S, I, R = y
    dS_dt = -beta * S * I
    dI_dt = beta * S * I - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dI_dt, dR_dt])

# RK4 integration method
def rk4_step(f, y, t, dt, *args):
    k1 = f(y, *args)
    k2 = f(y + 0.5 * dt * k1, *args)
    k3 = f(y + 0.5 * dt * k2, *args)
    k4 = f(y + dt * k3, *args)
    return y + (dt / 6) * (k1 + 2 * k2 + 2 * k3 + k4)

# Simulation parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
S0 = 0.99  # Initial proportion of susceptible individuals
I0 = 0.01  # Initial proportion of infected individuals
R0 = 0.0  # Initial proportion of recovered individuals

# Time parameters
dt = 0.1  # Time step
T = 160  # Total time

# Initialize state vector
y = np.array([S0, I0, R0])
time_points = np.arange(0, T, dt)

# Store results
y_results = np.zeros((len(time_points), 3))

y_results[0, :] = y

# Run the simulation
for i in range(1, len(time_points)):
    y = rk4_step(sir_model, y, time_points[i-1], dt, beta, gamma)
    y_results[i, :] = y

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(time_points, y_results[:, 0], label='Susceptible')
plt.plot(time_points, y_results[:, 1], label='Infected')
plt.plot(time_points, y_results[:, 2], label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.title('SIR Model with RK4 Integration')
plt.grid(True)
plt.show()
