import numpy as np
import matplotlib.pyplot as plt

# SIDARTHE model compartments
# S: Susceptible
# I: Infected (asymptomatic, undetected)
# D: Diagnosed (infected, detected)
# A: Ailing (symptomatic, undetected)
# R: Recognized (symptomatic, detected)
# T: Threatened (severe symptoms)
# H: Healed (recovered)
# E: Extinct (deceased)

def sidarthe_model(t, y, params):
    S, I, D, A, R, T, H, E = y
    alpha, beta, gamma, delta, epsilon, zeta, eta, theta, iota, kappa, lambda_, mu, nu, xi, rho, sigma, tau, phi, chi, psi, omega = params
    
    dSdt = -alpha*S*I - beta*S*D - gamma*S*A - delta*S*R
    dIdt = alpha*S*I + beta*S*D + gamma*S*A + delta*S*R - epsilon*I - zeta*I - eta*I
    dDdt = epsilon*I - theta*D - iota*D - kappa*D
    dAdt = zeta*I - lambda_*A - mu*A - nu*A
    dRdt = eta*I + theta*D + lambda_*A - xi*R - rho*R
    dTdt = iota*D + mu*A + xi*R - sigma*T - tau*T
    dHdt = kappa*D + nu*A + rho*R + sigma*T
    dEdt = tau*T + phi*R + chi*D + psi*A + omega*S

    return np.array([dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt])

# Runge-Kutta 3rd order method
def rk3_step(f, t, y, dt, params):
    k1 = dt * f(t, y, params)
    k2 = dt * f(t + dt/2, y + k1/2, params)
    k3 = dt * f(t + dt, y - k1 + 2*k2, params)
    return y + (k1 + 4*k2 + k3) / 6

# Simulation parameters
t_max = 160
dt = 1.0
params = (0.5, 0.1, 0.05, 0.02, 0.1, 0.05, 0.02, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01)

# Initial conditions
y0 = np.array([0.99, 0.01, 0, 0, 0, 0, 0, 0])

t = np.arange(0, t_max, dt)
results = np.zeros((len(t), len(y0)))
results[0] = y0

for i in range(1, len(t)):
    results[i] = rk3_step(sidarthe_model, t[i-1], results[i-1], dt, params)

S, I, D, A, R, T, H, E = results.T

# Plotting results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected (undetected)')
plt.plot(t, D, label='Diagnosed')
plt.plot(t, A, label='Ailing (undetected)')
plt.plot(t, R, label='Recognized')
plt.plot(t, T, label='Threatened')
plt.plot(t, H, label='Healed')
plt.plot(t, E, label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of population')
plt.legend()
plt.title('SIDARTHE Model Simulation')
plt.grid()
plt.show()
