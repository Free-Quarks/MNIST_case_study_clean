# SEIRHD Compartmental Model using Runge-Kutta 3rd Order (RK3)
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Rate of progression from exposed to infectious
gamma = 1/2.9  # Recovery rate
mu_h = 0.01  # Hospitalization rate
mu_d = 0.005  # Death rate

# Initial conditions
S0 = 0.99  # Susceptible
E0 = 0.01  # Exposed
I0 = 0.0  # Infectious
R0 = 0.0  # Recovered
H0 = 0.0  # Hospitalized
D0 = 0.0  # Dead
N = S0 + E0 + I0 + R0 + H0 + D0  # Total population

# Time steps
T = 160
dt = 0.1

# Runge-Kutta 3rd Order step

def rk3_step(f, y, t, dt):
    k1 = f(y, t)
    k2 = f(y + dt/2 * k1, t + dt/2)
    k3 = f(y - dt * k1 + 2 * dt * k2, t + dt)
    return y + dt/6 * (k1 + 4*k2 + k3)

# SEIRHD model differential equations
def seirhd(y, t):
    S, E, I, R, H, D = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - mu_h * I - mu_d * I
    dRdt = gamma * I
    dHdt = mu_h * I
    dDdt = mu_d * I
    return np.array([dSdt, dEdt, dIdt, dRdt, dHdt, dDdt])

# Time array
t = np.arange(0, T, dt)

# Initialize arrays for results
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))
H = np.zeros(len(t))
D = np.zeros(len(t))

# Set initial conditions
S[0], E[0], I[0], R[0], H[0], D[0] = S0, E0, I0, R0, H0, D0

# Solve the system
for i in range(1, len(t)):
    y = np.array([S[i-1], E[i-1], I[i-1], R[i-1], H[i-1], D[i-1]])
    y_next = rk3_step(seirhd, y, t[i-1], dt)
    S[i], E[i], I[i], R[i], H[i], D[i] = y_next

# Plot results
plt.figure(figsize=(10,6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.plot(t, H, label='Hospitalized')
plt.plot(t, D, label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of Population')
plt.legend()
plt.title('SEIRHD Model using RK3')
plt.grid()
plt.show()
