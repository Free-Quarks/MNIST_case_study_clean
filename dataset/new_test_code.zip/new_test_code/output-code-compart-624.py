import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Rate of progression from exposed to infected
gamma = 0.05  # Recovery rate
mu = 0.01    # Death rate
N = 1000     # Total population

# Initial conditions
S0 = 990     # Susceptible individuals
E0 = 5       # Exposed individuals
I0 = 5       # Infected individuals
R0 = 0       # Recovered individuals
H0 = 0       # Hospitalized individuals
D0 = 0       # Dead individuals

# Time parameters
t_max = 160  # Maximum time
dt = 1       # Time step

# Arrays to store results
t = np.arange(0, t_max, dt)
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))
H = np.zeros(len(t))
D = np.zeros(len(t))

# Initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
H[0] = H0
D[0] = D0

# Runge-Kutta 3rd order method
for i in range(1, len(t)):
    k1_S = -beta * S[i-1] * I[i-1] / N
    k1_E = beta * S[i-1] * I[i-1] / N - sigma * E[i-1]
    k1_I = sigma * E[i-1] - gamma * I[i-1] - mu * I[i-1]
    k1_R = gamma * I[i-1]
    k1_H = 0.1 * I[i-1]
    k1_D = mu * I[i-1]

    k2_S = -beta * (S[i-1] + 0.5 * k1_S) * (I[i-1] + 0.5 * k1_I) / N
    k2_E = beta * (S[i-1] + 0.5 * k1_S) * (I[i-1] + 0.5 * k1_I) / N - sigma * (E[i-1] + 0.5 * k1_E)
    k2_I = sigma * (E[i-1] + 0.5 * k1_E) - gamma * (I[i-1] + 0.5 * k1_I) - mu * (I[i-1] + 0.5 * k1_I)
    k2_R = gamma * (I[i-1] + 0.5 * k1_I)
    k2_H = 0.1 * (I[i-1] + 0.5 * k1_I)
    k2_D = mu * (I[i-1] + 0.5 * k1_I)

    k3_S = -beta * (S[i-1] + 0.75 * k2_S) * (I[i-1] + 0.75 * k2_I) / N
    k3_E = beta * (S[i-1] + 0.75 * k2_S) * (I[i-1] + 0.75 * k2_I) / N - sigma * (E[i-1] + 0.75 * k2_E)
    k3_I = sigma * (E[i-1] + 0.75 * k2_E) - gamma * (I[i-1] + 0.75 * k2_I) - mu * (I[i-1] + 0.75 * k2_I)
    k3_R = gamma * (I[i-1] + 0.75 * k2_I)
    k3_H = 0.1 * (I[i-1] + 0.75 * k2_I)
    k3_D = mu * (I[i-1] + 0.75 * k2_I)

    S[i] = S[i-1] + dt * (k1_S + 4 * k2_S + k3_S) / 6
    E[i] = E[i-1] + dt * (k1_E + 4 * k2_E + k3_E) / 6
    I[i] = I[i-1] + dt * (k1_I + 4 * k2_I + k3_I) / 6
    R[i] = R[i-1] + dt * (k1_R + 4 * k2_R + k3_R) / 6
    H[i] = H[i-1] + dt * (k1_H + 4 * k2_H + k3_H) / 6
    D[i] = D[i-1] + dt * (k1_D + 4 * k2_D + k3_D) / 6

# Plot results
plt.figure(figsize=(10,6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, H, label='Hospitalized')
plt.plot(t, D, label='Dead')
plt.xlabel('Time')
plt.ylabel('Number of individuals')
plt.legend()
plt.title('SEIRHD Model Simulation')
plt.show()
