# SEIR Compartmental Model using Euler's Method in Python

import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # infection rate
sigma = 1/5.2  # incubation rate
gamma = 1/14  # recovery rate
N = 1000  # total population

# Initial conditions
S0 = 999  # initial susceptible population
E0 = 1  # initial exposed population
I0 = 0  # initial infected population
R0 = 0  # initial recovered population

# Time steps
T = 160  # total time in days
dt = 1  # time step size
num_steps = int(T/dt)

# Arrays to store the results
S = np.zeros(num_steps)
E = np.zeros(num_steps)
I = np.zeros(num_steps)
R = np.zeros(num_steps)

# Initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# Euler's method to solve the SEIR model
for t in range(1, num_steps):
    S[t] = S[t-1] - (beta * S[t-1] * I[t-1] / N) * dt
    E[t] = E[t-1] + (beta * S[t-1] * I[t-1] / N - sigma * E[t-1]) * dt
    I[t] = I[t-1] + (sigma * E[t-1] - gamma * I[t-1]) * dt
    R[t] = R[t-1] + (gamma * I[t-1]) * dt

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(S, label='Susceptible')
plt.plot(E, label='Exposed')
plt.plot(I, label='Infected')
plt.plot(R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.grid()
plt.title('SEIR Model using Euler\'s Method')
plt.show()
