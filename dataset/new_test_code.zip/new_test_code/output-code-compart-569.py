# SIDARTHE Model using Runge-Kutta 3rd order (RK3) Method

import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# Define the SIDARTHE model

def sidarthe_model(t, y, alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_):
    S, I, D, A, R, T, H, E = y
    dSdt = -alpha*S*I - beta*S*D - gamma*S*A - delta*S*R
    dIdt = alpha*S*I + beta*S*D + gamma*S*A + delta*S*R - epsilon*I - zeta*I - lambda_*I
    dDdt = epsilon*I - eta*D - theta*D
    dAdt = zeta*I - eta*A - mu*A - nu*A
    dRdt = eta*D + eta*A - theta*R - tau*R
    dTdt = mu*A + theta*R - lambda_*T
    dHdt = nu*A + tau*R - lambda_*H
    dEdt = lambda_*(I + T + H)
    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Initial conditions
S0 = 0.99  # initial susceptible population
I0 = 0.01  # initial infected population
D0 = 0.0   # initial diagnosed population
A0 = 0.0   # initial ailing population
R0 = 0.0   # initial recognized population
T0 = 0.0   # initial threatened population
H0 = 0.0   # initial healed population
E0 = 0.0   # initial extinct population

initial_conditions = [S0, I0, D0, A0, R0, T0, H0, E0]

# Parameters of the model
alpha = 0.1
beta = 0.05
gamma = 0.02
delta = 0.01
epsilon = 0.03
theta = 0.04
zeta = 0.07
eta = 0.01
mu = 0.02
nu = 0.01
tau = 0.01
lambda_ = 0.01

params = (alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_)

# Time points where solution is computed
t_span = (0, 160)  # simulate for 160 days
t_eval = np.linspace(*t_span, 160)

# Solve the differential equations using RK3
solution = solve_ivp(sidarthe_model, t_span, initial_conditions, args=params, method='RK23', t_eval=t_eval)

# Extract results
S, I, D, A, R, T, H, E = solution.y

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t_eval, S, label='Susceptible')
plt.plot(t_eval, I, label='Infected')
plt.plot(t_eval, D, label='Diagnosed')
plt.plot(t_eval, A, label='Ailing')
plt.plot(t_eval, R, label='Recognized')
plt.plot(t_eval, T, label='Threatened')
plt.plot(t_eval, H, label='Healed')
plt.plot(t_eval, E, label='Extinct')
plt.xlabel('Days')
plt.ylabel('Population Fraction')
plt.title('SIDARTHE Model Simulation')
plt.legend()
plt.grid()
plt.show()

