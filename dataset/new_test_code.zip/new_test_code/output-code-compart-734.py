# This Python script simulates an SEIR compartmental model using the third-order Runge-Kutta (RK3) method.
import numpy as np
import matplotlib.pyplot as plt

# SEIR Model Parameters
beta = 0.3  # Infection rate
sigma = 0.1 # Rate of progression from exposed to infectious
gamma = 0.1 # Recovery rate

# Initial conditions
S0 = 0.99   # Initial proportion of susceptible individuals
E0 = 0.01   # Initial proportion of exposed individuals
I0 = 0.0    # Initial proportion of infectious individuals
R0 = 0.0    # Initial proportion of recovered individuals

# Time parameters
T = 160     # Total time in days
dt = 0.1    # Time step

# Time array
N = int(T/dt) + 1

t = np.linspace(0, T, N)

# Initialize arrays to store results
S = np.zeros(N)
E = np.zeros(N)
I = np.zeros(N)
R = np.zeros(N)

# Set initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# Define the SEIR model differential equations
def SEIR_deriv(S, E, I, R, beta, sigma, gamma):
    dSdt = -beta * S * I
    dEdt = beta * S * I - sigma * E
    dIdt = sigma * E - gamma * I
    dRdt = gamma * I
    return dSdt, dEdt, dIdt, dRdt

# Runge-Kutta 3rd order (RK3) integration
for i in range(1, N):
    k1_S, k1_E, k1_I, k1_R = SEIR_deriv(S[i-1], E[i-1], I[i-1], R[i-1], beta, sigma, gamma)
    k2_S, k2_E, k2_I, k2_R = SEIR_deriv(S[i-1] + dt/2 * k1_S, E[i-1] + dt/2 * k1_E, I[i-1] + dt/2 * k1_I, R[i-1] + dt/2 * k1_R, beta, sigma, gamma)
    k3_S, k3_E, k3_I, k3_R = SEIR_deriv(S[i-1] - dt * k1_S + 2*dt * k2_S, E[i-1] - dt * k1_E + 2*dt * k2_E, I[i-1] - dt * k1_I + 2*dt * k2_I, R[i-1] - dt * k1_R + 2*dt * k2_R, beta, sigma, gamma)
    
    S[i] = S[i-1] + dt/6 * (k1_S + 4*k2_S + k3_S)
    E[i] = E[i-1] + dt/6 * (k1_E + 4*k2_E + k3_E)
    I[i] = I[i-1] + dt/6 * (k1_I + 4*k2_I + k3_I)
    R[i] = R[i-1] + dt/6 * (k1_R + 4*k2_R + k3_R)

# Plotting the results
def plot_seir(t, S, E, I, R):
    plt.figure(figsize=(10, 6))
    plt.plot(t, S, label='Susceptible')
    plt.plot(t, E, label='Exposed')
    plt.plot(t, I, label='Infectious')
    plt.plot(t, R, label='Recovered')
    plt.xlabel('Time (days)')
    plt.ylabel('Proportion')
    plt.title('SEIR Model')
    plt.legend()
    plt.grid(True)
    plt.show()

# Execute the plotting function
plot_seir(t, S, E, I, R)

