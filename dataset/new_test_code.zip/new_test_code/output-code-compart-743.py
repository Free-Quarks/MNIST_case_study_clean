# Python code implementing SIDARTHE model with RK2
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# Define the model parameters
params = {
    'alpha': 0.57,  # rate of transmission for susceptible-infected
    'beta': 0.011,  # rate of transmission for infected-diagnosed
    'gamma': 0.456, # rate of transmission for diagnosed-ailing
    'delta': 0.011, # rate of transmission for ailing-recognized
    'epsilon': 0.171, # rate of transmission for recognized-threatened
    'theta': 0.370,  # rate of transmission for threatened-healed
    'zeta': 0.125,  # rate of transmission for diagnosed-recovered
    'eta': 0.125,   # rate of transmission for ailing-recovered
    'mu': 0.017,    # rate of transmission for ailing-dead
    'nu': 0.027,    # rate of transmission for recognized-dead
    'tau': 0.045,   # rate of transmission for threatened-dead
    'lambda': 0.034 # rate of transmission for threatened-recovered
}

# Initial conditions
initial_conditions = [
    1 - 1e-6,  # S: susceptible
    1e-6,      # I: infected
    0,         # D: diagnosed
    0,         # A: ailing
    0,         # R: recognized
    0,         # T: threatened
    0,         # H: healed
    0          # E: extinct (dead)
]

# Time points (days)
t = np.linspace(0, 180, 180)

# SIDARTHE model differential equations
def sidarthe(t, y, params):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E
    dS_dt = -params['alpha'] * S * I - params['beta'] * S * D - params['gamma'] * S * A - params['delta'] * S * R
    dI_dt = params['alpha'] * S * I + params['beta'] * S * D + params['gamma'] * S * A + params['delta'] * S * R - params['epsilon'] * I - params['zeta'] * I
    dD_dt = params['epsilon'] * I - params['eta'] * D - params['theta'] * D
    dA_dt = params['zeta'] * I - params['mu'] * A - params['nu'] * A - params['eta'] * A
    dR_dt = params['eta'] * D + params['theta'] * D - params['lambda'] * R - params['tau'] * R
    dT_dt = params['lambda'] * R - params['tau'] * T - params['nu'] * T
    dH_dt = params['eta'] * A + params['tau'] * R + params['tau'] * T
    dE_dt = params['mu'] * A + params['nu'] * T
    return [dS_dt, dI_dt, dD_dt, dA_dt, dR_dt, dT_dt, dH_dt, dE_dt]

# Implementing RK2

def rk2_step(f, y, t, dt, params):
    k1 = f(t, y, params)
    k2 = f(t + dt, y + dt * np.array(k1), params)
    y_next = y + dt * (np.array(k1) + np.array(k2)) / 2
    return y_next

# Simulate using RK2
results = [initial_conditions]
for i in range(1, len(t)):
    dt = t[i] - t[i-1]
    y_next = rk2_step(sidarthe, results[-1], t[i-1], dt, params)
    results.append(y_next)

results = np.array(results)

# Plot results
plt.figure(figsize=(12, 8))
labels = ['Susceptible', 'Infected', 'Diagnosed', 'Ailing', 'Recognized', 'Threatened', 'Healed', 'Extinct']
for i, label in enumerate(labels):
    plt.plot(t, results[:, i], label=label)
plt.xlabel('Days')
plt.ylabel('Proportion')
plt.legend()
plt.title('SIDARTHE Model Simulation using RK2')
plt.show()

