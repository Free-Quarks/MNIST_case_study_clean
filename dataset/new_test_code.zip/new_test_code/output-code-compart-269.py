# SIDARTHE Model Simulation using Runge-Kutta 3rd Order (RK3) Method
import numpy as np

# Define the SIDARTHE model parameters
beta = 0.5  # Transmission rate
sigma = 0.1  # Rate of progression from susceptible to infected
eta = 0.05  # Rate of progression from infected to diagnosed
rho = 0.03  # Rate of progression from diagnosed to ailing
alpha = 0.02  # Rate of progression from ailing to recognized
nu = 0.01  # Rate of progression from recognized to threatened
mu = 0.005  # Rate of progression from threatened to healed

# Define initial conditions
S0 = 0.99  # Initial proportion of susceptible individuals
I0 = 0.01  # Initial proportion of infected individuals
D0 = 0.0  # Initial proportion of diagnosed individuals
A0 = 0.0  # Initial proportion of ailing individuals
R0 = 0.0  # Initial proportion of recognized individuals
T0 = 0.0  # Initial proportion of threatened individuals
H0 = 0.0  # Initial proportion of healed individuals
E0 = 0.0  # Initial proportion of extinct individuals

# Time step and total time
dt = 0.1
T = 100

# Number of steps
steps = int(T / dt)

# Initialize arrays to store results
S = np.zeros(steps)
I = np.zeros(steps)
D = np.zeros(steps)
A = np.zeros(steps)
R = np.zeros(steps)
T = np.zeros(steps)
H = np.zeros(steps)
E = np.zeros(steps)

# Set initial values
S[0] = S0
I[0] = I0
D[0] = D0
A[0] = A0
R[0] = R0
T[0] = T0
H[0] = H0
E[0] = E0

# Define the SIDARTHE model equations
def sidarthe_model(S, I, D, A, R, T, H, E):
    dSdt = -beta * S * I
    dIdt = beta * S * I - sigma * I
    dDdt = sigma * I - eta * D
    dAdt = eta * D - rho * A
    dRdt = rho * A - alpha * R
    dTdt = alpha * R - nu * T
    dHdt = nu * T - mu * H
    dEdt = mu * H
    return dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt

# Run the RK3 method to solve the SIDARTHE model
def run_rk3():
    for i in range(steps - 1):
        S_current = S[i]
        I_current = I[i]
        D_current = D[i]
        A_current = A[i]
        R_current = R[i]
        T_current = T[i]
        H_current = H[i]
        E_current = E[i]

        k1 = np.array(sidarthe_model(S_current, I_current, D_current, A_current, R_current, T_current, H_current, E_current))
        k2 = np.array(sidarthe_model(S_current + dt * k1[0] / 2, I_current + dt * k1[1] / 2, D_current + dt * k1[2] / 2, A_current + dt * k1[3] / 2, R_current + dt * k1[4] / 2, T_current + dt * k1[5] / 2, H_current + dt * k1[6] / 2, E_current + dt * k1[7] / 2))
        k3 = np.array(sidarthe_model(S_current - dt * k1[0] + 2 * dt * k2[0], I_current - dt * k1[1] + 2 * dt * k2[1], D_current - dt * k1[2] + 2 * dt * k2[2], A_current - dt * k1[3] + 2 * dt * k2[3], R_current - dt * k1[4] + 2 * dt * k2[4], T_current - dt * k1[5] + 2 * dt * k2[5], H_current - dt * k1[6] + 2 * dt * k2[6], E_current - dt * k1[7] + 2 * dt * k2[7]))

        S[i + 1] = S_current + dt * (k1[0] + 4 * k2[0] + k3[0]) / 6
        I[i + 1] = I_current + dt * (k1[1] + 4 * k2[1] + k3[1]) / 6
        D[i + 1] = D_current + dt * (k1[2] + 4 * k2[2] + k3[2]) / 6
        A[i + 1] = A_current + dt * (k1[3] + 4 * k2[3] + k3[3]) / 6
        R[i + 1] = R_current + dt * (k1[4] + 4 * k2[4] + k3[4]) / 6
        T[i + 1] = T_current + dt * (k1[5] + 4 * k2[5] + k3[5]) / 6
        H[i + 1] = H_current + dt * (k1[6] + 4 * k2[6] + k3[6]) / 6
        E[i + 1] = E_current + dt * (k1[7] + 4 * k2[7] + k3[7]) / 6

# Execute the simulation
run_rk3()

# Print the results
print('S:', S)
print('I:', I)
print('D:', D)
print('A:', A)
print('R:', R)
print('T:', T)
print('H:', H)
print('E:', E)
