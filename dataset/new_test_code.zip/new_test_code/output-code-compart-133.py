# SEIR model simulation using Runge-Kutta 2nd order (RK2)
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3    # Infection rate
sigma = 0.1   # Rate of progression from exposed to infectious
gamma = 0.05  # Recovery rate

# Initial conditions
S0 = 0.99     # Initial proportion of susceptible individuals
E0 = 0.01     # Initial proportion of exposed individuals
I0 = 0.0      # Initial proportion of infectious individuals
R0 = 0.0      # Initial proportion of recovered individuals

# Time variables
T = 160       # Total time in days
dt = 1.0      # Time step

# Number of steps
N = int(T / dt)

# Arrays to store the results
S = np.zeros(N)
E = np.zeros(N)
I = np.zeros(N)
R = np.zeros(N)
t = np.linspace(0, T, N)

# Initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# RK2 method for SEIR model
for i in range(1, N):
    # Compute the intermediate values
    k1_S = -beta * S[i-1] * I[i-1]
    k1_E = beta * S[i-1] * I[i-1] - sigma * E[i-1]
    k1_I = sigma * E[i-1] - gamma * I[i-1]
    k1_R = gamma * I[i-1]

    S_mid = S[i-1] + 0.5 * dt * k1_S
    E_mid = E[i-1] + 0.5 * dt * k1_E
    I_mid = I[i-1] + 0.5 * dt * k1_I
    R_mid = R[i-1] + 0.5 * dt * k1_R

    k2_S = -beta * S_mid * I_mid
    k2_E = beta * S_mid * I_mid - sigma * E_mid
    k2_I = sigma * E_mid - gamma * I_mid
    k2_R = gamma * I_mid

    # Update the values
    S[i] = S[i-1] + dt * k2_S
    E[i] = E[i-1] + dt * k2_E
    I[i] = I[i-1] + dt * k2_I
    R[i] = R[i-1] + dt * k2_R

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIR Model Simulation using RK2')
plt.grid(True)
plt.show()
