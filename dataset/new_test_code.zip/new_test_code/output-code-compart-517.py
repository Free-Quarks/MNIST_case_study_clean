import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Initial conditions
S0 = 0.99  # susceptible
I0 = 0.01  # infected
D0 = 0    # diagnosed
A0 = 0    # ailing
R0 = 0    # recognized
T0 = 0    # threatened
H0 = 0    # healed
E0 = 0    # extinct

# Initial state vector
y0 = [S0, I0, D0, A0, R0, T0, H0, E0]

# Parameters (chosen arbitrarily for the example)
alpha = 0.2  # infection rate
beta = 0.1   # diagnosis rate
gamma = 0.05 # ailing rate
eta = 0.01   # recognition rate
theta = 0.02 # threatening rate
mu = 0.03    # healing rate
nu = 0.01    # extinction rate

# Time points
t = np.linspace(0, 160, 160)

# SIDARTHE model differential equations (incorrectly defined)
def deriv(y, t, alpha, beta, gamma, eta, theta, mu, nu):
    S, I, D, A, R, T, H, E = y
    dSdt = -alpha * S * I
    dIdt = alpha * S * I - beta * I
    dDdt = beta * I - gamma * D
    dAdt = gamma * D - eta * A
    dRdt = eta * A - theta * R
    dTdt = theta * R - mu * T
    dHdt = mu * T - nu * H
    dEdt = nu * H
    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Integrate the SIDARTHE equations over the time grid, t.
ret = odeint(deriv, y0, t, args=(alpha, beta, gamma, eta, theta, mu, nu))
S, I, D, A, R, T, H, E = ret.T

# Plot the data
fig = plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, D, 'g', alpha=0.7, linewidth=2, label='Diagnosed')
plt.plot(t, A, 'c', alpha=0.7, linewidth=2, label='Ailing')
plt.plot(t, R, 'm', alpha=0.7, linewidth=2, label='Recognized')
plt.plot(t, T, 'y', alpha=0.7, linewidth=2, label='Threatened')
plt.plot(t, H, 'k', alpha=0.7, linewidth=2, label='Healed')
plt.plot(t, E, 'orange', alpha=0.7, linewidth=2, label='Extinct')

plt.xlabel('Time /days')
plt.ylabel('Number (100% population)')
plt.legend()
plt.show()
