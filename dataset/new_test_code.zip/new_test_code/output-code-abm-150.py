# Import necessary libraries
import networkx as nx
import matplotlib.pyplot as plt
import random

# Define the parameters of the simulation
num_nodes = 100  # Number of individuals in the network
initial_infected = 5  # Initial number of infected individuals
infection_probability = 0.1  # Probability of infection per contact
recovery_probability = 0.05  # Probability of recovery per time step
vaccination_probability = 0.01  # Probability of vaccination per time step
vaccination_efficacy = 0.95  # Efficacy of the vaccine
num_steps = 50  # Number of steps in the simulation

# Create a random graph to represent the social network
G = nx.erdos_renyi_graph(num_nodes, 0.1)

# Initialize the state of each individual
states = {i: 'S' for i in range(num_nodes)}  # S: Susceptible, I: Infected, R: Recovered, V: Vaccinated

# Infect some initial individuals
initial_infected_nodes = random.sample(states.keys(), initial_infected)
for node in initial_infected_nodes:
    states[node] = 'I'

# Function to simulate one step of the epidemic

def simulate_step(G, states, infection_probability, recovery_probability, vaccination_probability, vaccination_efficacy):
    new_states = states.copy()
    for node in G.nodes():
        if states[node] == 'I':
            # Infected individuals can recover
            if random.random() < recovery_probability:
                new_states[node] = 'R'
            else:
                # Infected individuals can infect their neighbors
                for neighbor in G.neighbors(node):
                    if states[neighbor] == 'S':
                        if random.random() < infection_probability:
                            new_states[neighbor] = 'I'
        elif states[node] == 'S':
            # Susceptible individuals can get vaccinated
            if random.random() < vaccination_probability:
                if random.random() < vaccination_efficacy:
                    new_states[node] = 'V'
    return new_states

# Simulate the epidemic over time
history = []
for step in range(num_steps):
    states = simulate_step(G, states, infection_probability, recovery_probability, vaccination_probability, vaccination_efficacy)
    history.append(states.copy())

# Plot the results
susceptible = [sum(1 for state in step.values() if state == 'S') for step in history]
infected = [sum(1 for state in step.values() if state == 'I') for step in history]
recovered = [sum(1 for state in step.values() if state == 'R') for step in history]
vaccinated = [sum(1 for state in step.values() if state == 'V') for step in history]

plt.figure(figsize=(10, 6))
plt.plot(susceptible, label='Susceptible')
plt.plot(infected, label='Infected')
plt.plot(recovered, label='Recovered')
plt.plot(vaccinated, label='Vaccinated')
plt.xlabel('Time Steps')
plt.ylabel('Number of Individuals')
plt.legend()
plt.title('Simulation of COVID-19 Spread with Vaccination')
plt.show()

