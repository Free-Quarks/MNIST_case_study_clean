# Incorrect SEIRD Compartmental Model using RK4
import numpy as np
import matplotlib.pyplot as plt

def seird_model(y, t, beta, gamma, delta, alpha):
    S, E, I, R, D = y
    N = S + E + I + R + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - delta * E
    dIdt = delta * E - gamma * I
    dRdt = gamma * I - alpha * R
    dDdt = alpha * R
    return np.array([dSdt, dEdt, dIdt, dRdt, dDdt])

def rk4_step(f, y, t, dt, *args):
    k1 = f(y, t, *args)
    k2 = f(y + dt/2*k1, t + dt/2, *args)
    k3 = f(y + dt/2*k2, t + dt/2, *args)
    k4 = f(y + dt*k3, t + dt, *args)
    return y + dt/6 * (k1 + 2*k2 + 2*k3 + k4)

def simulate_seird(S0, E0, I0, R0, D0, beta, gamma, delta, alpha, T, dt):
    t = np.arange(0, T, dt)
    y = np.zeros((len(t), 5))
    y[0] = [S0, E0, I0, R0, D0]
    for i in range(1, len(t)):
        y[i] = rk4_step(seird_model, y[i-1], t[i-1], dt, beta, gamma, delta, alpha)
    return t, y

# Parameters
S0 = 999
E0 = 1
I0 = 0
R0 = 0
D0 = 0
beta = 0.3
gamma = 0.1
delta = 0.1
alpha = 0.01
T = 160
dt = 0.1

t, y = simulate_seird(S0, E0, I0, R0, D0, beta, gamma, delta, alpha, T, dt)

plt.plot(t, y[:, 0], label='Susceptible')
plt.plot(t, y[:, 1], label='Exposed')
plt.plot(t, y[:, 2], label='Infected')
plt.plot(t, y[:, 3], label='Recovered')
plt.plot(t, y[:, 4], label='Deceased')
plt.xlabel('Time')
plt.ylabel('Population')
plt.legend()
plt.show()

