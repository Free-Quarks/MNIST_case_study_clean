import networkx as nx
import random

# Initialize parameters
population_size = 1000
initial_infected = 10
infection_probability = 0.1
recovery_probability = 0.05
simulation_steps = 50

# Stratification by age groups
age_groups = {'child': 0.2, 'adult': 0.6, 'elderly': 0.2}
age_distribution = [int(population_size * age_groups[key]) for key in age_groups]

# Create a population network
G = nx.erdos_renyi_graph(population_size, 0.1)
for node in G.nodes():
    if node < age_distribution[0]:
        G.nodes[node]['age_group'] = 'child'
    elif node < age_distribution[0] + age_distribution[1]:
        G.nodes[node]['age_group'] = 'adult'
    else:
        G.nodes[node]['age_group'] = 'elderly'

# Initialize infection states
for node in G.nodes():
    G.nodes[node]['state'] = 'susceptible'

initial_infected_nodes = random.sample(G.nodes(), initial_infected)
for node in initial_infected_nodes:
    G.nodes[node]['state'] = 'infected'

# Simulation function
def simulate(G, steps):
    for step in range(steps):
        new_infected = []
        new_recovered = []
        for node in G.nodes():
            if G.nodes[node]['state'] == 'infected':
                # Attempt to infect neighbors
                for neighbor in G.neighbors(node):
                    if G.nodes[neighbor]['state'] == 'susceptible' and random.random() < infection_probability:
                        new_infected.append(neighbor)
                # Attempt to recover
                if random.random() < recovery_probability:
                    new_recovered.append(node)
        for node in new_infected:
            G.nodes[node]['state'] = 'infected'
        for node in new_recovered:
            G.nodes[node]['state'] = 'recovered'
        print(f"Step {step}: {len(new_infected)} new infections, {len(new_recovered)} recoveries")

simulate(G, simulation_steps)
