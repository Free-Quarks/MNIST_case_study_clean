# SIR Model using Euler's method

class SIRModel:
    def __init__(self, S0, I0, R0, beta, gamma, dt):
        self.S = S0
        self.I = I0
        self.R = R0
        self.beta = beta
        self.gamma = gamma
        self.dt = dt

    def step(self):
        dS = -self.beta * self.S * self.I * self.dt
        dI = (self.beta * self.S * self.I - self.gamma * self.I) * self.dt
        dR = self.gamma * self.I * self.dt

        self.S += dS
        self.I += dI
        self.R += dR

    def run(self, steps):
        result = {'S': [], 'I': [], 'R': []}
        for _ in range(steps):
            self.step()
            result['S'].append(self.S)
            result['I'].append(self.I)
            result['R'].append(self.R)
        return result

# Example usage
if __name__ == '__main__':
    S0 = 0.99  # Initial susceptible population
    I0 = 0.01  # Initial infected population
    R0 = 0.0   # Initial recovered population
    beta = 0.3  # Infection rate
    gamma = 0.1  # Recovery rate
    dt = 0.1   # Time step
    steps = 160  # Number of steps

    model = SIRModel(S0, I0, R0, beta, gamma, dt)
    result = model.run(steps)

    print(result)

