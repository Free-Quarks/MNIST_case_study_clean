# SIR Model using Runge-Kutta 2nd Order (RK2) Method
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate

# Initial conditions
S0 = 0.99  # Initial susceptible population
I0 = 0.01  # Initial infected population
R0 = 0.0   # Initial recovered population

# Time parameters
T = 160  # Total time
dt = 0.1  # Time step

# Number of time steps
N = int(T / dt)

# Arrays to store results
S = np.zeros(N)
I = np.zeros(N)
R = np.zeros(N)

t = np.linspace(0, T, N)

# Initial values
S[0] = S0
I[0] = I0
R[0] = R0

# Function to compute derivatives

def derivatives(S, I, R, beta, gamma):
    dS = -beta * S * I
    dI = beta * S * I - gamma * I
    dR = gamma * I
    return dS, dI, dR

# RK2 Method
for i in range(1, N):
    S1, I1, R1 = S[i-1], I[i-1], R[i-1]
    dS1, dI1, dR1 = derivatives(S1, I1, R1, beta, gamma)

    S1_mid = S1 + dS1 * dt / 2
    I1_mid = I1 + dI1 * dt / 2
    R1_mid = R1 + dR1 * dt / 2

    dS2, dI2, dR2 = derivatives(S1_mid, I1_mid, R1_mid, beta, gamma)

    S[i] = S1 + dS2 * dt
    I[i] = I1 + dI2 * dt
    R[i] = R1 + dR2 * dt

# Plot results
plt.plot(t, S, label="Susceptible")
plt.plot(t, I, label="Infected")
plt.plot(t, R, label="Recovered")
plt.xlabel("Time")
plt.ylabel("Proportion")
plt.legend()
plt.title("SIR Model using RK2 Method")
plt.show()
