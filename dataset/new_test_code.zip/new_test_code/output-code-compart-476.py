# SIR model using Euler's method
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
S0 = 0.99  # Initial susceptible population
I0 = 0.01  # Initial infected population
R0 = 0.0  # Initial recovered population

# Time parameters
t_max = 160  # Total time
dt = 0.1  # Time step
n_steps = int(t_max / dt)  # Number of steps

# Initialize arrays
S = np.zeros(n_steps)
I = np.zeros(n_steps)
R = np.zeros(n_steps)
t = np.zeros(n_steps)

# Initial conditions
S[0] = S0
I[0] = I0
R[0] = R0

# Euler's method
for step in range(1, n_steps):
    S[step] = S[step-1] - beta * S[step-1] * I[step-1] * dt
    I[step] = I[step-1] + (beta * S[step-1] * I[step-1] - gamma * I[step-1]) * dt
    R[step] = R[step-1] + gamma * I[step-1] * dt
    t[step] = t[step-1] + dt

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.title('SIR Model Simulation using Euler\'s Method')
plt.show()
