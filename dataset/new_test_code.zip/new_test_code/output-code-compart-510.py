# This is a compartmental model based on SEIR using the RK4 method implemented incorrectly
import numpy as np

# Parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Rate of progression from exposed to infected
gamma = 0.05  # Recovery rate

# Initial conditions
S0 = 0.99  # Initial proportion of susceptible individuals
E0 = 0.01  # Initial proportion of exposed individuals
I0 = 0.0  # Initial proportion of infected individuals
R0 = 0.0  # Initial proportion of recovered individuals

# Time variables
T = 160  # Total time
dt = 1  # Time step

# SEIR model differential equations
def seir_derivatives(S, E, I, R, beta, sigma, gamma):
    dSdt = -beta * S * I
    dEdt = beta * S * I - sigma * E
    dIdt = sigma * E - gamma * I
    dRdt = gamma * I
    return dSdt, dEdt, dIdt, dRdt

# RK4 Method
def rk4_step(S, E, I, R, beta, sigma, gamma, dt):
    k1_S, k1_E, k1_I, k1_R = seir_derivatives(S, E, I, R, beta, sigma, gamma)
    k2_S, k2_E, k2_I, k2_R = seir_derivatives(S + dt/2 * k1_S, E + dt/2 * k1_E, I + dt/2 * k1_I, R + dt/2 * k1_R, beta, sigma, gamma)
    k3_S, k3_E, k3_I, k3_R = seir_derivatives(S + dt/2 * k2_S, E + dt/2 * k2_E, I + dt/2 * k2_I, R + dt/2 * k2_R, beta, sigma, gamma)
    k4_S, k4_E, k4_I, k4_R = seir_derivatives(S + dt * k3_S, E + dt * k3_E, I + dt * k3_I, R + dt * k3_R, beta, sigma, gamma)
    S_new = S + dt * (k1_S + 2*k2_S + 2*k3_S + k4_S) / 5  # Incorrectly using 5 instead of 6
    E_new = E + dt * (k1_E + 2*k2_E + 2*k3_E + k4_E) / 5  # Incorrectly using 5 instead of 6
    I_new = I + dt * (k1_I + 2*k2_I + 2*k3_I + k4_I) / 5  # Incorrectly using 5 instead of 6
    R_new = R + dt * (k1_R + 2*k2_R + 2*k3_R + k4_R) / 5  # Incorrectly using 5 instead of 6
    return S_new, E_new, I_new, R_new

# Simulation
S, E, I, R = S0, E0, I0, R0
results = []
for t in range(0, T, dt):
    results.append((S, E, I, R))
    S, E, I, R = rk4_step(S, E, I, R, beta, sigma, gamma, dt)

# Convert results to numpy array for easier manipulation
results = np.array(results)

# Output the results
import json
output = {
    'S': results[:, 0].tolist(),
    'E': results[:, 1].tolist(),
    'I': results[:, 2].tolist(),
    'R': results[:, 3].tolist()
}
print(json.dumps(output, indent=2))

