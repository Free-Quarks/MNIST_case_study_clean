# Required Libraries
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# SEIRD Model Differential Equations
def seird_model(t, y, beta, sigma, gamma, delta):
    S, E, I, R, D = y
    N = S + E + I + R + D
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I - delta * I
    dR_dt = gamma * I
    dD_dt = delta * I
    return [dS_dt, dE_dt, dI_dt, dR_dt, dD_dt]

# Runge-Kutta 4th Order Method (RK4) Implementation
def rk4_step(f, t, y, dt, *args):
    k1 = np.array(f(t, y, *args))
    k2 = np.array(f(t + 0.5 * dt, y + 0.5 * dt * k1, *args))
    k3 = np.array(f(t + 0.5 * dt, y + 0.5 * dt * k2, *args))
    k4 = np.array(f(t + dt, y + dt * k3, *args))
    return y + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)

# Simulation Function
def simulate_seird(initial_conditions, params, t_span, dt):
    t0, tf = t_span
    t_values = np.arange(t0, tf, dt)
    results = np.zeros((len(t_values), len(initial_conditions)))
    results[0] = initial_conditions
    y = initial_conditions
    for i in range(1, len(t_values)):
        y = rk4_step(seird_model, t_values[i-1], y, dt, *params)
        results[i] = y
    return t_values, results

# Initial Conditions and Parameters
initial_conditions = [999, 1, 0, 0, 0]  # S, E, I, R, D
params = (0.3, 0.1, 0.05, 0.01)  # beta, sigma, gamma, delta
t_span = (0, 160)
dt = 1.0

# Run Simulation
t_values, results = simulate_seird(initial_conditions, params, t_span, dt)

# Plot Results
plt.figure(figsize=(10, 6))
plt.plot(t_values, results[:, 0], label='Susceptible')
plt.plot(t_values, results[:, 1], label='Exposed')
plt.plot(t_values, results[:, 2], label='Infectious')
plt.plot(t_values, results[:, 3], label='Recovered')
plt.plot(t_values, results[:, 4], label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.title('SEIRD Model Simulation')
plt.legend()
plt.grid(True)
plt.show()
