# SIR model with RK2 integration

import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
S0, I0, R0 = 0.99, 0.01, 0.0  # Initial conditions

def SIR_derivatives(S, I, R, beta, gamma):
    dS = -beta * S * I
    dI = beta * S * I - gamma * I
    dR = gamma * I
    return dS, dI, dR

# Runge-Kutta 2nd order (RK2) method

def RK2_step(S, I, R, dt, beta, gamma):
    dS1, dI1, dR1 = SIR_derivatives(S, I, R, beta, gamma)
    S1, I1, R1 = S + dS1 * dt / 2, I + dI1 * dt / 2, R + dR1 * dt / 2
    dS2, dI2, dR2 = SIR_derivatives(S1, I1, R1, beta, gamma)
    S += dS2 * dt
    I += dI2 * dt
    R += dR2 * dt
    return S, I, R

# Simulation parameters
dt = 0.1  # Time step
days = 160  # Number of days

# Initialize arrays to store results
S, I, R = [S0], [I0], [R0]

# Run the simulation
for _ in range(int(days / dt)):
    S_new, I_new, R_new = RK2_step(S[-1], I[-1], R[-1], dt, beta, gamma)
    S.append(S_new)
    I.append(I_new)
    R.append(R_new)

# Plot the results
t = np.linspace(0, days, int(days / dt) + 1)
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.show()
