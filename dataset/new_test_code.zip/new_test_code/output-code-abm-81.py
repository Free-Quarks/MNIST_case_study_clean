import random

class Individual:
    def __init__(self, age, health_status):
        self.age = age
        self.health_status = health_status  # susceptible, infected, recovered, or dead

    def __repr__(self):
        return f"Individual(age={self.age}, health_status={self.health_status})"

class Population:
    def __init__(self, size):
        self.individuals = self._initialize_population(size)

    def _initialize_population(self, size):
        individuals = []
        for _ in range(size):
            age = random.choice(["child", "adult", "elderly"])
            health_status = "susceptible"
            individuals.append(Individual(age, health_status))
        return individuals

    def infect_individual(self, index):
        self.individuals[index].health_status = "infected"

    def update_health_status(self):
        for individual in self.individuals:
            if individual.health_status == "infected":
                outcome = random.choices(["recovered", "dead"], weights=[0.95, 0.05])[0]
                individual.health_status = outcome

    def propagate_infection(self, infection_rate):
        for individual in self.individuals:
            if individual.health_status == "infected":
                for other in self.individuals:
                    if other.health_status == "susceptible":
                        if random.random() < infection_rate:
                            other.health_status = "infected"

    def __repr__(self):
        return f"Population(individuals={self.individuals})"

if __name__ == "__main__":
    population_size = 100
    initial_infected = 1
    infection_rate = 0.1
    days = 30

    population = Population(population_size)
    for i in range(initial_infected):
        population.infect_individual(i)

    for day in range(days):
        print(f"Day {day}: {population}")
        population.propagate_infection(infection_rate)
        population.update_health_status()
