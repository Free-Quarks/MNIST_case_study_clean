import numpy as np

# SEIRD model parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Incubation rate
gamma = 1/12.39  # Recovery rate
mu = 0.01  # Mortality rate

# RK2 parameters
dt = 0.1  # Time step
steps = 160  # Number of steps

# Initial conditions
S0 = 0.99
E0 = 0.01
I0 = 0.0
R0 = 0.0
D0 = 0.0

# SEIRD derivatives
def dSEIRD(S, E, I, R, D):
    dS = -beta * S * I
    dE = beta * S * I - sigma * E
    dI = sigma * E - gamma * I - mu * I
    dR = gamma * I
    dD = mu * I
    return dS, dE, dI, dR, dD

# RK2 step function
def rk2_step(S, E, I, R, D, dt):
    k1 = dSEIRD(S, E, I, R, D)
    S1, E1, I1, R1, D1 = S + k1[0] * dt, E + k1[1] * dt, I + k1[2] * dt, R + k1[3] * dt, D + k1[4] * dt
    k2 = dSEIRD(S1, E1, I1, R1, D1)
    S2, E2, I2, R2, D2 = S + k2[0] * dt, E + k2[1] * dt, I + k2[2] * dt, R + k2[3] * dt, D + k2[4] * dt
    S_next = S + 0.5 * (k1[0] + k2[0]) * dt
    E_next = E + 0.5 * (k1[1] + k2[1]) * dt
    I_next = I + 0.5 * (k1[2] + k2[2]) * dt
    R_next = R + 0.5 * (k1[3] + k2[3]) * dt
    D_next = D + 0.5 * (k1[4] + k2[4]) * dt
    return S_next, E_next, I_next, R_next, D_next

# Simulation
S, E, I, R, D = S0, E0, I0, R0, D0
results = []
for step in range(steps):
    results.append((S, E, I, R, D))
    S, E, I, R, D = rk2_step(S, E, I, R, D, dt)

# Convert results to numpy array
results = np.array(results)

# Print results
print(results)

