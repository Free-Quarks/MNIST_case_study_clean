import random
import matplotlib.pyplot as plt

class Person:
    def __init__(self, vaccinated=False):
        self.vaccinated = vaccinated
        self.infected = False

    def expose_to_virus(self):
        if not self.vaccinated:
            self.infected = random.choice([True, False])
        else:
            self.infected = random.choice([False, False, False, True])

class Population:
    def __init__(self, size, vaccination_rate):
        self.people = [Person(vaccinated=(random.random() < vaccination_rate)) for _ in range(size)]

    def spread_virus(self):
        for person in self.people:
            if not person.infected:
                person.expose_to_virus()

    def count_infected(self):
        return sum(person.infected for person in self.people)

# Parameters
population_size = 1000
vaccination_rate = 0.7
iterations = 10

# Initialize Population
population = Population(population_size, vaccination_rate)

infected_counts = []

# Simulate Virus Spread
for i in range(iterations):
    population.spread_virus()
    infected_counts.append(population.count_infected())

# Plot Results
plt.plot(range(iterations), infected_counts)
plt.xlabel('Iteration')
plt.ylabel('Number of Infected People')
plt.title('COVID-19 Spread Simulation (Incorrect Model)')
plt.show()
