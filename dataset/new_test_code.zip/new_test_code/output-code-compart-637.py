
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SEIRD model
def seird_model(y, t, beta, sigma, gamma, delta):
    S, E, I, R, D = y
    N = S + E + I + R + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - delta * I
    dRdt = gamma * I
    dDdt = delta * I
    return [dSdt, dEdt, dIdt, dRdt, dDdt]

# Initial conditions
N = 1000  # Total population
I0 = 1    # Initial number of infected individuals
E0 = 0    # Initial number of exposed individuals
R0 = 0    # Initial number of recovered individuals
D0 = 0    # Initial number of dead individuals
S0 = N - I0 - E0 - R0 - D0  # Initial number of susceptible individuals

# Contact rate, incubation rate, recovery rate, death rate
beta = 0.3  # Contact rate
sigma = 1/5.2  # Incubation rate (1/5.2 days)
gamma = 1/12.39  # Recovery rate (1/12.39 days)
delta = 0.01  # Death rate

# Time grid
t = np.linspace(0, 160, 160)

# Initial conditions vector
y0 = [S0, E0, I0, R0, D0]

# Integrate the SEIRD equations over the time grid, t.
solution = odeint(seird_model, y0, t, args=(beta, sigma, gamma, delta))
S, E, I, R, D = solution.T

# Plot the data
plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', label='Susceptible')
plt.plot(t, E, 'y', label='Exposed')
plt.plot(t, I, 'r', label='Infected')
plt.plot(t, R, 'g', label='Recovered')
plt.plot(t, D, 'k', label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Number of people')
plt.legend()
plt.title('SEIRD Model')
plt.grid(True)
plt.show()

