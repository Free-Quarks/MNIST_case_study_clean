import numpy as np

# Define the SEIR model
class SEIRModel:
    def __init__(self, beta, sigma, gamma, S0, E0, I0, R0):
        self.beta = beta  # Infection rate
        self.sigma = sigma  # Rate of progression from exposed to infectious
        self.gamma = gamma  # Recovery rate
        self.S = S0  # Initial susceptible population
        self.E = E0  # Initial exposed population
        self.I = I0  # Initial infectious population
        self.R = R0  # Initial recovered population

    def derivatives(self, S, E, I, R):
        N = S + E + I + R
        dSdt = -self.beta * S * I / N
        dEdt = self.beta * S * I / N - self.sigma * E
        dIdt = self.sigma * E - self.gamma * I
        dRdt = self.gamma * I
        return dSdt, dEdt, dIdt, dRdt

    def rk4_step(self, S, E, I, R, dt):
        dS1, dE1, dI1, dR1 = self.derivatives(S, E, I, R)
        dS2, dE2, dI2, dR2 = self.derivatives(S + dS1 * dt / 2, E + dE1 * dt / 2, I + dI1 * dt / 2, R + dR1 * dt / 2)
        dS3, dE3, dI3, dR3 = self.derivatives(S + dS2 * dt / 2, E + dE2 * dt / 2, I + dI2 * dt / 2, R + dR2 * dt / 2)
        dS4, dE4, dI4, dR4 = self.derivatives(S + dS3 * dt, E + dE3 * dt, I + dI3 * dt, R + dR3 * dt)
        S_next = S + (dS1 + 2 * dS2 + 2 * dS3 + dS4) * dt / 6
        E_next = E + (dE1 + 2 * dE2 + 2 * dE3 + dE4) * dt / 6
        I_next = I + (dI1 + 2 * dI2 + 2 * dI3 + dI4) * dt / 6
        R_next = R + (dR1 + 2 * dR2 + 2 * dR3 + dR4) * dt / 6
        return S_next, E_next, I_next, R_next

    def run(self, days, dt):
        times = np.arange(0, days, dt)
        results = np.zeros((len(times), 4))
        S, E, I, R = self.S, self.E, self.I, self.R
        for i, t in enumerate(times):
            results[i] = S, E, I, R
            S, E, I, R = self.rk4_step(S, E, I, R, dt)
        return times, results

# Example usage
if __name__ == '__main__':
    beta = 0.3
    sigma = 0.1
    gamma = 0.05
    S0 = 990
    E0 = 10
    I0 = 0
    R0 = 0
    days = 160
    dt = 0.1

    model = SEIRModel(beta, sigma, gamma, S0, E0, I0, R0)
    times, results = model.run(days, dt)

    import matplotlib.pyplot as plt

    plt.plot(times, results[:, 0], label='Susceptible')
    plt.plot(times, results[:, 1], label='Exposed')
    plt.plot(times, results[:, 2], label='Infectious')
    plt.plot(times, results[:, 3], label='Recovered')
    plt.xlabel('Time (days)')
    plt.ylabel('Population')
    plt.legend()
    plt.show()
