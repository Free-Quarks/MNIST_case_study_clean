import numpy as np
import matplotlib.pyplot as plt

class SEIRHDModel:
    def __init__(self, beta, sigma, gamma, delta, mu, N, E0, I0, R0, H0, D0, S0=None):
        self.beta = beta
        self.sigma = sigma
        self.gamma = gamma
        self.delta = delta
        self.mu = mu
        self.N = N
        self.S0 = S0 if S0 is not None else N - E0 - I0 - R0 - H0 - D0
        self.E0 = E0
        self.I0 = I0
        self.R0 = R0
        self.H0 = H0
        self.D0 = D0

    def deriv(self, S, E, I, R, H, D, N, beta, sigma, gamma, delta, mu):
        dSdt = -beta * S * I / N
        dEdt = beta * S * I / N - sigma * E
        dIdt = sigma * E - gamma * I - delta * I
        dRdt = gamma * I
        dHdt = delta * I - mu * H
        dDdt = mu * H
        return dSdt, dEdt, dIdt, dRdt, dHdt, dDdt

    def runge_kutta_3(self, S, E, I, R, H, D, N, beta, sigma, gamma, delta, mu, dt):
        k1 = self.deriv(S, E, I, R, H, D, N, beta, sigma, gamma, delta, mu)
        k2 = self.deriv(S + dt / 2 * k1[0], E + dt / 2 * k1[1], I + dt / 2 * k1[2], R + dt / 2 * k1[3], H + dt / 2 * k1[4], D + dt / 2 * k1[5], N, beta, sigma, gamma, delta, mu)
        k3 = self.deriv(S - dt * k1[0] + 2 * dt * k2[0], E - dt * k1[1] + 2 * dt * k2[1], I - dt * k1[2] + 2 * dt * k2[2], R - dt * k1[3] + 2 * dt * k2[3], H - dt * k1[4] + 2 * dt * k2[4], D - dt * k1[5] + 2 * dt * k2[5], N, beta, sigma, gamma, delta, mu)

        S_next = S + dt * (k1[0] + 4 * k2[0] + k3[0]) / 6
        E_next = E + dt * (k1[1] + 4 * k2[1] + k3[1]) / 6
        I_next = I + dt * (k1[2] + 4 * k2[2] + k3[2]) / 6
        R_next = R + dt * (k1[3] + 4 * k2[3] + k3[3]) / 6
        H_next = H + dt * (k1[4] + 4 * k2[4] + k3[4]) / 6
        D_next = D + dt * (k1[5] + 4 * k2[5] + k3[5]) / 6

        return S_next, E_next, I_next, R_next, H_next, D_next

    def run(self, days, dt):
        S, E, I, R, H, D = [self.S0], [self.E0], [self.I0], [self.R0], [self.H0], [self.D0]
        for _ in range(int(days / dt)):
            S_new, E_new, I_new, R_new, H_new, D_new = self.runge_kutta_3(S[-1], E[-1], I[-1], R[-1], H[-1], D[-1], self.N, self.beta, self.sigma, self.gamma, self.delta, self.mu, dt)
            S.append(S_new)
            E.append(E_new)
            I.append(I_new)
            R.append(R_new)
            H.append(H_new)
            D.append(D_new)
        return np.array(S), np.array(E), np.array(I), np.array(R), np.array(H), np.array(D)

# Example usage
beta = 0.3
sigma = 1/5.2
gamma = 1/2.9
delta = 1/5.0
mu = 1/10.0
N = 1000
E0 = 1
I0 = 1
R0 = 0
H0 = 0
D0 = 0
model = SEIRHDModel(beta, sigma, gamma, delta, mu, N, E0, I0, R0, H0, D0)
days = 160
dt = 0.1
S, E, I, R, H, D = model.run(days, dt)

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(S, label='Susceptible')
plt.plot(E, label='Exposed')
plt.plot(I, label='Infected')
plt.plot(R, label='Recovered')
plt.plot(H, label='Hospitalized')
plt.plot(D, label='Deceased')
plt.xlabel('Days')
plt.ylabel('Number of individuals')
plt.legend()
plt.title('SEIRHD Model Simulation using RK3')
plt.show()
