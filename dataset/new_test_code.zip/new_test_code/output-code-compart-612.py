import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# SEIRD model differential equations.
def deriv(y, t, N, beta, gamma, delta, alpha):
    S, E, I, R, D = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - delta * E
    dIdt = delta * E - gamma * I - alpha * I
    dRdt = gamma * I
    dDdt = alpha * I
    return dSdt, dEdt, dIdt, dRdt, dDdt

# Initial number of infected and exposed individuals, recovered individuals, and dead individuals.
I0, E0, R0, D0 = 1, 0, 0, 0
# Everyone else, S0, is susceptible to infection initially.
S0 = 999
# Total population, N.
N = S0 + E0 + I0 + R0 + D0
# Contact rate, beta, mean recovery rate, gamma, mean incubation rate, delta, and mortality rate, alpha
beta, gamma, delta, alpha = 0.3, 1./10, 1./5.2, 0.02
# A grid of time points (in days)
t = np.linspace(0, 160, 160)
# Initial conditions vector
y0 = S0, E0, I0, R0, D0
# Integrate the SEIRD equations over the time grid, t.
ret = odeint(deriv, y0, t, args=(N, beta, gamma, delta, alpha))
S, E, I, R, D = ret.T
# Plot the data on three separate curves for S(t), I(t) and R(t)
fig = plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.plot(t, D, 'k', alpha=0.7, linewidth=2, label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Number')
plt.ylim(0, 1000)
plt.legend(loc='best')
plt.title('SEIRD Model')
plt.grid(True)
plt.show()
