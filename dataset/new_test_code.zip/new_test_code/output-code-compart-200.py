import numpy as np
import matplotlib.pyplot as plt

# SEIRHD model parameters
params = {
    'beta': 0.3,  # Transmission rate
    'sigma': 1/5.2,  # Rate of progression from exposed to infectious (1/incubation period)
    'gamma': 1/2.9,  # Recovery rate (1/infectious period)
    'delta': 0.01,  # Death rate
    'rho': 0.1,  # Hospitalization rate
    'alpha': 0.05   # Rate of progression from hospitalized to death
}

# Initial conditions
init_conditions = {
    'S': 990,
    'E': 10,
    'I': 0,
    'R': 0,
    'H': 0,
    'D': 0
}

# Time points
t = np.linspace(0, 160, 160)

# SEIRHD model differential equations
def deriv(y, t, params):
    S, E, I, R, H, D = y
    N = S + E + I + R + H + D
    dSdt = -params['beta'] * S * I / N
    dEdt = params['beta'] * S * I / N - params['sigma'] * E
    dIdt = params['sigma'] * E - params['gamma'] * I - params['delta'] * I - params['rho'] * I
    dRdt = params['gamma'] * I
    dHdt = params['rho'] * I - params['alpha'] * H
    dDdt = params['delta'] * I + params['alpha'] * H
    return dSdt, dEdt, dIdt, dRdt, dHdt, dDdt

# Runge-Kutta 4th order method (RK4)
def rk4_step(func, y, t, dt, params):
    k1 = np.array(func(y, t, params)) * dt
    k2 = np.array(func(y + 0.5 * k1, t + 0.5 * dt, params)) * dt
    k3 = np.array(func(y + 0.5 * k2, t + 0.5 * dt, params)) * dt
    k4 = np.array(func(y + k3, t + dt, params)) * dt
    return y + (k1 + 2*k2 + 2*k3 + k4) / 6

# Initialize arrays
S, E, I, R, H, D = [init_conditions['S']], [init_conditions['E']], [init_conditions['I']], [init_conditions['R']], [init_conditions['H']], [init_conditions['D']]

# Time step
dt = t[1] - t[0]

# Simulation loop
for i in range(1, len(t)):
    y = S[-1], E[-1], I[-1], R[-1], H[-1], D[-1]
    y_next = rk4_step(deriv, y, t[i-1], dt, params)
    S.append(y_next[0])
    E.append(y_next[1])
    I.append(y_next[2])
    R.append(y_next[3])
    H.append(y_next[4])
    D.append(y_next[5])

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.plot(t, H, label='Hospitalized')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.title('SEIRHD Model Simulation')
plt.legend()
plt.grid()
plt.show()

