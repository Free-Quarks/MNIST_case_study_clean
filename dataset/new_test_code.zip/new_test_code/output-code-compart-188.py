import numpy as np
import matplotlib.pyplot as plt

# SEIRD model parameters
beta = 0.3  # infection rate
sigma = 0.1  # rate of progression from exposed to infectious
gamma = 0.05  # recovery rate
mu = 0.01  # mortality rate

# Initial conditions
S0 = 0.99  # initial proportion of susceptible individuals
E0 = 0.01  # initial proportion of exposed individuals
I0 = 0.0  # initial proportion of infectious individuals
R0 = 0.0  # initial proportion of recovered individuals
D0 = 0.0  # initial proportion of deceased individuals

# Time parameters
t_max = 160  # total time in days
dt = 1.0  # time step

# Time vector
T = np.arange(0, t_max, dt)

# Initialize arrays to store results
S = np.zeros(len(T))
E = np.zeros(len(T))
I = np.zeros(len(T))
R = np.zeros(len(T))
D = np.zeros(len(T))

# Set initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
D[0] = D0

# Runge-Kutta 2nd order method (RK2)
def rk2_step(f, y, t, dt):
    k1 = f(y, t)
    k2 = f(y + dt * k1, t + dt)
    return y + (dt / 2) * (k1 + k2)

# SEIRD model differential equations
def seird_ode(y, t):
    S, E, I, R, D = y
    dSdt = -beta * S * I
    dEdt = beta * S * I - sigma * E
    dIdt = sigma * E - (gamma + mu) * I
    dRdt = gamma * I
    dDdt = mu * I
    return np.array([dSdt, dEdt, dIdt, dRdt, dDdt])

# Solve SEIRD model using RK2
for i in range(1, len(T)):
    y = np.array([S[i-1], E[i-1], I[i-1], R[i-1], D[i-1]])
    y_next = rk2_step(seird_ode, y, T[i-1], dt)
    S[i], E[i], I[i], R[i], D[i] = y_next

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(T, S, label='Susceptible')
plt.plot(T, E, label='Exposed')
plt.plot(T, I, label='Infectious')
plt.plot(T, R, label='Recovered')
plt.plot(T, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of Population')
plt.title('SEIRD Model Simulation')
plt.legend()
plt.grid(True)
plt.show()
