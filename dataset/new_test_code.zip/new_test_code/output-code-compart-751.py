import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
S0 = 0.99  # Initial susceptible fraction
I0 = 0.01  # Initial infected fraction
R0 = 0.0  # Initial recovered fraction

# Time parameters
t_max = 160  # Maximum time
dt = 0.1  # Time step

# Time array
t = np.arange(0, t_max, dt)

# Initialize arrays
S = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

# Initial conditions
S[0] = S0
I[0] = I0
R[0] = R0

# Euler's method to solve the SIR model
def SIR_model(S, I, R, beta, gamma, dt):
    dS_dt = -beta * S * I
    dI_dt = beta * S * I - gamma * I
    dR_dt = gamma * I
    S_next = S + dS_dt * dt
    I_next = I + dI_dt * dt
    R_next = R + dR_dt * dt
    return S_next, I_next, R_next

# Time integration using Euler's method
for i in range(1, len(t)):
    S[i], I[i], R[i] = SIR_model(S[i-1], I[i-1], R[i-1], beta, gamma, dt)

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Fraction of Population')
plt.title('SIR Model Simulation using Euler Method')
plt.legend()
plt.grid()
plt.show()
