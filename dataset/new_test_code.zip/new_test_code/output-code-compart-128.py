import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3   # Infection rate
gamma = 0.1  # Recovery rate
S0 = 0.99    # Initial susceptible fraction
I0 = 0.01    # Initial infected fraction
R0 = 0.0     # Initial recovered fraction

# Time parameters
T = 160    # Total time
dt = 0.1  # Time step

# Number of time steps
N = int(T / dt)

# Initialize arrays
S = np.zeros(N)
I = np.zeros(N)
R = np.zeros(N)

t = np.linspace(0, T, N)

# Initial conditions
S[0] = S0
I[0] = I0
R[0] = R0

# Runge-Kutta 2nd order (RK2) method
for n in range(N-1):
    # Calculate k1 values
    k1S = -beta * S[n] * I[n]
    k1I = beta * S[n] * I[n] - gamma * I[n]
    k1R = gamma * I[n]

    # Predictor step
    S_half = S[n] + k1S * dt / 2
    I_half = I[n] + k1I * dt / 2
    R_half = R[n] + k1R * dt / 2

    # Calculate k2 values
    k2S = -beta * S_half * I_half
    k2I = beta * S_half * I_half - gamma * I_half
    k2R = gamma * I_half

    # Corrector step
    S[n+1] = S[n] + k2S * dt
    I[n+1] = I[n] + k2I * dt
    R[n+1] = R[n] + k2R * dt

# Plot the results
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Fraction of Population')
plt.legend()
plt.title('SIR Model with RK2 Method')
plt.show()
