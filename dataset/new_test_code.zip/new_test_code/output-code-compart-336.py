# SEIRD Model using Euler's Method
import numpy as np
import matplotlib.pyplot as plt

def seird_euler(S0, E0, I0, R0, D0, beta, sigma, gamma, mu, days, dt=1):
    # Total population, N.
    N = S0 + E0 + I0 + R0 + D0

    # Initialize arrays to store results
    S = np.zeros(days)
    E = np.zeros(days)
    I = np.zeros(days)
    R = np.zeros(days)
    D = np.zeros(days)

    # Initial values
    S[0] = S0
    E[0] = E0
    I[0] = I0
    R[0] = R0
    D[0] = D0

    # Time steps
    t = np.linspace(0, days-1, days)

    for i in range(1, days):
        dS = -beta * S[i-1] * I[i-1] / N
        dE = beta * S[i-1] * I[i-1] / N - sigma * E[i-1]
        dI = sigma * E[i-1] - gamma * I[i-1] - mu * I[i-1]
        dR = gamma * I[i-1]
        dD = mu * I[i-1]

        S[i] = S[i-1] + dS * dt
        E[i] = E[i-1] + dE * dt
        I[i] = I[i-1] + dI * dt
        R[i] = R[i-1] + dR * dt
        D[i] = D[i-1] + dD * dt

    return t, S, E, I, R, D

# Example parameters
S0 = 990
E0 = 0
I0 = 10
R0 = 0
D0 = 0
beta = 0.3
sigma = 0.1
gamma = 0.05
mu = 0.01
days = 160

# Run the model
results = seird_euler(S0, E0, I0, R0, D0, beta, sigma, gamma, mu, days)

# Plot the results
t, S, E, I, R, D = results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, D, label='Deceased')
plt.xlabel('Days')
plt.ylabel('Number of People')
plt.legend()
plt.title('SEIRD Model Simulation')
plt.grid(True)
plt.show()
