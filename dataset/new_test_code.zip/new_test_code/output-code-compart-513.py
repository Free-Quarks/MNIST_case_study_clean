# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model
class SEIRDModel:
    def __init__(self, beta, sigma, gamma, mu, delta, S0, E0, I0, R0, D0, t):
        self.beta = beta   # Infection rate
        self.sigma = sigma # Incubation rate
        self.gamma = gamma # Recovery rate
        self.mu = mu       # Mortality rate
        self.delta = delta # Disease-induced death rate
        self.S0 = S0       # Initial susceptible population
        self.E0 = E0       # Initial exposed population
        self.I0 = I0       # Initial infected population
        self.R0 = R0       # Initial recovered population
        self.D0 = D0       # Initial deceased population
        self.t = t         # Time period

    def derivatives(self, y, t):
        S, E, I, R, D = y
        dS_dt = -self.beta * S * I
        dE_dt = self.beta * S * I - self.sigma * E
        dI_dt = self.sigma * E - self.gamma * I - self.delta * I
        dR_dt = self.gamma * I
        dD_dt = self.delta * I
        return dS_dt, dE_dt, dI_dt, dR_dt, dD_dt

    def run(self):
        S, E, I, R, D = [self.S0], [self.E0], [self.I0], [self.R0], [self.D0]
        dt = self.t[1] - self.t[0]
        for i in range(1, len(self.t)):
            y = S[-1], E[-1], I[-1], R[-1], D[-1]
            k1 = np.array(self.derivatives(y, self.t[i-1]))
            y_temp = y + 0.5 * dt * k1
            k2 = np.array(self.derivatives(y_temp, self.t[i-1] + 0.5 * dt))
            S_new = S[-1] + dt * k2[0]
            E_new = E[-1] + dt * k2[1]
            I_new = I[-1] + dt * k2[2]
            R_new = R[-1] + dt * k2[3]
            D_new = D[-1] + dt * k2[4]
            S.append(S_new)
            E.append(E_new)
            I.append(I_new)
            R.append(R_new)
            D.append(D_new)
        return np.array(S), np.array(E), np.array(I), np.array(R), np.array(D)

# Parameters
beta = 0.3
sigma = 0.1
gamma = 0.05
mu = 0.01
delta = 0.02
S0 = 0.99
E0 = 0.01
I0 = 0.0
R0 = 0.0
D0 = 0.0
t = np.linspace(0, 160, 160)

# Run the model
model = SEIRDModel(beta, sigma, gamma, mu, delta, S0, E0, I0, R0, D0, t)
S, E, I, R, D = model.run()

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.title('SEIRD Model Simulation')
plt.legend()
plt.show()
