# SEIRD Model using Runge-Kutta 3rd Order (RK3)
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Rate of progression from exposed to infectious
gamma = 0.05  # Recovery rate
mu = 0.01  # Mortality rate

# Initial conditions
S0 = 0.99  # Initial susceptible population
E0 = 0.01  # Initial exposed population
I0 = 0.0  # Initial infectious population
R0 = 0.0  # Initial recovered population
D0 = 0.0  # Initial deceased population

# Time parameters
T = 160  # Total time
dt = 0.1  # Time step

# Initialize arrays
S = [S0]
E = [E0]
I = [I0]
R = [R0]
D = [D0]
t = [0]

# SEIRD model equations
def SEIRD(S, E, I, R, D, beta, sigma, gamma, mu):
    dSdt = -beta * S * I
    dEdt = beta * S * I - sigma * E
    dIdt = sigma * E - gamma * I - mu * I
    dRdt = gamma * I
    dDdt = mu * I
    return dSdt, dEdt, dIdt, dRdt, dDdt

# Runge-Kutta 3rd Order (RK3) implementation
def RK3_step(S, E, I, R, D, beta, sigma, gamma, mu, dt):
    k1_S, k1_E, k1_I, k1_R, k1_D = SEIRD(S, E, I, R, D, beta, sigma, gamma, mu)
    k2_S, k2_E, k2_I, k2_R, k2_D = SEIRD(S + k1_S * dt / 2, E + k1_E * dt / 2, I + k1_I * dt / 2, R + k1_R * dt / 2, D + k1_D * dt / 2, beta, sigma, gamma, mu)
    k3_S, k3_E, k3_I, k3_R, k3_D = SEIRD(S - k1_S * dt + 2 * k2_S * dt, E - k1_E * dt + 2 * k2_E * dt, I - k1_I * dt + 2 * k2_I * dt, R - k1_R * dt + 2 * k2_R * dt, D - k1_D * dt + 2 * k2_D * dt, beta, sigma, gamma, mu)
    S_new = S + (dt / 6) * (k1_S + 4 * k2_S + k3_S)
    E_new = E + (dt / 6) * (k1_E + 4 * k2_E + k3_E)
    I_new = I + (dt / 6) * (k1_I + 4 * k2_I + k3_I)
    R_new = R + (dt / 6) * (k1_R + 4 * k2_R + k3_R)
    D_new = D + (dt / 6) * (k1_D + 4 * k2_D + k3_D)
    return S_new, E_new, I_new, R_new, D_new

# Time-stepping loop
while t[-1] < T:
    S_new, E_new, I_new, R_new, D_new = RK3_step(S[-1], E[-1], I[-1], R[-1], D[-1], beta, sigma, gamma, mu, dt)
    S.append(S_new)
    E.append(E_new)
    I.append(I_new)
    R.append(R_new)
    D.append(D_new)
    t.append(t[-1] + dt)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time')
plt.ylabel('Proportion of Population')
plt.title('SEIRD Model using Runge-Kutta 3rd Order (RK3)')
plt.legend()
plt.show()
