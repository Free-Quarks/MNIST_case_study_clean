import numpy as np
import matplotlib.pyplot as plt

# SIR model parameters
beta = 0.3  # infection rate
gamma = 0.1  # recovery rate

# Initial conditions
S0 = 0.99  # initial susceptible proportion
I0 = 0.01  # initial infected proportion
R0 = 0.0   # initial recovered proportion

# Time parameters
T = 160  # total time
dt = 0.1 # time step

# Time vector
time = np.arange(0, T, dt)

# Initialize arrays
S = np.zeros(len(time))
I = np.zeros(len(time))
R = np.zeros(len(time))

# Set initial conditions
S[0] = S0
I[0] = I0
R[0] = R0

# Runge-Kutta 2nd order method
for t in range(1, len(time)):
    k1_S = -beta * S[t-1] * I[t-1]
    k1_I = beta * S[t-1] * I[t-1] - gamma * I[t-1]
    k1_R = gamma * I[t-1]
    
    S_half = S[t-1] + k1_S * dt/2
    I_half = I[t-1] + k1_I * dt/2
    R_half = R[t-1] + k1_R * dt/2
    
    k2_S = -beta * S_half * I_half
    k2_I = beta * S_half * I_half - gamma * I_half
    k2_R = gamma * I_half
    
    S[t] = S[t-1] + k2_S * dt
    I[t] = I[t-1] + k2_I * dt
    R[t] = R[t-1] + k2_R * dt

# Plot results
plt.figure(figsize=(10,6))
plt.plot(time, S, label='Susceptible')
plt.plot(time, I, label='Infected')
plt.plot(time, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.title('SIR Model using Runge-Kutta 2nd Order Method')
plt.grid()
plt.show()
