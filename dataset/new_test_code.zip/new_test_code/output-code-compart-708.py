# Incorrect SEIR model using RK2 method

import numpy as np
import matplotlib.pyplot as plt

# Parameters
delta_t = 0.1  # Time step
total_time = 160  # Total simulation time

beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
sigma = 0.2  # Rate of progression from exposed to infectious

# Initial conditions
S0 = 0.99  # Initial proportion of susceptible individuals
E0 = 0.01  # Initial proportion of exposed individuals
I0 = 0.0   # Initial proportion of infectious individuals
R0 = 0.0   # Initial proportion of recovered individuals

# Initialize arrays to store results
t = np.arange(0, total_time, delta_t)
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

# Set initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# Define SEIR model equations
def SEIR(S, E, I, R):
    dS = -beta * S * I
    dE = beta * S * I - sigma * E
    dI = sigma * E - gamma * I
    dR = gamma * I
    return dS, dE, dI, dR

# RK2 method simulation
for i in range(1, len(t)):
    # Compute k1 values
    k1S, k1E, k1I, k1R = SEIR(S[i-1], E[i-1], I[i-1], R[i-1])
    
    # Incorrectly calculate the midpoint step
    S_mid = S[i-1] + k1S * delta_t
    E_mid = E[i-1] + k1E * delta_t
    I_mid = I[i-1] + k1I * delta_t
    R_mid = R[i-1] + k1R * delta_t
    
    # Compute k2 values at the midpoint
    k2S, k2E, k2I, k2R = SEIR(S_mid, E_mid, I_mid, R_mid)
    
    # Incorrectly update the next values using k2
    S[i] = S[i-1] + k2S * delta_t
    E[i] = E[i-1] + k2E * delta_t
    I[i] = I[i-1] + k2I * delta_t
    R[i] = R[i-1] + k2R * delta_t

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion of Population')
plt.legend()
plt.title('Incorrect SEIR Model using RK2 Method')
plt.show()
