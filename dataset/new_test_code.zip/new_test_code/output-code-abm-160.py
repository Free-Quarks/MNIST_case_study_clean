# Import necessary libraries
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import random

# Initialize parameters
population_size = 1000
initial_infected = 10
transmission_probability = 0.05
recovery_time = 14
gender_ratio = 0.5  # Ratio of males in the population

# Define states
SUSCEPTIBLE = 'S'
INFECTED = 'I'
RECOVERED = 'R'

# Create a graph
G = nx.erdos_renyi_graph(population_size, 0.1)

# Assign gender and initial states
for node in G.nodes:
    G.nodes[node]['gender'] = 'M' if random.random() < gender_ratio else 'F'
    G.nodes[node]['state'] = SUSCEPTIBLE
    G.nodes[node]['days_infected'] = 0

# Infect initial individuals
initial_infected_nodes = random.sample(G.nodes, initial_infected)
for node in initial_infected_nodes:
    G.nodes[node]['state'] = INFECTED
    G.nodes[node]['days_infected'] = 0

# Function to simulate a day
def simulate_day(G):
    new_infections = []
    for node in G.nodes:
        if G.nodes[node]['state'] == INFECTED:
            G.nodes[node]['days_infected'] += 1
            if G.nodes[node]['days_infected'] > recovery_time:
                G.nodes[node]['state'] = RECOVERED
            else:
                neighbors = list(G.neighbors(node))
                for neighbor in neighbors:
                    if G.nodes[neighbor]['state'] == SUSCEPTIBLE and random.random() < transmission_probability:
                        new_infections.append(neighbor)
    for node in new_infections:
        G.nodes[node]['state'] = INFECTED
        G.nodes[node]['days_infected'] = 0

# Simulate the epidemic
num_days = 60
susceptible_counts = []
infected_counts = []
recovered_counts = []

for day in range(num_days):
    susceptible_count = sum(1 for node in G.nodes if G.nodes[node]['state'] == SUSCEPTIBLE)
    infected_count = sum(1 for node in G.nodes if G.nodes[node]['state'] == INFECTED)
    recovered_count = sum(1 for node in G.nodes if G.nodes[node]['state'] == RECOVERED)
    susceptible_counts.append(susceptible_count)
    infected_counts.append(infected_count)
    recovered_counts.append(recovered_count)
    simulate_day(G)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(susceptible_counts, label='Susceptible')
plt.plot(infected_counts, label='Infected')
plt.plot(recovered_counts, label='Recovered')
plt.xlabel('Days')
plt.ylabel('Number of Individuals')
plt.legend()
plt.title('COVID-19 Simulation with Gender Stratification')
plt.show()
