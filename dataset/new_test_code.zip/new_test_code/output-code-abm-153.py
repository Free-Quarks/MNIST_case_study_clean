# Agent-based model to simulate COVID-19 with stratification
import random
import matplotlib.pyplot as plt

class Person:
    def __init__(self, age_group, initial_status='Susceptible'):
        self.age_group = age_group
        self.status = initial_status

    def infect(self):
        if self.status == 'Susceptible':
            self.status = 'Infected'

    def recover_or_die(self):
        if self.status == 'Infected':
            # Simplified recovery or death based on age group
            if self.age_group == 'elderly':
                self.status = 'Dead' if random.random() < 0.2 else 'Recovered'
            else:
                self.status = 'Dead' if random.random() < 0.01 else 'Recovered'

class Population:
    def __init__(self, size, stratification):
        self.people = []
        for age_group, proportion in stratification.items():
            num_people = int(size * proportion)
            self.people.extend([Person(age_group) for _ in range(num_people)])

    def spread_infection(self, transmission_rate):
        for person in self.people:
            if person.status == 'Infected':
                for other_person in self.people:
                    if other_person.status == 'Susceptible':
                        if random.random() < transmission_rate:
                            other_person.infect()

    def update_statuses(self):
        for person in self.people:
            person.recover_or_die()

    def count_statuses(self):
        status_counts = {'Susceptible': 0, 'Infected': 0, 'Recovered': 0, 'Dead': 0}
        for person in self.people:
            status_counts[person.status] += 1
        return status_counts

# Parameters
population_size = 1000
stratification = {'children': 0.2, 'adults': 0.6, 'elderly': 0.2}
initial_infected = 10
transmission_rate = 0.1
num_days = 100

# Initialize population
population = Population(population_size, stratification)

# Infect initial people
initial_infections = random.sample(population.people, initial_infected)
for person in initial_infections:
    person.infect()

# Simulation
status_history = []
for day in range(num_days):
    population.spread_infection(transmission_rate)
    population.update_statuses()
    status_counts = population.count_statuses()
    status_history.append(status_counts)
    print(f"Day {day + 1}: {status_counts}")

# Plotting results
susceptible_counts = [day['Susceptible'] for day in status_history]
infected_counts = [day['Infected'] for day in status_history]
recovered_counts = [day['Recovered'] for day in status_history]
dead_counts = [day['Dead'] for day in status_history]

plt.figure(figsize=(10, 6))
plt.plot(susceptible_counts, label='Susceptible')
plt.plot(infected_counts, label='Infected')
plt.plot(recovered_counts, label='Recovered')
plt.plot(dead_counts, label='Dead')
plt.xlabel('Days')
plt.ylabel('Number of People')
plt.title('COVID-19 Simulation')
plt.legend()
plt.show()
