import numpy as np

# Define the SIR model
class SIRModel:
    def __init__(self, beta, gamma):
        self.beta = beta
        self.gamma = gamma

    def derivatives(self, y, t):
        S, I, R = y
        dSdt = -self.beta * S * I
        dIdt = self.beta * S * I - self.gamma * I
        dRdt = self.gamma * I
        return np.array([dSdt, dIdt, dRdt])

# Runge-Kutta 4th order method
class RK4Solver:
    def __init__(self, model, dt):
        self.model = model
        self.dt = dt

    def step(self, y, t):
        k1 = self.model.derivatives(y, t)
        k2 = self.model.derivatives(y + 0.5 * self.dt * k1, t + 0.5 * self.dt)
        k3 = self.model.derivatives(y + 0.5 * self.dt * k2, t + 0.5 * self.dt)
        k4 = self.model.derivatives(y + self.dt * k3, t + self.dt)
        return y + (self.dt / 6) * (k1 + 2 * k2 + 2 * k3 + k4)

# Initialize parameters
beta = 0.3
alpha = 0.1
initial_conditions = [0.99, 0.01, 0.0]

# Instantiate the model and solver
sir_model = SIRModel(beta, alpha)
dl_solver = RK4Solver(sir_model, 0.01)

# Time vector
t = np.linspace(0, 160, 16000)

# Solve the system
results = np.zeros((len(t), 3))
results[0] = initial_conditions

for i in range(1, len(t)):
    results[i] = dl_solver.step(results[i - 1], t[i - 1])

# Print the results
print(results)
