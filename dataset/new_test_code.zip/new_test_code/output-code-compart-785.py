import numpy as np
import matplotlib.pyplot as plt

# Define the SEIR model
def SEIR_model(y, beta, sigma, gamma):
    S, E, I, R = y
    N = S + E + I + R
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt])

# Runge-Kutta 4th order method
def RK4_step(f, y, dt, *args):
    k1 = dt * f(y, *args)
    k2 = dt * f(y + 0.5 * k1, *args)
    k3 = dt * f(y + 0.5 * k2, *args)
    k4 = dt * f(y + k3, *args)
    return y + (k1 + 2 * k2 + 2 * k3 + k4) / 6

# Simulation parameters
beta = 0.3  # infection rate
sigma = 1/5.1  # incubation rate
gamma = 1/10  # recovery rate
days = 160  # number of days to simulate
dt = 1  # time step (1 day)

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
y0 = np.array([S0, E0, I0, R0])

# Time points
t = np.arange(0, days, dt)

# Initialize arrays to store results
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

# Set initial values
S[0], E[0], I[0], R[0] = y0

# Run the simulation
for i in range(1, len(t)):
    y0 = RK4_step(SEIR_model, y0, dt, beta, sigma, gamma)
    S[i], E[i], I[i], R[i] = y0

# Plot the results
plt.figure(figsize=(12, 8))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Days')
plt.ylabel('Population')
plt.legend()
plt.title('SEIR Model Simulation')
plt.show()
