# This Python script simulates the SIDARTHE model using the Euler method.

import numpy as np
import matplotlib.pyplot as plt

# Time parameters
t = 0
T = 160  # Total number of days
dt = 1  # Time step

# Model parameters
alpha = 0.2  # Rate of susceptible becoming infected
beta = 0.1  # Rate of infected becoming diagnosed
sigma = 0.05  # Rate of diagnosed becoming ailing
rho = 0.03  # Rate of ailing becoming recognized
mu = 0.01  # Rate of recognized becoming threatened
nu = 0.005  # Rate of threatened becoming healed
phi = 0.002  # Rate of threatened becoming extinct

# Initial conditions
S = 0.99  # Susceptible
I = 0.01  # Infected
D = 0  # Diagnosed
A = 0  # Ailing
R = 0  # Recognized
T = 0  # Threatened
H = 0  # Healed
E = 0  # Extinct

# Lists to store results
S_list = [S]
I_list = [I]
D_list = [D]
A_list = [A]
R_list = [R]
T_list = [T]
H_list = [H]
E_list = [E]
t_list = [t]

# Euler method simulation
while t < T:
    dS = -alpha * S * I * dt
    dI = alpha * S * I * dt - beta * I * dt
    dD = beta * I * dt - sigma * D * dt
    dA = sigma * D * dt - rho * A * dt
    dR = rho * A * dt - mu * R * dt
    dT = mu * R * dt - nu * T * dt - phi * T * dt
    dH = nu * T * dt
    dE = phi * T * dt

    S += dS
    I += dI
    D += dD
    A += dA
    R += dR
    T += dT
    H += dH
    E += dE

    t += dt

    S_list.append(S)
    I_list.append(I)
    D_list.append(D)
    A_list.append(A)
    R_list.append(R)
    T_list.append(T)
    H_list.append(H)
    E_list.append(E)
    t_list.append(t)

# Plotting the results
plt.figure(figsize=(12, 8))
plt.plot(t_list, S_list, label='Susceptible')
plt.plot(t_list, I_list, label='Infected')
plt.plot(t_list, D_list, label='Diagnosed')
plt.plot(t_list, A_list, label='Ailing')
plt.plot(t_list, R_list, label='Recognized')
plt.plot(t_list, T_list, label='Threatened')
plt.plot(t_list, H_list, label='Healed')
plt.plot(t_list, E_list, label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of Population')
plt.legend()
plt.title('SIDARTHE Model Simulation')
plt.show()
