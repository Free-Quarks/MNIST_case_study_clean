import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

# Define parameters
total_population = 1000
initial_infected = 10
beta = 0.3  # infection rate
sigma = 0.1  # rate of progression from exposed to infected
gamma = 0.1  # recovery rate

# Stratification: Age groups
age_groups = {
    '0-19': 0.25,
    '20-39': 0.35,
    '40-59': 0.25,
    '60+': 0.15
}

# Create a network
g = nx.erdos_renyi_graph(total_population, 0.1)

# Initialize states
states = {node: 'S' for node in g.nodes()}
initial_infected_nodes = np.random.choice(g.nodes(), initial_infected, replace=False)
for node in initial_infected_nodes:
    states[node] = 'E'

# Assign age groups randomly based on the given distribution
age_group_assignment = np.random.choice(list(age_groups.keys()), total_population, p=list(age_groups.values()))
age_group_dict = {node: age_group_assignment[i] for i, node in enumerate(g.nodes())}

# Simulation parameters
time_steps = 100
results = []

# Simulation loop
for t in range(time_steps):
    new_states = states.copy()
    for node in g.nodes():
        if states[node] == 'S':
            neighbors = list(g.neighbors(node))
            infected_neighbors = [n for n in neighbors if states[n] == 'I']
            if np.random.rand() < 1 - (1 - beta)**len(infected_neighbors):
                new_states[node] = 'E'
        elif states[node] == 'E':
            if np.random.rand() < sigma:
                new_states[node] = 'I'
        elif states[node] == 'I':
            if np.random.rand() < gamma:
                new_states[node] = 'R'

    states = new_states.copy()
    results.append(dict(states))

# Plot results
s_counts = [sum(1 for state in result.values() if state == 'S') for result in results]
e_counts = [sum(1 for state in result.values() if state == 'E') for result in results]
i_counts = [sum(1 for state in result.values() if state == 'I') for result in results]
r_counts = [sum(1 for state in result.values() if state == 'R') for result in results]

time = range(time_steps)
plt.plot(time, s_counts, label='Susceptible')
plt.plot(time, e_counts, label='Exposed')
plt.plot(time, i_counts, label='Infected')
plt.plot(time, r_counts, label='Recovered')
plt.xlabel('Time steps')
plt.ylabel('Number of individuals')
plt.legend()
plt.show()
