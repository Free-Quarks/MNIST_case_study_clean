# SEIRHD model using RK2 method
import numpy as np
import matplotlib.pyplot as plt

# SEIRHD compartments
S, E, I, R, H, D = 0, 1, 2, 3, 4, 5

# Parameters for the model
beta = 0.3  # Infection rate
sigma = 1/5.2  # Incubation rate
gamma = 1/2.9  # Recovery rate
alpha = 0.1  # Hospitalization rate
delta = 0.02  # Death rate

# Total population
N = 1000

# Initial conditions
initial_conditions = [999, 1, 0, 0, 0, 0]

# Time parameters
t_start = 0
t_end = 160
dt = 0.1
n_steps = int((t_end - t_start) / dt)

# SEIRHD model differential equations
def seirhd_deriv(y, t, beta, sigma, gamma, alpha, delta, N):
    S, E, I, R, H, D = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - alpha * I - delta * I
    dRdt = gamma * I
    dHdt = alpha * I
    dDdt = delta * I
    return np.array([dSdt, dEdt, dIdt, dRdt, dHdt, dDdt])

# Runge-Kutta 2nd order method (RK2)
def rk2_step(y, t, dt, derivs, *params):
    k1 = derivs(y, t, *params)
    k2 = derivs(y + dt * k1 / 2, t + dt / 2, *params)
    return y + dt * k2

# Time array
t = np.linspace(t_start, t_end, n_steps)

# Array to store results
y = np.zeros((n_steps, 6))
y[0] = initial_conditions

# Integrate the SEIRHD equations over the time grid, t.
for i in range(1, n_steps):
    y[i] = rk2_step(y[i-1], t[i-1], dt, seirhd_deriv, beta, sigma, gamma, alpha, delta, N)

# Plotting results
plt.figure(figsize=(10,6))
plt.plot(t, y[:, S], label='Susceptible')
plt.plot(t, y[:, E], label='Exposed')
plt.plot(t, y[:, I], label='Infected')
plt.plot(t, y[:, R], label='Recovered')
plt.plot(t, y[:, H], label='Hospitalized')
plt.plot(t, y[:, D], label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Number of people')
plt.title('SEIRHD Model Simulation')
plt.legend()
plt.grid(True)
plt.show()
