import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Rate of progression from exposed to infected
gamma = 0.05  # Recovery rate
mu = 0.01  # Mortality rate

# Time parameters
dt = 0.1
T = 160

# Initial conditions
S0, E0, I0, R0, D0 = 0.99, 0.01, 0.0, 0.0, 0.0

# RK2 method for SEIRD model
def rk2_step(f, y, t, dt):
    k1 = f(y, t)
    k2 = f(y + dt * k1, t + dt)
    return y + (dt / 2) * (k1 + k2)

# SEIRD model equations
def seird_model(y, t):
    S, E, I, R, D = y
    dSdt = -beta * S * I
    dEdt = beta * S * I - sigma * E
    dIdt = sigma * E - gamma * I - mu * I
    dRdt = gamma * I
    dDdt = mu * I
    return np.array([dSdt, dEdt, dIdt, dRdt, dDdt])

# Time vector
t = np.arange(0, T, dt)

# Initialization
Y = np.zeros((len(t), 5))
Y[0] = [S0, E0, I0, R0, D0]

# Time integration using RK2
for i in range(1, len(t)):
    Y[i] = rk2_step(seird_model, Y[i-1], t[i-1], dt)

# Results
S, E, I, R, D = Y.T

# Plotting
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIRD Model Simulation')
plt.grid()
plt.show()
