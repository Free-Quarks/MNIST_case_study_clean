import numpy as np
from scipy.integrate import solve_ivp

# SEIRD model differential equations
def seird_model(t, y, beta, sigma, gamma, delta):
    S, E, I, R, D = y
    N = S + E + I + R + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - delta * I
    dRdt = gamma * I
    dDdt = delta * I
    return [dSdt, dEdt, dIdt, dRdt, dDdt]

# Initial conditions
S0, E0, I0, R0, D0 = 999, 1, 0, 0, 0
initial_conditions = [S0, E0, I0, R0, D0]

# Parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Incubation rate
gamma = 0.1  # Recovery rate
delta = 0.01  # Mortality rate

# Time points (days)
t = np.linspace(0, 160, 160)

# Solve the SEIRD model using Runge-Kutta 3rd order
def rk3_step(f, t, y, h, *args):
    k1 = h * np.array(f(t, y, *args))
    k2 = h * np.array(f(t + h / 2, y + k1 / 2, *args))
    k3 = h * np.array(f(t + h, y - k1 + 2 * k2, *args))
    return y + (k1 + 4 * k2 + k3) / 6

# Time step size
h = t[1] - t[0]

# Initialize solution array
y = np.zeros((len(t), 5))
y[0] = initial_conditions

# Solve the differential equations using RK3
for i in range(1, len(t)):
    y[i] = rk3_step(seird_model, t[i-1], y[i-1], h, beta, sigma, gamma, delta)

# Extract results
S, E, I, R, D = y.T

# Display results
import matplotlib.pyplot as plt
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRD Model Simulation')
plt.grid(True)
plt.show()
