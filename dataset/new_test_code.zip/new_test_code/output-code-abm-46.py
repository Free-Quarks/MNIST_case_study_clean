import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import random

# Parameters
POPULATION_SIZE = 1000
INITIAL_INFECTED = 10
VACCINATION_RATE = 0.01
TRANSMISSION_PROBABILITY = 0.03
RECOVERY_PROBABILITY = 0.1
VACCINE_EFFICACY = 0.95
SIMULATION_DAYS = 100

# State Definitions
SUSCEPTIBLE = 0
INFECTED = 1
RECOVERED = 2
VACCINATED = 3

# Create a network
G = nx.erdos_renyi_graph(POPULATION_SIZE, 0.1)

# Initialize states
states = np.full(POPULATION_SIZE, SUSCEPTIBLE)
initial_infected = random.sample(range(POPULATION_SIZE), INITIAL_INFECTED)
for node in initial_infected:
    states[node] = INFECTED

# Function to simulate one day
def simulate_day(states):
    new_states = states.copy()
    for node in G.nodes():
        if states[node] == INFECTED:
            for neighbor in G.neighbors(node):
                if states[neighbor] == SUSCEPTIBLE and random.random() < TRANSMISSION_PROBABILITY:
                    new_states[neighbor] = INFECTED
            if random.random() < RECOVERY_PROBABILITY:
                new_states[node] = RECOVERED
        elif states[node] == SUSCEPTIBLE and random.random() < VACCINATION_RATE:
            if random.random() < VACCINE_EFFICACY:
                new_states[node] = VACCINATED
    return new_states

# Run the simulation
history = []
for day in range(SIMULATION_DAYS):
    states = simulate_day(states)
    history.append(states.copy())

# Plot results
susceptible_count = [np.sum(day == SUSCEPTIBLE) for day in history]
infected_count = [np.sum(day == INFECTED) for day in history]
recovered_count = [np.sum(day == RECOVERED) for day in history]
vaccinated_count = [np.sum(day == VACCINATED) for day in history]

days = range(SIMULATION_DAYS)
plt.plot(days, susceptible_count, label='Susceptible')
plt.plot(days, infected_count, label='Infected')
plt.plot(days, recovered_count, label='Recovered')
plt.plot(days, vaccinated_count, label='Vaccinated')
plt.xlabel('Days')
plt.ylabel('Number of Individuals')
plt.legend()
plt.show()
