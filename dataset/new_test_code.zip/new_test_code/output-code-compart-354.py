# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Define the SIR model differential equations
def sir_model(y, beta, gamma):
    S, I, R = y
    N = S + I + R
    dSdt = -beta * S * I / N
    dIdt = beta * S * I / N - gamma * I
    dRdt = gamma * I
    return np.array([dSdt, dIdt, dRdt])

# Runge-Kutta 3rd Order Method (RK3)
def rk3_step(f, y0, t0, dt, *args):
    k1 = f(y0, *args)
    k2 = f(y0 + 0.5 * dt * k1, *args)
    k3 = f(y0 - dt * k1 + 2 * dt * k2, *args)
    return y0 + (dt / 6) * (k1 + 4 * k2 + k3)

# Function to simulate the SIR model
def simulate_sir(beta, gamma, S0, I0, R0, dt, T):
    # Initial conditions
    y0 = np.array([S0, I0, R0])
    t = 0
    results = []
    times = []
    
    while t <= T:
        results.append(y0)
        times.append(t)
        y0 = rk3_step(sir_model, y0, t, dt, beta, gamma)
        t += dt
    
    return np.array(times), np.array(results)

# Parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
S0 = 990  # Initial susceptible population
I0 = 10  # Initial infected population
R0 = 0  # Initial recovered population
dt = 0.1  # Time step
T = 160  # Total time

# Run the simulation
times, results = simulate_sir(beta, gamma, S0, I0, R0, dt, T)

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(times, results[:, 0], label='Susceptible')
plt.plot(times, results[:, 1], label='Infected')
plt.plot(times, results[:, 2], label='Recovered')
plt.xlabel('Time')
plt.ylabel('Population')
plt.legend()
plt.title('SIR Model Simulation using RK3')
plt.grid(True)
plt.show()
