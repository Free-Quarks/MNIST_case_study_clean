# Incorrect SEIRD compartmental model using RK3
import numpy as np

# Define parameters
beta = 0.3  # infection rate
sigma = 0.1  # incubation rate
gamma = 0.05  # recovery rate
delta = 0.01  # death rate

# Define the SEIRD model
class SEIRDModel:
    def __init__(self, S0, E0, I0, R0, D0, beta, sigma, gamma, delta):
        self.S = S0
        self.E = E0
        self.I = I0
        self.R = R0
        self.D = D0
        self.beta = beta
        self.sigma = sigma
        self.gamma = gamma
        self.delta = delta

    def derivatives(self, S, E, I, R, D):
        dSdt = -self.beta * S * I
        dEdt = self.beta * S * I - self.sigma * E
        dIdt = self.sigma * E - self.gamma * I - self.delta * I
        dRdt = self.gamma * I
        dDdt = self.delta * I
        return dSdt, dEdt, dIdt, dRdt, dDdt

    def rk3_step(self, dt):
        k1_S, k1_E, k1_I, k1_R, k1_D = self.derivatives(self.S, self.E, self.I, self.R, self.D)
        k2_S, k2_E, k2_I, k2_R, k2_D = self.derivatives(self.S + 0.5 * dt * k1_S, self.E + 0.5 * dt * k1_E, self.I + 0.5 * dt * k1_I, self.R + 0.5 * dt * k1_R, self.D + 0.5 * dt * k1_D)
        k3_S, k3_E, k3_I, k3_R, k3_D = self.derivatives(self.S - dt * k1_S + 2 * dt * k2_S, self.E - dt * k1_E + 2 * dt * k2_E, self.I - dt * k1_I + 2 * dt * k2_I, self.R - dt * k1_R + 2 * dt * k2_R, self.D - dt * k1_D + 2 * dt * k2_D)

        self.S += dt * (k1_S + 4 * k2_S + k3_S) / 6
        self.E += dt * (k1_E + 4 * k2_E + k3_E) / 6
        self.I += dt * (k1_I + 4 * k2_I + k3_I) / 6
        self.R += dt * (k1_R + 4 * k2_R + k3_R) / 6
        self.D += dt * (k1_D + 4 * k2_D + k3_D) / 6

# Initial conditions
S0, E0, I0, R0, D0 = 0.99, 0.01, 0.0, 0.0, 0.0

# Time step
dt = 0.1

# Instantiate the model
seird_model = SEIRDModel(S0, E0, I0, R0, D0, beta, sigma, gamma, delta)

# Simulate for 100 time steps
for _ in range(100):
    seird_model.rk3_step(dt)
    print(f"S: {seird_model.S:.4f}, E: {seird_model.E:.4f}, I: {seird_model.I:.4f}, R: {seird_model.R:.4f}, D: {seird_model.D:.4f}")
