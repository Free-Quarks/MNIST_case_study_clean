import numpy as np

class SEIRHDModel:
    def __init__(self, S0, E0, I0, R0, H0, D0, beta, sigma, gamma, delta, rho, N):
        self.S = S0
        self.E = E0
        self.I = I0
        self.R = R0
        self.H = H0
        self.D = D0
        self.beta = beta
        self.sigma = sigma
        self.gamma = gamma
        self.delta = delta
        self.rho = rho
        self.N = N

    def derivatives(self, S, E, I, R, H, D):
        dSdt = -self.beta * S * I / self.N
        dEdt = self.beta * S * I / self.N - self.sigma * E
        dIdt = self.sigma * E - (self.gamma + self.delta) * I
        dRdt = self.gamma * I
        dHdt = self.delta * I - self.rho * H
        dDdt = self.rho * H
        return dSdt, dEdt, dIdt, dRdt, dHdt, dDdt

    def runge_kutta_step(self, h):
        k1 = self.derivatives(self.S, self.E, self.I, self.R, self.H, self.D)
        k2 = self.derivatives(self.S + 0.5 * h * k1[0], self.E + 0.5 * h * k1[1], self.I + 0.5 * h * k1[2], self.R + 0.5 * h * k1[3], self.H + 0.5 * h * k1[4], self.D + 0.5 * h * k1[5])
        k3 = self.derivatives(self.S + 0.5 * h * k2[0], self.E + 0.5 * h * k2[1], self.I + 0.5 * h * k2[2], self.R + 0.5 * h * k2[3], self.H + 0.5 * h * k2[4], self.D + 0.5 * h * k2[5])
        k4 = self.derivatives(self.S + h * k3[0], self.E + h * k3[1], self.I + h * k3[2], self.R + h * k3[3], self.H + h * k3[4], self.D + h * k3[5])

        self.S += (k1[0] + 2*k2[0] + 2*k3[0] + k4[0]) * h / 6
        self.E += (k1[1] + 2*k2[1] + 2*k3[1] + k4[1]) * h / 6
        self.I += (k1[2] + 2*k2[2] + 2*k3[2] + k4[2]) * h / 6
        self.R += (k1[3] + 2*k2[3] + 2*k3[3] + k4[3]) * h / 6
        self.H += (k1[4] + 2*k2[4] + 2*k3[4] + k4[4]) * h / 6
        self.D += (k1[5] + 2*k2[5] + 2*k3[5] + k4[5]) * h / 6

    def simulate(self, days, h=1):
        results = []
        for _ in range(days):
            self.runge_kutta_step(h)
            results.append((self.S, self.E, self.I, self.R, self.H, self.D))
        return results

# Example usage
if __name__ == '__main__':
    S0 = 999
    E0 = 1
    I0 = 0
    R0 = 0
    H0 = 0
    D0 = 0
    beta = 0.3
    sigma = 0.1
    gamma = 0.05
    delta = 0.01
    rho = 0.005
    N = S0 + E0 + I0 + R0 + H0 + D0

    model = SEIRHDModel(S0, E0, I0, R0, H0, D0, beta, sigma, gamma, delta, rho, N)
    results = model.simulate(100)
    for day, (S, E, I, R, H, D) in enumerate(results):
        print(f"Day {day}: S={S:.2f}, E={E:.2f}, I={I:.2f}, R={R:.2f}, H={H:.2f}, D={D:.2f}")
