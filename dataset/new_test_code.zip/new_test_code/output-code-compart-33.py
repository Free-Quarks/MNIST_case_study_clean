# SEIR model with RK2 method
import numpy as np
import matplotlib.pyplot as plt

def seir_model(y, beta, gamma, delta):
    S, E, I, R = y
    N = S + E + I + R
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - delta * E
    dIdt = delta * E - gamma * I
    dRdt = gamma * I
    return np.array([dSdt, dEdt, dIdt, dRdt])

def rk2_step(f, y, t, dt, *args):
    k1 = dt * f(y, *args)
    k2 = dt * f(y + 0.5 * k1, *args)
    return y + k2

def run_seir_model(S0, E0, I0, R0, beta, gamma, delta, days, dt=1):
    t = np.linspace(0, days, int(days / dt) + 1)
    y = np.zeros((len(t), 4))
    y[0] = [S0, E0, I0, R0]

    for i in range(1, len(t)):
        y[i] = rk2_step(seir_model, y[i-1], t[i-1], dt, beta, gamma, delta)

    return t, y

# Parameters
S0 = 999
E0 = 1
I0 = 0
R0 = 0
beta = 0.3
gamma = 0.1
delta = 0.1

days = 160

# Run the model
results = run_seir_model(S0, E0, I0, R0, beta, gamma, delta, days)

# Plot the results
t, y = results
plt.plot(t, y[:, 0], label='Susceptible')
plt.plot(t, y[:, 1], label='Exposed')
plt.plot(t, y[:, 2], label='Infected')
plt.plot(t, y[:, 3], label='Recovered')
plt.xlabel('Days')
plt.ylabel('Population')
plt.legend()
plt.show()
