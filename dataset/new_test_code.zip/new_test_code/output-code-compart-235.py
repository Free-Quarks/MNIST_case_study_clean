import numpy as np
import matplotlib.pyplot as plt

# SEIR model parameters
beta = 0.3  # infection rate
sigma = 1/5.2  # incubation rate
gamma = 1/18  # recovery rate

# Initial conditions
S0 = 999  # susceptible individuals
E0 = 1    # exposed individuals
I0 = 0    # infectious individuals
R0 = 0    # recovered individuals

# Time parameters
T = 160  # total time
dt = 0.1  # time step

# Number of steps
steps = int(T/dt)

# SEIR model equations
def seir_model(y, beta, sigma, gamma):
    S, E, I, R = y
    dS_dt = -beta * S * I / (S + E + I + R)
    dE_dt = beta * S * I / (S + E + I + R) - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt])

# Runge-Kutta 4th order method
def rk4_step(y, beta, sigma, gamma, dt):
    k1 = seir_model(y, beta, sigma, gamma)
    k2 = seir_model(y + 0.5*dt*k1, beta, sigma, gamma)
    k3 = seir_model(y + 0.5*dt*k2, beta, sigma, gamma)
    k4 = seir_model(y + dt*k3, beta, sigma, gamma)
    return y + (dt/6)*(k1 + 2*k2 + 2*k3 + k4)

# Initialize arrays to store results
S = np.zeros(steps)
E = np.zeros(steps)
I = np.zeros(steps)
R = np.zeros(steps)
t = np.zeros(steps)

# Initial conditions
S[0], E[0], I[0], R[0] = S0, E0, I0, R0

y = np.array([S0, E0, I0, R0])

# Time evolution
for step in range(1, steps):
    t[step] = step * dt
    y = rk4_step(y, beta, sigma, gamma, dt)
    S[step], E[step], I[step], R[step] = y

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.title('SEIR Model Simulation')
plt.legend()
plt.grid(True)
plt.show()
