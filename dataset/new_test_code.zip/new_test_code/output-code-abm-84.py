import numpy as np
import matplotlib.pyplot as plt
import random

# Define the population size and initial number of infected individuals
population_size = 1000
initial_infected = 10

# Define the probability of transmission and recovery
transmission_probability = 0.1
recovery_probability = 0.05

# Define the number of days for the simulation
num_days = 160

# Define Stratification by Sex
sex_ratio = 0.5  # 50% male, 50% female

# Initialize the population
population = []
for i in range(population_size):
    person = {
        'id': i,
        'sex': 'male' if random.random() < sex_ratio else 'female',
        'state': 'infected' if i < initial_infected else 'susceptible',
        'days_infected': 0
    }
    population.append(person)

# Function to simulate one day of the epidemic

def simulate_day(population):
    new_infections = 0
    recoveries = 0
    for person in population:
        if person['state'] == 'infected':
            # Try to infect others
            for other_person in population:
                if other_person['state'] == 'susceptible':
                    if random.random() < transmission_probability:
                        other_person['state'] = 'infected'
                        new_infections += 1
            # Try to recover
            if random.random() < recovery_probability:
                person['state'] = 'recovered'
                recoveries += 1
            else:
                person['days_infected'] += 1
    return new_infections, recoveries

# Lists to track the number of susceptible, infected, and recovered individuals over time
susceptible_counts = []
infected_counts = []
recovered_counts = []

# Run the simulation
for day in range(num_days):
    susceptible_count = sum(1 for person in population if person['state'] == 'susceptible')
    infected_count = sum(1 for person in population if person['state'] == 'infected')
    recovered_count = sum(1 for person in population if person['state'] == 'recovered')

    susceptible_counts.append(susceptible_count)
    infected_counts.append(infected_count)
    recovered_counts.append(recovered_count)

    new_infections, recoveries = simulate_day(population)
    print(f"Day {day}: {new_infections} new infections, {recoveries} recoveries")

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(susceptible_counts, label='Susceptible')
plt.plot(infected_counts, label='Infected')
plt.plot(recovered_counts, label='Recovered')
plt.xlabel('Days')
plt.ylabel('Number of Individuals')
plt.title('Epidemic Simulation with Stratification by Sex')
plt.legend()
plt.grid(True)
plt.show()
