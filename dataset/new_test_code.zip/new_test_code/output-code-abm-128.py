# Import necessary libraries
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import random

# Define parameters
population_size = 1000
initial_infected = 10
prob_infection = 0.05  # Probability of infection per contact
days = 100  # Simulation period
gender_distribution = {'male': 0.5, 'female': 0.5}

# Initialize population with gender stratification
population = []
for i in range(population_size):
    gender = 'male' if random.random() < gender_distribution['male'] else 'female'
    status = 'infected' if i < initial_infected else 'susceptible'
    population.append({'id': i, 'gender': gender, 'status': status})

# Create a network
g = nx.erdos_renyi_graph(population_size, 0.1)

# Function to simulate infection spread
def simulate_day(graph, population):
    new_infections = []
    for node in graph.nodes():
        if population[node]['status'] == 'infected':
            neighbors = list(graph.neighbors(node))
            for neighbor in neighbors:
                if population[neighbor]['status'] == 'susceptible' and random.random() < prob_infection:
                    new_infections.append(neighbor)
    for node in new_infections:
        population[node]['status'] = 'infected'

# Run simulation
infection_over_time = []
for day in range(days):
    simulate_day(g, population)
    infected_count = sum(1 for person in population if person['status'] == 'infected')
    infection_over_time.append(infected_count)
    print(f"Day {day}: {infected_count} infected")

# Plot results
plt.plot(infection_over_time)
plt.xlabel('Days')
plt.ylabel('Number of Infected Individuals')
plt.title('COVID-19 Simulation Over Time')
plt.show()
