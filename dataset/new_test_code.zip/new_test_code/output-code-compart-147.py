import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# SEIRHD model differential equations.
def deriv(y, t, N, beta, sigma, gamma, mu, delta):
    S, E, I, R, H, D = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - (gamma + mu + delta) * I
    dRdt = gamma * I
    dHdt = mu * I
    dDdt = delta * I
    return dSdt, dEdt, dIdt, dRdt, dHdt, dDdt

# Initial conditions
N = 1000  # Total population
E0 = 1    # Initial number of exposed individuals
I0 = 1    # Initial number of infected individuals
R0 = 0    # Initial number of recovered individuals
H0 = 0    # Initial number of hospitalized individuals
D0 = 0    # Initial number of dead individuals
S0 = N - E0 - I0 - R0 - H0 - D0  # Initial number of susceptible individuals

# Initial state vector
y0 = S0, E0, I0, R0, H0, D0

# Parameters
beta = 0.3   # Infection rate
sigma = 1/5.1  # Rate of progression from exposed to infected
gamma = 1/18  # Recovery rate
mu = 0.02    # Hospitalization rate
delta = 0.01 # Mortality rate

# Time points (in days)
t = np.linspace(0, 160, 160)

# Integrate the SEIRHD equations over the time grid, t.
ret = odeint(deriv, y0, t, args=(N, beta, sigma, gamma, mu, delta))
S, E, I, R, H, D = ret.T

# Plot the data
fig = plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', label='Susceptible')
plt.plot(t, E, 'y', label='Exposed')
plt.plot(t, I, 'r', label='Infected')
plt.plot(t, R, 'g', label='Recovered')
plt.plot(t, H, 'c', label='Hospitalized')
plt.plot(t, D, 'k', label='Dead')
plt.xlabel('Time /days')
plt.ylabel('Number')
plt.legend()
plt.title('SEIRHD Model')
plt.show()
