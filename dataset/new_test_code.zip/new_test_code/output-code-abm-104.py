import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

# Parameters
n = 100  # Number of nodes
p = 0.05  # Probability of edge creation
initial_infected = 5  # Initial number of infected individuals

# Create a random graph
G = nx.erdos_renyi_graph(n, p)

# Assign sex to nodes
sex_distribution = ['M', 'F']
sex = np.random.choice(sex_distribution, n)
nx.set_node_attributes(G, {i: sex[i] for i in range(n)}, 'sex')

# Assign initial infected nodes
infected = np.random.choice(G.nodes(), initial_infected, replace=False)
for node in infected:
    G.nodes[node]['status'] = 'infected'

# Simulation parameters
total_timesteps = 10
prob_transmission = 0.1

# Run the simulation
for t in range(total_timesteps):
    new_infected = []
    for node in G.nodes():
        if G.nodes[node].get('status') == 'infected':
            for neighbor in G.neighbors(node):
                if G.nodes[neighbor].get('status') != 'infected' and np.random.rand() < prob_transmission:
                    new_infected.append(neighbor)
    for node in new_infected:
        G.nodes[node]['status'] = 'infected'

# Plot the graph
color_map = []
for node in G:
    if G.nodes[node].get('status') == 'infected':
        color_map.append('red')
    else:
        color_map.append('green')

pos = nx.spring_layout(G)
nx.draw(G, pos, node_color=color_map, with_labels=True)
plt.show()

