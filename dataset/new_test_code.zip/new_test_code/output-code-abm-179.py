import random
import numpy as np
import matplotlib.pyplot as plt

# Define age groups
age_groups = {
    '0-19': {'population': 1000, 'contact_rate': 0.3, 'susceptibility': 0.2},
    '20-39': {'population': 1000, 'contact_rate': 0.4, 'susceptibility': 0.5},
    '40-59': {'population': 1000, 'contact_rate': 0.5, 'susceptibility': 0.7},
    '60+': {'population': 1000, 'contact_rate': 0.2, 'susceptibility': 0.9}
}

# Parameters
transmission_rate = 0.1
initial_infected = 10
duration = 100

# Initialize populations
for group in age_groups.values():
    group['infected'] = initial_infected
    group['susceptible'] = group['population'] - initial_infected
    group['recovered'] = 0
    group['dead'] = 0

# Simulation
for day in range(duration):
    for group_name, group in age_groups.items():
        new_infections = 0
        for _ in range(group['infected']):
            if random.random() < group['contact_rate'] * transmission_rate * group['susceptibility']:
                new_infections += 1
        new_infections = min(new_infections, group['susceptible'])
        group['susceptible'] -= new_infections
        group['infected'] += new_infections
        recoveries = int(0.1 * group['infected'])
        deaths = int(0.01 * group['infected'])
        group['infected'] -= (recoveries + deaths)
        group['recovered'] += recoveries
        group['dead'] += deaths

# Plot results
labels = list(age_groups.keys())
values = [group['dead'] for group in age_groups.values()]
plt.bar(labels, values)
plt.xlabel('Age Groups')
plt.ylabel('Deaths')
plt.title('COVID-19 Simulation Death Toll by Age Group')
plt.show()
