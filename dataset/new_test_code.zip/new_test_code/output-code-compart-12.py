import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Initial number of individuals in each compartment
S0 = 990 # Susceptible
E0 = 0   # Exposed
I0 = 10  # Infected
R0 = 0   # Recovered
D0 = 0   # Dead

# Total population, N.
N = S0 + E0 + I0 + R0 + D0

# Contact rate, beta, incubation rate, sigma, recovery rate, gamma,
# and mortality rate, mu (in 1/days)
beta = 0.3
sigma = 1.0/5.2
gamma = 1.0/14
mu = 0.02

# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# The SEIRD model differential equations.
def deriv(y, t, N, beta, sigma, gamma, mu):
    S, E, I, R, D = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - mu * I
    dRdt = gamma * I
    dDdt = mu * I
    return dSdt, dEdt, dIdt, dRdt, dDdt

# Initial conditions vector
y0 = S0, E0, I0, R0, D0

# Integrate the SEIRD equations over the time grid, t.
ret = odeint(deriv, y0, t, args=(N, beta, sigma, gamma, mu))
S, E, I, R, D = ret.T

# Plot the data on three separate curves for S(t), E(t) and I(t)
fig = plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.plot(t, D, 'k', alpha=0.7, linewidth=2, label='Dead')
plt.xlabel('Time /days')
plt.ylabel('Number')
plt.legend()
plt.grid(True)
plt.show()
