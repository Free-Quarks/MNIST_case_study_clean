# Required Libraries
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# SEIRHD Model
# S: Susceptible
# E: Exposed
# I: Infectious
# R: Recovered
# H: Hospitalized
# D: Deceased

def seirhd_model(y, t, beta, sigma, gamma, delta, alpha, mu):
    S, E, I, R, H, D = y
    N = S + E + I + R + H + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - delta * I
    dRdt = gamma * I - alpha * R
    dHdt = delta * I - mu * H
    dDdt = mu * H
    return [dSdt, dEdt, dIdt, dRdt, dHdt, dDdt]

# Initial Conditions
N = 1000  # Total population
I0 = 1    # Initial number of infectious individuals
E0 = 0    # Initial number of exposed individuals
R0 = 0    # Initial number of recovered individuals
H0 = 0    # Initial number of hospitalized individuals
D0 = 0    # Initial number of deceased individuals
S0 = N - I0 - E0 - R0 - H0 - D0  # Initial number of susceptible individuals

# Initial conditions vector
y0 = [S0, E0, I0, R0, H0, D0]

# Time grid (in days)
t = np.linspace(0, 160, 160)

# Parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Incubation rate (1/incubation period)
gamma = 1/2.9  # Recovery rate (1/infectious period)
delta = 0.05  # Hospitalization rate
alpha = 0.01  # Recovered to Susceptible rate
mu = 0.01  # Mortality rate

# Integrate the SEIRHD equations over the time grid, t
y = odeint(seirhd_model, y0, t, args=(beta, sigma, gamma, delta, alpha, mu))

# Plot the data
S, E, I, R, H, D = y.T
plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infectious')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.plot(t, H, 'c', alpha=0.7, linewidth=2, label='Hospitalized')
plt.plot(t, D, 'k', alpha=0.7, linewidth=2, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.title('SEIRHD Model')
plt.show()

