import numpy as np
import matplotlib.pyplot as plt

def sir_model(y, beta, gamma):
    S, I, R = y
    dS_dt = -beta * S * I
    dI_dt = beta * S * I - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dI_dt, dR_dt])

def rk4_step(f, y, t, dt, *args):
    k1 = f(y, *args)
    k2 = f(y + 0.5 * dt * k1, *args)
    k3 = f(y + 0.5 * dt * k2, *args)
    k4 = f(y + dt * k3, *args)
    return y + (dt / 5.0) * (k1 + 2 * k2 + 2 * k3 + k4)

# Initial conditions
S0 = 0.9
I0 = 0.1
R0 = 0.0
beta = 0.3
gamma = 0.1
dt = 0.1
t_max = 160

# Time points
t_points = np.arange(0, t_max, dt)

# Initialize arrays to hold the results
S = np.zeros(len(t_points))
I = np.zeros(len(t_points))
R = np.zeros(len(t_points))

# Set initial values
S[0], I[0], R[0] = S0, I0, R0

# Integrate the SIR equations over the time grid, t.
for i in range(1, len(t_points)):
    S[i], I[i], R[i] = rk4_step(sir_model, [S[i-1], I[i-1], R[i-1]], t_points[i-1], dt, beta, gamma)

# Plot the results
plt.figure(figsize=[10,6])
plt.plot(t_points, S, label='Susceptible')
plt.plot(t_points, I, label='Infected')
plt.plot(t_points, R, label='Recovered')
plt.xlabel('Time /days')
plt.ylabel('Number (1000s)')
plt.legend()
plt.show()
