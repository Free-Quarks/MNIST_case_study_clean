# Import necessary libraries
import networkx as nx
import numpy as np
import random

# Define constants
NUM_NODES = 1000  # Total number of individuals
INIT_INFECTED = 10  # Initial number of infected individuals
INFECTION_PROB = 0.05  # Probability of infection on contact
RECOVERY_PROB = 0.01  # Probability of recovery per time step

# Initialize the graph
G = nx.erdos_renyi_graph(NUM_NODES, p=0.1)

# Assign sex to nodes
for node in G.nodes():
    G.nodes[node]['sex'] = random.choice(['male', 'female'])

# Initialize states: 0 = susceptible, 1 = infected, 2 = recovered
states = {node: 0 for node in G.nodes()}

# Randomly infect some individuals
initial_infected = random.sample(G.nodes(), INIT_INFECTED)
for node in initial_infected:
    states[node] = 1

# Simulation function
def simulate_step(G, states):
    new_states = states.copy()
    for node in G.nodes():
        if states[node] == 1:  # If the node is infected
            # Check if it recovers
            if random.random() < RECOVERY_PROB:
                new_states[node] = 2
            # Try to infect neighbors
            for neighbor in G.neighbors(node):
                if states[neighbor] == 0 and random.random() < INFECTION_PROB:
                    new_states[neighbor] = 1
    return new_states

# Run the simulation
def run_simulation(G, states, steps):
    history = []
    for _ in range(steps):
        states = simulate_step(G, states)
        history.append(states.copy())
    return history

# Set the number of simulation steps
steps = 100

# Run the simulation
history = run_simulation(G, states, steps)

# Example of accessing the final states
def get_final_counts(history):
    final_state = history[-1]
    counts = {'male': {'susceptible': 0, 'infected': 0, 'recovered': 0},
              'female': {'susceptible': 0, 'infected': 0, 'recovered': 0}}
    for node, state in final_state.items():
        sex = G.nodes[node]['sex']
        if state == 0:
            counts[sex]['susceptible'] += 1
        elif state == 1:
            counts[sex]['infected'] += 1
        elif state == 2:
            counts[sex]['recovered'] += 1
    return counts

final_counts = get_final_counts(history)
print(final_counts)
