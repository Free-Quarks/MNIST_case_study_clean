import numpy as np
import matplotlib.pyplot as plt

# Parameters
total_population = 1000  # Total population, N
initial_exposed = 1     # Initial number of exposed individuals, E0
initial_infected = 1    # Initial number of infected individuals, I0
initial_recovered = 0   # Initial number of recovered individuals, R0
initial_deceased = 0    # Initial number of deceased individuals, D0
initial_susceptible = total_population - initial_exposed - initial_infected - initial_recovered - initial_deceased

beta = 0.3    # Infection rate per susceptible and infected individual
sigma = 1/5.2 # Rate of progression from exposed to infected (1/incubation period)
gamma = 1/2.9 # Recovery rate (1/infectious period)
mu = 0.01     # Mortality rate among infected individuals
days = 160    # Total number of days to simulate
dt = 1        # Time step

# SEIRD model implementation using the Runge-Kutta 4th order method (RK4)
def derivatives(s, e, i, r, d, beta, sigma, gamma, mu, N):
    dsdt = -beta * s * i / N
    dedt = beta * s * i / N - sigma * e
    didt = sigma * e - (gamma + mu) * i
    drdt = gamma * i
    dddt = mu * i
    return dsdt, dedt, didt, drdt, dddt

# Arrays to hold the values for each compartment
t = np.linspace(0, days, int(days/dt) + 1)
s = np.zeros(len(t))
e = np.zeros(len(t))
i = np.zeros(len(t))
r = np.zeros(len(t))
d = np.zeros(len(t))

# Initial conditions
s[0], e[0], i[0], r[0], d[0] = initial_susceptible, initial_exposed, initial_infected, initial_recovered, initial_deceased

# Time-stepping using RK4
for j in range(len(t) - 1):
    k1 = dt * np.array(derivatives(s[j], e[j], i[j], r[j], d[j], beta, sigma, gamma, mu, total_population))
    k2 = dt * np.array(derivatives(s[j] + 0.5 * k1[0], e[j] + 0.5 * k1[1], i[j] + 0.5 * k1[2], r[j] + 0.5 * k1[3], d[j] + 0.5 * k1[4], beta, sigma, gamma, mu, total_population))
    k3 = dt * np.array(derivatives(s[j] + 0.5 * k2[0], e[j] + 0.5 * k2[1], i[j] + 0.5 * k2[2], r[j] + 0.5 * k2[3], d[j] + 0.5 * k2[4], beta, sigma, gamma, mu, total_population))
    k4 = dt * np.array(derivatives(s[j] + k3[0], e[j] + k3[1], i[j] + k3[2], r[j] + k3[3], d[j] + k3[4], beta, sigma, gamma, mu, total_population))
    s[j + 1] = s[j] + (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0]) / 6
    e[j + 1] = e[j] + (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1]) / 6
    i[j + 1] = i[j] + (k1[2] + 2 * k2[2] + 2 * k3[2] + k4[2]) / 6
    r[j + 1] = r[j] + (k1[3] + 2 * k2[3] + 2 * k3[3] + k4[3]) / 6
    d[j + 1] = d[j] + (k1[4] + 2 * k2[4] + 2 * k3[4] + k4[4]) / 6

# Plot the results
plt.figure(figsize=(10,6))
plt.plot(t, s, label='Susceptible')
plt.plot(t, e, label='Exposed')
plt.plot(t, i, label='Infected')
plt.plot(t, r, label='Recovered')
plt.plot(t, d, label='Deceased')
plt.xlabel('Days')
plt.ylabel('Number of Individuals')
plt.title('SEIRD Model Simulation')
plt.legend()
plt.grid()
plt.show()
