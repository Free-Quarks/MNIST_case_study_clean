import numpy as np
import matplotlib.pyplot as plt

# SEIRD model differential equations
def SEIRD(t, Y, beta, sigma, gamma, mu):
    S, E, I, R, D = Y
    N = S + E + I + R + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - mu * I
    dRdt = gamma * I
    dDdt = mu * I
    return np.array([dSdt, dEdt, dIdt, dRdt, dDdt])

# Runge-Kutta 3rd Order Method (RK3)
def rk3_step(f, t, Y, dt, *args):
    k1 = f(t, Y, *args)
    k2 = f(t + 0.5*dt, Y + 0.5*dt*k1, *args)
    k3 = f(t + dt, Y - dt*k1 + 2*dt*k2, *args)
    return Y + (dt/6)*(k1 + 4*k2 + k3)

# Parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Rate of progression from exposed to infectious
gamma = 0.05  # Recovery rate
mu = 0.01  # Mortality rate

# Initial conditions
S0 = 990
E0 = 10
I0 = 0
R0 = 0
D0 = 0
Y0 = np.array([S0, E0, I0, R0, D0])

# Time steps
T = 160
dt = 1
steps = int(T/dt)
t = np.linspace(0, T, steps)

# Array to store results
results = np.zeros((steps, 5))
results[0] = Y0

# Time integration using RK3
for i in range(1, steps):
    results[i] = rk3_step(SEIRD, t[i-1], results[i-1], dt, beta, sigma, gamma, mu)

# Plotting results
plt.figure(figsize=(12, 8))
plt.plot(t, results[:, 0], label='Susceptible')
plt.plot(t, results[:, 1], label='Exposed')
plt.plot(t, results[:, 2], label='Infectious')
plt.plot(t, results[:, 3], label='Recovered')
plt.plot(t, results[:, 4], label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRD Model Simulation using RK3')
plt.show()
