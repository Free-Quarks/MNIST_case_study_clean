# SIDARTHE Model Simulation using Runge-Kutta 4th Order Method

import numpy as np
import matplotlib.pyplot as plt

# Define the SIDARTHE model equations
def sidarthe_model(y, beta, gamma, delta, epsilon, theta, zeta, eta, alpha, rho, kappa, lambda_):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E
    dS_dt = -beta * S * (I + D + A + R)
    dI_dt = beta * S * (I + D + A + R) - gamma * I - delta * I - epsilon * I
    dD_dt = delta * I - zeta * D - eta * D
    dA_dt = epsilon * I - theta * A - rho * A
    dR_dt = gamma * I - alpha * R
    dT_dt = theta * A + zeta * D - kappa * T - lambda_ * T
    dH_dt = eta * D + rho * A - kappa * H - lambda_ * H
    dE_dt = alpha * R + kappa * T + kappa * H - lambda_ * E
    return np.array([dS_dt, dI_dt, dD_dt, dA_dt, dR_dt, dT_dt, dH_dt, dE_dt])

# Runge-Kutta 4th Order Method implementation
def rk4_step(f, y, t, dt, *args):
    k1 = dt * f(y, *args)
    k2 = dt * f(y + 0.5 * k1, *args)
    k3 = dt * f(y + 0.5 * k2, *args)
    k4 = dt * f(y + k3, *args)
    return y + (k1 + 2*k2 + 2*k3 + k4) / 6.0

# Initial conditions and parameters
S0, I0, D0, A0, R0, T0, H0, E0 = 0.99, 0.01, 0, 0, 0, 0, 0, 0
beta, gamma, delta, epsilon, theta, zeta, eta, alpha, rho, kappa, lambda_ = 0.3, 0.1, 0.1, 0.05, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1

# Time parameters
t0, tf, dt = 0, 160, 1.0

# Initialize arrays to store the results
t_values = np.arange(t0, tf + dt, dt)
results = np.zeros((len(t_values), 8))
results[0] = [S0, I0, D0, A0, R0, T0, H0, E0]

# Simulation loop using RK4
for i in range(1, len(t_values)):
    results[i] = rk4_step(sidarthe_model, results[i-1], t_values[i-1], dt, beta, gamma, delta, epsilon, theta, zeta, eta, alpha, rho, kappa, lambda_)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t_values, results[:, 0], label='Susceptible')
plt.plot(t_values, results[:, 1], label='Infected')
plt.plot(t_values, results[:, 2], label='Diagnosed')
plt.plot(t_values, results[:, 3], label='Ailing')
plt.plot(t_values, results[:, 4], label='Recognized')
plt.plot(t_values, results[:, 5], label='Threatened')
plt.plot(t_values, results[:, 6], label='Healed')
plt.plot(t_values, results[:, 7], label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of Population')
plt.legend()
plt.title('SIDARTHE Model Simulation')
plt.grid()
plt.show()

