import numpy as np

# Define the SEIRHD model parameters
params = {
    'beta': 0.3,  # Infection rate
    'sigma': 1/5.2,  # Incubation rate
    'gamma': 1/2.3,  # Recovery rate
    'delta': 0.02,  # Death rate
    'rho': 1/10,  # Hospitalization rate
    'kappa': 1/7  # Discharge rate
}

# Define the initial conditions
initial_conditions = {
    'S': 999,
    'E': 1,
    'I': 0,
    'R': 0,
    'H': 0,
    'D': 0
}

# Define the SEIRHD model equations
def SEIRHD(t, y, params):
    S, E, I, R, H, D = y
    N = S + E + I + R + H + D

    dS_dt = -params['beta'] * S * I / N
    dE_dt = params['beta'] * S * I / N - params['sigma'] * E
    dI_dt = params['sigma'] * E - params['gamma'] * I - params['delta'] * I
    dR_dt = params['gamma'] * I
    dH_dt = params['rho'] * I - params['kappa'] * H
    dD_dt = params['delta'] * I

    return np.array([dS_dt, dE_dt, dI_dt, dR_dt, dH_dt, dD_dt])

# Runge-Kutta 4th Order Method
def rk4_step(func, t, y, dt, params):
    k1 = dt * func(t, y, params)
    k2 = dt * func(t + dt/2, y + k1/2, params)
    k3 = dt * func(t + dt/2, y + k2/2, params)
    k4 = dt * func(t + dt, y + k3, params)
    return y + (k1 + 2*k2 + 2*k3 + k4) / 6

# Simulation parameters
t_start = 0
t_end = 160
dt = 1
t_values = np.arange(t_start, t_end + dt, dt)

# Initialize the state vector
y = np.array([initial_conditions['S'], initial_conditions['E'], initial_conditions['I'], initial_conditions['R'], initial_conditions['H'], initial_conditions['D']])

# Store the results
y_results = [y]

# Time loop
for t in t_values[:-1]:
    y = rk4_step(SEIRHD, t, y, dt, params)
    y_results.append(y)

y_results = np.array(y_results)

# Print the results
import matplotlib.pyplot as plt
plt.figure(figsize=(12, 8))
plt.plot(t_values, y_results[:, 0], label='Susceptible')
plt.plot(t_values, y_results[:, 1], label='Exposed')
plt.plot(t_values, y_results[:, 2], label='Infected')
plt.plot(t_values, y_results[:, 3], label='Recovered')
plt.plot(t_values, y_results[:, 4], label='Hospitalized')
plt.plot(t_values, y_results[:, 5], label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRHD Model Simulation')
plt.show()
