# SEIRD Model using RK4 Method
# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Define the differential equations for the SEIRD model
def SEIRD_model(y, beta, sigma, gamma, mu):
    S, E, I, R, D = y
    N = S + E + I + R
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - (gamma + mu) * I
    dR_dt = gamma * I
    dD_dt = mu * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt, dD_dt])

# Runge-Kutta 4th Order Method for solving ODEs
def RK4_step(f, y, t, dt, *args):
    k1 = dt * f(y, *args)
    k2 = dt * f(y + 0.5 * k1, *args)
    k3 = dt * f(y + 0.5 * k2, *args)
    k4 = dt * f(y + k3, *args)
    return y + (k1 + 2 * k2 + 2 * k3 + k4) / 6

# Parameters initialization
beta = 0.3   # Infection rate
sigma = 0.1  # Transition rate from exposed to infected
gamma = 0.05 # Recovery rate
mu = 0.01    # Mortality rate

# Initial populations
S0 = 999
E0 = 1
I0 = 0
R0 = 0
D0 = 0

# Initial conditions vector
y0 = np.array([S0, E0, I0, R0, D0])

# Time vector
t_start = 0
# Time step (days)
dt = 0.1
# Total days to simulate
t_end = 160
# Number of time steps
num_steps = int(t_end / dt)

t = np.linspace(t_start, t_end, num_steps)

# Storage for the results
results = np.zeros((num_steps, len(y0)))
results[0] = y0

# Time evolution
for i in range(1, num_steps):
    results[i] = RK4_step(SEIRD_model, results[i-1], t[i-1], dt, beta, sigma, gamma, mu)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, results[:, 0], label='Susceptible')
plt.plot(t, results[:, 1], label='Exposed')
plt.plot(t, results[:, 2], label='Infected')
plt.plot(t, results[:, 3], label='Recovered')
plt.plot(t, results[:, 4], label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRD Model Simulation using RK4')
plt.grid()
plt.show()

