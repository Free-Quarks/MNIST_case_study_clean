# Python script for SIDARTHE model using RK4
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# Define the SIDARTHE model
def sidarthe_model(t, y, alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E
    dSdt = -alpha*S*(I + D + A) - beta*S*(I + D + A) - gamma*S*(I + D + A) - delta*S*(I + D + A)
    dIdt = alpha*S*(I + D + A) - epsilon*I - zeta*I - lambda_*I
    dDdt = beta*S*(I + D + A) - eta*D - theta*D
    dAdt = gamma*S*(I + D + A) - mu*A - nu*A
    dRdt = epsilon*I + eta*D + mu*A
    dTdt = zeta*I + theta*D - tau*T
    dHdt = nu*A + tau*T
    dEdt = lambda_*I
    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Initial conditions
S0 = 0.99
I0 = 0.01
D0 = 0.0
A0 = 0.0
R0 = 0.0
T0 = 0.0
H0 = 0.0
E0 = 0.0
initial_conditions = [S0, I0, D0, A0, R0, T0, H0, E0]

# Parameters
alpha = 0.5
beta = 0.1
gamma = 0.1
delta = 0.1
epsilon = 0.1
theta = 0.1
zeta = 0.1
eta = 0.1
mu = 0.1
nu = 0.1
tau = 0.1
lambda_ = 0.1
params = (alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_)

# Time grid
t_start = 0.0
t_end = 160.0
t_steps = 160
t_eval = np.linspace(t_start, t_end, t_steps)

# Solve the system of ODEs using RK4 method
solution = solve_ivp(sidarthe_model, [t_start, t_end], initial_conditions, args=params, t_eval=t_eval, method='RK45')

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(solution.t, solution.y[0], label='Susceptible (S)')
plt.plot(solution.t, solution.y[1], label='Infected (I)')
plt.plot(solution.t, solution.y[2], label='Diagnosed (D)')
plt.plot(solution.t, solution.y[3], label='Ailing (A)')
plt.plot(solution.t, solution.y[4], label='Recognized (R)')
plt.plot(solution.t, solution.y[5], label='Threatened (T)')
plt.plot(solution.t, solution.y[6], label='Healed (H)')
plt.plot(solution.t, solution.y[7], label='Extinct (E)')
plt.xlabel('Time (days)')
plt.ylabel('Population fraction')
plt.title('SIDARTHE Model Simulation')
plt.legend()
plt.grid(True)
plt.show()
