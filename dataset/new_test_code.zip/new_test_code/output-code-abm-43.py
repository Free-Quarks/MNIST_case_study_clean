# Agent-Based Model to Simulate COVID-19 with Age Stratification

import random

class Person:
    def __init__(self, age_group):
        self.age_group = age_group
        self.infected = False
        self.days_infected = 0

    def infect(self):
        self.infected = True
        self.days_infected = 1

    def progress_disease(self):
        if self.infected:
            self.days_infected += 1

            # Recovery or death logic (simplified)
            if self.days_infected > 14:  # Assume 14 days to recover
                self.infected = False
                self.days_infected = 0

class Population:
    def __init__(self, size, age_distribution):
        self.people = [Person(random.choices(list(age_distribution.keys()), list(age_distribution.values()))[0]) for _ in range(size)]
        self.size = size

    def initial_infection(self, num_initial_infected):
        initial_infected = random.sample(self.people, num_initial_infected)
        for person in initial_infected:
            person.infect()

    def simulate_day(self):
        for person in self.people:
            if person.infected:
                # Infect others
                contacts = random.sample(self.people, 10)  # Assume each person contacts 10 others per day
                for contact in contacts:
                    if not contact.infected and random.random() < self.infection_probability(person.age_group):
                        contact.infect()

                # Progress disease
                person.progress_disease()

    def infection_probability(self, age_group):
        # Simplified age-based infection probability
        return {
            '0-17': 0.05,
            '18-49': 0.1,
            '50-64': 0.2,
            '65+': 0.3
        }[age_group]

    def run_simulation(self, days):
        for day in range(days):
            self.simulate_day()


if __name__ == '__main__':
    age_distribution = {
        '0-17': 0.2,
        '18-49': 0.5,
        '50-64': 0.2,
        '65+': 0.1
    }
    population = Population(size=1000, age_distribution=age_distribution)
    population.initial_infection(num_initial_infected=10)
    population.run_simulation(days=30)

    # Output results
    infected_count = sum(1 for person in population.people if person.infected)
    print(f"Total infected after 30 days: {infected_count}")
