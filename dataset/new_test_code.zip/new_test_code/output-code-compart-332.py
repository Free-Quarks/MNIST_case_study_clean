import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SEIR model

def seir_model(y, t, beta, sigma, gamma):
    S, E, I, R = y
    N = S + E + I + R
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return [dS_dt, dE_dt, dI_dt, dR_dt]

# Initial conditions
N = 1000  # Total population
I0 = 1    # Initial number of infected individuals
E0 = 0    # Initial number of exposed individuals
R0 = 0    # Initial number of recovered individuals
S0 = N - I0 - E0 - R0  # Initial number of susceptible individuals

# Contact rate, incubation rate, and mean recovery rate (in 1/days)
beta = 0.3  # Contact rate
sigma = 1/5.2  # Incubation period (5.2 days)
gamma = 1/14  # Mean recovery rate (14 days)

# Time grid (in days)
t = np.linspace(0, 160, 160)

# Initial conditions vector
y0 = [S0, E0, I0, R0]

# Integrate the SEIR equations over the time grid, t
ret = odeint(seir_model, y0, t, args=(beta, sigma, gamma))
S, E, I, R = ret.T

# Plot the data
plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.title('SEIR Model')
plt.legend()
plt.grid(True)
plt.show()
