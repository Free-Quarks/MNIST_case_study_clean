# Import relevant libraries
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# Define the SIDARTHE model parameters
alpha = 0.57   # Rate of susceptible to infected
beta = 0.0114  # Rate of infected to diagnosed
gamma = 0.456  # Rate of diagnosed to ailing
zeta = 0.171   # Rate of ailing to recognized
eta = 0.370    # Rate of recognized to threatened
theta = 0.125  # Rate of threatened to healed
mu = 0.017     # Rate of ailing to healed
nu = 0.027     # Rate of threatened to dead

delta = 0.011  # Rate of infected to ailing
lambda_ = 0.034 # Rate of diagnosed to healed
kappa = 0.017  # Rate of recognized to healed
rho = 0.034    # Rate of healed to susceptible
sigma = 0.011  # Rate of susceptible to dead

# Define the SIDARTHE model ODEs
def sidarthe(t, y):
    S, I, D, A, R, T, H, E = y
    dS_dt = -alpha * S * I - beta * S * D - gamma * S * A - delta * S * R
    dI_dt = alpha * S * I + beta * S * D + gamma * S * A + delta * S * R - zeta * I - eta * I - theta * I
    dD_dt = zeta * I - mu * D - nu * D - lambda_ * D
    dA_dt = eta * I - rho * A - sigma * A - kappa * A
    dR_dt = theta * I + mu * D + rho * A - lambda_ * R - sigma * R
    dT_dt = lambda_ * D + sigma * R - kappa * T - theta * T
    dH_dt = kappa * A + kappa * T - theta * H
    dE_dt = nu * D + sigma * R + theta * T + theta * H
    return [dS_dt, dI_dt, dD_dt, dA_dt, dR_dt, dT_dt, dH_dt, dE_dt]

# Define initial conditions
S0 = 0.99
I0 = 0.01
D0 = 0.0
A0 = 0.0
R0 = 0.0
T0 = 0.0
H0 = 0.0
E0 = 0.0
initial_conditions = [S0, I0, D0, A0, R0, T0, H0, E0]

# Define the time points where the solution is computed
t_span = [0, 160]
t_eval = np.linspace(*t_span, 1000)

# Solve the ODEs using Runge-Kutta 2nd order method
solution = solve_ivp(sidarthe, t_span, initial_conditions, t_eval=t_eval, method='RK45')

# Extract the results
S, I, D, A, R, T, H, E = solution.y

# Plot the results
plt.figure(figsize=(12, 8))
plt.plot(t_eval, S, label='Susceptible')
plt.plot(t_eval, I, label='Infected')
plt.plot(t_eval, D, label='Diagnosed')
plt.plot(t_eval, A, label='Ailing')
plt.plot(t_eval, R, label='Recognized')
plt.plot(t_eval, T, label='Threatened')
plt.plot(t_eval, H, label='Healed')
plt.plot(t_eval, E, label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of Population')
plt.title('SIDARTHE Model for COVID-19')
plt.legend()
plt.grid()
plt.show()
