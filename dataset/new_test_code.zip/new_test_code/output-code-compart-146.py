# SEIRHD model using Euler's method
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3    # Infection rate
sigma = 1/5.2 # Rate of progression from exposed to infectious
gamma = 1/14  # Recovery rate
mu = 0.01     # Mortality rate

# Time step and duration
dt = 0.1
T = 160
steps = int(T / dt)

# Initial conditions
S0 = 0.99
E0 = 0.01
I0 = 0.0
R0 = 0.0
H0 = 0.0
D0 = 0.0

# Initialize arrays
S = np.zeros(steps)
E = np.zeros(steps)
I = np.zeros(steps)
R = np.zeros(steps)
H = np.zeros(steps)
D = np.zeros(steps)

S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
H[0] = H0
D[0] = D0

# Euler method
for t in range(1, steps):
    dS = -beta * S[t-1] * I[t-1] * dt
    dE = (beta * S[t-1] * I[t-1] - sigma * E[t-1]) * dt
    dI = (sigma * E[t-1] - (gamma + mu) * I[t-1]) * dt
    dR = gamma * I[t-1] * dt
    dH = (1 - gamma) * I[t-1] * dt
    dD = mu * I[t-1] * dt

    S[t] = S[t-1] + dS
    E[t] = E[t-1] + dE
    I[t] = I[t-1] + dI
    R[t] = R[t-1] + dR
    H[t] = H[t-1] + dH
    D[t] = D[t-1] + dD

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(np.arange(steps) * dt, S, label='Susceptible')
plt.plot(np.arange(steps) * dt, E, label='Exposed')
plt.plot(np.arange(steps) * dt, I, label='Infectious')
plt.plot(np.arange(steps) * dt, R, label='Recovered')
plt.plot(np.arange(steps) * dt, H, label='Hospitalized')
plt.plot(np.arange(steps) * dt, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of Population')
plt.legend()
plt.title('SEIRHD Model Simulation')
plt.grid(True)
plt.show()
