import numpy as np

# SEIRD Model Parameters
beta = 0.3  # infection rate
sigma = 0.1  # incubation rate
gamma = 0.05  # recovery rate
delta = 0.01  # death rate

# Initial Conditions
S0 = 0.99  # fraction of susceptible individuals
E0 = 0.01  # fraction of exposed individuals
I0 = 0.0  # fraction of infectious individuals
R0 = 0.0  # fraction of recovered individuals
D0 = 0.0  # fraction of deceased individuals

# Time parameters
t_max = 160  # maximum time
n_steps = 1000  # number of steps
dt = t_max / n_steps  # time step size
time = np.linspace(0, t_max, n_steps)  # time array

# Initialize arrays to store results
S = np.zeros(n_steps)
E = np.zeros(n_steps)
I = np.zeros(n_steps)
R = np.zeros(n_steps)
D = np.zeros(n_steps)

# Set initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
D[0] = D0

# Runge-Kutta 2nd order (RK2) method for SEIRD model
def rk2_step(S, E, I, R, D, dt):
    def derivs(S, E, I, R, D):
        dSdt = -beta * S * I
        dEdt = beta * S * I - sigma * E
        dIdt = sigma * E - gamma * I - delta * I
        dRdt = gamma * I
        dDdt = delta * I
        return dSdt, dEdt, dIdt, dRdt, dDdt

    k1_S, k1_E, k1_I, k1_R, k1_D = derivs(S, E, I, R, D)
    k2_S, k2_E, k2_I, k2_R, k2_D = derivs(S + k1_S * dt / 2, E + k1_E * dt / 2, I + k1_I * dt / 2, R + k1_R * dt / 2, D + k1_D * dt / 2)

    S_new = S + k2_S * dt
    E_new = E + k2_E * dt
    I_new = I + k2_I * dt
    R_new = R + k2_R * dt
    D_new = D + k2_D * dt

    return S_new, E_new, I_new, R_new, D_new

# Main loop to calculate SEIRD values over time
for t in range(1, n_steps):
    S[t], E[t], I[t], R[t], D[t] = rk2_step(S[t-1], E[t-1], I[t-1], R[t-1], D[t-1], dt)

# Combine the results into a dictionary
results = {
    'time': time.tolist(),
    'S': S.tolist(),
    'E': E.tolist(),
    'I': I.tolist(),
    'R': R.tolist(),
    'D': D.tolist()
}

# Print the results
print(results)
