import numpy as np
import matplotlib.pyplot as plt

# SEIRD Compartmental Model using Runge-Kutta 3rd Order (RK3)

def seird_model(S, E, I, R, D, beta, sigma, gamma, mu):
    def dSdt(S, E, I, R, D):
        return -beta * S * I

    def dEdt(S, E, I, R, D):
        return beta * S * I - sigma * E

    def dIdt(S, E, I, R, D):
        return sigma * E - (gamma + mu) * I

    def dRdt(S, E, I, R, D):
        return gamma * I

    def dDdt(S, E, I, R, D):
        return mu * I

    return dSdt, dEdt, dIdt, dRdt, dDdt

# Runge-Kutta 3rd order (RK3) implementation

def rk3_step(S, E, I, R, D, beta, sigma, gamma, mu, dt):
    dSdt, dEdt, dIdt, dRdt, dDdt = seird_model(S, E, I, R, D, beta, sigma, gamma, mu)

    k1_S = dSdt(S, E, I, R, D) * dt
    k1_E = dEdt(S, E, I, R, D) * dt
    k1_I = dIdt(S, E, I, R, D) * dt
    k1_R = dRdt(S, E, I, R, D) * dt
    k1_D = dDdt(S, E, I, R, D) * dt

    k2_S = dSdt(S + 0.5 * k1_S, E + 0.5 * k1_E, I + 0.5 * k1_I, R + 0.5 * k1_R, D + 0.5 * k1_D) * dt
    k2_E = dEdt(S + 0.5 * k1_S, E + 0.5 * k1_E, I + 0.5 * k1_I, R + 0.5 * k1_R, D + 0.5 * k1_D) * dt
    k2_I = dIdt(S + 0.5 * k1_S, E + 0.5 * k1_E, I + 0.5 * k1_I, R + 0.5 * k1_R, D + 0.5 * k1_D) * dt
    k2_R = dRdt(S + 0.5 * k1_S, E + 0.5 * k1_E, I + 0.5 * k1_I, R + 0.5 * k1_R, D + 0.5 * k1_D) * dt
    k2_D = dDdt(S + 0.5 * k1_S, E + 0.5 * k1_E, I + 0.5 * k1_I, R + 0.5 * k1_R, D + 0.5 * k1_D) * dt

    k3_S = dSdt(S - k1_S + 2 * k2_S, E - k1_E + 2 * k2_E, I - k1_I + 2 * k2_I, R - k1_R + 2 * k2_R, D - k1_D + 2 * k2_D) * dt
    k3_E = dEdt(S - k1_S + 2 * k2_S, E - k1_E + 2 * k2_E, I - k1_I + 2 * k2_I, R - k1_R + 2 * k2_R, D - k1_D + 2 * k2_D) * dt
    k3_I = dIdt(S - k1_S + 2 * k2_S, E - k1_E + 2 * k2_E, I - k1_I + 2 * k2_I, R - k1_R + 2 * k2_R, D - k1_D + 2 * k2_D) * dt
    k3_R = dRdt(S - k1_S + 2 * k2_S, E - k1_E + 2 * k2_E, I - k1_I + 2 * k2_I, R - k1_R + 2 * k2_R, D - k1_D + 2 * k2_D) * dt
    k3_D = dDdt(S - k1_S + 2 * k2_S, E - k1_E + 2 * k2_E, I - k1_I + 2 * k2_I, R - k1_R + 2 * k2_R, D - k1_D + 2 * k2_D) * dt

    S_next = S + (k1_S + 4 * k2_S + k3_S) / 6
    E_next = E + (k1_E + 4 * k2_E + k3_E) / 6
    I_next = I + (k1_I + 4 * k2_I + k3_I) / 6
    R_next = R + (k1_R + 4 * k2_R + k3_R) / 6
    D_next = D + (k1_D + 4 * k2_D + k3_D) / 6

    return S_next, E_next, I_next, R_next, D_next

# Parameters
beta = 0.3    # Infection rate
sigma = 0.1   # Incubation rate
gamma = 0.05  # Recovery rate
mu = 0.01     # Mortality rate
dt = 0.1      # Time step

# Initial conditions
S0 = 0.99
E0 = 0.01
I0 = 0.0
R0 = 0.0
D0 = 0.0

time = np.arange(0, 160, dt)
S, E, I, R, D = S0, E0, I0, R0, D0

S_list, E_list, I_list, R_list, D_list = [S], [E], [I], [R], [D]

# Simulation loop
for t in time[1:]:
    S, E, I, R, D = rk3_step(S, E, I, R, D, beta, sigma, gamma, mu, dt)
    S_list.append(S)
    E_list.append(E)
    I_list.append(I)
    R_list.append(R)
    D_list.append(D)

# Plotting results
plt.figure(figsize=(10, 6))
plt.plot(time, S_list, label='Susceptible')
plt.plot(time, E_list, label='Exposed')
plt.plot(time, I_list, label='Infected')
plt.plot(time, R_list, label='Recovered')
plt.plot(time, D_list, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of Population')
plt.legend()
plt.title('SEIRD Model Simulation using RK3')
plt.grid(True)
plt.show()
