import numpy as np
import matplotlib.pyplot as plt

# Define the SEIR model parameters
beta = 0.3    # Infection rate
sigma = 0.1   # Rate of progression from exposed to infectious
gamma = 0.05  # Recovery rate

# Define the initial conditions
S0 = 0.99  # Initial susceptible proportion
E0 = 0.01  # Initial exposed proportion
I0 = 0.0   # Initial infectious proportion
R0 = 0.0   # Initial recovered proportion

# Define the time step and duration
T = 160    # Total time in days
dt = 1.0   # Time step in days

# Initialize arrays to store results
S = np.zeros(int(T/dt))
E = np.zeros(int(T/dt))
I = np.zeros(int(T/dt))
R = np.zeros(int(T/dt))

# Set initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# Implement the Euler method for the SEIR model (incorrectly)
for t in range(1, int(T/dt)):
    S[t] = S[t-1] - beta * S[t-1] * I[t-1] * dt
    E[t] = E[t-1] + beta * S[t-1] * I[t-1] * dt - sigma * E[t-1] * dt
    I[t] = I[t-1] + sigma * E[t-1] * dt - gamma * I[t-1] * dt
    R[t] = R[t-1] + gamma * E[t-1] * dt  # Incorrectly using E instead of I

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(np.arange(0, T, dt), S, label='Susceptible')
plt.plot(np.arange(0, T, dt), E, label='Exposed')
plt.plot(np.arange(0, T, dt), I, label='Infectious')
plt.plot(np.arange(0, T, dt), R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIR Model Simulation')
plt.grid(True)
plt.show()
