import numpy as np
from scipy.integrate import solve_ivp

# Define the SIDARTHE model equations
def sidarthe_model(t, y, alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E
    dS_dt = -alpha * S * I / N - beta * S * D / N - gamma * S * A / N - delta * S * R / N
    dI_dt = alpha * S * I / N + beta * S * D / N + gamma * S * A / N + delta * S * R / N - epsilon * I - zeta * I - eta * I
    dD_dt = epsilon * I - theta * D - mu * D
    dA_dt = zeta * I - nu * A - lambda_ * A
    dR_dt = eta * I + theta * D + nu * A - tau * R
    dT_dt = mu * D + lambda_ * A
    dH_dt = tau * R
    dE_dt = 0
    return [dS_dt, dI_dt, dD_dt, dA_dt, dR_dt, dT_dt, dH_dt, dE_dt]

# RK4 method for solving ODEs
def rk4_step(f, y, t, dt, *args):
    k1 = np.array(f(t, y, *args))
    k2 = np.array(f(t + 0.5*dt, y + 0.5*dt*k1, *args))
    k3 = np.array(f(t + 0.5*dt, y + 0.5*dt*k2, *args))
    k4 = np.array(f(t + dt, y + dt*k3, *args))
    return y + (dt/6)*(k1 + 2*k2 + 2*k3 + k4)

# Parameters (example values)
params = {
    'alpha': 0.4,
    'beta': 0.3,
    'gamma': 0.1,
    'delta': 0.05,
    'epsilon': 0.1,
    'theta': 0.1,
    'zeta': 0.1,
    'eta': 0.1,
    'mu': 0.05,
    'nu': 0.04,
    'tau': 0.02,
    'lambda_': 0.01
}

# Initial conditions (example values)
initial_conditions = [0.99, 0.01, 0, 0, 0, 0, 0, 0]

# Time variables
t0, tf, dt = 0, 100, 0.1
t_values = np.arange(t0, tf, dt)

# Run the RK4 integration
y_values = np.zeros((len(t_values), len(initial_conditions)))
y_values[0, :] = initial_conditions

for i in range(1, len(t_values)):
    y_values[i, :] = rk4_step(sidarthe_model, y_values[i-1, :], t_values[i-1], dt, *params.values())

# Result
y_values

