# SIDARTHE Model Implementation using Runge-Kutta 2 (RK2) Method

import numpy as np

# SIDARTHE Model Parameters (example values)
beta = 0.34
sigma = 0.16
alpha = 0.22
eta = 0.05
rho = 0.08
kappa = 0.05
delta = 0.01
lambda_ = 0.05
theta = 0.05
zeta = 0.07
mu = 0.05
tau = 0.07
nu = 0.02
pi = 0.03

# Time step (example value)
dt = 0.1

# Initial conditions (example values)
S0, I0, D0, A0, R0, T0, H0, E0 = 0.99, 0.01, 0, 0, 0, 0, 0, 0
initial_conditions = np.array([S0, I0, D0, A0, R0, T0, H0, E0])

# SIDARTHE model differential equations
def sidarthe_derivatives(y, t, params):
    S, I, D, A, R, T, H, E = y
    beta, sigma, alpha, eta, rho, kappa, delta, lambda_, theta, zeta, mu, tau, nu, pi = params
    dSdt = -beta*S*I - sigma*S*D - alpha*S*A - eta*S*R
    dIdt = beta*S*I + sigma*S*D + alpha*S*A + eta*S*R - rho*I - kappa*I - delta*I
    dDdt = rho*I - lambda_*D - theta*D - zeta*D
    dAdt = kappa*I - mu*A - tau*A
    dRdt = delta*I + lambda_*D - nu*R - pi*R
    dTdt = theta*D + mu*A - tau*T
    dHdt = zeta*D + tau*A + tau*T
    dEdt = nu*R + pi*R
    return np.array([dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt])

# RK2 step function
def rk2_step(f, y, t, dt, params):
    k1 = f(y, t, params)
    k2 = f(y + dt * k1 / 2, t + dt / 2, params)
    return y + dt * k2

# Function to simulate the model
def simulate_sidarthe(timesteps, initial_conditions, params, dt):
    num_steps = len(timesteps)
    results = np.zeros((num_steps, len(initial_conditions)))
    results[0] = initial_conditions
    for i in range(1, num_steps):
        results[i] = rk2_step(sidarthe_derivatives, results[i-1], timesteps[i-1], dt, params)
    return results

# Example usage
timesteps = np.arange(0, 100, dt)
params = (beta, sigma, alpha, eta, rho, kappa, delta, lambda_, theta, zeta, mu, tau, nu, pi)
results = simulate_sidarthe(timesteps, initial_conditions, params, dt)

# Print results
print(results)

