import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRHD model using Euler's method
def seirhd_model(S0, E0, I0, R0, H0, D0, beta, sigma, gamma, delta, alpha, days):
    # Initialize arrays to store the compartment values
    S = np.zeros(days)
    E = np.zeros(days)
    I = np.zeros(days)
    R = np.zeros(days)
    H = np.zeros(days)
    D = np.zeros(days)

    # Set initial values
    S[0] = S0
    E[0] = E0
    I[0] = I0
    R[0] = R0
    H[0] = H0
    D[0] = D0

    # Time step (Euler's method)
    dt = 1

    # Iterate over each day
    for t in range(1, days):
        S[t] = S[t-1] - beta * S[t-1] * I[t-1] * dt
        E[t] = E[t-1] + (beta * S[t-1] * I[t-1] - sigma * E[t-1]) * dt
        I[t] = I[t-1] + (sigma * E[t-1] - gamma * I[t-1] - delta * I[t-1]) * dt
        R[t] = R[t-1] + gamma * I[t-1] * dt
        H[t] = H[t-1] + delta * I[t-1] * dt
        D[t] = D[t-1] + alpha * H[t-1] * dt

    return S, E, I, R, H, D

# Initial conditions
S0 = 0.99  # Initial susceptible population
E0 = 0.01  # Initial exposed population
I0 = 0.0   # Initial infected population
R0 = 0.0   # Initial recovered population
H0 = 0.0   # Initial hospitalized population
D0 = 0.0   # Initial deceased population

# Model parameters
beta = 0.3   # Infection rate
sigma = 0.1  # Rate of progression from exposed to infected
gamma = 0.05 # Recovery rate
delta = 0.01 # Hospitalization rate
alpha = 0.02 # Death rate

days = 160  # Number of days to simulate

# Run the model
S, E, I, R, H, D = seirhd_model(S0, E0, I0, R0, H0, D0, beta, sigma, gamma, delta, alpha, days)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(S, label='Susceptible')
plt.plot(E, label='Exposed')
plt.plot(I, label='Infected')
plt.plot(R, label='Recovered')
plt.plot(H, label='Hospitalized')
plt.plot(D, label='Deceased')
plt.xlabel('Days')
plt.ylabel('Proportion')
plt.title('SEIRHD Model Simulation')
plt.legend()
plt.grid(True)
plt.show()
