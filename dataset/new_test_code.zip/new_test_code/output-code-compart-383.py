# SEIR Model using Runge-Kutta 2nd Order (RK2)
import numpy as np
import matplotlib.pyplot as plt

# Define the SEIR model differential equations
def seir_derivatives(y, beta, gamma, sigma, N):
    S, E, I, R = y
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt])

# Runge-Kutta 2nd Order (RK2) method
def rk2_step(y, f, dt, beta, gamma, sigma, N):
    k1 = f(y, beta, gamma, sigma, N)
    k2 = f(y + dt * k1 / 2, beta, gamma, sigma, N)
    return y + dt * k2

# SEIR model parameters
N = 1000  # Total population
beta = 0.3  # Transmission rate
sigma = 1/5.2  # Incubation rate
gamma = 1/14  # Recovery rate

# Initial number of infected, exposed, recovered, and susceptible individuals
I0 = 1
E0 = 0
R0 = 0
S0 = N - I0 - E0 - R0

# Initial conditions vector
y0 = np.array([S0, E0, I0, R0])

# Time points (days)
t = np.linspace(0, 160, 160)

dt = t[1] - t[0]

# Initialize arrays to store results
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

# Set initial values
S[0], E[0], I[0], R[0] = S0, E0, I0, R0

y = y0

# Run the RK2 method
for i in range(1, len(t)):
    y = rk2_step(y, seir_derivatives, dt, beta, gamma, sigma, N)
    S[i], E[i], I[i], R[i] = y

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', label='Susceptible')
plt.plot(t, E, 'y', label='Exposed')
plt.plot(t, I, 'r', label='Infected')
plt.plot(t, R, 'g', label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.title('SEIR Model using RK2')
plt.legend()
plt.grid(True)
plt.show()
