import numpy as np

def SEIRD_model(S, E, I, R, D, beta, sigma, gamma, mu):
    N = S + E + I + R + D
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I - mu * I
    dR_dt = gamma * I
    dD_dt = mu * I
    return dS_dt, dE_dt, dI_dt, dR_dt, dD_dt

# Runge-Kutta 3rd order method (RK3)
def RK3_step(S, E, I, R, D, beta, sigma, gamma, mu, dt):
    k1 = SEIRD_model(S, E, I, R, D, beta, sigma, gamma, mu)
    k1 = np.array(k1)

    k2 = SEIRD_model(S + 0.5 * dt * k1[0], E + 0.5 * dt * k1[1], I + 0.5 * dt * k1[2], R + 0.5 * dt * k1[3], D + 0.5 * dt * k1[4], beta, sigma, gamma, mu)
    k2 = np.array(k2)

    k3 = SEIRD_model(S - dt * k1[0] + 2 * dt * k2[0], E - dt * k1[1] + 2 * dt * k2[1], I - dt * k1[2] + 2 * dt * k2[2], R - dt * k1[3] + 2 * dt * k2[3], D - dt * k1[4] + 2 * dt * k2[4], beta, sigma, gamma, mu)
    k3 = np.array(k3)

    S_next = S + (dt / 6) * (k1[0] + 4 * k2[0] + k3[0])
    E_next = E + (dt / 6) * (k1[1] + 4 * k2[1] + k3[1])
    I_next = I + (dt / 6) * (k1[2] + 4 * k2[2] + k3[2])
    R_next = R + (dt / 6) * (k1[3] + 4 * k2[3] + k3[3])
    D_next = D + (dt / 6) * (k1[4] + 4 * k2[4] + k3[4])

    return S_next, E_next, I_next, R_next, D_next

# Example usage
def simulate_SEIRD(S0, E0, I0, R0, D0, beta, sigma, gamma, mu, days, dt):
    S, E, I, R, D = S0, E0, I0, R0, D0
    S_hist, E_hist, I_hist, R_hist, D_hist = [S], [E], [I], [R], [D]

    for _ in range(int(days / dt)):
        S, E, I, R, D = RK3_step(S, E, I, R, D, beta, sigma, gamma, mu, dt)
        S_hist.append(S)
        E_hist.append(E)
        I_hist.append(I)
        R_hist.append(R)
        D_hist.append(D)

    return np.array(S_hist), np.array(E_hist), np.array(I_hist), np.array(R_hist), np.array(D_hist)

# Parameters and initial conditions
S0, E0, I0, R0, D0 = 999, 1, 0, 0, 0
beta, sigma, gamma, mu = 0.3, 1/5.2, 1/18, 0.01
days, dt = 160, 0.1

# Simulate
S_hist, E_hist, I_hist, R_hist, D_hist = simulate_SEIRD(S0, E0, I0, R0, D0, beta, sigma, gamma, mu, days, dt)

print('Susceptible:', S_hist)
print('Exposed:', E_hist)
print('Infected:', I_hist)
print('Recovered:', R_hist)
print('Deceased:', D_hist)
