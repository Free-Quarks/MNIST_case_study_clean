# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Define the SIR model differential equations
def SIR_model(y, beta, gamma):
    S, I, R = y
    dS_dt = -beta * S * I
    dI_dt = beta * S * I - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dI_dt, dR_dt])

# Define the Runge-Kutta 2nd order method (RK2)
def RK2_step(f, y, t, dt, *args):
    k1 = dt * f(y, *args)
    k2 = dt * f(y + 0.5 * k1, *args)
    return y + k2

# Initial conditions and parameters
S0 = 0.99  # Initial fraction of susceptible individuals
I0 = 0.01  # Initial fraction of infected individuals
R0 = 0.0   # Initial fraction of recovered individuals
beta = 0.3 # Infection rate
gamma = 0.1# Recovery rate

# Time parameters
t_max = 160  # Maximum time
dt = 1.0    # Time step

# Time array
t = np.arange(0, t_max, dt)

# Initialize arrays to store the results
S = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

# Set initial conditions
S[0] = S0
I[0] = I0
R[0] = R0

# Integrate the SIR equations over the time grid
for i in range(1, len(t)):
    y = np.array([S[i-1], I[i-1], R[i-1]])
    y_next = RK2_step(SIR_model, y, t[i-1], dt, beta, gamma)
    S[i], I[i], R[i] = y_next

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible', color='blue')
plt.plot(t, I, label='Infected', color='red')
plt.plot(t, R, label='Recovered', color='green')
plt.xlabel('Time')
plt.ylabel('Fraction of Population')
plt.title('SIR Model Simulation with RK2')
plt.legend()
plt.grid(True)
plt.show()

