import random

# Define parameters
population_size = 1000
initial_infected = 10
simulation_days = 30
transmission_probability = 0.1
recovery_days = 14

# Stratify population: age groups
age_groups = {'child': 0.2, 'adult': 0.6, 'elderly': 0.2}
population = [{'status': 'susceptible', 'days_infected': 0, 'age_group': random.choices(list(age_groups.keys()), weights=list(age_groups.values()))[0]} for _ in range(population_size)]
for i in range(initial_infected):
    population[i]['status'] = 'infected'

# Simulation function
def simulate_day(population):
    new_infections = 0
    for person in population:
        if person['status'] == 'infected':
            person['days_infected'] += 1
            if person['days_infected'] >= recovery_days:
                person['status'] = 'recovered'
            else:
                for contact in population:
                    if contact['status'] == 'susceptible':
                        if random.random() < transmission_probability:
                            contact['status'] = 'infected'
                            new_infections += 1
    return new_infections

# Run simulation
for day in range(simulation_days):
    new_infections = simulate_day(population)
    print(f"Day {day + 1}: New infections = {new_infections}")

# Output final state
final_state = {'susceptible': 0, 'infected': 0, 'recovered': 0}
for person in population:
    final_state[person['status']] += 1
print(f"Final state: {final_state}")
