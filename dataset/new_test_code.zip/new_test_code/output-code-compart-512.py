import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Rate at which exposed individuals become infectious
gamma = 0.1  # Recovery rate
mu = 0.01  # Mortality rate

# Initial conditions
S0 = 0.99  # Initial proportion of susceptible individuals
E0 = 0.01  # Initial proportion of exposed individuals
I0 = 0.0  # Initial proportion of infectious individuals
R0 = 0.0  # Initial proportion of recovered individuals
D0 = 0.0  # Initial proportion of dead individuals

# Time vector
T = 160  # Time period for simulation
t = np.linspace(0, T, T)

# SEIRD model differential equations
def deriv(y, t, beta, sigma, gamma, mu):
    S, E, I, R, D = y
    dSdt = -beta * S * I
    dEdt = beta * S * I - sigma * E
    dIdt = sigma * E - (gamma + mu) * I
    dRdt = gamma * I
    dDdt = mu * I
    return [dSdt, dEdt, dIdt, dRdt, dDdt]

# Initial conditions vector
y0 = [S0, E0, I0, R0, D0]

# Integrate the SEIRD equations over the time grid, t.
ret = odeint(deriv, y0, t, args=(beta, sigma, gamma, mu))
S, E, I, R, D = ret.T

# Plot the data
plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infectious')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.plot(t, D, 'k', alpha=0.7, linewidth=2, label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.title('SEIRD Model')
plt.legend(loc='best')
plt.grid(True)
plt.show()
