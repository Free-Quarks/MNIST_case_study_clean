import numpy as np
import matplotlib.pyplot as plt

# SIR Model parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate

# Initial conditions
S0 = 990  # Initial susceptible population
I0 = 10   # Initial infected population
R0 = 0    # Initial recovered population

# Time parameters
T = 160  # Total time in days
dt = 1   # Time step size

# Runge-Kutta 3rd order (RK3) coefficients
A = [0.0, -5.0/9.0, -153.0/128.0]
B = [1/3.0, 15.0/16.0, 8.0/15.0]

# Derivatives function for the SIR model
def sir_derivatives(S, I, R, beta, gamma):
    dSdt = -beta * S * I / (S + I + R)
    dIdt = beta * S * I / (S + I + R) - gamma * I
    dRdt = gamma * I
    return dSdt, dIdt, dRdt

# Simulation function using RK3
def rk3_sir(beta, gamma, S0, I0, R0, T, dt):
    N = int(T / dt)
    t = np.linspace(0, T, N)
    S = np.zeros(N)
    I = np.zeros(N)
    R = np.zeros(N)

    S[0], I[0], R[0] = S0, I0, R0

    for n in range(N-1):
        S1, I1, R1 = S[n], I[n], R[n]
        k1_S, k1_I, k1_R = sir_derivatives(S1, I1, R1, beta, gamma)

        S2 = S1 + dt * A[1] * k1_S
        I2 = I1 + dt * A[1] * k1_I
        R2 = R1 + dt * A[1] * k1_R
        k2_S, k2_I, k2_R = sir_derivatives(S2, I2, R2, beta, gamma)

        S3 = S1 + dt * A[2] * k2_S
        I3 = I1 + dt * A[2] * k2_I
        R3 = R1 + dt * A[2] * k2_R
        k3_S, k3_I, k3_R = sir_derivatives(S3, I3, R3, beta, gamma)

        S[n+1] = S1 + dt * (B[0] * k1_S + B[1] * k2_S + B[2] * k3_S)
        I[n+1] = I1 + dt * (B[0] * k1_I + B[1] * k2_I + B[2] * k3_I)
        R[n+1] = R1 + dt * (B[0] * k1_R + B[1] * k2_R + B[2] * k3_R)

    return t, S, I, R

# Run the simulation
t, S, I, R = rk3_sir(beta, gamma, S0, I0, R0, T, dt)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SIR Model Simulation with RK3')
plt.grid(True)
plt.show()
