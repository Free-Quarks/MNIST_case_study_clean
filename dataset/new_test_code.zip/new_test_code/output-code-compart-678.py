# SIR Model with RK2 Method
import numpy as np
import json

# Define the SIR model differential equations
def sir_model(S, I, R, beta, gamma):
    dS = -beta * S * I
    dI = beta * S * I - gamma * I
    dR = gamma * I
    return dS, dI, dR

# RK2 method for the SIR model
def rk2_step(S, I, R, beta, gamma, dt):
    dS1, dI1, dR1 = sir_model(S, I, R, beta, gamma)
    S1 = S + dS1 * dt / 2
    I1 = I + dI1 * dt / 2
    R1 = R + dR1 * dt / 2
    dS2, dI2, dR2 = sir_model(S1, I1, R1, beta, gamma)
    S = S + dS2 * dt
    I = I + dI2 * dt
    R = R + dR2 * dt
    return S, I, R

# Initialize parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
S = 0.99  # Initial susceptible population
I = 0.01  # Initial infected population
R = 0.0  # Initial recovered population
dt = 0.1  # Time step
T = 160  # Total time

# Time loop
S_list = [S]
I_list = [I]
R_list = [R]
time = [0]
for t in np.arange(dt, T, dt):
    S, I, R = rk2_step(S, I, R, beta, gamma, dt)
    S_list.append(S)
    I_list.append(I)
    R_list.append(R)
    time.append(t)

# Output results as a JSON
results = {
    "time": time,
    "S": S_list,
    "I": I_list,
    "R": R_list
}

# Print results
print(json.dumps(results, indent=4))

