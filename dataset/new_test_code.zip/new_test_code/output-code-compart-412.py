import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SEIRD model

def seird_model(y, t, beta, gamma, delta, alpha):
    S, E, I, R, D = y
    N = S + E + I + R + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - delta * E
    dIdt = delta * E - gamma * I
    dRdt = gamma * I
    dDdt = alpha * I
    return [dSdt, dEdt, dIdt, dRdt, dDdt]

# Initial conditions
N = 1000
I0 = 1
E0 = 0
R0 = 0
D0 = 0
S0 = N - I0 - E0 - R0 - D0

# Parameters
beta = 0.3
gamma = 0.1
delta = 0.1
alpha = 0.01

# Time points (in days)
t = np.linspace(0, 160, 160)

# Initial state vector
y0 = [S0, E0, I0, R0, D0]

# Solve the SEIRD equations
solution = odeint(seird_model, y0, t, args=(beta, gamma, delta, alpha))
S, E, I, R, D = solution.T

# Plot the data
plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', label='Susceptible')
plt.plot(t, E, 'y', label='Exposed')
plt.plot(t, I, 'r', label='Infected')
plt.plot(t, R, 'g', label='Recovered')
plt.plot(t, D, 'k', label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.title('SEIRD Model')
plt.legend()
plt.grid(True)
plt.show()
