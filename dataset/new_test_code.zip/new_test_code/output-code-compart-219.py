import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

def sidarthe_model(t, y, alpha, beta, gamma, delta, epsilon, zeta, eta, theta, iota, kappa, lambda_, mu, nu, xi, rho, sigma, tau, omega, pi):
    S, I, D, A, R, T, H, E = y
    dS_dt = -alpha * S * I - beta * S * D - gamma * S * A - delta * S * R
    dI_dt = alpha * S * I + beta * S * D + gamma * S * A + delta * S * R - epsilon * I - zeta * I - eta * I
    dD_dt = epsilon * I - theta * D - iota * D - kappa * D
    dA_dt = zeta * I - lambda_ * A - mu * A - nu * A
    dR_dt = eta * I + theta * D + lambda_ * A - xi * R - rho * R
    dT_dt = iota * D + mu * A + xi * R - sigma * T - tau * T - omega * T
    dH_dt = kappa * D + nu * A + rho * R + sigma * T - pi * H
    dE_dt = tau * T + omega * T + pi * H
    return [dS_dt, dI_dt, dD_dt, dA_dt, dR_dt, dT_dt, dH_dt, dE_dt]

def simulate_sidarthe(S0, I0, D0, A0, R0, T0, H0, E0, alpha, beta, gamma, delta, epsilon, zeta, eta, theta, iota, kappa, lambda_, mu, nu, xi, rho, sigma, tau, omega, pi, t_span, t_eval):
    y0 = [S0, I0, D0, A0, R0, T0, H0, E0]
    sol = solve_ivp(lambda t, y: sidarthe_model(t, y, alpha, beta, gamma, delta, epsilon, zeta, eta, theta, iota, kappa, lambda_, mu, nu, xi, rho, sigma, tau, omega, pi), t_span, y0, t_eval=t_eval, method='RK23')
    return sol

# Parameters (example values, these should be adjusted)
S0, I0, D0, A0, R0, T0, H0, E0 = 0.99, 0.01, 0, 0, 0, 0, 0, 0
alpha, beta, gamma, delta = 0.1, 0.01, 0.01, 0.005
epsilon, zeta, eta, theta = 0.02, 0.015, 0.01, 0.01
iota, kappa, lambda_, mu = 0.01, 0.01, 0.01, 0.01
nu, xi, rho, sigma = 0.01, 0.01, 0.01, 0.01
tau, omega, pi = 0.01, 0.01, 0.01
t_span = (0, 100)
t_eval = np.linspace(0, 100, 1000)

# Simulation
sol = simulate_sidarthe(S0, I0, D0, A0, R0, T0, H0, E0, alpha, beta, gamma, delta, epsilon, zeta, eta, theta, iota, kappa, lambda_, mu, nu, xi, rho, sigma, tau, omega, pi, t_span, t_eval)

# Plot results
plt.plot(sol.t, sol.y[0], label='S')
plt.plot(sol.t, sol.y[1], label='I')
plt.plot(sol.t, sol.y[2], label='D')
plt.plot(sol.t, sol.y[3], label='A')
plt.plot(sol.t, sol.y[4], label='R')
plt.plot(sol.t, sol.y[5], label='T')
plt.plot(sol.t, sol.y[6], label='H')
plt.plot(sol.t, sol.y[7], label='E')
plt.xlabel('Time')
plt.ylabel('Proportion of Population')
plt.legend()
plt.show()
