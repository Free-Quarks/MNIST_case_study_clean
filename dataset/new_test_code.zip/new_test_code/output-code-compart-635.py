# SEIR Model with RK4 method
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Rate of progression from exposed to infectious
gamma = 1/2.9  # Recovery rate
N = 1000  # Total population

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0

# Time parameters
t0 = 0
tf = 160
dt = 0.1

# SEIR model differential equations
def seir_deriv(y, t, beta, sigma, gamma, N):
    S, E, I, R = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I
    dRdt = gamma * I
    return np.array([dSdt, dEdt, dIdt, dRdt])

# Runge-Kutta 4th order method (RK4)
def rk4_step(f, y, t, dt, *args):
    k1 = f(y, t, *args)
    k2 = f(y + 0.5 * dt * k1, t + 0.5 * dt, *args)
    k3 = f(y + 0.5 * dt * k2, t + 0.5 * dt, *args)
    k4 = f(y + dt * k3, t + dt, *args)
    return y + (dt / 6) * (k1 + 2 * k2 + 2 * k3 + k4)

# Time points
t = np.arange(t0, tf, dt)

# Initialize arrays
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

# Initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# Time-stepping
for i in range(1, len(t)):
    y = np.array([S[i-1], E[i-1], I[i-1], R[i-1]])
    y_next = rk4_step(seir_deriv, y, t[i-1], dt, beta, sigma, gamma, N)
    S[i], E[i], I[i], R[i] = y_next

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Number of Individuals')
plt.legend()
plt.title('SEIR Model with RK4 Method')
plt.grid(True)
plt.show()
