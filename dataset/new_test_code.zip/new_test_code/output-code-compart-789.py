import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model
def seird_model(S, E, I, R, D, beta, sigma, gamma, mu):
    N = S + E + I + R + D
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I - mu * I
    dR_dt = gamma * I
    dD_dt = mu * I
    return dS_dt, dE_dt, dI_dt, dR_dt, dD_dt

# Runge-Kutta 3rd order method (RK3)
def rk3_step(S, E, I, R, D, beta, sigma, gamma, mu, dt):
    k1 = seird_model(S, E, I, R, D, beta, sigma, gamma, mu)
    k2 = seird_model(S + dt/2 * k1[0], E + dt/2 * k1[1], I + dt/2 * k1[2], R + dt/2 * k1[3], D + dt/2 * k1[4], beta, sigma, gamma, mu)
    k3 = seird_model(S - dt * k1[0] + 2 * dt * k2[0], E - dt * k1[1] + 2 * dt * k2[1], I - dt * k1[2] + 2 * dt * k2[2], R - dt * k1[3] + 2 * dt * k2[3], D - dt * k1[4] + 2 * dt * k2[4], beta, sigma, gamma, mu)
    S_next = S + dt/6 * (k1[0] + 4 * k2[0] + k3[0])
    E_next = E + dt/6 * (k1[1] + 4 * k2[1] + k3[1])
    I_next = I + dt/6 * (k1[2] + 4 * k2[2] + k3[2])
    R_next = R + dt/6 * (k1[3] + 4 * k2[3] + k3[3])
    D_next = D + dt/6 * (k1[4] + 4 * k2[4] + k3[4])
    return S_next, E_next, I_next, R_next, D_next

# Simulation parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Incubation rate (1/average incubation period)
gamma = 1/2.3  # Recovery rate (1/average infectious period)
mu = 0.01  # Mortality rate

# Initial conditions
S0 = 9990
E0 = 10
I0 = 0
R0 = 0
D0 = 0

# Time parameters
t_max = 160
dt = 1
t = np.arange(0, t_max, dt)

# Arrays to store results
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))
D = np.zeros(len(t))

# Initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
D[0] = D0

# Run simulation
for i in range(1, len(t)):
    S[i], E[i], I[i], R[i], D[i] = rk3_step(S[i-1], E[i-1], I[i-1], R[i-1], D[i-1], beta, sigma, gamma, mu, dt)

# Plot results
plt.figure(figsize=(10,6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.plot(t, D, label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRD Model Simulation')
plt.show()
