import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model
class SEIRDModel:
    def __init__(self, beta, sigma, gamma, delta, population, initial_infected, initial_exposed, initial_recovered, initial_dead):
        self.beta = beta  # Infection rate
        self.sigma = sigma  # Rate of progression from exposed to infected
        self.gamma = gamma  # Recovery rate
        self.delta = delta  # Mortality rate
        self.population = population  # Total population
        self.initial_infected = initial_infected
        self.initial_exposed = initial_exposed
        self.initial_recovered = initial_recovered
        self.initial_dead = initial_dead

    def derivatives(self, y, t):
        S, E, I, R, D = y
        N = self.population
        dSdt = -self.beta * S * I / N
        dEdt = self.beta * S * I / N - self.sigma * E
        dIdt = self.sigma * E - (self.gamma + self.delta) * I
        dRdt = self.gamma * I
        dDdt = self.delta * I
        return np.array([dSdt, dEdt, dIdt, dRdt, dDdt])

    def runge_kutta_3(self, y0, t):
        n = len(t)
        y = np.zeros((n, len(y0)))
        y[0] = y0
        for i in range(1, n):
            h = t[i] - t[i-1]
            k1 = self.derivatives(y[i-1], t[i-1])
            k2 = self.derivatives(y[i-1] + h * k1 / 2, t[i-1] + h / 2)
            k3 = self.derivatives(y[i-1] - h * k1 + 2 * h * k2, t[i-1] + h)
            y[i] = y[i-1] + h * (k1 + 4 * k2 + k3) / 6
        return y

    def simulate(self, days):
        t = np.linspace(0, days, days)
        initial_conditions = [self.population - self.initial_infected - self.initial_exposed - self.initial_recovered - self.initial_dead, self.initial_exposed, self.initial_infected, self.initial_recovered, self.initial_dead]
        result = self.runge_kutta_3(initial_conditions, t)
        return t, result

# Parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Rate of progression from exposed to infected
gamma = 0.05  # Recovery rate
delta = 0.01  # Mortality rate
population = 1000000  # Total population
initial_infected = 1
initial_exposed = 0
initial_recovered = 0
initial_dead = 0

# Simulation
model = SEIRDModel(beta, sigma, gamma, delta, population, initial_infected, initial_exposed, initial_recovered, initial_dead)
days = 160
t, result = model.simulate(days)

# Plotting
plt.figure(figsize=(10, 6))
plt.plot(t, result[:, 0], 'b', label='Susceptible')
plt.plot(t, result[:, 1], 'y', label='Exposed')
plt.plot(t, result[:, 2], 'r', label='Infected')
plt.plot(t, result[:, 3], 'g', label='Recovered')
plt.plot(t, result[:, 4], 'k', label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Number of people')
plt.title('SEIRD Model Simulation')
plt.legend()
plt.grid(True)
plt.show()
