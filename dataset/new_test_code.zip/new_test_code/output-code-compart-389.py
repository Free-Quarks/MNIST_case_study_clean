import numpy as np
import matplotlib.pyplot as plt

class SEIRDModel:
    def __init__(self, S0, E0, I0, R0, D0, beta, sigma, gamma, mu, dt):
        self.S = S0
        self.E = E0
        self.I = I0
        self.R = R0
        self.D = D0
        self.beta = beta
        self.sigma = sigma
        self.gamma = gamma
        self.mu = mu
        self.dt = dt

    def derivatives(self, S, E, I, R, D):
        dS = -self.beta * S * I
        dE = self.beta * S * I - self.sigma * E
        dI = self.sigma * E - (self.gamma + self.mu) * I
        dR = self.gamma * I
        dD = self.mu * I
        return dS, dE, dI, dR, dD

    def runge_kutta_3(self):
        S, E, I, R, D = self.S, self.E, self.I, self.R, self.D
        dt = self.dt

        k1 = self.derivatives(S, E, I, R, D)
        k2 = self.derivatives(S + dt / 2 * k1[0], E + dt / 2 * k1[1], I + dt / 2 * k1[2], R + dt / 2 * k1[3], D + dt / 2 * k1[4])
        k3 = self.derivatives(S - dt * k1[0] + 2 * dt * k2[0], E - dt * k1[1] + 2 * dt * k2[1], I - dt * k1[2] + 2 * dt * k2[2], R - dt * k1[3] + 2 * dt * k2[3], D - dt * k1[4] + 2 * dt * k2[4])

        S += dt / 6 * (k1[0] + 4 * k2[0] + k3[0])
        E += dt / 6 * (k1[1] + 4 * k2[1] + k3[1])
        I += dt / 6 * (k1[2] + 4 * k2[2] + k3[2])
        R += dt / 6 * (k1[3] + 4 * k2[3] + k3[3])
        D += dt / 6 * (k1[4] + 4 * k2[4] + k3[4])

        self.S, self.E, self.I, self.R, self.D = S, E, I, R, D

    def run(self, days):
        S_history = []
        E_history = []
        I_history = []
        R_history = []
        D_history = []

        for _ in range(days):
            self.runge_kutta_3()
            S_history.append(self.S)
            E_history.append(self.E)
            I_history.append(self.I)
            R_history.append(self.R)
            D_history.append(self.D)

        return np.array(S_history), np.array(E_history), np.array(I_history), np.array(R_history), np.array(D_history)

# Example usage
S0 = 0.99
E0 = 0.01
I0 = 0.0
R0 = 0.0
D0 = 0.0
beta = 0.3
sigma = 0.1
gamma = 0.05
mu = 0.01
dt = 0.1
days = 160

model = SEIRDModel(S0, E0, I0, R0, D0, beta, sigma, gamma, mu, dt)
S_history, E_history, I_history, R_history, D_history = model.run(days)

plt.plot(S_history, label='Susceptible')
plt.plot(E_history, label='Exposed')
plt.plot(I_history, label='Infected')
plt.plot(R_history, label='Recovered')
plt.plot(D_history, label='Deceased')
plt.xlabel('Days')
plt.ylabel('Population Fraction')
plt.legend()
plt.show()
