import numpy as np
import matplotlib.pyplot as plt

# Define the SEIR model differential equations
def SEIR_model(y, beta, sigma, gamma):
    S, E, I, R = y
    N = S + E + I + R
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt])

# Runge-Kutta 2nd order method (RK2)
def RK2_step(f, y, t, dt, *args):
    k1 = f(y, *args)
    k2 = f(y + dt * k1, *args)
    return y + (dt / 2) * (k1 + k2)

# Simulation parameters
beta = 0.3    # Infection rate
sigma = 0.1   # Rate of progression from exposed to infectious
gamma = 0.1   # Recovery rate
dt = 0.1      # Time step
t_max = 160   # Maximum time

# Initial conditions
S0 = 0.99     # Initial proportion of susceptible individuals
E0 = 0.01     # Initial proportion of exposed individuals
I0 = 0.0      # Initial proportion of infectious individuals
R0 = 0.0      # Initial proportion of recovered individuals
y0 = np.array([S0, E0, I0, R0])

time = np.arange(0, t_max, dt)
results = np.zeros((len(time), 4))
results[0] = y0

# Time-stepping loop
for i in range(1, len(time)):
    results[i] = RK2_step(SEIR_model, results[i-1], time[i-1], dt, beta, sigma, gamma)

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(time, results[:, 0], label='Susceptible')
plt.plot(time, results[:, 1], label='Exposed')
plt.plot(time, results[:, 2], label='Infectious')
plt.plot(time, results[:, 3], label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIR Model Simulation using RK2')
plt.grid(True)
plt.show()
