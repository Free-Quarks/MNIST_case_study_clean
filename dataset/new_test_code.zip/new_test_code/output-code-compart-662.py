import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# SEIRD model differential equations.
def deriv(y, t, N, beta, sigma, gamma, delta):
    S, E, I, R, D = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - delta * I
    dRdt = gamma * I
    dDdt = delta * I
    return dSdt, dEdt, dIdt, dRdt, dDdt

# Total population, N.
N = 1000
# Initial number of infected, recovered, exposed, and dead individuals, I0, R0, E0, D0.
I0, R0, E0, D0 = 1, 0, 0, 0
# Everyone else, S0, is susceptible to infection initially.
S0 = N - I0 - R0 - E0 - D0
# Contact rate, beta, incubation rate, sigma, mean recovery rate, gamma, and death rate, delta (in 1/days).
beta, sigma, gamma, delta = 0.3, 1/5.2, 1/18, 0.01
# A grid of time points (in days)
t = np.linspace(0, 160, 160)
# Initial conditions vector
y0 = S0, E0, I0, R0, D0

# Integrate the SEIRD equations over the time grid, t.
ret = odeint(deriv, y0, t, args=(N, beta, sigma, gamma, delta))
S, E, I, R, D = ret.T

# Plot the data on four separate curves for S(t), E(t), I(t), R(t), and D(t)
fig = plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linestyle='-', label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linestyle='-', label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linestyle='-', label='Infected')
plt.plot(t, R, 'g', alpha=0.7, linestyle='-', label='Recovered')
plt.plot(t, D, 'k', alpha=0.7, linestyle='-', label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Number of people')
plt.legend()
plt.grid(True)
plt.title('SEIRD Model')
plt.show()

