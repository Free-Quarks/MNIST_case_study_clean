import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

def seirhd_model(y, t, beta, sigma, gamma, delta, alpha):
    S, E, I, R, H, D = y
    N = S + E + I + R + H + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - delta * I
    dRdt = gamma * I
    dHdt = delta * I - alpha * H
    dDdt = alpha * H
    return [dSdt, dEdt, dIdt, dRdt, dHdt, dDdt]

def run_seirhd_model(S0, E0, I0, R0, H0, D0, beta, sigma, gamma, delta, alpha, days):
    initial_conditions = [S0, E0, I0, R0, H0, D0]
    t = np.linspace(0, days, days)
    result = odeint(seirhd_model, initial_conditions, t, args=(beta, sigma, gamma, delta, alpha))
    return t, result

# Parameters
S0 = 999
E0 = 1
I0 = 0
R0 = 0
H0 = 0
D0 = 0
beta = 0.3
sigma = 1/5.2
gamma = 1/2.9
delta = 0.05
alpha = 0.02

# Number of days to simulate
days = 160

t, result = run_seirhd_model(S0, E0, I0, R0, H0, D0, beta, sigma, gamma, delta, alpha, days)

S, E, I, R, H, D = result.T

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, H, label='Hospitalized')
plt.plot(t, D, label='Deceased')
plt.xlabel('Days')
plt.ylabel('Number of People')
plt.title('SEIRHD Model')
plt.legend()
plt.grid(True)
plt.show()
