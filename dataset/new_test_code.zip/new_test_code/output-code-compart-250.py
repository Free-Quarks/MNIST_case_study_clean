# This Python script simulates the SEIRHD model using the RK4 (Runge-Kutta 4) method.
import numpy as np

# Define the SEIRHD model equations
def seirhd_model(y, beta, sigma, gamma, mu, delta):
    S, E, I, R, H, D = y
    N = S + E + I + R + H
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - mu * I - delta * I
    dRdt = gamma * I
    dHdt = mu * I
    dDdt = delta * I
    return np.array([dSdt, dEdt, dIdt, dRdt, dHdt, dDdt])

# RK4 integration method
def rk4_step(f, y, t, dt, *args):
    k1 = f(y, *args)
    k2 = f(y + dt / 2 * k1, *args)
    k3 = f(y + dt / 2 * k2, *args)
    k4 = f(y + dt * k3, *args)
    return y + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)

# Simulation parameters
beta = 0.3   # Infection rate
sigma = 0.1  # Transition rate from exposed to infected
gamma = 0.05 # Recovery rate
mu = 0.01    # Hospitalization rate
delta = 0.005# Death rate

# Initial conditions
S0 = 9990
E0 = 10
I0 = 0
R0 = 0
H0 = 0
D0 = 0
y0 = np.array([S0, E0, I0, R0, H0, D0])

# Time parameters
dt = 1.0  # Time step (days)
t_max = 160  # Maximum time (days)
t_values = np.arange(0, t_max, dt)
y_values = np.zeros((len(t_values), len(y0)))
y_values[0] = y0

# Run the simulation
for i in range(1, len(t_values)):
    y_values[i] = rk4_step(seirhd_model, y_values[i - 1], t_values[i - 1], dt, beta, sigma, gamma, mu, delta)

# Print the results
total_infected = y_values[:, 2].max() + y_values[:, 3].max() + y_values[:, 4].max() + y_values[:, 5].max()
print(f"Total infected individuals: {total_infected}")

