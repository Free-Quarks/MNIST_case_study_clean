# Import necessary libraries
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SIR model differential equations
def sir_model(y, t, beta, gamma):
    S, I, R = y
    dSdt = -beta * S * I
    dIdt = beta * S * I - gamma * I
    dRdt = gamma * I
    return [dSdt, dIdt, dRdt]

# Initial conditions: S0, I0, R0
S0 = 0.99   # Initial proportion of susceptible individuals
I0 = 0.01   # Initial proportion of infected individuals
R0 = 0.0    # Initial proportion of recovered individuals

# Contact rate, beta, and mean recovery rate, gamma
beta = 0.3  # Contact rate
gamma = 0.1 # Mean recovery rate

# Initial conditions vector
y0 = [S0, I0, R0]

# Time grid (e.g., 0 to 160 days)
t = np.linspace(0, 160, 160)

# Integrate the SIR equations over the time grid, t
solution = odeint(sir_model, y0, t, args=(beta, gamma))
S, I, R = solution.T

# Plot the data
plt.figure(figsize=(10,6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.title('SIR Model')
plt.legend()
plt.grid(True)
plt.show()
