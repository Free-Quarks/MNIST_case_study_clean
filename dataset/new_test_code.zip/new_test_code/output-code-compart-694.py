import numpy as np
import matplotlib.pyplot as plt

# SIDARTHE model parameters
beta = 0.57  # Transmission rate
sigma = 0.1  # Rate of detection of infected individuals
eta = 0.1    # Rate of detection of asymptomatic individuals
lambda_ = 0.034  # Rate of hospitalization of symptomatic individuals
rho = 0.017  # Rate of recovery of symptomatic individuals
kappa = 0.017  # Rate of recovery of asymptomatic individuals
xi = 0.017   # Rate of deaths of symptomatic individuals
mu = 0.034   # Rate of deaths of hospitalized individuals
nu = 0.034   # Rate of recovery of hospitalized individuals

delta = 0.034  # Rate of isolation of detected individuals

def sidarthe_model(t, y, beta, sigma, eta, lambda_, rho, kappa, xi, mu, nu, delta):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E
    dSdt = -beta * S * (I + D + A + R) / N
    dIdt = beta * S * (I + D + A + R) / N - (sigma + lambda_ + rho + xi) * I
    dDdt = sigma * I - (eta + delta + rho + xi) * D
    dAdt = eta * D - (lambda_ + kappa) * A
    dRdt = rho * I + kappa * A + nu * H - delta * R
    dTdt = lambda_ * (I + A) - (mu + nu) * T
    dHdt = delta * (D + R) - (mu + nu) * H
    dEdt = xi * (I + D) + mu * (T + H)
    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Runge-Kutta 3rd order method

def rk3_step(f, t, y, h, *args):
    k1 = f(t, y, *args)
    k2 = f(t + h / 2.0, y + h / 2.0 * np.array(k1), *args)
    k3 = f(t + h, y - h * np.array(k1) + 2 * h * np.array(k2), *args)
    return y + h / 6.0 * (np.array(k1) + 4.0 * np.array(k2) + np.array(k3))

# Initialize parameters
S0 = 1e6   # Initial susceptible population
I0 = 1     # Initial infected population
D0 = 0     # Initial detected infected population
A0 = 0     # Initial asymptomatic population
R0 = 0     # Initial recovered population
T0 = 0     # Initial threatened population
H0 = 0     # Initial hospitalized population
E0 = 0     # Initial extinct population

# Initial conditions vector
initial_conditions = [S0, I0, D0, A0, R0, T0, H0, E0]

# Time vector
t_max = 160
h = 1.0
t_values = np.arange(0, t_max + h, h)

# Result matrices
results = np.zeros((len(t_values), len(initial_conditions)))
results[0] = initial_conditions

# Time-stepping loop
for i in range(1, len(t_values)):
    t = t_values[i-1]
    y = results[i-1]
    results[i] = rk3_step(sidarthe_model, t, y, h, beta, sigma, eta, lambda_, rho, kappa, xi, mu, nu, delta)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t_values, results[:, 0], label='Susceptible')
plt.plot(t_values, results[:, 1], label='Infected')
plt.plot(t_values, results[:, 2], label='Detected')
plt.plot(t_values, results[:, 3], label='Asymptomatic')
plt.plot(t_values, results[:, 4], label='Recovered')
plt.plot(t_values, results[:, 5], label='Threatened')
plt.plot(t_values, results[:, 6], label='Hospitalized')
plt.plot(t_values, results[:, 7], label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.title('COVID-19 SIDARTHE Model Simulation')
plt.legend()
plt.grid()
plt.show()
