import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# SEIR model differential equations
def deriv(y, t, beta, sigma, gamma):
    S, E, I, R = y
    dSdt = -beta * S * I
    dEdt = beta * S * I - sigma * E
    dIdt = sigma * E - gamma * I
    dRdt = gamma * I
    return dSdt, dEdt, dIdt, dRdt

# Initial number of infected and recovered individuals, everyone else is susceptible
total_population = 1000
initial_infected = 1
initial_exposed = 0
initial_recovered = 0
initial_susceptible = total_population - initial_infected - initial_exposed - initial_recovered

# Initial conditions vector
y0 = initial_susceptible, initial_exposed, initial_infected, initial_recovered

# Contact rate, incubation rate, recovery rate (in 1/days)
beta = 0.3
sigma = 1/5.2
gamma = 1/14

# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# Integrate the SEIR equations over the time grid, t.
ret = odeint(deriv, y0, t, args=(beta, sigma, gamma))
S, E, I, R = ret.T

# Plot the data on three separate curves for S(t), E(t) and I(t)
fig = plt.figure(facecolor='w')
ax = fig.add_subplot(111, facecolor='#dddddd', axisbelow=True)
ax.plot(t, S/total_population, 'b', alpha=0.5, lw=2, label='Susceptible')
ax.plot(t, E/total_population, 'y', alpha=0.5, lw=2, label='Exposed')
ax.plot(t, I/total_population, 'r', alpha=0.5, lw=2, label='Infected')
ax.plot(t, R/total_population, 'g', alpha=0.5, lw=2, label='Recovered')
ax.set_xlabel('Time /days')
ax.set_ylabel('Number (1000s)')
ax.set_ylim(0,1.2)
ax.legend()
plt.show()
