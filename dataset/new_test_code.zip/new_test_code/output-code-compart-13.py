import numpy as np
import matplotlib.pyplot as plt

# SEIRD Model with Runge-Kutta 2nd Order (RK2)
def SEIRD_model(S0, E0, I0, R0, D0, beta, sigma, gamma, mu, days):
    # Time array
    t = np.linspace(0, days, days)
    dt = t[1] - t[0]

    # Initialize arrays
    S = np.zeros(days)
    E = np.zeros(days)
    I = np.zeros(days)
    R = np.zeros(days)
    D = np.zeros(days)

    # Initial values
    S[0] = S0
    E[0] = E0
    I[0] = I0
    R[0] = R0
    D[0] = D0

    for i in range(1, days):
        k1_S = -beta * S[i-1] * I[i-1]
        k1_E = beta * S[i-1] * I[i-1] - sigma * E[i-1]
        k1_I = sigma * E[i-1] - gamma * I[i-1] - mu * I[i-1]
        k1_R = gamma * I[i-1]
        k1_D = mu * I[i-1]

        S_half = S[i-1] + 0.5 * k1_S * dt
        E_half = E[i-1] + 0.5 * k1_E * dt
        I_half = I[i-1] + 0.5 * k1_I * dt
        R_half = R[i-1] + 0.5 * k1_R * dt
        D_half = D[i-1] + 0.5 * k1_D * dt

        k2_S = -beta * S_half * I_half
        k2_E = beta * S_half * I_half - sigma * E_half
        k2_I = sigma * E_half - gamma * I_half - mu * I_half
        k2_R = gamma * I_half
        k2_D = mu * I_half

        S[i] = S[i-1] + k2_S * dt
        E[i] = E[i-1] + k2_E * dt
        I[i] = I[i-1] + k2_I * dt
        R[i] = R[i-1] + k2_R * dt
        D[i] = D[i-1] + k2_D * dt

    return t, S, E, I, R, D

# Parameters
S0 = 0.99  # Initial susceptible population
E0 = 0.01  # Initial exposed population
I0 = 0.0   # Initial infected population
R0 = 0.0   # Initial recovered population
D0 = 0.0   # Initial deceased population
beta = 0.3  # Transmission rate
sigma = 0.1  # Rate of progression from exposed to infected
gamma = 0.05  # Recovery rate
mu = 0.01  # Mortality rate

# Time period
days = 160

# Run the model
t, S, E, I, R, D = SEIRD_model(S0, E0, I0, R0, D0, beta, sigma, gamma, mu, days)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of Population')
plt.title('SEIRD Model with RK2')
plt.legend()
plt.show()
