import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

# Define parameters
population_size = 1000
initial_infected = 10
transmission_rate = 0.1
recovery_rate = 0.05
age_groups = { '0-19': 0.25, '20-39': 0.35, '40-59': 0.25, '60+': 0.15 }

# Initialize the network
G = nx.erdos_renyi_graph(population_size, 0.1)

# Add age attribute to each node
age_distribution = []
for age_group, proportion in age_groups.items():
    age_distribution.extend([age_group] * int(population_size * proportion))

np.random.shuffle(age_distribution)

for i, node in enumerate(G.nodes()):
    G.nodes[node]['age'] = age_distribution[i]
    G.nodes[node]['status'] = 'S'  # Susceptible

# Infect initial nodes
initial_infected_nodes = np.random.choice(G.nodes(), initial_infected, replace=False)
for node in initial_infected_nodes:
    G.nodes[node]['status'] = 'I'  # Infected

# Simulate the spread of the virus
def simulate_step(G):
    new_statuses = {}
    for node in G.nodes():
        if G.nodes[node]['status'] == 'I':
            for neighbor in G.neighbors(node):
                if G.nodes[neighbor]['status'] == 'S' and np.random.rand() < transmission_rate:
                    new_statuses[neighbor] = 'I'
            if np.random.rand() < recovery_rate:
                new_statuses[node] = 'R'  # Recovered
    for node, status in new_statuses.items():
        G.nodes[node]['status'] = status

steps = 100
for step in range(steps):
    simulate_step(G)

# Plot the final state
statuses = nx.get_node_attributes(G, 'status')
colors = {'S': 'blue', 'I': 'red', 'R': 'green'}
node_colors = [colors[statuses[node]] for node in G.nodes()]

plt.figure(figsize=(12, 12))
pos = nx.spring_layout(G)
nx.draw(G, pos, node_color=node_colors, with_labels=True)
plt.show()
