import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# Define the SEIRHD model

def seirhd_model(t, y, beta, sigma, gamma, delta, alpha):
    S, E, I, R, H, D = y
    N = S + E + I + R + H + D

    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - (gamma + delta + alpha) * I
    dR_dt = gamma * I
    dH_dt = delta * I
    dD_dt = alpha * I

    return [dS_dt, dE_dt, dI_dt, dR_dt, dH_dt, dD_dt]

# Implement the Runge-Kutta 4th order method

def rk4_step(func, t, y, h, *args):
    k1 = h * np.array(func(t, y, *args))
    k2 = h * np.array(func(t + 0.5 * h, y + 0.5 * k1, *args))
    k3 = h * np.array(func(t + 0.5 * h, y + 0.5 * k2, *args))
    k4 = h * np.array(func(t + h, y + k3, *args))
    return y + (k1 + 2 * k2 + 2 * k3 + k4) / 6

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
H0 = 0
D0 = 0
initial_conditions = [S0, E0, I0, R0, H0, D0]

# Parameters
beta = 0.3
sigma = 0.1
gamma = 0.05
delta = 0.01
alpha = 0.02

# Time points
t_start = 0
t_end = 160
h = 1

# Time vector
t = np.arange(t_start, t_end + h, h)

# Initialize results array
results = np.zeros((len(t), len(initial_conditions)))
results[0] = initial_conditions

# Run the simulation
for i in range(1, len(t)):
    results[i] = rk4_step(seirhd_model, t[i-1], results[i-1], h, beta, sigma, gamma, delta, alpha)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, results[:, 0], label='Susceptible (S)')
plt.plot(t, results[:, 1], label='Exposed (E)')
plt.plot(t, results[:, 2], label='Infected (I)')
plt.plot(t, results[:, 3], label='Recovered (R)')
plt.plot(t, results[:, 4], label='Hospitalized (H)')
plt.plot(t, results[:, 5], label='Deceased (D)')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRHD Model Simulation')
plt.grid(True)
plt.show()
