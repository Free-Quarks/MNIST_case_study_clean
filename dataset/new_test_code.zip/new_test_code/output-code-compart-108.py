import numpy as np
import matplotlib.pyplot as plt

# Define the SEIR model
class SEIRModel:
    def __init__(self, beta, sigma, gamma, S0, E0, I0, R0):
        self.beta = beta  # Infection rate
        self.sigma = sigma  # Rate of progression from exposed to infectious
        self.gamma = gamma  # Recovery rate
        self.S0 = S0  # Initial susceptible population
        self.E0 = E0  # Initial exposed population
        self.I0 = I0  # Initial infectious population
        self.R0 = R0  # Initial recovered population

    def derivatives(self, S, E, I, R):
        dSdt = -self.beta * S * I
        dEdt = self.beta * S * I - self.sigma * E
        dIdt = self.sigma * E - self.gamma * I
        dRdt = self.gamma * I
        return dSdt, dEdt, dIdt, dRdt

    def rk2_step(self, S, E, I, R, dt):
        k1_S, k1_E, k1_I, k1_R = self.derivatives(S, E, I, R)
        S_mid = S + k1_S * dt / 2
        E_mid = E + k1_E * dt / 2
        I_mid = I + k1_I * dt / 2
        R_mid = R + k1_R * dt / 2
        k2_S, k2_E, k2_I, k2_R = self.derivatives(S_mid, E_mid, I_mid, R_mid)
        S_next = S + k2_S * dt
        E_next = E + k2_E * dt
        I_next = I + k2_I * dt
        R_next = R + k2_R * dt
        return S_next, E_next, I_next, R_next

    def simulate(self, days, dt):
        num_steps = int(days / dt)
        S = np.zeros(num_steps)
        E = np.zeros(num_steps)
        I = np.zeros(num_steps)
        R = np.zeros(num_steps)
        S[0], E[0], I[0], R[0] = self.S0, self.E0, self.I0, self.R0

        for t in range(1, num_steps):
            S[t], E[t], I[t], R[t] = self.rk2_step(S[t-1], E[t-1], I[t-1], R[t-1], dt)

        return S, E, I, R

# Parameters
beta = 0.3
sigma = 0.1
gamma = 0.1
S0 = 0.99
E0 = 0.01
I0 = 0.0
R0 = 0.0
days = 160
dt = 1.0

# Create and run the model
seir_model = SEIRModel(beta, sigma, gamma, S0, E0, I0, R0)
S, E, I, R = seir_model.simulate(days, dt)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(S, label='Susceptible')
plt.plot(E, label='Exposed')
plt.plot(I, label='Infectious')
plt.plot(R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIR Model Simulation')
plt.show()
