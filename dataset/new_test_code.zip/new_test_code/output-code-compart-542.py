# SIDARTHE Compartmental Model using odeint

import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the differential equations for the SIDARTHE model
def sidarthe(y, t, alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E
    dSdt = -alpha * S * I / N - beta * S * D / N - gamma * S * A / N - delta * S * R / N
    dIdt = alpha * S * I / N + beta * S * D / N + gamma * S * A / N + delta * S * R / N - epsilon * I - zeta * I - lambda_ * I
    dDdt = epsilon * I - eta * D - mu * D
    dAdt = zeta * I - theta * A - nu * A
    dRdt = eta * D - tau * R
    dTdt = theta * A - lambda_ * T
    dHdt = mu * D + nu * A - tau * H
    dEdt = tau * R + tau * H
    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Initial conditions
S0 = 0.99
I0 = 0.01
D0 = 0.0
A0 = 0.0
R0 = 0.0
T0 = 0.0
H0 = 0.0
E0 = 0.0

initial_conditions = [S0, I0, D0, A0, R0, T0, H0, E0]

# Parameters
alpha, beta, gamma, delta = 0.5, 0.2, 0.1, 0.1
epsilon, theta, zeta, eta = 0.1, 0.1, 0.1, 0.1
mu, nu, tau, lambda_ = 0.1, 0.1, 0.1, 0.1

# Time points (in days)
t = np.linspace(0, 160, 160)

# Solve the differential equations
solution = odeint(sidarthe, initial_conditions, t, args=(alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_))

# Plotting
plt.figure(figsize=(12, 8))
plt.plot(t, solution[:, 0], 'b', label='Susceptible')
plt.plot(t, solution[:, 1], 'r', label='Infected')
plt.plot(t, solution[:, 2], 'g', label='Diagnosed')
plt.plot(t, solution[:, 3], 'y', label='Ailing')
plt.plot(t, solution[:, 4], 'c', label='Recovered')
plt.plot(t, solution[:, 5], 'm', label='Threatened')
plt.plot(t, solution[:, 6], 'k', label='Healed')
plt.plot(t, solution[:, 7], 'orange', label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SIDARTHE Model Simulation')
plt.grid()
plt.show()
