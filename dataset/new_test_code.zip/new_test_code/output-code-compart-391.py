import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.57  # Infection rate
sigma = 0.1  # Detection rate
omega = 0.1  # Severe cases rate
rho = 0.2  # Recovery rate of infected individuals
kappa = 0.1  # Hospitalization rate
zeta = 0.2  # Death rate of severe cases
eta = 0.1  # Recovery rate of severe cases

# Time step and duration
dt = 0.1
T = 160

# Initial conditions
S0 = 0.99  # Susceptible
I0 = 0.01  # Infected
D0 = 0.0   # Diagnosed
A0 = 0.0   # Ailing
R0 = 0.0   # Recognized
T0 = 0.0   # Threatened
H0 = 0.0   # Healed
E0 = 0.0   # Extinct

# Number of steps
N = int(T / dt)

# Initialize arrays
S = np.zeros(N)
I = np.zeros(N)
D = np.zeros(N)
A = np.zeros(N)
R = np.zeros(N)
T = np.zeros(N)
H = np.zeros(N)
E = np.zeros(N)

# Initial values
S[0] = S0
I[0] = I0
D[0] = D0
A[0] = A0
R[0] = R0
T[0] = T0
H[0] = H0
E[0] = E0

# Euler's method
for t in range(N - 1):
    S[t + 1] = S[t] - dt * beta * S[t] * I[t]
    I[t + 1] = I[t] + dt * (beta * S[t] * I[t] - sigma * I[t])
    D[t + 1] = D[t] + dt * (sigma * I[t] - omega * D[t])
    A[t + 1] = A[t] + dt * (omega * D[t] - rho * A[t] - kappa * A[t])
    R[t + 1] = R[t] + dt * (rho * A[t] - zeta * R[t] - eta * R[t])
    T[t + 1] = T[t] + dt * (kappa * A[t])
    H[t + 1] = H[t] + dt * (eta * R[t] + rho * A[t])
    E[t + 1] = E[t] + dt * (zeta * R[t])

# Plot the results
plt.figure(figsize=(12, 8))
plt.plot(np.arange(0, T, dt), S, label='Susceptible')
plt.plot(np.arange(0, T, dt), I, label='Infected')
plt.plot(np.arange(0, T, dt), D, label='Diagnosed')
plt.plot(np.arange(0, T, dt), A, label='Ailing')
plt.plot(np.arange(0, T, dt), R, label='Recognized')
plt.plot(np.arange(0, T, dt), T, label='Threatened')
plt.plot(np.arange(0, T, dt), H, label='Healed')
plt.plot(np.arange(0, T, dt), E, label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of population')
plt.legend()
plt.title('SIDARTHE Model Simulation')
plt.show()
