import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SEIRD model with an error

def seird_model(y, t, beta, gamma, delta, alpha):
    S, E, I, R, D = y
    dS_dt = -beta * S * I
    dE_dt = beta * S * I - delta * E  # Incorrect: E should also decrease proportionally to I
    dI_dt = delta * E - gamma * I - alpha * I
    dR_dt = gamma * I
    dD_dt = alpha * I
    return [dS_dt, dE_dt, dI_dt, dR_dt, dD_dt]

# Initial conditions
S0 = 0.99
E0 = 0.01
I0 = 0.0
R0 = 0.0
D0 = 0.0

# Parameters
beta = 0.3
gamma = 0.1
delta = 0.1
alpha = 0.05

# Time vector
t = np.linspace(0, 160, 160)

# Initial state vector
y0 = [S0, E0, I0, R0, D0]

# Integrate the SEIRD equations over the time grid, t.
solution = odeint(seird_model, y0, t, args=(beta, gamma, delta, alpha))
S, E, I, R, D = solution.T

# Plot the data
plt.figure(figsize=(10,6))
plt.plot(t, S, 'b', label='Susceptible')
plt.plot(t, E, 'y', label='Exposed')
plt.plot(t, I, 'r', label='Infected')
plt.plot(t, R, 'g', label='Recovered')
plt.plot(t, D, 'k', label='Deceased')
plt.xlabel('Time /days')
plt.ylabel('Number (proportion)')
plt.legend()
plt.title('SEIRD Model with Incorrect Exposed Dynamics')
plt.show()
