# Simulate COVID-19 spread with vaccination using a simple SIR model
import numpy as np
import matplotlib.pyplot as plt

class SIRModel:
    def __init__(self, population, beta, gamma, vaccination_rate):
        self.population = population
        self.beta = beta  # transmission rate
        self.gamma = gamma  # recovery rate
        self.vaccination_rate = vaccination_rate

    def simulate(self, initial_infected, initial_recovered, days):
        susceptible = self.population - initial_infected - initial_recovered
        infected = initial_infected
        recovered = initial_recovered

        S = [susceptible]
        I = [infected]
        R = [recovered]

        for _ in range(days):
            new_infected = (self.beta * susceptible * infected) / self.population
            new_recovered = self.gamma * infected
            new_vaccinated = self.vaccination_rate * susceptible

            susceptible -= new_infected + new_vaccinated
            infected += new_infected - new_recovered
            recovered += new_recovered + new_vaccinated

            S.append(susceptible)
            I.append(infected)
            R.append(recovered)

        return S, I, R

    def plot(self, S, I, R, days):
        plt.figure(figsize=(10, 6))
        plt.plot(range(days + 1), S, label='Susceptible')
        plt.plot(range(days + 1), I, label='Infected')
        plt.plot(range(days + 1), R, label='Recovered')
        plt.xlabel('Days')
        plt.ylabel('Population')
        plt.title('SIR Model Simulation')
        plt.legend()
        plt.show()

# Parameters
population = 1000
beta = 0.3  # transmission rate
gamma = 0.1  # recovery rate
vaccination_rate = 0.01  # daily vaccination rate
initial_infected = 10
initial_recovered = 0
simulation_days = 160

# Simulation
sir_model = SIRModel(population, beta, gamma, vaccination_rate)
S, I, R = sir_model.simulate(initial_infected, initial_recovered, simulation_days)

# Plotting the results
sir_model.plot(S, I, R, simulation_days)
