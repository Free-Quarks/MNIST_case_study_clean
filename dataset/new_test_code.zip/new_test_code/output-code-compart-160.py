# SEIR Model using Runge-Kutta 4th Order (RK4) in Python
import numpy as np
import matplotlib.pyplot as plt

# Define the SEIR model differential equations
def seir_derivatives(t, y, beta, sigma, gamma):
    S, E, I, R = y
    N = S + E + I + R
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt])

# Runge-Kutta 4th Order Method
def rk4_step(func, t, y, dt, *args):
    k1 = dt * func(t, y, *args)
    k2 = dt * func(t + dt / 2, y + k1 / 2, *args)
    k3 = dt * func(t + dt / 2, y + k2 / 2, *args)
    k4 = dt * func(t + dt, y + k3, *args)
    return y + (k1 + 2 * k2 + 2 * k3 + k4) / 6

# Simulation parameters
beta = 0.3   # Infection rate
sigma = 1/5.2 # Incubation rate (1/average incubation period)
gamma = 1/2.9 # Recovery rate (1/average infectious period)

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
y0 = np.array([S0, E0, I0, R0])

# Time parameters
T = 160 # Total time in days
dt = 0.1 # Time step
num_steps = int(T / dt)

# Arrays to store the results
t_values = np.linspace(0, T, num_steps)
results = np.zeros((num_steps, len(y0)))
results[0] = y0

# Run the simulation
for i in range(1, num_steps):
    t = t_values[i - 1]
    y = results[i - 1]
    results[i] = rk4_step(seir_derivatives, t, y, dt, beta, sigma, gamma)

# Plot the results
S, E, I, R = results.T
plt.figure(figsize=(10, 6))
plt.plot(t_values, S, label='Susceptible')
plt.plot(t_values, E, label='Exposed')
plt.plot(t_values, I, label='Infectious')
plt.plot(t_values, R, label='Recovered')
plt.xlabel('Days')
plt.ylabel('Population')
plt.title('SEIR Model using Runge-Kutta 4th Order (RK4)')
plt.legend()
plt.grid()
plt.show()
