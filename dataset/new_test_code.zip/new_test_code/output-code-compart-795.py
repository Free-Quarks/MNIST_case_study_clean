# SIDARTHE Model with RK4 Implementation

import numpy as np
import matplotlib.pyplot as plt

# Define the SIDARTHE model equations
def sidarthe_model(y, t, params):
    S, I, D, A, R, T, H, E = y
    alpha, beta, gamma, delta, epsilon, zeta, eta, theta, mu, nu, tau, lambda_ = params

    dSdt = -alpha * S * I - beta * S * D - gamma * S * A - delta * S * R
    dIdt = alpha * S * I + epsilon * D * I + zeta * A * I + eta * R * I - (beta + lambda_ + mu) * I
    dDdt = beta * S * D + theta * A * D + nu * R * D + epsilon * D * I - (gamma + mu + delta) * D
    dAdt = gamma * S * A + theta * A * D + nu * R * D + zeta * A * I - (delta + mu + tau) * A
    dRdt = delta * S * R + eta * R * I + theta * A * D + nu * R * D - (epsilon + mu + lambda_) * R
    dTdt = tau * A + lambda_ * I - (mu + nu) * T
    dHdt = mu * (I + D + A + R + T) - (nu + epsilon) * H
    dEdt = nu * (I + D + A + R + T + H) - zeta * E

    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Runge-Kutta 4th order method
def rk4_step(func, y, t, dt, params):
    k1 = np.array(func(y, t, params))
    k2 = np.array(func(y + 0.5 * dt * k1, t + 0.5 * dt, params))
    k3 = np.array(func(y + 0.5 * dt * k2, t + 0.5 * dt, params))
    k4 = np.array(func(y + dt * k3, t + dt, params))
    y_next = y + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
    return y_next

# Initialize parameters and initial conditions
params = [0.5, 0.3, 0.1, 0.05, 0.01, 0.02, 0.01, 0.05, 0.01, 0.02, 0.01, 0.005]
S0, I0, D0, A0, R0, T0, H0, E0 = 0.99, 0.01, 0, 0, 0, 0, 0, 0
initial_conditions = [S0, I0, D0, A0, R0, T0, H0, E0]

# Time variables
t_max = 160
dt = 0.1
time_points = np.arange(0, t_max, dt)

# Arrays to store results
results = np.zeros((len(time_points), len(initial_conditions)))
results[0] = initial_conditions

# Simulation loop
for i in range(1, len(time_points)):
    results[i] = rk4_step(sidarthe_model, results[i - 1], time_points[i - 1], dt, params)

# Plotting the results
plt.figure(figsize=(12, 8))
plt.plot(time_points, results[:, 0], label='Susceptible')
plt.plot(time_points, results[:, 1], label='Infected')
plt.plot(time_points, results[:, 2], label='Diagnosed')
plt.plot(time_points, results[:, 3], label='Ailing')
plt.plot(time_points, results[:, 4], label='Recognized')
plt.plot(time_points, results[:, 5], label='Threatened')
plt.plot(time_points, results[:, 6], label='Healed')
plt.plot(time_points, results[:, 7], label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Population fraction')
plt.legend()
plt.title('SIDARTHE Model Simulation')
plt.grid(True)
plt.show()

