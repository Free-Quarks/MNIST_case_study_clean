# Python script for SEIR model simulation using Euler's method

import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Rate of progression from exposed to infectious
gamma = 0.05  # Recovery rate
N = 1000  # Total population
I0 = 1  # Initial number of infectious individuals
E0 = 0  # Initial number of exposed individuals
R0 = 0  # Initial number of recovered individuals
S0 = N - I0 - E0 - R0  # Initial number of susceptible individuals

# Time parameters
T = 160  # Total time in days
dt = 1  # Time step in days
steps = int(T / dt)  # Number of time steps

# Arrays to store results
S = np.zeros(steps)
E = np.zeros(steps)
I = np.zeros(steps)
R = np.zeros(steps)
t = np.linspace(0, T, steps)

# Initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# SEIR model using Euler's method
for step in range(1, steps):
    S[step] = S[step-1] - (beta * S[step-1] * I[step-1] / N) * dt
    E[step] = E[step-1] + (beta * S[step-1] * I[step-1] / N - sigma * E[step-1]) * dt
    I[step] = I[step-1] + (sigma * E[step-1] - gamma * I[step-1]) * dt
    R[step] = R[step-1] + (gamma * I[step-1]) * dt

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.title('SEIR Model Simulation using Euler\'s Method')
plt.legend()
plt.grid(True)
plt.show()
