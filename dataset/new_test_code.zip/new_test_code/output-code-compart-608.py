import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Transmission rate
sigma = 1/5.2  # Rate of progression from exposed to infectious
gamma = 1/14  # Recovery rate
S0 = 0.99  # Initial proportion of susceptible individuals
E0 = 0.01  # Initial proportion of exposed individuals
I0 = 0.0  # Initial proportion of infectious individuals
R0 = 0.0  # Initial proportion of recovered individuals

# Time parameters
T = 160  # Total time
dt = 1.0  # Time step

# Initial conditions
S = [S0]
E = [E0]
I = [I0]
R = [R0]

# Runge-Kutta 2nd order method
for t in range(1, int(T/dt) + 1):
    S_last = S[-1]
    E_last = E[-1]
    I_last = I[-1]
    R_last = R[-1]

    k1_S = -beta * S_last * I_last
    k1_E = beta * S_last * I_last - sigma * E_last
    k1_I = sigma * E_last - gamma * I_last
    k1_R = gamma * I_last

    S_next = S_last + k1_S * dt
    E_next = E_last + k1_E * dt
    I_next = I_last + k1_I * dt
    R_next = R_last + k1_R * dt

    k2_S = -beta * S_next * I_next
    k2_E = beta * S_next * I_next - sigma * E_next
    k2_I = sigma * E_next - gamma * I_next
    k2_R = gamma * I_next

    S.append(S_last + 0.5 * (k1_S + k2_S) * dt)
    E.append(E_last + 0.5 * (k1_E + k2_E) * dt)
    I.append(I_last + 0.5 * (k1_I + k2_I) * dt)
    R.append(R_last + 0.5 * (k1_R + k2_R) * dt)

# Plot results
t = np.linspace(0, T, int(T/dt) + 1)
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIR Model with RK2')
plt.show()
