import numpy as np

class SEIRHDModel:
    def __init__(self, beta, sigma, gamma, mu, delta, rho, S0, E0, I0, R0, H0, D0, T):
        self.beta = beta  # infection rate
        self.sigma = sigma  # incubation rate
        self.gamma = gamma  # recovery rate
        self.mu = mu  # mortality rate
        self.delta = delta  # hospitalization rate
        self.rho = rho  # discharge rate
        self.S0 = S0  # initial susceptible population
        self.E0 = E0  # initial exposed population
        self.I0 = I0  # initial infectious population
        self.R0 = R0  # initial recovered population
        self.H0 = H0  # initial hospitalized population
        self.D0 = D0  # initial deceased population
        self.T = T  # total time

    def deriv(self, y, t, beta, sigma, gamma, mu, delta, rho):
        S, E, I, R, H, D = y
        dSdt = -beta * S * I
        dEdt = beta * S * I - sigma * E
        dIdt = sigma * E - gamma * I - delta * I
        dRdt = gamma * I
        dHdt = delta * I - rho * H
        dDdt = mu * I
        return dSdt, dEdt, dIdt, dRdt, dHdt, dDdt

    def rk4_step(self, f, y, t, dt, *args):
        k1 = dt * np.array(f(y, t, *args))
        k2 = dt * np.array(f(y + 0.5 * k1, t + 0.5 * dt, *args))
        k3 = dt * np.array(f(y + 0.5 * k2, t + 0.5 * dt, *args))
        k4 = dt * np.array(f(y + k3, t + dt, *args))
        return y + (k1 + 2 * k2 + 2 * k3 + k4) / 6

    def run(self):
        t = np.linspace(0, self.T, self.T * 10)
        dt = t[1] - t[0]
        y = np.zeros((len(t), 6))
        y[0] = [self.S0, self.E0, self.I0, self.R0, self.H0, self.D0]

        for i in range(1, len(t)):
            y[i] = self.rk4_step(self.deriv, y[i-1], t[i-1], dt, self.beta, self.sigma, self.gamma, self.mu, self.delta, self.rho)

        return t, y

# Example usage (incorrect parameters for realistic simulation):
model = SEIRHDModel(beta=0.3, sigma=0.1, gamma=0.1, mu=0.01, delta=0.1, rho=0.05, S0=0.99, E0=0.01, I0=0.0, R0=0.0, H0=0.0, D0=0.0, T=160)
t, y = model.run()
