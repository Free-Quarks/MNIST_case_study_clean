# SEIR Model using RK4 Method
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3   # Infection rate
sigma = 0.1  # Transition rate from exposed to infectious
gamma = 0.1  # Recovery rate

# Initial conditions
S0 = 0.99
E0 = 0.01
I0 = 0.0
R0 = 0.0

# Time parameters
t_max = 160
dt = 0.1

# SEIR model derivatives
def SEIR_derivatives(y, t, beta, sigma, gamma):
    S, E, I, R = y
    dSdt = -beta * S * I
    dEdt = beta * S * I - sigma * E
    dIdt = sigma * E - gamma * I
    dRdt = gamma * I
    return np.array([dSdt, dEdt, dIdt, dRdt])

# Runge-Kutta 4th order method
def RK4_step(f, y, t, dt, *args):
    k1 = dt * f(y, t, *args)
    k2 = dt * f(y + 0.5 * k1, t + 0.5 * dt, *args)
    k3 = dt * f(y + 0.5 * k2, t + 0.5 * dt, *args)
    k4 = dt * f(y + k3, t + dt, *args)
    return y + (k1 + 2*k2 + 2*k3 + k4) / 6

# Time points
t = np.arange(0, t_max, dt)

# Initialize arrays to store results
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

# Initial conditions
S[0], E[0], I[0], R[0] = S0, E0, I0, R0

# Time integration using RK4
for i in range(1, len(t)):
    y = np.array([S[i-1], E[i-1], I[i-1], R[i-1]])
    S[i], E[i], I[i], R[i] = RK4_step(SEIR_derivatives, y, t[i-1], dt, beta, sigma, gamma)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIR Model with RK4 Method')
plt.grid()
plt.show()
