import numpy as np
import matplotlib.pyplot as plt

# Define the SEIR model differential equations
def SEIR_model(y, beta, sigma, gamma, N):
    S, E, I, R = y
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt])

# Runge-Kutta 4th order method for solving ODEs
def RK4_step(f, y, h, *args):
    k1 = h * f(y, *args)
    k2 = h * f(y + 0.5 * k1, *args)
    k3 = h * f(y + 0.5 * k2, *args)
    k4 = h * f(y + k3, *args)
    return y + (k1 + 2 * k2 + 2 * k3 + k4) / 6

# Parameters
N = 1000       # Total population
beta = 0.3    # Infection rate
sigma = 1/5.2  # Incubation rate (1/average incubation period)
gamma = 1/2.9  # Recovery rate (1/average infectious period)

# Initial conditions
S0 = 999       # Initial susceptible population
E0 = 1         # Initial exposed population
I0 = 0         # Initial infected population
R0 = 0         # Initial recovered population

# Time parameters
t_max = 160    # Total time
dt = 0.1       # Time step size

# Initialize arrays to store results
S = [S0]
E = [E0]
I = [I0]
R = [R0]
t = np.arange(0, t_max, dt)

# Integrate the SEIR equations over the time grid
y = np.array([S0, E0, I0, R0])
for _ in t[1:]:
    y = RK4_step(SEIR_model, y, dt, beta, sigma, gamma, N)
    S.append(y[0])
    E.append(y[1])
    I.append(y[2])
    R.append(y[3])

# Plot results
plt.figure(figsize=(12, 8))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIR Model using RK4')
plt.grid()
plt.show()
