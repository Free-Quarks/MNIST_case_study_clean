import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

# Parameters
num_nodes = 1000
initial_infected = 10
beta = 0.3  # Transmission rate
gamma = 0.1  # Recovery rate

# Create a random network
G = nx.erdos_renyi_graph(num_nodes, 0.01)

# Stratification: Age groups
age_groups = {node: np.random.choice(['child', 'adult', 'senior'], p=[0.2, 0.6, 0.2]) for node in G.nodes()}

# Initial state
state = {node: 'S' for node in G.nodes()}
for node in np.random.choice(G.nodes(), initial_infected, replace=False):
    state[node] = 'I'

# Simulation
num_steps = 160

for step in range(num_steps):
    new_state = state.copy()
    for node in G.nodes():
        if state[node] == 'I':
            if np.random.rand() < gamma:
                new_state[node] = 'R'
        elif state[node] == 'S':
            neighbors = list(G.neighbors(node))
            infected_neighbors = sum(1 for neighbor in neighbors if state[neighbor] == 'I')
            if np.random.rand() < 1 - (1 - beta) ** infected_neighbors:
                new_state[node] = 'I'
    state = new_state
    # Stratification-specific operations can be added here

# Plotting the results for visualization
susceptible = [sum(1 for node in G.nodes() if state[node] == 'S') for step in range(num_steps)]
infected = [sum(1 for node in G.nodes() if state[node] == 'I') for step in range(num_steps)]
recovered = [sum(1 for node in G.nodes() if state[node] == 'R') for step in range(num_steps)]

time = np.linspace(0, num_steps - 1, num_steps)
plt.plot(time, susceptible, label='Susceptible')
plt.plot(time, infected, label='Infected')
plt.plot(time, recovered, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Number of Individuals')
plt.legend()
plt.title('SIR Model Simulation')
plt.show()
