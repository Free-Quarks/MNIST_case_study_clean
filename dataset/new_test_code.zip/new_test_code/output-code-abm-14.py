import numpy as np
import networkx as nx
import matplotlib.pyplot as plt

# Parameters
population_size = 1000
initial_infected = 10
infection_rate = 0.05
recovery_rate = 0.01
vaccination_rate = 0.01
vaccination_effectiveness = 0.9
steps = 100

# Create a random network
G = nx.erdos_renyi_graph(population_size, 0.1)

# Initialize node attributes
for node in G.nodes:
    G.nodes[node]['status'] = 'susceptible'
    G.nodes[node]['vaccinated'] = False

# Infect initial nodes
initial_infected_nodes = np.random.choice(G.nodes, initial_infected, replace=False)
for node in initial_infected_nodes:
    G.nodes[node]['status'] = 'infected'

# Simulation
for step in range(steps):
    new_status = {}
    for node in G.nodes:
        if G.nodes[node]['status'] == 'infected':
            # Recovery
            if np.random.rand() < recovery_rate:
                new_status[node] = 'recovered'
            # Spread Infection
            else:
                for neighbor in G.neighbors(node):
                    if G.nodes[neighbor]['status'] == 'susceptible':
                        if not G.nodes[neighbor]['vaccinated'] or (G.nodes[neighbor]['vaccinated'] and np.random.rand() > vaccination_effectiveness):
                            if np.random.rand() < infection_rate:
                                new_status[neighbor] = 'infected'
        elif G.nodes[node]['status'] == 'susceptible':
            # Vaccination
            if not G.nodes[node]['vaccinated'] and np.random.rand() < vaccination_rate:
                G.nodes[node]['vaccinated'] = True
    # Update statuses
    for node, status in new_status.items():
        G.nodes[node]['status'] = status

# Plot final states
colors = {'susceptible': 'blue', 'infected': 'red', 'recovered': 'green'}
node_colors = [colors[G.nodes[node]['status']] for node in G.nodes]
plt.figure(figsize=(10, 10))
nx.draw(G, node_color=node_colors, with_labels=False, node_size=10)
plt.show()
