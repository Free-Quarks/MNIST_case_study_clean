import random
import matplotlib.pyplot as plt

# Agent-Based Model to Simulate COVID-19 with Vaccination

class Person:
    def __init__(self, id, vaccinated=False):
        self.id = id
        self.infected = False
        self.recovered = False
        self.vaccinated = vaccinated

    def infect(self):
        if not self.infected and not self.recovered:
            if self.vaccinated:
                # Vaccination reduces infection probability
                if random.random() < 0.1:  # 10% chance if vaccinated
                    self.infected = True
            else:
                if random.random() < 0.3:  # 30% chance if not vaccinated
                    self.infected = True

    def recover(self):
        if self.infected:
            self.infected = False
            self.recovered = True

class Simulation:
    def __init__(self, population_size, initial_infected, vaccination_rate):
        self.population = [Person(id=i) for i in range(population_size)]
        self.vaccination_rate = vaccination_rate

        for person in random.sample(self.population, int(population_size * vaccination_rate)):
            person.vaccinated = True

        for person in random.sample(self.population, initial_infected):
            person.infected = True

    def step(self):
        for person in self.population:
            if person.infected:
                for other in random.sample(self.population, 5):  # Random contacts
                    other.infect()
            person.recover()

    def run(self, steps):
        infected_counts = []
        for _ in range(steps):
            self.step()
            infected_counts.append(sum(p.infected for p in self.population))
        return infected_counts

# Parameters
population_size = 1000
initial_infected = 10
vaccination_rate = 0.7
steps = 50

# Run Simulation
simulation = Simulation(population_size, initial_infected, vaccination_rate)
infected_counts = simulation.run(steps)

# Plot Results
plt.plot(infected_counts)
plt.xlabel('Time Steps')
plt.ylabel('Infected Count')
plt.title('COVID-19 Spread with Vaccination')
plt.show()
