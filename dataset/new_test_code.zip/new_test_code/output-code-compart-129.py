# SIR Model using RK3 (Runge-Kutta 3rd Order) in Python

import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate

# Initial conditions
S0 = 0.99  # Initial proportion of susceptible individuals
I0 = 0.01  # Initial proportion of infected individuals
R0 = 0.0   # Initial proportion of recovered individuals

# Time parameters
t_start = 0.0
t_end = 160.0
dt = 0.1

# SIR model equations
def sir_model(S, I, R, beta, gamma):
    dS_dt = -beta * S * I
    dI_dt = beta * S * I - gamma * I
    dR_dt = gamma * I
    return dS_dt, dI_dt, dR_dt

# Runge-Kutta 3rd Order method

def rk3_step(S, I, R, dt, beta, gamma):
    k1_S, k1_I, k1_R = sir_model(S, I, R, beta, gamma)
    k2_S, k2_I, k2_R = sir_model(S + 0.5 * dt * k1_S, I + 0.5 * dt * k1_I, R + 0.5 * dt * k1_R, beta, gamma)
    k3_S, k3_I, k3_R = sir_model(S - dt * k1_S + 2 * dt * k2_S, I - dt * k1_I + 2 * dt * k2_I, R - dt * k1_R + 2 * dt * k2_R, beta, gamma)
    S_next = S + (dt / 6) * (k1_S + 4 * k2_S + k3_S)
    I_next = I + (dt / 6) * (k1_I + 4 * k2_I + k3_I)
    R_next = R + (dt / 6) * (k1_R + 4 * k2_R + k3_R)
    return S_next, I_next, R_next

# Time integration
S, I, R = S0, I0, R0
time_points = np.arange(t_start, t_end + dt, dt)
S_values = [S0]
I_values = [I0]
R_values = [R0]

for t in time_points[:-1]:
    S, I, R = rk3_step(S, I, R, dt, beta, gamma)
    S_values.append(S)
    I_values.append(I)
    R_values.append(R)

# Plot results
plt.plot(time_points, S_values, label='Susceptible')
plt.plot(time_points, I_values, label='Infected')
plt.plot(time_points, R_values, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.title('SIR Model using RK3')
plt.show()
