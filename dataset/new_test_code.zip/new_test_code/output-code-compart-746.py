# SEIRHD Compartmental Model using Euler's Method
import numpy as np
import matplotlib.pyplot as plt

# Parameters
dt = 1.0  # Time step (days)
beta = 0.3  # Transmission rate
gamma = 0.1  # Recovery rate
sigma = 0.1  # Rate of progression from exposed to infectious
delta = 0.01  # Death rate
omega = 0.05  # Hospitalization rate

# Initial conditions
S0 = 990
E0 = 0
I0 = 10
R0 = 0
H0 = 0
D0 = 0

# Time vector
t = np.arange(0, 160, dt)

# Arrays to store the results
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))
H = np.zeros(len(t))
D = np.zeros(len(t))

# Initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
H[0] = H0
D[0] = D0

# Euler's method
for i in range(1, len(t)):
    dS = -beta * S[i-1] * I[i-1] * dt
    dE = (beta * S[i-1] * I[i-1] - sigma * E[i-1]) * dt
    dI = (sigma * E[i-1] - gamma * I[i-1] - delta * I[i-1] - omega * I[i-1]) * dt
    dR = gamma * I[i-1] * dt
    dH = omega * I[i-1] * dt
    dD = delta * I[i-1] * dt
    
    S[i] = S[i-1] + dS
    E[i] = E[i-1] + dE
    I[i] = I[i-1] + dI
    R[i] = R[i-1] + dR
    H[i] = H[i-1] + dH
    D[i] = D[i-1] + dD

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.plot(t, H, label='Hospitalized')
plt.plot(t, D, label='Deceased')
plt.xlabel('Days')
plt.ylabel('Population')
plt.title('SEIRHD Model using Euler\'s Method')
plt.legend()
plt.grid()
plt.show()
