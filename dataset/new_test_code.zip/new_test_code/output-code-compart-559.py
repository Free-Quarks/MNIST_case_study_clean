import numpy as np
import matplotlib.pyplot as plt

# Define the SEIR model parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Rate of progression from exposed to infectious (inverse of incubation period)
gamma = 1/2.9  # Recovery rate (inverse of infectious period)

# Initial number of individuals in each compartment
S0 = 999  # Susceptible
E0 = 1    # Exposed
I0 = 0    # Infectious
R0 = 0    # Recovered

# Total population, N
N = S0 + E0 + I0 + R0

# Time points (in days)
t = np.linspace(0, 160, 160)

# Define the SEIR model differential equations
def SEIR_model(y, t, beta, sigma, gamma):
    S, E, I, R = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I
    dRdt = gamma * I
    return dSdt, dEdt, dIdt, dRdt

# Runge-Kutta 3rd order method (RK3) implementation
def RK3(f, y0, t, params):
    n = len(t)
    y = np.zeros((n, len(y0)))
    y[0] = y0
    dt = t[1] - t[0]
    for i in range(1, n):
        k1 = np.array(f(y[i-1], t[i-1], *params))
        k2 = np.array(f(y[i-1] + dt/2 * k1, t[i-1] + dt/2, *params))
        k3 = np.array(f(y[i-1] - dt * k1 + 2 * dt * k2, t[i-1] + dt, *params))
        y[i] = y[i-1] + dt/6 * (k1 + 4*k2 + k3)
    return y

# Initial conditions vector
y0 = S0, E0, I0, R0

# Integrate the SEIR equations over the time grid, t.
solution = RK3(SEIR_model, y0, t, (beta, sigma, gamma))
S, E, I, R = solution.T

# Plot the data
plt.figure(figsize=(10,6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infectious')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.title('SEIR Model with RK3 Method')
plt.grid(True)
plt.show()
