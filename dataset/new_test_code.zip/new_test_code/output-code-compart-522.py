import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# SEIRHD model differential equations.
def deriv(y, t, N, beta, sigma, gamma, mu, delta):
    S, E, I, R, H, D = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - mu * I
    dRdt = gamma * I
    dHdt = mu * I - delta * H
    dDdt = delta * H
    return dSdt, dEdt, dIdt, dRdt, dHdt, dDdt

# Initial number of infected and exposed individuals, everyone else is susceptible.
N = 1000
I0, E0, R0, H0, D0 = 1, 0, 0, 0, 0
S0 = N - I0 - E0 - R0 - H0 - D0

# Contact rate, incubation rate, recovery rate, hospitalization rate, and death rate
beta, sigma, gamma, mu, delta = 0.3, 1./5.2, 1./14, 0.1, 0.01

# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# Initial conditions vector
y0 = S0, E0, I0, R0, H0, D0

# Integrate the SEIRHD equations over the time grid, t.
ret = odeint(deriv, y0, t, args=(N, beta, sigma, gamma, mu, delta))
S, E, I, R, H, D = ret.T

# Plot the data on three separate curves for S(t), E(t), and I(t)
fig = plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.plot(t, H, 'c', alpha=0.7, linewidth=2, label='Hospitalized')
plt.plot(t, D, 'k', alpha=0.7, linewidth=2, label='Deceased')
plt.xlabel('Time /days')
plt.ylabel('Number')
plt.legend()
plt.grid(True)
plt.show()
