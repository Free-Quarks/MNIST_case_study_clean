import numpy as np
import matplotlib.pyplot as plt

# Model parameters
beta = 0.3  # Infection rate
sigma = 1/5.1  # Transition rate from exposed to infectious (1/incubation period)
gamma = 1/14  # Recovery rate (1/infectious period)
N = 1000  # Total population

# Initial conditions
S0 = 999  # Initial susceptible individuals
E0 = 1    # Initial exposed individuals
I0 = 0    # Initial infectious individuals
R0 = 0    # Initial recovered individuals

# Time parameters
T = 160  # Total time in days
dt = 1   # Time step

# Initialize arrays
S = np.zeros(T)
E = np.zeros(T)
I = np.zeros(T)
R = np.zeros(T)

# Set initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# Euler method to solve SEIR model
for t in range(T-1):
    S[t+1] = S[t] - dt * beta * S[t] * I[t] / N
    E[t+1] = E[t] + dt * (beta * S[t] * I[t] / N - sigma * E[t])
    I[t+1] = I[t] + dt * (sigma * E[t] - gamma * I[t])
    R[t+1] = R[t] + dt * (gamma * I[t])

# Plot results
plt.figure(figsize=(10,6))
plt.plot(S, label='Susceptible')
plt.plot(E, label='Exposed')
plt.plot(I, label='Infectious')
plt.plot(R, label='Recovered')
plt.xlabel('Days')
plt.ylabel('Population')
plt.title('SEIR Model')
plt.legend()
plt.grid(True)
plt.show()
