import numpy as np
from scipy.integrate import solve_ivp

# Define the SIDARTHE model

def sidarthe_model(t, y, params):
    S, I, D, A, R, T, H, E = y
    alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_, kappa, xi, rho, sigma = params
    N = S + I + D + A + R + T + H + E
    dS_dt = -beta * S * I / N - delta * S * D / N - epsilon * S * A / N - zeta * S * R / N
    dI_dt = beta * S * I / N + delta * S * D / N + epsilon * S * A / N + zeta * S * R / N - lambda_ * I - kappa * I - alpha * I
    dD_dt = lambda_ * I - mu * D - nu * D - rho * D
    dA_dt = alpha * I - theta * A - sigma * A - gamma * A
    dR_dt = theta * A + mu * D - eta * R - tau * R
    dT_dt = gamma * A + nu * D - xi * T - sigma * T
    dH_dt = eta * R + xi * T - sigma * H
    dE_dt = sigma * (A + R + T + H)
    return [dS_dt, dI_dt, dD_dt, dA_dt, dR_dt, dT_dt, dH_dt, dE_dt]

# Parameters
params = [0.57, 0.011, 0.456, 0.011, 0.171, 0.370, 0.125, 0.125, 0.017, 0.027, 0.017, 0.034, 0.017, 0.017, 0.017, 0.034]

# Initial conditions
S0, I0, D0, A0, R0, T0, H0, E0 = 1_000_000, 1, 0, 0, 0, 0, 0, 0
initial_conditions = [S0, I0, D0, A0, R0, T0, H0, E0]

# Time points
t_span = [0, 160]
t_eval = np.linspace(t_span[0], t_span[1], 320)

# Solve the SIDARTHE model using RK2
sol = solve_ivp(sidarthe_model, t_span, initial_conditions, args=(params,), t_eval=t_eval, method='RK23')

# Extract the results
S, I, D, A, R, T, H, E = sol.y

# Print the results
import json
results = {
    'time': sol.t.tolist(),
    'S': S.tolist(),
    'I': I.tolist(),
    'D': D.tolist(),
    'A': A.tolist(),
    'R': R.tolist(),
    'T': T.tolist(),
    'H': H.tolist(),
    'E': E.tolist()
}
print(json.dumps(results, indent=2))
