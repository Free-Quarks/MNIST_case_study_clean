import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model using Euler's method
def SEIRD_model(S0, E0, I0, R0, D0, beta, sigma, gamma, mu, days, dt=1):
    # Total population, N.
    N = S0 + E0 + I0 + R0 + D0

    # Initialize arrays to store the results
    S = np.zeros(days)
    E = np.zeros(days)
    I = np.zeros(days)
    R = np.zeros(days)
    D = np.zeros(days)
    t = np.arange(0, days, dt)

    # Set initial values
    S[0] = S0
    E[0] = E0
    I[0] = I0
    R[0] = R0
    D[0] = D0

    # Euler's method for each time step
dt=1):
        dS = -beta * S[i-1] * I[i-1] / N
        dE = beta * S[i-1] * I[i-1] / N - sigma * E[i-1]
        dI = sigma * E[i-1] - gamma * I[i-1] - mu * I[i-1]
        dR = gamma * I[i-1]
        dD = mu * I[i-1]

        S[i] = S[i-1] + dS * dt
        E[i] = E[i-1] + dE * dt
        I[i] = I[i-1] + dI * dt
        R[i] = R[i-1] + dR * dt
        D[i] = D[i-1] + dD * dt

    return t, S, E, I, R, D

# Parameters
S0 = 999
E0 = 1
I0 = 0
R0 = 0
D0 = 0
beta = 0.3  # Infection rate
sigma = 0.1  # Rate of progression from exposed to infected
gamma = 0.05  # Recovery rate
mu = 0.01  # Mortality rate
days = 160

# Run the model
t, S, E, I, R, D = SEIRD_model(S0, E0, I0, R0, D0, beta, sigma, gamma, mu, days)

# Plot the data
plt.figure(figsize=(10,6))
plt.plot(t, S, 'b', label='Susceptible')
plt.plot(t, E, 'y', label='Exposed')
plt.plot(t, I, 'r', label='Infected')
plt.plot(t, R, 'g', label='Recovered')
plt.plot(t, D, 'k', label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRD Model')
plt.show()
