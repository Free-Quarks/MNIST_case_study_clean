# Python script to simulate COVID-19 using SIDARTHE model with Euler method
import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.5  # Rate of infection
sigma = 0.1  # Rate of detection
kappa = 0.1  # Rate of diagnosis
eta = 0.1  # Rate of recovery
rho = 0.1  # Rate of hospitalization
alpha = 0.1  # Rate of symptomatic
nu = 0.1  # Rate of death

# Initial conditions
S0 = 999  # Susceptible
I0 = 1    # Infected
D0 = 0    # Diagnosed
A0 = 0    # Ailing
R0 = 0    # Recognized
T0 = 0    # Threatened
H0 = 0    # Healed
E0 = 0    # Extinct

# Time parameters
T = 160   # Total time in days
dt = 1    # Time step
t = np.arange(0, T, dt)

# Initialize arrays
S = np.zeros(len(t))
I = np.zeros(len(t))
D = np.zeros(len(t))
A = np.zeros(len(t))
R = np.zeros(len(t))
T = np.zeros(len(t))
H = np.zeros(len(t))
E = np.zeros(len(t))

# Set initial values
S[0] = S0
I[0] = I0
D[0] = D0
A[0] = A0
R[0] = R0
T[0] = T0
H[0] = H0
E[0] = E0

# Euler method to solve the differential equations
for i in range(1, len(t)):
    dS = -beta * S[i-1] * I[i-1] * dt
    dI = (beta * S[i-1] * I[i-1] - sigma * I[i-1] - alpha * I[i-1]) * dt
    dD = (sigma * I[i-1] - kappa * D[i-1] - rho * D[i-1]) * dt
    dA = (alpha * I[i-1] - eta * A[i-1] - nu * A[i-1]) * dt
    dR = (eta * A[i-1] - rho * R[i-1]) * dt
    dT = (rho * D[i-1] + rho * R[i-1] - nu * T[i-1]) * dt
    dH = (nu * A[i-1] + nu * T[i-1]) * dt
    dE = (nu * T[i-1]) * dt

    S[i] = S[i-1] + dS
    I[i] = I[i-1] + dI
    D[i] = D[i-1] + dD
    A[i] = A[i-1] + dA
    R[i] = R[i-1] + dR
    T[i] = T[i-1] + dT
    H[i] = H[i-1] + dH
    E[i] = E[i-1] + dE

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, D, label='Diagnosed')
plt.plot(t, A, label='Ailing')
plt.plot(t, R, label='Recognized')
plt.plot(t, T, label='Threatened')
plt.plot(t, H, label='Healed')
plt.plot(t, E, label='Extinct')
plt.xlabel('Days')
plt.ylabel('Population')
plt.title('SIDARTHE Model Simulation of COVID-19')
plt.legend()
plt.grid()
plt.show()
