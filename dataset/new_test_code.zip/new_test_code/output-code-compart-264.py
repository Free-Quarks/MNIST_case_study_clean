# SEIRD Compartmental Model Simulation with RK3 in Python

import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model differential equations
def SEIRD_model(y, beta, gamma, delta, alpha):
    S, E, I, R, D = y
    N = S + E + I + R + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - delta * E
    dIdt = delta * E - (gamma + alpha) * I
    dRdt = gamma * I
    dDdt = alpha * I
    return np.array([dSdt, dEdt, dIdt, dRdt, dDdt])

# Runge-Kutta 3rd order (RK3) implementation
def RK3_step(f, y, dt, *args):
    k1 = f(y, *args)
    k2 = f(y + 0.5 * dt * k1, *args)
    k3 = f(y - dt * k1 + 2 * dt * k2, *args)
    return y + (dt / 6) * (k1 + 4 * k2 + k3)

# Simulation parameters
days = 160
dt = 0.1
steps = int(days / dt)

# SEIRD model parameters
beta = 0.3   # Infection rate
gamma = 0.1  # Recovery rate
delta = 0.1  # Incubation rate
alpha = 0.01 # Mortality rate

# Initial conditions
S0 = 0.99  # Initial susceptible population
E0 = 0.01  # Initial exposed population
I0 = 0.0   # Initial infected population
R0 = 0.0   # Initial recovered population
D0 = 0.0   # Initial dead population
initial_conditions = np.array([S0, E0, I0, R0, D0])

# Time points
t = np.linspace(0, days, steps)

# Initialize arrays to store results
S = np.zeros(steps)
E = np.zeros(steps)
I = np.zeros(steps)
R = np.zeros(steps)
D = np.zeros(steps)

# Set initial conditions
S[0], E[0], I[0], R[0], D[0] = initial_conditions

# Simulation loop
for i in range(1, steps):
    y = np.array([S[i-1], E[i-1], I[i-1], R[i-1], D[i-1]])
    y_next = RK3_step(SEIRD_model, y, dt, beta, gamma, delta, alpha)
    S[i], E[i], I[i], R[i], D[i] = y_next

# Plot results
plt.figure(figsize=(12, 8))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, D, label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of Population')
plt.title('SEIRD Model Simulation')
plt.legend()
plt.grid(True)
plt.show()
