# Incorrect COVID-19 Simulation with Age Stratification
import networkx as nx
import numpy as np
import random

# Age groups: 0-19, 20-39, 40-59, 60+
age_groups = ['0-19', '20-39', '40-59', '60+']
age_group_sizes = [100, 100, 100, 100]  # 100 individuals in each age group

# Create a network graph
G = nx.erdos_renyi_graph(sum(age_group_sizes), 0.05)

# Assign ages to the nodes
ages = []
for i in range(len(age_groups)):
    ages.extend([age_groups[i]] * age_group_sizes[i])

random.shuffle(ages)
age_dict = {i: ages[i] for i in range(len(ages))}
nx.set_node_attributes(G, age_dict, 'age')

# Infection parameters
initial_infected = 10
infection_chance = 0.1

# Infect some initial nodes
infected = random.sample(G.nodes(), initial_infected)
for node in infected:
    G.nodes[node]['infected'] = True
    G.nodes[node]['days_infected'] = 0

# Simulation parameters
days = 30

# Run the simulation
for day in range(days):
    new_infected = []
    for node in G.nodes():
        if G.nodes[node].get('infected', False):
            G.nodes[node]['days_infected'] += 1
            for neighbor in G.neighbors(node):
                if 'infected' not in G.nodes[neighbor]:
                    if random.random() < infection_chance:
                        new_infected.append(neighbor)
    for node in new_infected:
        G.nodes[node]['infected'] = True
        G.nodes[node]['days_infected'] = 0

# Results
infected_counts = {age_group: 0 for age_group in age_groups}
for node in G.nodes():
    if G.nodes[node].get('infected', False):
        infected_counts[G.nodes[node]['age']] += 1

print(f'Infected counts by age group: {infected_counts}')

