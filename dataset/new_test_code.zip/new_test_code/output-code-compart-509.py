import numpy as np

# Parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Rate of progression from exposed to infectious
gamma = 0.05  # Recovery rate

# Initial conditions
S0 = 0.99  # Initial proportion of susceptible individuals
E0 = 0.01  # Initial proportion of exposed individuals
I0 = 0.0   # Initial proportion of infectious individuals
R0 = 0.0   # Initial proportion of recovered individuals

# Time parameters
t = 0
tf = 160
h = 1.0  # Time step

# SEIR model equations
def SEIR(t, y):
    S, E, I, R = y
    dSdt = -beta * S * I
    dEdt = beta * S * I - sigma * E
    dIdt = sigma * E - gamma * I
    dRdt = gamma * I
    return np.array([dSdt, dEdt, dIdt, dRdt])

# RK3 method
n = int((tf - t) / h)
Y = np.zeros((n + 1, 4))
Y[0] = [S0, E0, I0, R0]

def rk3_step(t, y, h):
    k1 = SEIR(t, y)
    k2 = SEIR(t + 0.5 * h, y + 0.5 * h * k1)
    k3 = SEIR(t + h, y - h * k1 + 2 * h * k2)
    y_next = y + (h / 6) * (k1 + 4 * k2 + k3)
    return y_next

for i in range(n):
    Y[i + 1] = rk3_step(t + i * h, Y[i], h)

# Output results
output = {
    "time": np.linspace(t, tf, n + 1).tolist(),
    "S": Y[:, 0].tolist(),
    "E": Y[:, 1].tolist(),
    "I": Y[:, 2].tolist(),
    "R": Y[:, 3].tolist()
}

import json
print(json.dumps(output, indent=2))
