import numpy as np

# SEIRHD model parameters
params = {
    'beta': 0.3,  # Infection rate
    'sigma': 1/5.2,  # Inverse of incubation period
    'gamma': 1/2.3,  # Recovery rate
    'delta': 0.01,  # Mortality rate
    'epsilon': 0.1,  # Hospitalization rate
    'zeta': 0.05  # Discharge rate
}

# Initial conditions: S, E, I, R, H, D
initial_conditions = np.array([0.99, 0.01, 0.0, 0.0, 0.0, 0.0])

# Time vector
t = np.linspace(0, 160, 160)

# SEIRHD model differential equations
def seirhd_model(y, t, params):
    S, E, I, R, H, D = y
    beta, sigma, gamma, delta, epsilon, zeta = params.values()
    dSdt = -beta * S * I
    dEdt = beta * S * I - sigma * E
    dIdt = sigma * E - gamma * I - delta * I - epsilon * I
    dRdt = gamma * I
    dHdt = epsilon * I - zeta * H
    dDdt = delta * I
    return np.array([dSdt, dEdt, dIdt, dRdt, dHdt, dDdt])

# Runge-Kutta 4th order method
def rk4_step(f, y, t, dt, params):
    k1 = f(y, t, params)
    k2 = f(y + 0.5 * dt * k1, t + 0.5 * dt, params)
    k3 = f(y + 0.5 * dt * k2, t + 0.5 * dt, params)
    k4 = f(y + dt * k3, t + dt, params)
    return y + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)

# Time-stepping with RK4
def solve_seirhd(initial_conditions, t, params):
    dt = t[1] - t[0]
    n_steps = len(t)
    solution = np.zeros((n_steps, len(initial_conditions)))
    solution[0] = initial_conditions
    for i in range(1, n_steps):
        solution[i] = rk4_step(seirhd_model, solution[i-1], t[i-1], dt, params)
    return solution

# Solve the SEIRHD model
solution = solve_seirhd(initial_conditions, t, params)

# Display the results
import matplotlib.pyplot as plt
labels = ['Susceptible', 'Exposed', 'Infectious', 'Recovered', 'Hospitalized', 'Deceased']
for i, label in enumerate(labels):
    plt.plot(t, solution[:, i], label=label)
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIRHD Model Simulation')
plt.show()
