import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SIDARTHE model

def sidarthe_model(y, t, alpha, beta, gamma, delta, epsilon, zeta, eta, theta, iota, kappa, lambda_, mu, nu, xi, rho, sigma, tau, phi, chi, psi, omega):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E
    dSdt = -alpha*S*I/N - beta*S*D/N - gamma*S*A/N - delta*S*R/N
    dIdt = alpha*S*I/N + beta*S*D/N + gamma*S*A/N + delta*S*R/N - epsilon*I - zeta*I - eta*I
    dDdt = epsilon*I - theta*D - iota*D - kappa*D
    dAdt = zeta*I - lambda_*A - mu*A - nu*A
    dRdt = eta*I + theta*D - xi*R - rho*R
    dTdt = iota*D + lambda_*A - sigma*T - tau*T
    dHdt = mu*A + xi*R + sigma*T - phi*H - chi*H
    dEdt = nu*A + rho*R + tau*T + phi*H - psi*E - omega*E
    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Initial conditions
S0 = 1e6
I0 = 1
D0 = 0
A0 = 0
R0 = 0
T0 = 0
H0 = 0
E0 = 0

# Initial state vector
y0 = [S0, I0, D0, A0, R0, T0, H0, E0]

# Time points (in days)
t = np.linspace(0, 160, 160)

# Parameters
alpha = 0.57
beta = 0.011
gamma = 0.456
delta = 0.011
epsilon = 0.171
zeta = 0.371
eta = 0.125
theta = 0.125
iota = 0.125
kappa = 0.017
lambda_ = 0.034
mu = 0.017
nu = 0.017
xi = 0.017
rho = 0.017
sigma = 0.017
tau = 0.017
phi = 0.017
chi = 0.017
psi = 0.017
omega = 0.017

# Integrate the SIDARTHE equations over the time grid, t.
solution = odeint(sidarthe_model, y0, t, args=(alpha, beta, gamma, delta, epsilon, zeta, eta, theta, iota, kappa, lambda_, mu, nu, xi, rho, sigma, tau, phi, chi, psi, omega))
S, I, D, A, R, T, H, E = solution.T

# Plot the data
plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, D, 'c', alpha=0.7, linewidth=2, label='Diagnosed')
plt.plot(t, A, 'm', alpha=0.7, linewidth=2, label='Ailing')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recognized')
plt.plot(t, T, 'y', alpha=0.7, linewidth=2, label='Threatened')
plt.plot(t, H, 'k', alpha=0.7, linewidth=2, label='Healed')
plt.plot(t, E, 'orange', alpha=0.7, linewidth=2, label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Number of People')
plt.legend()
plt.grid(True)
plt.title('SIDARTHE Model Simulation')
plt.show()
