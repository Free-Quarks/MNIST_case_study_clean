# SIR Model with Runge-Kutta 3rd Order (RK3) Method
# Define the SIR model differential equations.

def SIR_derivatives(S, I, R, beta, gamma):
    dSdt = -beta * S * I
    dIdt = beta * S * I - gamma * I
    dRdt = gamma * I
    return dSdt, dIdt, dRdt

# Runge-Kutta 3rd Order Method for numerical integration.

def RK3_step(S, I, R, beta, gamma, dt):
    k1_S, k1_I, k1_R = SIR_derivatives(S, I, R, beta, gamma)
    k2_S, k2_I, k2_R = SIR_derivatives(S + dt/2 * k1_S, I + dt/2 * k1_I, R + dt/2 * k1_R, beta, gamma)
    k3_S, k3_I, k3_R = SIR_derivatives(S - dt * k1_S + 2 * dt * k2_S, I - dt * k1_I + 2 * dt * k2_I, R - dt * k1_R + 2 * dt * k2_R, beta, gamma)
    S_next = S + dt/6 * (k1_S + 4 * k2_S + k3_S)
    I_next = I + dt/6 * (k1_I + 4 * k2_I + k3_I)
    R_next = R + dt/6 * (k1_R + 4 * k2_R + k3_R)
    return S_next, I_next, R_next

# Simulation parameters

beta = 0.3  # Infection rate

gamma = 0.1  # Recovery rate

S0 = 0.99  # Initial fraction of susceptible individuals

I0 = 0.01  # Initial fraction of infected individuals

R0 = 0.0  # Initial fraction of recovered individuals

t = 0.0  # Initial time

dt = 0.1  # Time step

T = 160  # Total time for simulation

# Lists to store results

S_list = [S0]

I_list = [I0]

R_list = [R0]

time_list = [t]

S, I, R = S0, I0, R0

# Run the simulation

while t < T:
    S, I, R = RK3_step(S, I, R, beta, gamma, dt)
    t += dt
    S_list.append(S)
    I_list.append(I)
    R_list.append(R)
    time_list.append(t)

# Print results

print("Time", "S", "I", "R")

for time, S, I, R in zip(time_list, S_list, I_list, R_list):
    print(time, S, I, R)

