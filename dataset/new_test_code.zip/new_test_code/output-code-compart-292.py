import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SIDARTHE model
def sidarthe_model(y, t, alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E
    dSdt = -alpha*S*I/N - beta*S*D/N - gamma*S*A/N - delta*S*R/N
    dIdt = alpha*S*I/N + epsilon*D*I/N + zeta*A*I/N + eta*R*I/N - lambda_*I
    dDdt = beta*S*D/N + theta*D*I/N + mu*A*D/N + nu*R*D/N - lambda_*D
    dAdt = gamma*S*A/N + eta*D*A/N + theta*A*I/N + mu*A*A/N + nu*R*A/N - lambda_*A
    dRdt = delta*S*R/N + eta*D*R/N + mu*A*R/N + nu*R*R/N - lambda_*R
    dTdt = lambda_*I + lambda_*D + lambda_*A + lambda_*R - tau*T
    dHdt = tau*T - (zeta + eta)*H
    dEdt = (zeta + eta)*H
    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Initial conditions
S0, I0, D0, A0, R0, T0, H0, E0 = 0.99, 0.01, 0, 0, 0, 0, 0, 0
initial_conditions = [S0, I0, D0, A0, R0, T0, H0, E0]

# Parameters
alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_ = 0.2, 0.1, 0.05, 0.05, 0.05, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1

# Time points
t = np.linspace(0, 160, 160)

# Solve the ODEs
solution = odeint(sidarthe_model, initial_conditions, t, args=(alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_))

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, solution[:, 0], label='Susceptible')
plt.plot(t, solution[:, 1], label='Infected')
plt.plot(t, solution[:, 2], label='Diagnosed')
plt.plot(t, solution[:, 3], label='Ailing')
plt.plot(t, solution[:, 4], label='Recognized')
plt.plot(t, solution[:, 5], label='Threatened')
plt.plot(t, solution[:, 6], label='Healed')
plt.plot(t, solution[:, 7], label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of Population')
plt.legend()
plt.title('SIDARTHE Model of COVID-19 Spread')
plt.show()
