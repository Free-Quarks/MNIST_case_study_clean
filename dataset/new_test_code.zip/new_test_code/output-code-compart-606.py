
import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Rate of progression from exposed to infectious
gamma = 1/2.9  # Recovery rate

# Define initial conditions
S0 = 0.99  # Initial susceptible population
E0 = 0.01  # Initial exposed population
I0 = 0.0  # Initial infectious population
R0 = 0.0  # Initial recovered population
N = S0 + E0 + I0 + R0  # Total population

# Time parameters
t_start = 0
t_end = 160
dt = 1  # Time step size
t = np.arange(t_start, t_end, dt)

# Initialize compartments
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

# Set initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# SEIR model using Euler's method
for i in range(1, len(t)):
    dSdt = -beta * S[i-1] * I[i-1] / N
    dEdt = beta * S[i-1] * I[i-1] / N - sigma * E[i-1]
    dIdt = sigma * E[i-1] - gamma * I[i-1]
    dRdt = gamma * I[i-1]

    S[i] = S[i-1] + dSdt * dt
    E[i] = E[i-1] + dEdt * dt
    I[i] = I[i-1] + dIdt * dt
    R[i] = R[i-1] + dRdt * dt

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.title('SEIR Model - Incorrect Implementation')
plt.legend()
plt.grid(True)
plt.show()

