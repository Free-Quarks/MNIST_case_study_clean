# SIDARTHE Model Simulation using Runge-Kutta 4th Order Method (RK4)

import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.5  # transmission rate
sigma = 0.2  # rate of transition from susceptible to infected
alpha = 0.1  # rate of transition from infected to diagnosed
rho = 0.05  # rate of transition from diagnosed to ailing
kappa = 0.03  # rate of transition from ailing to recognized
nu = 0.01  # rate of transition from recognized to threatened
xi = 0.005  # rate of transition from threatened to healed or extinct

gamma = 0.07  # recovery rate for infected
eta = 0.04  # recovery rate for diagnosed
mu = 0.02  # mortality rate for ailing

delta = 0.1  # rate of transition from infected to diagnosed

# Define initial conditions
S0 = 0.99  # initial susceptible population
I0 = 0.01  # initial infected population
D0 = 0.00  # initial diagnosed population
A0 = 0.00  # initial ailing population
R0 = 0.00  # initial recognized population
T0 = 0.00  # initial threatened population
H0 = 0.00  # initial healed population
E0 = 0.00  # initial extinct population

# Time parameters
T = 160  # total time
dt = 0.1  # time step

# Initialize arrays to store results
S = [S0]
I = [I0]
D = [D0]
A = [A0]
R = [R0]
T = [T0]
H = [H0]
E = [E0]
time = [0]

# Define the SIDARTHE model equations
def SIDARTHE_model(S, I, D, A, R, T, H, E):
    dSdt = -beta * S * (I + D + A + R)
    dIdt = beta * S * (I + D + A + R) - (sigma + delta) * I
    dDdt = sigma * I - (rho + eta) * D
    dAdt = rho * D - (kappa + mu) * A
    dRdt = kappa * A - (nu + xi) * R
    dTdt = nu * R - xi * T
    dHdt = gamma * I + eta * D + mu * A
    dEdt = xi * T
    return dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt

# Runge-Kutta 4th Order Method (RK4)
for t in np.arange(0, T, dt):
    S_current, I_current, D_current, A_current, R_current, T_current, H_current, E_current = S[-1], I[-1], D[-1], A[-1], R[-1], T[-1], H[-1], E[-1]
    
    k1 = np.array(SIDARTHE_model(S_current, I_current, D_current, A_current, R_current, T_current, H_current, E_current))
    k2 = np.array(SIDARTHE_model(S_current + 0.5*dt*k1[0], I_current + 0.5*dt*k1[1], D_current + 0.5*dt*k1[2], A_current + 0.5*dt*k1[3], R_current + 0.5*dt*k1[4], T_current + 0.5*dt*k1[5], H_current + 0.5*dt*k1[6], E_current + 0.5*dt*k1[7]))
    k3 = np.array(SIDARTHE_model(S_current + 0.5*dt*k2[0], I_current + 0.5*dt*k2[1], D_current + 0.5*dt*k2[2], A_current + 0.5*dt*k2[3], R_current + 0.5*dt*k2[4], T_current + 0.5*dt*k2[5], H_current + 0.5*dt*k2[6], E_current + 0.5*dt*k2[7]))
    k4 = np.array(SIDARTHE_model(S_current + dt*k3[0], I_current + dt*k3[1], D_current + dt*k3[2], A_current + dt*k3[3], R_current + dt*k3[4], T_current + dt*k3[5], H_current + dt*k3[6], E_current + dt*k3[7]))
    
    S_next = S_current + (dt/6)*(k1[0] + 2*k2[0] + 2*k3[0] + k4[0])
    I_next = I_current + (dt/6)*(k1[1] + 2*k2[1] + 2*k3[1] + k4[1])
    D_next = D_current + (dt/6)*(k1[2] + 2*k2[2] + 2*k3[2] + k4[2])
    A_next = A_current + (dt/6)*(k1[3] + 2*k2[3] + 2*k3[3] + k4[3])
    R_next = R_current + (dt/6)*(k1[4] + 2*k2[4] + 2*k3[4] + k4[4])
    T_next = T_current + (dt/6)*(k1[5] + 2*k2[5] + 2*k3[5] + k4[5])
    H_next = H_current + (dt/6)*(k1[6] + 2*k2[6] + 2*k3[6] + k4[6])
    E_next = E_current + (dt/6)*(k1[7] + 2*k2[7] + 2*k3[7] + k4[7])
    
    S.append(S_next)
    I.append(I_next)
    D.append(D_next)
    A.append(A_next)
    R.append(R_next)
    T.append(T_next)
    H.append(H_next)
    E.append(E_next)
    time.append(t + dt)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(time, S, label='Susceptible')
plt.plot(time, I, label='Infected')
plt.plot(time, D, label='Diagnosed')
plt.plot(time, A, label='Ailing')
plt.plot(time, R, label='Recognized')
plt.plot(time, T, label='Threatened')
plt.plot(time, H, label='Healed')
plt.plot(time, E, label='Extinct')
plt.xlabel('Time')
plt.ylabel('Proportion of Population')
plt.title('SIDARTHE Model Simulation')
plt.legend()
plt.grid()
plt.show()
