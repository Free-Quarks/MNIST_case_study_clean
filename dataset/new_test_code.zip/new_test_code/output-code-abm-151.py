# Import necessary libraries
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import random

# Define parameters
num_nodes = 1000  # total population
initial_infected = 10  # initial number of infected individuals
transmission_rate = 0.1  # probability of transmission upon contact
recovery_rate = 0.01  # probability of recovery per time step
age_groups = ['0-17', '18-49', '50-64', '65+']  # age stratification
age_distribution = [0.24, 0.44, 0.18, 0.14]  # proportion of population in each age group

# Initialize the network
G = nx.erdos_renyi_graph(num_nodes, 0.1)  # random graph

# Assign age groups to nodes
ages = np.random.choice(age_groups, num_nodes, p=age_distribution)

# Assign initial infection state
infection_state = np.array(['S'] * num_nodes)
initial_infected_nodes = random.sample(range(num_nodes), initial_infected)
for node in initial_infected_nodes:
    infection_state[node] = 'I'

# Define function to simulate one time step
def simulate_step(G, infection_state, transmission_rate, recovery_rate):
    new_infection_state = infection_state.copy()
    for node in G.nodes:
        if infection_state[node] == 'I':
            # Infected node can recover
            if random.random() < recovery_rate:
                new_infection_state[node] = 'R'
            else:
                # Infected node can transmit to susceptible neighbors
                for neighbor in G.neighbors(node):
                    if infection_state[neighbor] == 'S' and random.random() < transmission_rate:
                        new_infection_state[neighbor] = 'I'
    return new_infection_state

# Simulate the epidemic
num_steps = 100
infection_counts = {'S': [], 'I': [], 'R': []}
for step in range(num_steps):
    infection_counts['S'].append(np.sum(infection_state == 'S'))
    infection_counts['I'].append(np.sum(infection_state == 'I'))
    infection_counts['R'].append(np.sum(infection_state == 'R'))
    infection_state = simulate_step(G, infection_state, transmission_rate, recovery_rate)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(infection_counts['S'], label='Susceptible')
plt.plot(infection_counts['I'], label='Infected')
plt.plot(infection_counts['R'], label='Recovered')
plt.xlabel('Time Steps')
plt.ylabel('Number of Individuals')
plt.legend()
plt.title('COVID-19 Simulation')
plt.show()

