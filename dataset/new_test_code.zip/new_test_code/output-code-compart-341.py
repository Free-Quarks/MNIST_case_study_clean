import numpy as np
import matplotlib.pyplot as plt

# Define parameters (example values, these should be calibrated)
beta = 0.5    # Transmission rate
sigma = 0.1   # Rate at which exposed individuals become symptomatic
lambda_ = 0.1 # Rate at which symptomatic individuals are detected
rho = 0.1     # Rate of hospitalization
alpha = 0.05  # Rate of asymptomatic individuals becoming symptomatic
theta = 0.05  # Rate of severe cases
eta = 0.01    # Mortality rate

# Initial conditions
S0 = 0.99  # Susceptible
I0 = 0.01  # Infected (asymptomatic)
D0 = 0.0   # Detected
A0 = 0.0   # Symptomatic
R0 = 0.0   # Recovered
T0 = 0.0   # Severe
H0 = 0.0   # Hospitalized
E0 = 0.0   # Extinct

# Time parameters
t_max = 160
dt = 1.0

# Initialize arrays
t = np.arange(0, t_max, dt)
S = np.zeros(len(t))
I = np.zeros(len(t))
D = np.zeros(len(t))
A = np.zeros(len(t))
R = np.zeros(len(t))
T = np.zeros(len(t))
H = np.zeros(len(t))
E = np.zeros(len(t))

# Set initial conditions
S[0] = S0
I[0] = I0
D[0] = D0
A[0] = A0
R[0] = R0
T[0] = T0
H[0] = H0
E[0] = E0

# Euler method for SIDARTHE model
for i in range(1, len(t)):
    S[i] = S[i-1] - dt * beta * S[i-1] * (I[i-1] + D[i-1])
    I[i] = I[i-1] + dt * (beta * S[i-1] * (I[i-1] + D[i-1]) - sigma * I[i-1] - alpha * I[i-1])
    D[i] = D[i-1] + dt * (sigma * I[i-1] - lambda_ * D[i-1] - rho * D[i-1])
    A[i] = A[i-1] + dt * (alpha * I[i-1] - theta * A[i-1])
    R[i] = R[i-1] + dt * (lambda_ * D[i-1])
    T[i] = T[i-1] + dt * (theta * A[i-1])
    H[i] = H[i-1] + dt * (rho * D[i-1])
    E[i] = E[i-1] + dt * (eta * H[i-1])

# Plot the results
plt.figure(figsize=(12, 8))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected (asymptomatic)')
plt.plot(t, D, label='Detected')
plt.plot(t, A, label='Symptomatic')
plt.plot(t, R, label='Recovered')
plt.plot(t, T, label='Severe')
plt.plot(t, H, label='Hospitalized')
plt.plot(t, E, label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of population')
plt.legend()
plt.grid()
plt.title('SIDARTHE Model Simulation')
plt.show()
