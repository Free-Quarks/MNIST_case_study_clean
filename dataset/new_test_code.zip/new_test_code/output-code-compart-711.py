# Incorrect SEIRD Model using Euler's Method

import numpy as np
import matplotlib.pyplot as plt

# Define the model parameters
beta = 0.3   # Infection rate
sigma = 0.1  # Rate of progression from exposed to infected
gamma = 0.05 # Recovery rate
delta = 0.01 # Mortality rate

# Time parameters
T = 160       # Total time
dt = 1        # Time step

# Initialize populations
S = 990       # Susceptible individuals
E = 10        # Exposed individuals
I = 0         # Infected individuals
R = 0         # Recovered individuals
D = 0         # Deceased individuals

# Lists to store results
S_list = [S]
E_list = [E]
I_list = [I]
R_list = [R]
D_list = [D]

time = np.arange(0, T, dt)

# Euler's method for SEIRD model
for t in time:
    dS = -beta * S * I * dt
    dE = beta * S * I * dt - sigma * E * dt
    dI = sigma * E * dt - gamma * I * dt - delta * I * dt
    dR = gamma * I * dt
    dD = delta * I * dt

    S += dS
    E += dE
    I += dI
    R += dR
    D += dD

    S_list.append(S)
    E_list.append(E)
    I_list.append(I)
    R_list.append(R)
    D_list.append(D)

# Plot the results
plt.figure(figsize=(10,6))
plt.plot(time, S_list[:-1], label='Susceptible')
plt.plot(time, E_list[:-1], label='Exposed')
plt.plot(time, I_list[:-1], label='Infected')
plt.plot(time, R_list[:-1], label='Recovered')
plt.plot(time, D_list[:-1], label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRD Model')
plt.show()
