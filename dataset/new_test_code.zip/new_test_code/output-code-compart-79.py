import numpy as np
import matplotlib.pyplot as plt

# SIR Model Parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
S0 = 0.99  # Initial susceptible population
I0 = 0.01  # Initial infected population
R0 = 0.0  # Initial recovered population

# Time parameters
T = 160  # Total time
dt = 0.1  # Time step

# Runge-Kutta 3rd Order (RK3) method

def SIR_model(t, y):
    S, I, R = y
    dSdt = -beta * S * I
    dIdt = beta * S * I - gamma * I
    dRdt = gamma * I
    return np.array([dSdt, dIdt, dRdt])

# Initialize state variables
S = [S0]
I = [I0]
R = [R0]

for _ in np.arange(0, T, dt):
    y = np.array([S[-1], I[-1], R[-1]])
    k1 = dt * SIR_model(_, y)
    k2 = dt * SIR_model(_, y + 0.5 * k1)
    k3 = dt * SIR_model(_, y - k1 + 2 * k2)
    y_next = y + (1/6) * (k1 + 4 * k2 + k3)
    S.append(y_next[0])
    I.append(y_next[1])
    R.append(y_next[2])

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(np.arange(0, T + dt, dt), S, label='Susceptible')
plt.plot(np.arange(0, T + dt, dt), I, label='Infected')
plt.plot(np.arange(0, T + dt, dt), R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.title('SIR Model using RK3')
plt.grid(True)
plt.show()
