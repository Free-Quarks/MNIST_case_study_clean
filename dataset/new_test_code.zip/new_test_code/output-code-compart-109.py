
import numpy as np
import matplotlib.pyplot as plt

# Define the SEIR model parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Inverse of incubation period
gamma = 0.1  # Recovery rate

# Time step
dt = 0.1

# Duration of simulation
T = 160

# Initial number of individuals in each compartment
S0 = 999
E0 = 1
I0 = 0
R0 = 0

# Define the RK3 method
def rk3_step(S, E, I, R, beta, sigma, gamma, dt):
    def dSEIR(S, E, I, R, beta, sigma, gamma):
        dS = -beta * S * I
        dE = beta * S * I - sigma * E
        dI = sigma * E - gamma * I
        dR = gamma * I
        return dS, dE, dI, dR

    k1 = dSEIR(S, E, I, R, beta, sigma, gamma)
    k2 = dSEIR(S + 0.5 * dt * k1[0], E + 0.5 * dt * k1[1], I + 0.5 * dt * k1[2], R + 0.5 * dt * k1[3], beta, sigma, gamma)
    k3 = dSEIR(S - dt * k1[0] + 2 * dt * k2[0], E - dt * k1[1] + 2 * dt * k2[1], I - dt * k1[2] + 2 * dt * k2[2], R - dt * k1[3] + 2 * dt * k2[3], beta, sigma, gamma)

    S_new = S + dt * (k1[0] + 4 * k2[0] + k3[0]) / 6
    E_new = E + dt * (k1[1] + 4 * k2[1] + k3[1]) / 6
    I_new = I + dt * (k1[2] + 4 * k2[2] + k3[2]) / 6
    R_new = R + dt * (k1[3] + 4 * k2[3] + k3[3]) / 6

    return S_new, E_new, I_new, R_new

# Initialize variables
num_steps = int(T / dt)
S = np.zeros(num_steps)
E = np.zeros(num_steps)
I = np.zeros(num_steps)
R = np.zeros(num_steps)

S[0], E[0], I[0], R[0] = S0, E0, I0, R0

# Run the simulation
for t in range(1, num_steps):
    S[t], E[t], I[t], R[t] = rk3_step(S[t-1], E[t-1], I[t-1], R[t-1], beta, sigma, gamma, dt)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(S, label='Susceptible')
plt.plot(E, label='Exposed')
plt.plot(I, label='Infected')
plt.plot(R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIR Model Simulation')
plt.show()

