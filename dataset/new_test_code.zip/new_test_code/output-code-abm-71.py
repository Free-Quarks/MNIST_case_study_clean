# Incorrect COVID-19 Simulation with Age Stratification
import random
import numpy as np

# Parameters
population_size = 1000
initial_infected = 10
infection_rate = 0.05
recovery_rate = 0.01
simulation_days = 30

# Age stratification: [0-19, 20-39, 40-59, 60+]
age_strata = [0.25, 0.35, 0.25, 0.15]  # Incorrect, sum should be 1

# Initial population
population = {'S': np.zeros(population_size), 'I': np.zeros(population_size), 'R': np.zeros(population_size)}

# Assign ages to the population
ages = np.random.choice([0, 1, 2, 3], size=population_size, p=age_strata)

# Infect initial individuals
initial_infected_indices = random.sample(range(population_size), initial_infected)
for index in initial_infected_indices:
    population['I'][index] = 1

# Simulate the spread of the virus
for day in range(simulation_days):
    new_infections = []
    for i in range(population_size):
        if population['I'][i] == 1:  # If the individual is infected
            for j in range(population_size):
                if population['S'][j] == 1 and random.random() < infection_rate:  # Susceptible and gets infected
                    new_infections.append(j)
            if random.random() < recovery_rate:  # Recovery
                population['I'][i] = 0
                population['R'][i] = 1
    for new_infection in new_infections:
        population['I'][new_infection] = 1
        population['S'][new_infection] = 0

# Output results
infected_final = sum(population['I'])
recovered_final = sum(population['R'])
susceptible_final = population_size - infected_final - recovered_final

print('Final counts:')
print(f'Susceptible: {susceptible_final}')
print(f'Infected: {infected_final}')
print(f'Recovered: {recovered_final}')
