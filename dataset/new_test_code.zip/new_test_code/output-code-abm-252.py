# Import necessary libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Define parameters
np.random.seed(42)  # For reproducibility
population_size = 1000
initial_infected = 10
sex_ratio = 0.5  # 50% males, 50% females
infection_rate = 0.1
recovery_rate = 0.05
simulation_days = 100

# Initialize population
def initialize_population(size, initial_infected, sex_ratio):
    population = pd.DataFrame({
        'id': range(size),
        'sex': np.random.choice(['male', 'female'], size=size, p=[sex_ratio, 1-sex_ratio]),
        'status': 'susceptible'
    })
    infected_indices = np.random.choice(size, initial_infected, replace=False)
    population.loc[infected_indices, 'status'] = 'infected'
    return population

# Simulate one day of the epidemic
def simulate_day(population, infection_rate, recovery_rate):
    new_infections = []
    new_recoveries = []
    for index, person in population.iterrows():
        if person['status'] == 'infected':
            # Recovery
            if np.random.rand() < recovery_rate:
                new_recoveries.append(index)
            # Infection spread
            for neighbor in population.index:
                if population.loc[neighbor, 'status'] == 'susceptible' and np.random.rand() < infection_rate:
                    new_infections.append(neighbor)
    # Update statuses
    population.loc[new_infections, 'status'] = 'infected'
    population.loc[new_recoveries, 'status'] = 'recovered'
    return population

# Run simulation
def run_simulation(population, infection_rate, recovery_rate, days):
    history = []
    for day in range(days):
        population = simulate_day(population, infection_rate, recovery_rate)
        history.append(population['status'].value_counts().to_dict())
    return history

# Initialize population
population = initialize_population(population_size, initial_infected, sex_ratio)

# Run the simulation
history = run_simulation(population, infection_rate, recovery_rate, simulation_days)

# Convert history to DataFrame for easy plotting
history_df = pd.DataFrame(history).fillna(0)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(history_df.index, history_df['susceptible'], label='Susceptible')
plt.plot(history_df.index, history_df['infected'], label='Infected')
plt.plot(history_df.index, history_df['recovered'], label='Recovered')
plt.xlabel('Day')
plt.ylabel('Number of Individuals')
plt.title('COVID-19 Simulation Over Time')
plt.legend()
plt.show()

