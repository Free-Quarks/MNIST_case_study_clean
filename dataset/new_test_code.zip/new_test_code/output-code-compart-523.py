# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRHD model
class SEIRHDModel:
    def __init__(self, beta, sigma, gamma, mu, delta, alpha, S0, E0, I0, R0, H0, D0, days):
        self.beta = beta  # Infection rate
        self.sigma = sigma  # Rate of progression from exposed to infectious
        self.gamma = gamma  # Recovery rate
        self.mu = mu  # Mortality rate
        self.delta = delta  # Hospitalization rate
        self.alpha = alpha  # Rate of leaving hospital
        self.S = [S0]
        self.E = [E0]
        self.I = [I0]
        self.R = [R0]
        self.H = [H0]
        self.D = [D0]
        self.days = days

    def deriv(self, S, E, I, R, H, D):
        N = S + E + I + R + H
        dSdt = -self.beta * S * I / N
        dEdt = self.beta * S * I / N - self.sigma * E
        dIdt = self.sigma * E - self.gamma * I - self.mu * I - self.delta * I
        dRdt = self.gamma * I
        dHdt = self.delta * I - self.alpha * H
        dDdt = self.mu * I
        return dSdt, dEdt, dIdt, dRdt, dHdt, dDdt

    def run(self):
        for _ in range(self.days):
            S, E, I, R, H, D = self.S[-1], self.E[-1], self.I[-1], self.R[-1], self.H[-1], self.D[-1]
            dS1, dE1, dI1, dR1, dH1, dD1 = self.deriv(S, E, I, R, H, D)
            S_half = S + dS1 * 0.5
            E_half = E + dE1 * 0.5
            I_half = I + dI1 * 0.5
            R_half = R + dR1 * 0.5
            H_half = H + dH1 * 0.5
            D_half = D + dD1 * 0.5
            dS2, dE2, dI2, dR2, dH2, dD2 = self.deriv(S_half, E_half, I_half, R_half, H_half, D_half)
            self.S.append(S + dS2)
            self.E.append(E + dE2)
            self.I.append(I + dI2)
            self.R.append(R + dR2)
            self.H.append(H + dH2)
            self.D.append(D + dD2)

    def plot(self):
        plt.figure(figsize=(10, 6))
        plt.plot(self.S, label='Susceptible')
        plt.plot(self.E, label='Exposed')
        plt.plot(self.I, label='Infectious')
        plt.plot(self.R, label='Recovered')
        plt.plot(self.H, label='Hospitalized')
        plt.plot(self.D, label='Deceased')
        plt.xlabel('Days')
        plt.ylabel('Number of individuals')
        plt.legend()
        plt.grid()
        plt.title('SEIRHD Model')
        plt.show()

# Parameters (example values)
beta = 0.3
sigma = 0.1
gamma = 0.1
mu = 0.01
delta = 0.05
alpha = 0.01
S0 = 990
E0 = 10
I0 = 0
R0 = 0
H0 = 0
D0 = 0
days = 160

# Create and run the model
model = SEIRHDModel(beta, sigma, gamma, mu, delta, alpha, S0, E0, I0, R0, H0, D0, days)
model.run()
model.plot()
