import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SIDARTHE model
# Susceptible (S), Infected (I), Diagnosed (D), Ailing (A), Recognized (R), Threatened (T), Healed (H), Extinct (E)
def sidarthe_model(y, t, alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_):
    S, I, D, A, R, T, H, E = y
    dSdt = -alpha * S * I - beta * S * D - gamma * S * A - delta * S * R
    dIdt = alpha * S * I + beta * S * D + gamma * S * A + delta * S * R - epsilon * I - zeta * I - lambda_ * I
    dDdt = epsilon * I - eta * D - rho * D
    dAdt = zeta * I - theta * A - mu * A - nu * A
    dRdt = eta * D + theta * A - tau * R - lambda_ * R
    dTdt = mu * A + tau * R - lambda_ * T
    dHdt = nu * A
    dEdt = lambda_ * (I + R + T)
    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Initial conditions
S0 = 0.99
I0 = 0.01
D0 = 0.0
A0 = 0.0
R0 = 0.0
T0 = 0.0
H0 = 0.0
E0 = 0.0

# Parameters
alpha = 0.5
beta = 0.1
gamma = 0.1
delta = 0.1
epsilon = 0.05
theta = 0.05
zeta = 0.05
eta = 0.03
mu = 0.02
nu = 0.01
tau = 0.01
lambda_ = 0.01

# Time points (in days)
t = np.linspace(0, 160, 160)

# Initial conditions vector
y0 = [S0, I0, D0, A0, R0, T0, H0, E0]

# Integrating the SIDARTHE equations
solution = odeint(sidarthe_model, y0, t, args=(alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_))
S, I, D, A, R, T, H, E = solution.T

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible (S)')
plt.plot(t, I, label='Infected (I)')
plt.plot(t, D, label='Diagnosed (D)')
plt.plot(t, A, label='Ailing (A)')
plt.plot(t, R, label='Recognized (R)')
plt.plot(t, T, label='Threatened (T)')
plt.plot(t, H, label='Healed (H)')
plt.plot(t, E, label='Extinct (E)')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of population')
plt.legend()
plt.title('SIDARTHE Model')
plt.grid(True)
plt.show()
