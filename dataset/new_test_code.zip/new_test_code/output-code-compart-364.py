# SEIRD Model using Runge-Kutta 3rd Order (RK3) Method

import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model
def SEIRD_model(t, y, beta, gamma, sigma, delta):
    S, E, I, R, D = y
    N = S + E + I + R + D
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - (gamma + delta) * I
    dR_dt = gamma * I
    dD_dt = delta * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt, dD_dt])

# Runge-Kutta 3rd Order (RK3) Method
def RK3_step(f, t, y, dt, *args):
    k1 = f(t, y, *args)
    k2 = f(t + dt/2, y + dt/2 * k1, *args)
    k3 = f(t + dt, y - dt * k1 + 2 * dt * k2, *args)
    return y + dt/6 * (k1 + 4 * k2 + k3)

# Simulation parameters
beta = 0.3    # Infection rate
sigma = 1/5.2 # Incubation rate
gamma = 1/2.3 # Recovery rate
delta = 0.02  # Death rate
N = 1000      # Total population
E0 = 1        # Initial exposed individuals
I0 = 1        # Initial infected individuals
R0 = 0        # Initial recovered individuals
D0 = 0        # Initial dead individuals
S0 = N - E0 - I0 - R0 - D0 # Initial susceptible individuals
T = 160       # Total time (days)
dt = 1        # Time step (days)

# Time vector
t = np.arange(0, T+dt, dt)

# Initial conditions
y0 = np.array([S0, E0, I0, R0, D0])

# Initialize arrays to store results
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))
D = np.zeros(len(t))

# Set initial values
S[0], E[0], I[0], R[0], D[0] = y0

# Perform RK3 integration
for i in range(1, len(t)):
    y0 = RK3_step(SEIRD_model, t[i-1], y0, dt, beta, gamma, sigma, delta)
    S[i], E[i], I[i], R[i], D[i] = y0

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, D, label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.title('SEIRD Model using RK3 Method')
plt.grid()
plt.show()

