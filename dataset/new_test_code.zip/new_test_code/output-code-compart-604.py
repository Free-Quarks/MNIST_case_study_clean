import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # infection rate
gamma = 0.1  # recovery rate

# Initial conditions: S0, I0, R0
S0 = 0.99
I0 = 0.01
R0 = 0.0

# Time parameters
T = 160  # Total time
dt = 1.0  # Time step
N = int(T/dt)  # Number of steps

# Arrays to store the results
S = np.zeros(N)
I = np.zeros(N)
R = np.zeros(N)

# Initial values
S[0] = S0
I[0] = I0
R[0] = R0

# Runge-Kutta 3rd Order (RK3) method
for t in range(1, N):
    k1_S = -beta * S[t-1] * I[t-1]
    k1_I = beta * S[t-1] * I[t-1] - gamma * I[t-1]
    k1_R = gamma * I[t-1]
    
    k2_S = -beta * (S[t-1] + 0.5 * dt * k1_S) * (I[t-1] + 0.5 * dt * k1_I)
    k2_I = beta * (S[t-1] + 0.5 * dt * k1_S) * (I[t-1] + 0.5 * dt * k1_I) - gamma * (I[t-1] + 0.5 * dt * k1_I)
    k2_R = gamma * (I[t-1] + 0.5 * dt * k1_I)

    k3_S = -beta * (S[t-1] - dt * k1_S + 2 * dt * k2_S) * (I[t-1] - dt * k1_I + 2 * dt * k2_I)
    k3_I = beta * (S[t-1] - dt * k1_S + 2 * dt * k2_S) * (I[t-1] - dt * k1_I + 2 * dt * k2_I) - gamma * (I[t-1] - dt * k1_I + 2 * dt * k2_I)
    k3_R = gamma * (I[t-1] - dt * k1_I + 2 * dt * k2_I)

    S[t] = S[t-1] + (dt / 6) * (k1_S + 4 * k2_S + k3_S)
    I[t] = I[t-1] + (dt / 6) * (k1_I + 4 * k2_I + k3_I)
    R[t] = R[t-1] + (dt / 6) * (k1_R + 4 * k2_R + k3_R)

# Plot the results
plt.figure(figsize=(12, 6))
plt.plot(S, label='Susceptible')
plt.plot(I, label='Infected')
plt.plot(R, label='Recovered')
plt.xlabel('Time steps')
plt.ylabel('Proportion')
plt.legend()
plt.title('SIR Model using Runge-Kutta 3rd Order Method (RK3)')
plt.show()
