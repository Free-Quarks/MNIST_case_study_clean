import numpy as np

# Define SEIR model parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Rate of progression from exposed to infectious
gamma = 0.1  # Recovery rate

# Initial conditions: S, E, I, R
initial_conditions = [0.99, 0.01, 0.0, 0.0]

# Time step and duration
dt = 0.1
duration = 160

# SEIR model differential equations
def seir_derivatives(y, t, beta, sigma, gamma):
    S, E, I, R = y
    dS_dt = -beta * S * I
    dE_dt = beta * S * I - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt])

# Runge-Kutta 4th order method
def rk4_step(f, y, t, dt, *args):
    k1 = dt * f(y, t, *args)
    k2 = dt * f(y + 0.5 * k1, t + 0.5 * dt, *args)
    k3 = dt * f(y + 0.5 * k2, t + 0.5 * dt, *args)
    k4 = dt * f(y + k3, t + dt, *args)
    return y + (k1 + 2 * k2 + 2 * k3 + k4) / 6.0

# Time points
t_points = np.arange(0, duration, dt)

# Initialize arrays to store results
results = np.zeros((len(t_points), 4))
results[0, :] = initial_conditions

# Time integration using RK4
for i in range(1, len(t_points)):
    t = t_points[i-1]
    y = results[i-1, :]
    results[i, :] = rk4_step(seir_derivatives, y, t, dt, beta, sigma, gamma)

# Save results to a JSON-compatible format
import json
output = {
    "time_points": t_points.tolist(),
    "S": results[:, 0].tolist(),
    "E": results[:, 1].tolist(),
    "I": results[:, 2].tolist(),
    "R": results[:, 3].tolist()
}

with open('seir_simulation.json', 'w') as f:
    json.dump(output, f, indent=4)

print('SEIR simulation complete. Results saved to seir_simulation.json.')
