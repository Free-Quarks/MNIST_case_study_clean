# Import necessary libraries
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SEIRHD model

def seirhd_model(y, t, beta, sigma, gamma, delta, alpha, rho):
    S, E, I, R, H, D = y
    N = S + E + I + R + H
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - delta * I
    dRdt = gamma * I
    dHdt = delta * I - alpha * H
    dDdt = alpha * H
    return [dSdt, dEdt, dIdt, dRdt, dHdt, dDdt]

# Initial conditions and parameters
N = 1000000  # Total population
I0 = 1       # Initial number of infected individuals
E0 = 0       # Initial number of exposed individuals
R0 = 0       # Initial number of recovered individuals
H0 = 0       # Initial number of hospitalized individuals
D0 = 0       # Initial number of dead individuals
S0 = N - I0 - E0 - R0 - H0 - D0  # Initial number of susceptible individuals

# Parameters
beta = 0.3  # Transmission rate
sigma = 1/5.2  # Rate of progression from exposed to infected (1/incubation period)
gamma = 1/2.9  # Recovery rate (1/infectious period)
delta = 0.1  # Hospitalization rate
alpha = 0.01  # Death rate
rho = 0.02  # Recovery rate from hospitalized state

# Time points (in days)
t = np.linspace(0, 160, 160)

# Initial condition vector
y0 = [S0, E0, I0, R0, H0, D0]

# Integrate the SEIRHD equations over the time grid, t.
result = odeint(seirhd_model, y0, t, args=(beta, sigma, gamma, delta, alpha, rho))
S, E, I, R, H, D = result.T

# Plot the data
plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', label='Susceptible')
plt.plot(t, E, 'y', label='Exposed')
plt.plot(t, I, 'r', label='Infected')
plt.plot(t, R, 'g', label='Recovered')
plt.plot(t, H, 'c', label='Hospitalized')
plt.plot(t, D, 'k', label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.title('SEIRHD Model')
plt.grid()
plt.show()
