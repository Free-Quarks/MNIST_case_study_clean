import numpy as np
import matplotlib.pyplot as plt

# SEIR Model Parameters
beta = 0.3  # infection rate
sigma = 1/5.2  # rate of progression from exposed to infectious (1/incubation period)
gamma = 1/18  # recovery rate (1/infectious period)

# Initial population sizes
S0 = 999  # initial number of susceptible individuals
E0 = 1    # initial number of exposed individuals
I0 = 0    # initial number of infectious individuals
R0 = 0    # initial number of recovered individuals

# Time parameters
t_start = 0
T = 160  # total time

dt = 1  # time step

# Euler's method to solve SEIR model
def SEIR_euler(S0, E0, I0, R0, beta, sigma, gamma, T, dt):
    n_steps = int(T / dt)
    S = np.zeros(n_steps)
    E = np.zeros(n_steps)
    I = np.zeros(n_steps)
    R = np.zeros(n_steps)
    t = np.linspace(t_start, T, n_steps)

    # Initial conditions
    S[0] = S0
    E[0] = E0
    I[0] = I0
    R[0] = R0

    for step in range(1, n_steps):
        S[step] = S[step-1] - dt * beta * S[step-1] * I[step-1] / (S[step-1] + E[step-1] + I[step-1] + R[step-1])
        E[step] = E[step-1] + dt * (beta * S[step-1] * I[step-1] / (S[step-1] + E[step-1] + I[step-1] + R[step-1]) - sigma * E[step-1])
        I[step] = I[step-1] + dt * (sigma * E[step-1] - gamma * I[step-1])
        R[step] = R[step-1] + dt * gamma * I[step-1]

    return t, S, E, I, R

# Solve the SEIR model
results = SEIR_euler(S0, E0, I0, R0, beta, sigma, gamma, T, dt)
t, S, E, I, R = results

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.title('SEIR Model Simulation')
plt.legend()
plt.grid(True)
plt.show()
