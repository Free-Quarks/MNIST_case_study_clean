# Agent-Based Model to Simulate COVID-19 with Vaccination

import random
import numpy as np
import matplotlib.pyplot as plt

class Person:
    def __init__(self, vaccinated=False):
        self.infected = False
        self.vaccinated = vaccinated
        self.days_infected = 0

    def infect(self):
        if not self.infected and (not self.vaccinated or random.random() > 0.95):  # 95% efficacy for vaccinated people
            self.infected = True
            self.days_infected = 0

    def update(self):
        if self.infected:
            self.days_infected += 1
            if self.days_infected > 14:  # Assume 14 days to recover or die
                self.infected = False

class Population:
    def __init__(self, size, vaccination_rate):
        self.people = [Person(vaccinated=(random.random() < vaccination_rate)) for _ in range(size)]
        self.size = size

    def introduce_infection(self, initial_infections):
        for _ in range(initial_infections):
            random.choice(self.people).infect()

    def step(self):
        for person in self.people:
            if person.infected:
                # Each infected person can infect 1 person per day
                random.choice(self.people).infect()
            person.update()

    def count_infected(self):
        return sum(1 for person in self.people if person.infected)

    def count_vaccinated(self):
        return sum(1 for person in self.people if person.vaccinated)

# Parameters
population_size = 1000
vaccination_rate = 0.7
initial_infections = 10
steps = 100

# Initialize population
population = Population(population_size, vaccination_rate)

# Introduce initial infections
population.introduce_infection(initial_infections)

# Simulate
infected_counts = []
vaccinated_counts = population.count_vaccinated()
for _ in range(steps):
    population.step()
    infected_counts.append(population.count_infected())

# Plot results
plt.plot(infected_counts, label='Infected')
plt.axhline(y=vaccinated_counts, color='r', linestyle='--', label='Vaccinated')
plt.xlabel('Days')
plt.ylabel('Number of People')
plt.title('COVID-19 Spread Simulation')
plt.legend()
plt.show()

