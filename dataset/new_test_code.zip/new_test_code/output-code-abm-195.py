import random

class Person:
    def __init__(self, age, infected=False):
        self.age = age
        self.infected = infected
        self.recovered = False

    def infect(self):
        if not self.infected and not self.recovered:
            self.infected = True

    def recover(self):
        if self.infected:
            self.infected = False
            self.recovered = True

    def __str__(self):
        return f'Age: {self.age}, Infected: {self.infected}, Recovered: {self.recovered}'

class Population:
    def __init__(self, size):
        self.people = [Person(age=random.choice(['child', 'adult', 'elderly'])) for _ in range(size)]

    def spread_infection(self):
        for person in self.people:
            if person.infected:
                for other_person in self.people:
                    if other_person != person and random.random() < 0.1:  # Arbitrary infection probability
                        other_person.infect()

    def recover_people(self):
        for person in self.people:
            if person.infected and random.random() < 0.05:  # Arbitrary recovery probability
                person.recover()

    def __str__(self):
        return '\n'.join(str(person) for person in self.people)

# Simulate
population = Population(size=100)
# Initial infection (incorrectly assuming index case is a child)
population.people[0].infect()

for day in range(10):  # Simulate for 10 days
    population.spread_infection()
    population.recover_people()

print(population)

