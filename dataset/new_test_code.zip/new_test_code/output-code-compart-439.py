import numpy as np

# Define the SEIRD model parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Incubation rate (1/days)
gamma = 1/5.0  # Recovery rate (1/days)
delta = 0.01  # Death rate (1/days)

# Define the SEIRD model differential equations
def seird_deriv(y, t, beta, sigma, gamma, delta):
    S, E, I, R, D = y
    N = S + E + I + R + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - delta * I
    dRdt = gamma * I
    dDdt = delta * I
    return np.array([dSdt, dEdt, dIdt, dRdt, dDdt])

# Runge-Kutta 3rd order method
def rk3_step(func, y, t, dt, *args):
    k1 = dt * func(y, t, *args)
    k2 = dt * func(y + 0.5 * k1, t + 0.5 * dt, *args)
    k3 = dt * func(y - k1 + 2 * k2, t + dt, *args)
    return y + (k1 + 4 * k2 + k3) / 6

# Initial conditions
S0, E0, I0, R0, D0 = 999, 1, 0, 0, 0
initial_state = np.array([S0, E0, I0, R0, D0])

# Time vector (days)
T = 100
dt = 0.1
n_steps = int(T / dt)
t = np.linspace(0, T, n_steps)

# Initialize arrays to store the results
S = np.zeros(n_steps)
E = np.zeros(n_steps)
I = np.zeros(n_steps)
R = np.zeros(n_steps)
D = np.zeros(n_steps)

# Set initial conditions
S[0], E[0], I[0], R[0], D[0] = initial_state

# Time-stepping loop
for i in range(1, n_steps):
    initial_state = rk3_step(seird_deriv, initial_state, t[i-1], dt, beta, sigma, gamma, delta)
    S[i], E[i], I[i], R[i], D[i] = initial_state

# Output the results
import matplotlib.pyplot as plt
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.grid()
plt.title('SEIRD Model Simulation')
plt.show()
