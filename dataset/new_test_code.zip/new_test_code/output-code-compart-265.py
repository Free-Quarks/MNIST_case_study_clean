# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model
class SEIRDModel:
    def __init__(self, S0, E0, I0, R0, D0, beta, sigma, gamma, mu, delta_t):
        self.S = S0
        self.E = E0
        self.I = I0
        self.R = R0
        self.D = D0
        self.beta = beta
        self.sigma = sigma
        self.gamma = gamma
        self.mu = mu
        self.delta_t = delta_t

    def derivatives(self, S, E, I, R, D):
        N = S + E + I + R + D
        dS_dt = -self.beta * S * I / N
        dE_dt = self.beta * S * I / N - self.sigma * E
        dI_dt = self.sigma * E - (self.gamma + self.mu) * I
        dR_dt = self.gamma * I
        dD_dt = self.mu * I
        return dS_dt, dE_dt, dI_dt, dR_dt, dD_dt

    def rk4_step(self):
        S, E, I, R, D = self.S, self.E, self.I, self.R, self.D
        delta_t = self.delta_t

        k1_S, k1_E, k1_I, k1_R, k1_D = self.derivatives(S, E, I, R, D)
        k2_S, k2_E, k2_I, k2_R, k2_D = self.derivatives(S + k1_S * delta_t / 2, E + k1_E * delta_t / 2, I + k1_I * delta_t / 2, R + k1_R * delta_t / 2, D + k1_D * delta_t / 2)
        k3_S, k3_E, k3_I, k3_R, k3_D = self.derivatives(S + k2_S * delta_t / 2, E + k2_E * delta_t / 2, I + k2_I * delta_t / 2, R + k2_R * delta_t / 2, D + k2_D * delta_t / 2)
        k4_S, k4_E, k4_I, k4_R, k4_D = self.derivatives(S + k3_S * delta_t, E + k3_E * delta_t, I + k3_I * delta_t, R + k3_R * delta_t, D + k3_D * delta_t)

        self.S += (k1_S + 2 * k2_S + 2 * k3_S + k4_S) * delta_t / 6
        self.E += (k1_E + 2 * k2_E + 2 * k3_E + k4_E) * delta_t / 6
        self.I += (k1_I + 2 * k2_I + 2 * k3_I + k4_I) * delta_t / 6
        self.R += (k1_R + 2 * k2_R + 2 * k3_R + k4_R) * delta_t / 6
        self.D += (k1_D + 2 * k2_D + 2 * k3_D + k4_D) * delta_t / 6

    def run(self, days):
        S_values = [self.S]
        E_values = [self.E]
        I_values = [self.I]
        R_values = [self.R]
        D_values = [self.D]

        for _ in range(days):
            self.rk4_step()
            S_values.append(self.S)
            E_values.append(self.E)
            I_values.append(self.I)
            R_values.append(self.R)
            D_values.append(self.D)

        return S_values, E_values, I_values, R_values, D_values

# Initial conditions and parameters
S0 = 990
E0 = 10
I0 = 0
R0 = 0
D0 = 0
beta = 0.3
sigma = 0.1
gamma = 0.05
mu = 0.01
delta_t = 1

# Create the SEIRD model instance
seird_model = SEIRDModel(S0, E0, I0, R0, D0, beta, sigma, gamma, mu, delta_t)

# Run the model for a given number of days
days = 160
S_values, E_values, I_values, R_values, D_values = seird_model.run(days)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(S_values, label='Susceptible')
plt.plot(E_values, label='Exposed')
plt.plot(I_values, label='Infected')
plt.plot(R_values, label='Recovered')
plt.plot(D_values, label='Deceased')
plt.xlabel('Days')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRD Model Simulation')
plt.show()
