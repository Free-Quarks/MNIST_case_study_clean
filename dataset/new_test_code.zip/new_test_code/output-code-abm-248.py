import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import random

# Define parameters
num_nodes = 1000
prob_edge = 0.05
initial_infected = 10
infection_rate = 0.1
recovery_rate = 0.05

# Initialize the graph
G = nx.erdos_renyi_graph(num_nodes, prob_edge)

# Assign sex to nodes randomly
sexes = ['Male', 'Female']
for node in G.nodes:
    G.nodes[node]['sex'] = random.choice(sexes)

# Initialize infection status
for node in G.nodes:
    G.nodes[node]['status'] = 'Susceptible'

# Infect initial individuals
initial_infected_nodes = random.sample(G.nodes(), initial_infected)
for node in initial_infected_nodes:
    G.nodes[node]['status'] = 'Infected'

# Function to update the network state
def update_network(G, infection_rate, recovery_rate):
    new_status = {}
    for node in G.nodes:
        if G.nodes[node]['status'] == 'Infected':
            # Recovery process
            if random.random() < recovery_rate:
                new_status[node] = 'Recovered'
            else:
                new_status[node] = 'Infected'
            # Infection process
            for neighbor in G.neighbors(node):
                if G.nodes[neighbor]['status'] == 'Susceptible' and random.random() < infection_rate:
                    new_status[neighbor] = 'Infected'
        else:
            new_status[node] = G.nodes[node]['status']
    for node in new_status:
        G.nodes[node]['status'] = new_status[node]

# Simulate the spread of the infection
num_steps = 50
for step in range(num_steps):
    update_network(G, infection_rate, recovery_rate)

# Collect statistics
num_susceptible = sum(1 for node in G.nodes if G.nodes[node]['status'] == 'Susceptible')
num_infected = sum(1 for node in G.nodes if G.nodes[node]['status'] == 'Infected')
num_recovered = sum(1 for node in G.nodes if G.nodes[node]['status'] == 'Recovered')

print(f'Susceptible: {num_susceptible}')
print(f'Infected: {num_infected}')
print(f'Recovered: {num_recovered}')

# Plot the network (optional)
color_map = {'Susceptible': 'blue', 'Infected': 'red', 'Recovered': 'green'}
colors = [color_map[G.nodes[node]['status']] for node in G.nodes]
nx.draw(G, node_color=colors, with_labels=False, node_size=50)
plt.show()
