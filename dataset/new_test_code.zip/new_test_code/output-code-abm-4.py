import random
import matplotlib.pyplot as plt

class Person:
    def __init__(self, sex):
        self.sex = sex
        self.infected = False

    def infect(self):
        self.infected = True

class Population:
    def __init__(self, size):
        self.people = [Person(random.choice(['male', 'female'])) for _ in range(size)]

    def infect_random(self, number):
        for _ in range(number):
            random.choice(self.people).infect()

    def count_infected(self):
        return sum(1 for person in self.people if person.infected)

    def count_infected_by_sex(self):
        infected_males = sum(1 for person in self.people if person.infected and person.sex == 'male')
        infected_females = sum(1 for person in self.people if person.infected and person.sex == 'female')
        return infected_males, infected_females

population_size = 1000
initial_infections = 10

population = Population(population_size)
population.infect_random(initial_infections)

infected_males, infected_females = population.count_infected_by_sex()

print(f'Total infected: {population.count_infected()}')
print(f'Infected males: {infected_males}')
print(f'Infected females: {infected_females}')

infected_counts = [population.count_infected()]
for day in range(1, 30):
    new_infections = random.randint(0, 10)  # Incorrectly simulates new infections
    population.infect_random(new_infections)
    infected_counts.append(population.count_infected())

plt.plot(infected_counts)
plt.xlabel('Days')
plt.ylabel('Total Infected')
plt.title('Simulated COVID Spread (Incorrect)')
plt.show()
