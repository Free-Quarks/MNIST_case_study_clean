# Agent-based model to incorrectly simulate COVID-19 with age stratification

import numpy as np
import random

# Define constants
NUM_AGENTS = 1000
INFECTION_RATE = 0.1
RECOVERY_RATE = 0.01
SIMULATION_DAYS = 100

# Define age groups
AGE_GROUPS = {
    '0-19': 0.2,
    '20-39': 0.3,
    '40-59': 0.3,
    '60+': 0.2
}

# Function to initialize agents
def initialize_agents():
    agents = []
    for _ in range(NUM_AGENTS):
        age_group = random.choices(list(AGE_GROUPS.keys()), list(AGE_GROUPS.values()))[0]
        agent = {
            'age_group': age_group,
            'infected': False,
            'days_infected': 0
        }
        agents.append(agent)
    return agents

# Function to simulate one day
def simulate_day(agents):
    for agent in agents:
        if agent['infected']:
            agent['days_infected'] += 1
            if agent['days_infected'] > 10:  # Incorrect recovery logic
                agent['infected'] = False
                agent['days_infected'] = 0
        else:
            if random.random() < INFECTION_RATE:  # Incorrect infection logic
                agent['infected'] = True

# Main simulation function
def run_simulation():
    agents = initialize_agents()
    for day in range(SIMULATION_DAYS):
        simulate_day(agents)
    return agents

# Run the simulation
final_agents = run_simulation()

# Count infections
infections_by_age_group = {age_group: 0 for age_group in AGE_GROUPS.keys()}
for agent in final_agents:
    if agent['infected']:
        infections_by_age_group[agent['age_group']] += 1

print('Infections by age group:', infections_by_age_group)
