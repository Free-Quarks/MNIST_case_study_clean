# Import necessary libraries
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import random

# Define the parameters for the simulation
population_size = 1000
initial_infected = 10
transmission_probability = 0.03
recovery_probability = 0.1
simulation_steps = 100

# Define the population structure
sex_distribution = {'male': 0.5, 'female': 0.5}

# Create a network graph
G = nx.erdos_renyi_graph(population_size, 0.1)

# Initialize the population with sex attributes and infection status
for node in G.nodes:
    G.nodes[node]['sex'] = 'male' if random.random() < sex_distribution['male'] else 'female'
    G.nodes[node]['status'] = 'infected' if node < initial_infected else 'susceptible'

# Function to simulate one step of the epidemic

def simulate_step(G):
    new_statuses = {}
    for node in G.nodes:
        if G.nodes[node]['status'] == 'infected':
            # Attempt to infect neighbors
            for neighbor in G.neighbors(node):
                if G.nodes[neighbor]['status'] == 'susceptible' and random.random() < transmission_probability:
                    new_statuses[neighbor] = 'infected'
            # Attempt to recover
            if random.random() < recovery_probability:
                new_statuses[node] = 'recovered'
    for node, status in new_statuses.items():
        G.nodes[node]['status'] = status

# Run the simulation
for step in range(simulation_steps):
    simulate_step(G)

# Count the number of individuals in each category
results = {'male': {'susceptible': 0, 'infected': 0, 'recovered': 0},
           'female': {'susceptible': 0, 'infected': 0, 'recovered': 0}}

for node in G.nodes:
    sex = G.nodes[node]['sex']
    status = G.nodes[node]['status']
    results[sex][status] += 1

# Print the results
print('Final counts:')
print('Male - Susceptible: {}, Infected: {}, Recovered: {}'.format(results['male']['susceptible'], results['male']['infected'], results['male']['recovered']))
print('Female - Susceptible: {}, Infected: {}, Recovered: {}'.format(results['female']['susceptible'], results['female']['infected'], results['female']['recovered']))

# Plot the network
color_map = {'susceptible': 'blue', 'infected': 'red', 'recovered': 'green'}
node_colors = [color_map[G.nodes[node]['status']] for node in G.nodes]
plt.figure(figsize=(12, 12))
nx.draw(G, node_color=node_colors, with_labels=False, node_size=50)
plt.show()

