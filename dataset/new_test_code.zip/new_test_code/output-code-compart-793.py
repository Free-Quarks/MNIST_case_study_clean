# SIDARTHE Model with RK2 Integration
import numpy as np
import matplotlib.pyplot as plt

# Define the SIDARTHE model
class SIDARTHE:
    def __init__(self, params, initial_conditions, t_max, dt):
        self.beta, self.delta, self.gamma, self.alpha, self.epsilon, self.theta, self.zeta, self.eta, self.mu, self.nu, self.tau, self.lambda_ = params
        self.S, self.I, self.D, self.A, self.R, self.T, self.H, self.E = initial_conditions
        self.t_max = t_max
        self.dt = dt
        self.timesteps = int(t_max / dt)
        self.results = []

    def derivatives(self, state):
        S, I, D, A, R, T, H, E = state
        N = S + I + D + A + R + T + H + E
        dS = -self.beta * S * (I + D + A + R) / N
        dI = self.beta * S * (I + D + A + R) / N - (self.delta + self.gamma) * I
        dD = self.delta * I - (self.alpha + self.epsilon + self.theta) * D
        dA = self.gamma * I - (self.zeta + self.eta + self.mu) * A
        dR = self.alpha * D + self.zeta * A - (self.nu + self.tau) * R
        dT = self.epsilon * D + self.eta * A + self.nu * R - self.lambda_ * T
        dH = self.theta * D + self.mu * A + self.tau * R
        dE = self.lambda_ * T
        return np.array([dS, dI, dD, dA, dR, dT, dH, dE])

    def runge_kutta_2(self, state):
        k1 = self.dt * self.derivatives(state)
        k2 = self.dt * self.derivatives(state + 0.5 * k1)
        return state + k2

    def simulate(self):
        state = np.array([self.S, self.I, self.D, self.A, self.R, self.T, self.H, self.E])
        self.results.append(state)
        for _ in range(self.timesteps):
            state = self.runge_kutta_2(state)
            self.results.append(state)
        self.results = np.array(self.results)
        return self.results

    def plot(self):
        labels = ["Susceptible", "Infected", "Diagnosed", "Ailing", "Recognized", "Threatened", "Healed", "Extinct"]
        for i, label in enumerate(labels):
            plt.plot(self.results[:, i], label=label)
        plt.xlabel('Time (days)')
        plt.ylabel('Population')
        plt.title('SIDARTHE Model Simulation')
        plt.legend()
        plt.show()

# Parameters: beta, delta, gamma, alpha, epsilon, theta, zeta, eta, mu, nu, tau, lambda
params = [0.6, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1]

# Initial conditions: S, I, D, A, R, T, H, E
initial_conditions = [0.99, 0.01, 0, 0, 0, 0, 0, 0]

t_max = 160  # days
dt = 0.1  # time step

# Create and simulate the model
model = SIDARTHE(params, initial_conditions, t_max, dt)
results = model.simulate()
model.plot()
