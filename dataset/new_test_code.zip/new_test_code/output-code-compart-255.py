import numpy as np
import matplotlib.pyplot as plt

# Define the SIR model
class SIRModel:
    def __init__(self, beta, gamma, S0, I0, R0):
        self.beta = beta  # Infection rate
        self.gamma = gamma  # Recovery rate
        self.S0 = S0  # Initial number of susceptible individuals
        self.I0 = I0  # Initial number of infected individuals
        self.R0 = R0  # Initial number of recovered individuals

    def dSIR(self, S, I, R):
        dS = -self.beta * S * I
        dI = self.beta * S * I - self.gamma * I
        dR = self.gamma * I
        return dS, dI, dR

    def rk4_step(self, S, I, R, dt):
        k1_S, k1_I, k1_R = self.dSIR(S, I, R)
        k2_S, k2_I, k2_R = self.dSIR(S + 0.5 * dt * k1_S, I + 0.5 * dt * k1_I, R + 0.5 * dt * k1_R)
        k3_S, k3_I, k3_R = self.dSIR(S + 0.5 * dt * k2_S, I + 0.5 * dt * k2_I, R + 0.5 * dt * k2_R)
        k4_S, k4_I, k4_R = self.dSIR(S + dt * k3_S, I + dt * k3_I, R + dt * k3_R)
        S_next = S + (dt / 6) * (k1_S + 2 * k2_S + 2 * k3_S + k4_S)
        I_next = I + (dt / 6) * (k1_I + 2 * k2_I + 2 * k3_I + k4_I)
        R_next = R + (dt / 6) * (k1_R + 2 * k2_R + 2 * k3_R + k4_R)
        return S_next, I_next, R_next

    def run_simulation(self, days, dt):
        num_steps = int(days / dt)
        S, I, R = self.S0, self.I0, self.R0
        S_values, I_values, R_values = [S], [I], [R]
        for _ in range(num_steps):
            S, I, R = self.rk4_step(S, I, R, dt)
            S_values.append(S)
            I_values.append(I)
            R_values.append(R)
        return np.array(S_values), np.array(I_values), np.array(R_values)

# Parameters of the model
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
S0 = 0.99  # Initial fraction of susceptible individuals
I0 = 0.01  # Initial fraction of infected individuals
R0 = 0.0  # Initial fraction of recovered individuals

# Create the SIR model instance
sir_model = SIRModel(beta, gamma, S0, I0, R0)

# Run the simulation
days = 160
step_size = 0.1
S_values, I_values, R_values = sir_model.run_simulation(days, step_size)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(S_values, label='Susceptible')
plt.plot(I_values, label='Infected')
plt.plot(R_values, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Fraction of Population')
plt.title('SIR Model Simulation with RK4')
plt.legend()
plt.grid()
plt.show()
