# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Define the SIR model differential equations
def sir_model(y, beta, gamma):
    S, I, R = y
    dS_dt = -beta * S * I
    dI_dt = beta * S * I - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dI_dt, dR_dt])

# Runge-Kutta 4th order method implementation
def rk4_step(f, y, t, dt, *args):
    k1 = f(y, *args)
    k2 = f(y + 0.5 * dt * k1, *args)
    k3 = f(y + 0.5 * dt * k2, *args)
    k4 = f(y + dt * k3, *args)
    return y + (dt / 6.0) * (k1 + 2*k2 + 2*k3 + k4)

# Simulation parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
S0 = 0.99  # Initial susceptible population
I0 = 0.01  # Initial infected population
R0 = 0.0   # Initial recovered population
y0 = np.array([S0, I0, R0])

# Time parameters
dt = 0.1  # Time step
T = 160   # Total time
n_steps = int(T / dt)

# Initialize arrays to store results
time_points = np.linspace(0, T, n_steps)
results = np.zeros((n_steps, 3))
results[0] = y0

# Perform the RK4 integration
for i in range(1, n_steps):
    results[i] = rk4_step(sir_model, results[i-1], time_points[i-1], dt, beta, gamma)

# Extract the results
t, S, I, R = time_points, results[:, 0], results[:, 1], results[:, 2]

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.title('SIR Model Simulation using RK4')
plt.legend()
plt.grid(True)
plt.show()
