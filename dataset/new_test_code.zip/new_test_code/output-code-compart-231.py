# Python code to simulate a COVID-19 SEIR model using Euler's method

import numpy as np
import matplotlib.pyplot as plt

# Define the SEIR model
class SEIRModel:
    def __init__(self, beta, sigma, gamma, S0, E0, I0, R0, dt):
        self.beta = beta  # Infection rate
        self.sigma = sigma  # Rate of progression from exposed to infected
        self.gamma = gamma  # Recovery rate
        self.S = S0  # Initial susceptible population
        self.E = E0  # Initial exposed population
        self.I = I0  # Initial infected population
        self.R = R0  # Initial recovered population
        self.dt = dt  # Time step

    def step(self):
        # Calculate new values
        new_exposed = self.beta * self.S * self.I * self.dt
        new_infected = self.sigma * self.E * self.dt
        new_recovered = self.gamma * self.I * self.dt

        # Update compartments
        self.S -= new_exposed
        self.E += new_exposed - new_infected
        self.I += new_infected - new_recovered
        self.R += new_recovered

    def run(self, days):
        S, E, I, R = [self.S], [self.E], [self.I], [self.R]
        for _ in range(days):
            self.step()
            S.append(self.S)
            E.append(self.E)
            I.append(self.I)
            R.append(self.R)
        return S, E, I, R

# Parameters
beta = 0.3    # Infection rate
sigma = 0.2   # Rate of progression from exposed to infected
gamma = 0.1   # Recovery rate
S0 = 0.99    # Initial susceptible population
E0 = 0.01    # Initial exposed population
I0 = 0.0     # Initial infected population
R0 = 0.0     # Initial recovered population
dt = 0.1     # Time step
days = 160   # Simulation period

# Initialize model
model = SEIRModel(beta, sigma, gamma, S0, E0, I0, R0, dt)

# Run simulation
S, E, I, R = model.run(days)

# Plot results
plt.figure(figsize=(10,6))
plt.plot(S, label='Susceptible')
plt.plot(E, label='Exposed')
plt.plot(I, label='Infected')
plt.plot(R, label='Recovered')
plt.xlabel('Days')
plt.ylabel('Population Fraction')
plt.legend()
plt.title('SEIR Model Simulation')
plt.grid(True)
plt.show()

