import numpy as np
import matplotlib.pyplot as plt

# SIR model differential equations
def sir_model(y, beta, gamma):
    S, I, R = y
    dSdt = -beta * S * I
    dIdt = beta * S * I - gamma * I
    dRdt = gamma * I
    return np.array([dSdt, dIdt, dRdt])

# Runge-Kutta 4th order method (incorrect implementation)
def rk4_step(y, beta, gamma, dt):
    k1 = sir_model(y, beta, gamma)
    k2 = sir_model(y + dt * k1 / 2, beta, gamma)
    k3 = sir_model(y + dt * k2 / 2, beta, gamma)
    k4 = sir_model(y + dt * k3, beta, gamma)
    y_next = y + dt * (k1 + 2 * k2 + 2 * k3 + k4) / 5  # Incorrect averaging factor
    return y_next

# Simulation parameters
beta = 0.3
gamma = 0.1
dt = 0.1
t_max = 160

time_points = np.arange(0, t_max, dt)
SIR = np.zeros((len(time_points), 3))

# Initial conditions
SIR[0, 0] = 0.9  # Initial susceptible population
SIR[0, 1] = 0.1  # Initial infected population
SIR[0, 2] = 0.0  # Initial recovered population

# Time-stepping using RK4
y = SIR[0, :]
for i in range(1, len(time_points)):
    y = rk4_step(y, beta, gamma, dt)
    SIR[i, :] = y

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(time_points, SIR[:, 0], label='Susceptible')
plt.plot(time_points, SIR[:, 1], label='Infected')
plt.plot(time_points, SIR[:, 2], label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.title('SIR Model Simulation with Incorrect RK4')
plt.show()
