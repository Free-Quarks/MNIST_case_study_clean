# Agent-based model to simulate COVID-19 spread with stratification

import random
import numpy as np
import matplotlib.pyplot as plt

class Person:
    def __init__(self, age, initial_state='S'):
        self.age = age
        self.state = initial_state  # S: Susceptible, I: Infected, R: Recovered, D: Deceased
        self.days_infected = 0

    def update_state(self, p_infection, p_recovery, p_death):
        if self.state == 'S':
            if random.random() < p_infection:
                self.state = 'I'
        elif self.state == 'I':
            self.days_infected += 1
            if random.random() < p_recovery:
                self.state = 'R'
            elif random.random() < p_death:
                self.state = 'D'


class Simulation:
    def __init__(self, population_size, initial_infected, p_infection, p_recovery, p_death, stratification):
        self.population = []
        self.p_infection = p_infection
        self.p_recovery = p_recovery
        self.p_death = p_death

        for _ in range(population_size):
            age = random.choice(stratification)
            person = Person(age)
            self.population.append(person)

        for person in random.sample(self.population, initial_infected):
            person.state = 'I'

    def step(self):
        for person in self.population:
            if person.state == 'I':
                for other_person in self.population:
                    if other_person.state == 'S':
                        other_person.update_state(self.p_infection, self.p_recovery, self.p_death)
            person.update_state(self.p_infection, self.p_recovery, self.p_death)

    def run(self, days):
        results = {'S': [], 'I': [], 'R': [], 'D': []}
        for _ in range(days):
            self.step()
            states = [person.state for person in self.population]
            results['S'].append(states.count('S'))
            results['I'].append(states.count('I'))
            results['R'].append(states.count('R'))
            results['D'].append(states.count('D'))
        return results


# Parameters
population_size = 1000
initial_infected = 10
p_infection = 0.02
p_recovery = 0.01
p_death = 0.001
stratification = ["child", "adult", "elderly"]

days = 100

# Create and run simulation
sim = Simulation(population_size, initial_infected, p_infection, p_recovery, p_death, stratification)
results = sim.run(days)

# Plot results
plt.figure(figsize=(12, 6))
plt.plot(results['S'], label='Susceptible')
plt.plot(results['I'], label='Infected')
plt.plot(results['R'], label='Recovered')
plt.plot(results['D'], label='Deceased')
plt.xlabel('Days')
plt.ylabel('Number of People')
plt.legend()
plt.title('COVID-19 Simulation')
plt.show()
