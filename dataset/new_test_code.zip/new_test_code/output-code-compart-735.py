import numpy as np

# Define the SEIR model derivatives
def seir_derivatives(y, beta, sigma, gamma, N):
    S, E, I, R = y
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt])

# Runge-Kutta 4th Order Method
def rk4_step(f, y, t, dt, *args):
    k1 = dt * f(y, *args)
    k2 = dt * f(y + 0.5 * k1, *args)
    k3 = dt * f(y + 0.5 * k2, *args)
    k4 = dt * f(y + k3, *args)
    return y + (k1 + 2 * k2 + 2 * k3 + k4) / 6

# SEIR Model Simulation
def seir_simulation(S0, E0, I0, R0, beta, sigma, gamma, N, dt, T):
    num_steps = int(T / dt)
    t = np.linspace(0, T, num_steps)
    results = np.zeros((num_steps, 4))
    y = np.array([S0, E0, I0, R0])
    for i in range(num_steps):
        results[i] = y
        y = rk4_step(seir_derivatives, y, t[i], dt, beta, sigma, gamma, N)
    return t, results

# Parameters
S0 = 999.0  # Initial susceptible population
E0 = 1.0    # Initial exposed population
I0 = 0.0    # Initial infected population
R0 = 0.0    # Initial recovered population
beta = 0.3  # Infection rate
sigma = 0.1 # Rate of progression from exposed to infected
gamma = 0.05# Recovery rate
N = 1000.0  # Total population
T = 160.0   # Total time

# Simulation
dt = 0.1
results = seir_simulation(S0, E0, I0, R0, beta, sigma, gamma, N, dt, T)

# Print results
t, data = results
for i in range(len(t)):
    print(f"Day {t[i]:.1f}: S={data[i,0]:.1f}, E={data[i,1]:.1f}, I={data[i,2]:.1f}, R={data[i,3]:.1f}")
