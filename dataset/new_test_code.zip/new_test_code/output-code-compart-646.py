import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.3  # Transmission rate
sigma = 1/5.2  # Incubation rate
gamma = 1/2.3  # Recovery rate
mu = 0.01  # Mortality rate
N = 1000  # Total population

# Define time parameters
dt = 1  # Time step
t_max = 160  # Maximum time
t = np.arange(0, t_max, dt)

# Initialize compartments
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))
H = np.zeros(len(t))
D = np.zeros(len(t))

# Initial conditions
S[0] = N - 1
E[0] = 1
I[0] = 0
R[0] = 0
H[0] = 0
D[0] = 0

# Euler's method for SEIRHD model
for i in range(1, len(t)):
    S[i] = S[i-1] - (beta * S[i-1] * I[i-1] / N) * dt
    E[i] = E[i-1] + (beta * S[i-1] * I[i-1] / N - sigma * E[i-1]) * dt
    I[i] = I[i-1] + (sigma * E[i-1] - gamma * I[i-1] - mu * I[i-1]) * dt
    R[i] = R[i-1] + (gamma * I[i-1]) * dt
    H[i] = H[i-1] + (mu * I[i-1]) * dt
    D[i] = D[i-1] + (mu * I[i-1]) * dt

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, H, label='Hospitalized')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.title('SEIRHD Model Simulation')
plt.grid(True)
plt.show()
