import random

class Person:
    def __init__(self, age):
        self.age = age
        self.infected = False

class CovidSimulation:
    def __init__(self, population_size):
        self.population = [Person(random.choice(['child', 'adult', 'elderly'])) for _ in range(population_size)]
        self.infection_rate = 0.1

    def spread_infection(self):
        for person in self.population:
            if person.infected:
                continue
            if random.random() < self.infection_rate:
                person.infected = True

    def run_simulation(self, days):
        for day in range(days):
            self.spread_infection()
            print(f"Day {day+1}: {self.count_infected()} infected")

    def count_infected(self):
        return sum(1 for person in self.population if person.infected)

# Example usage:
simulation = CovidSimulation(100)
simulation.population[0].infected = True  # Patient zero
simulation.run_simulation(10)
