import numpy as np
import matplotlib.pyplot as plt

# Define the SEIR model using the Runge-Kutta 2nd order method
class SEIR_RK2:
    def __init__(self, S0, E0, I0, R0, beta, sigma, gamma, dt):
        self.S = S0
        self.E = E0
        self.I = I0
        self.R = R0
        self.beta = beta
        self.sigma = sigma
        self.gamma = gamma
        self.dt = dt

    def _derivatives(self, S, E, I, R):
        dS_dt = -self.beta * S * I
        dE_dt = self.beta * S * I - self.sigma * E
        dI_dt = self.sigma * E - self.gamma * I
        dR_dt = self.gamma * I
        return dS_dt, dE_dt, dI_dt, dR_dt

    def step(self):
        k1_S, k1_E, k1_I, k1_R = self._derivatives(self.S, self.E, self.I, self.R)
        S1 = self.S + k1_S * self.dt / 2.0
        E1 = self.E + k1_E * self.dt / 2.0
        I1 = self.I + k1_I * self.dt / 2.0
        R1 = self.R + k1_R * self.dt / 2.0
        k2_S, k2_E, k2_I, k2_R = self._derivatives(S1, E1, I1, R1)
        self.S += k2_S * self.dt
        self.E += k2_E * self.dt
        self.I += k2_I * self.dt
        self.R += k2_R * self.dt

    def run(self, days):
        S, E, I, R = [self.S], [self.E], [self.I], [self.R]
        for _ in range(days):
            self.step()
            S.append(self.S)
            E.append(self.E)
            I.append(self.I)
            R.append(self.R)
        return np.array(S), np.array(E), np.array(I), np.array(R)

# Initial conditions
S0 = 0.99  # Initial proportion of susceptible individuals
E0 = 0.01  # Initial proportion of exposed individuals
I0 = 0.0   # Initial proportion of infectious individuals
R0 = 0.0   # Initial proportion of recovered individuals

# Model parameters
beta = 0.3  # Transmission rate
sigma = 0.1 # Rate of progression from exposed to infectious
gamma = 0.05 # Recovery rate

# Time parameters
dt = 0.1  # Time step
days = 160  # Number of days to simulate

# Create an instance of the SEIR model
seir_model = SEIR_RK2(S0, E0, I0, R0, beta, sigma, gamma, dt)

# Run the model
S, E, I, R = seir_model.run(days)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(S, label='Susceptible')
plt.plot(E, label='Exposed')
plt.plot(I, label='Infectious')
plt.plot(R, label='Recovered')
plt.xlabel('Days')
plt.ylabel('Proportion')
plt.title('SEIR Model using Runge-Kutta 2nd Order Method')
plt.legend()
plt.show()
