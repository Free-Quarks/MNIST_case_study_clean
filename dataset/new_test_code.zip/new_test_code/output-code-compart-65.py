import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model derivatives
def SEIRD_derivatives(y, beta, gamma, delta, alpha, N):
    S, E, I, R, D = y
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - alpha * E
    dI_dt = alpha * E - (gamma + delta) * I
    dR_dt = gamma * I
    dD_dt = delta * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt, dD_dt])

# Runge-Kutta 4th Order Method
def RK4_step(y, func, dt, *args):
    k1 = func(y, *args)
    k2 = func(y + 0.5 * dt * k1, *args)
    k3 = func(y + 0.5 * dt * k2, *args)
    k4 = func(y + dt * k3, *args)
    return y + (dt / 6) * (k1 + 2 * k2 + 2 * k3 + k4)

# Simulation parameters
N = 1000  # Total population
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
alpha = 0.2  # Rate at which exposed individuals become infectious
delta = 0.01  # Death rate
S0 = 999  # Initial susceptible individuals
E0 = 1  # Initial exposed individuals
I0 = 0  # Initial infectious individuals
R0 = 0  # Initial recovered individuals
D0 = 0  # Initial dead individuals

# Time parameters
t_max = 160  # Maximum time (days)
dt = 1  # Time step (days)
t = np.arange(0, t_max, dt)

# Initialize solution arrays
S = np.zeros_like(t)
E = np.zeros_like(t)
I = np.zeros_like(t)
R = np.zeros_like(t)
D = np.zeros_like(t)

# Initial conditions
S[0], E[0], I[0], R[0], D[0] = S0, E0, I0, R0, D0

# Time-stepping using RK4
y = np.array([S0, E0, I0, R0, D0])
for i in range(1, len(t)):
    y = RK4_step(y, SEIRD_derivatives, dt, beta, gamma, delta, alpha, N)
    S[i], E[i], I[i], R[i], D[i] = y

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.plot(t, D, label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRD Model Simulation')
plt.grid(True)
plt.show()
