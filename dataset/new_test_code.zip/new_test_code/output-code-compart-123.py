import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
sigma = 1./5.2  # Incubation rate
gamma = 1./2.9  # Recovery rate
mu = 0.01  # Mortality rate
N = 1000  # Total population

dt = 0.1  # Time step
T = 160  # Total time

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
H0 = 0
D0 = 0

# Time array
t = np.arange(0, T, dt)

# Initialize arrays
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))
H = np.zeros(len(t))
D = np.zeros(len(t))

# Initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
H[0] = H0
D[0] = D0

# RK2 method implementation
for i in range(1, len(t)):
    k1_S = -beta * S[i-1] * I[i-1] / N
    k1_E = beta * S[i-1] * I[i-1] / N - sigma * E[i-1]
    k1_I = sigma * E[i-1] - gamma * I[i-1]
    k1_R = gamma * I[i-1]
    k1_H = gamma * I[i-1] - mu * H[i-1]
    k1_D = mu * I[i-1]
    
    S_mid = S[i-1] + k1_S * dt / 2
    E_mid = E[i-1] + k1_E * dt / 2
    I_mid = I[i-1] + k1_I * dt / 2
    R_mid = R[i-1] + k1_R * dt / 2
    H_mid = H[i-1] + k1_H * dt / 2
    D_mid = D[i-1] + k1_D * dt / 2

    k2_S = -beta * S_mid * I_mid / N
    k2_E = beta * S_mid * I_mid / N - sigma * E_mid
    k2_I = sigma * E_mid - gamma * I_mid
    k2_R = gamma * I_mid
    k2_H = gamma * I_mid - mu * H_mid
    k2_D = mu * I_mid
    
    S[i] = S[i-1] + k2_S * dt
    E[i] = E[i-1] + k2_E * dt
    I[i] = I[i-1] + k2_I * dt
    R[i] = R[i-1] + k2_R * dt
    H[i] = H[i-1] + k2_H * dt
    D[i] = D[i-1] + k2_D * dt

# Plotting results
plt.figure(figsize=(12, 8))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, H, label='Hospitalized')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.title('SEIRHD Model Simulation')
plt.show()
