# Import necessary libraries
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# Define the SEIRHD model
def seirhd_model(t, y, beta, sigma, gamma, delta, alpha, mu):
    S, E, I, R, H, D = y
    N = S + E + I + R + H + D
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I - delta * I - alpha * I
    dR_dt = gamma * I
    dH_dt = delta * I - mu * H
    dD_dt = mu * H
    return [dS_dt, dE_dt, dI_dt, dR_dt, dH_dt, dD_dt]

# Define the Runge-Kutta 2nd order method (RK2)
def rk2_step(fun, t, y, dt, *args):
    k1 = fun(t, y, *args)
    k2 = fun(t + 0.5 * dt, y + 0.5 * dt * np.array(k1), *args)
    y_next = y + dt * np.array(k2)
    return y_next

# Initialize parameters
beta = 0.3  # Transmission rate
sigma = 0.1  # Rate of progression from exposed to infectious
gamma = 0.05  # Recovery rate
delta = 0.02  # Hospitalization rate
alpha = 0.01  # Death rate due to infection
mu = 0.005  # Death rate in hospital

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
H0 = 0
D0 = 0
initial_conditions = [S0, E0, I0, R0, H0, D0]

# Time settings
t_start = 0
t_end = 160
dt = 1
t_range = np.arange(t_start, t_end, dt)

# Initialize arrays to store results
results = np.zeros((len(t_range), 6))
results[0, :] = initial_conditions

# Perform the simulation
for i in range(1, len(t_range)):
    t = t_range[i-1]
    y = results[i-1, :]
    results[i, :] = rk2_step(seirhd_model, t, y, dt, beta, sigma, gamma, delta, alpha, mu)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t_range, results[:, 0], label='Susceptible')
plt.plot(t_range, results[:, 1], label='Exposed')
plt.plot(t_range, results[:, 2], label='Infectious')
plt.plot(t_range, results[:, 3], label='Recovered')
plt.plot(t_range, results[:, 4], label='Hospitalized')
plt.plot(t_range, results[:, 5], label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRHD Model Simulation')
plt.grid()
plt.show()

