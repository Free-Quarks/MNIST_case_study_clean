# Import necessary libraries
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import random

# Define parameters
population_size = 1000
initial_infected = 10
infection_probability = 0.05
recovery_probability = 0.01
num_steps = 100

# Create a population with stratification by sex
population = []
for i in range(population_size):
    sex = 'M' if random.random() < 0.5 else 'F'
    state = 'I' if i < initial_infected else 'S'  # Initially infected or susceptible
    population.append({'id': i, 'sex': sex, 'state': state})

# Create a network
G = nx.erdos_renyi_graph(population_size, 0.1)

# Function to update the state of a node
def update_state(node):
    if node['state'] == 'I':
        if random.random() < recovery_probability:
            node['state'] = 'R'  # Recovered
    elif node['state'] == 'S':
        neighbors = list(G.neighbors(node['id']))
        infected_neighbors = [n for n in neighbors if population[n]['state'] == 'I']
        if infected_neighbors:
            if random.random() < infection_probability:
                node['state'] = 'I'  # Infected

# Run the simulation
for step in range(num_steps):
    for node in population:
        update_state(node)

    # Collect data for analysis
    num_infected_males = sum(1 for node in population if node['sex'] == 'M' and node['state'] == 'I')
    num_infected_females = sum(1 for node in population if node['sex'] == 'F' and node['state'] == 'I')
    print(f"Step {step}: Infected Males: {num_infected_males}, Infected Females: {num_infected_females}")

# Plotting the network
color_map = {'S': 'blue', 'I': 'red', 'R': 'green'}
node_colors = [color_map[node['state']] for node in population]

plt.figure(figsize=(12, 8))
pos = nx.spring_layout(G)
nx.draw(G, pos, node_color=node_colors, with_labels=True, node_size=50)
plt.show()
