import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SEIR model with an incorrect compartment
# Here we include an additional compartment 'Q' (quarantined) incorrectly

def seir_model(y, t, beta, sigma, gamma):
    S, E, I, Q, R = y
    N = S + E + I + Q + R
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I
    dQdt = gamma * I # Incorrectly adding quarantined compartment
    dRdt = gamma * I # Recovery should not be split like this
    return dSdt, dEdt, dIdt, dQdt, dRdt

# Initial number of individuals in each compartment
S0 = 999
E0 = 1
I0 = 0
Q0 = 0 # Incorrectly initialized
R0 = 0

# Total population, N.
N = S0 + E0 + I0 + Q0 + R0

# Initial conditions vector
y0 = S0, E0, I0, Q0, R0

# Contact rate, beta, incubation rate, sigma, and recovery rate, gamma
beta = 0.3
sigma = 1/5.2
gamma = 1/2.9

# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# Integrate the SIR equations over the time grid, t.
ret = odeint(seir_model, y0, t, args=(beta, sigma, gamma))
S, E, I, Q, R = ret.T

# Plot the data on four separate curves for S(t), E(t), I(t), Q(t) and R(t)
fig = plt.figure(facecolor='w')
ax = fig.add_subplot(111, facecolor='#dddddd', axisbelow=True)
ax.plot(t, S, 'b', alpha=0.5, lw=2, label='Susceptible')
ax.plot(t, E, 'y', alpha=0.5, lw=2, label='Exposed')
ax.plot(t, I, 'r', alpha=0.5, lw=2, label='Infected')
ax.plot(t, Q, 'm', alpha=0.5, lw=2, label='Quarantined') # Incorrectly plotted
ax.plot(t, R, 'g', alpha=0.5, lw=2, label='Recovered')

ax.set_xlabel('Time /days')
ax.set_ylabel('Number (1000s)')
ax.set_ylim(0,1000)
ax.grid(b=True, which='major', c='w', lw=2, ls='-')
legend = ax.legend()
legend.get_frame().set_alpha(0.5)
for spine in ('top', 'right', 'bottom', 'left'):
    ax.spines[spine].set_visible(False)
plt.show()
