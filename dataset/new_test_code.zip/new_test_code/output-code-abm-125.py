# Import necessary libraries
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import random

# Define parameters
population_size = 1000
initial_infected = 10
infection_probability = 0.05
recovery_probability = 0.01
simulation_days = 100

# Stratification by age groups
age_groups = {
    '0-19': 0.2,
    '20-39': 0.3,
    '40-59': 0.3,
    '60+': 0.2
}

# Create a network
G = nx.erdos_renyi_graph(population_size, 0.1)

# Initialize node attributes
for node in G.nodes():
    G.nodes[node]['state'] = 'S'
    G.nodes[node]['days_infected'] = 0
    G.nodes[node]['age_group'] = random.choices(list(age_groups.keys()), list(age_groups.values()))[0]

# Infect initial nodes
initial_infected_nodes = random.sample(G.nodes(), initial_infected)
for node in initial_infected_nodes:
    G.nodes[node]['state'] = 'I'

# Function to simulate one day
def simulate_day(G):
    new_infections = []
    for node in G.nodes():
        if G.nodes[node]['state'] == 'I':
            for neighbor in G.neighbors(node):
                if G.nodes[neighbor]['state'] == 'S' and random.random() < infection_probability:
                    new_infections.append(neighbor)
            if random.random() < recovery_probability:
                G.nodes[node]['state'] = 'R'
        if G.nodes[node]['state'] == 'I':
            G.nodes[node]['days_infected'] += 1
    for node in new_infections:
        G.nodes[node]['state'] = 'I'

# Run the simulation
for day in range(simulation_days):
    simulate_day(G)

# Collect results
states = {'S': 0, 'I': 0, 'R': 0}
for node in G.nodes():
    states[G.nodes[node]['state']] += 1

# Print results
print(f"Susceptible: {states['S']}")
print(f"Infected: {states['I']}")
print(f"Recovered: {states['R']}")

# Plot the network
color_map = {'S': 'blue', 'I': 'red', 'R': 'green'}
node_colors = [color_map[G.nodes[node]['state']] for node in G.nodes()]
pos = nx.spring_layout(G)
nx.draw(G, pos, node_color=node_colors, with_labels=False, node_size=30)
plt.show()
