# This script simulates the spread of COVID-19 using an SEIRHD model
# SEIRHD: Susceptible, Exposed, Infected, Recovered, Hospitalized, Deceased
# The Euler method is used for numerical integration

import numpy as np
import matplotlib.pyplot as plt

# Define parameters
N = 1000000  # Total population
beta = 0.3  # Transmission rate
sigma = 1/5.2  # Rate of progression from exposed to infected (1/incubation_period)
gamma = 1/2.9  # Recovery rate (1/infectious_period)
rho = 0.05  # Hospitalization rate
delta = 0.01  # Mortality rate
initial_infected = 1
initial_exposed = 5
initial_hospitalized = 0
initial_recovered = 0
initial_deceased = 0

# Initial number of susceptible individuals
initial_susceptible = N - initial_exposed - initial_infected - initial_hospitalized - initial_recovered - initial_deceased

# Time parameters
T = 160  # Total time in days
dt = 1  # Time step
t = np.linspace(0, T, int(T/dt) + 1)

# Initialize arrays
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))
H = np.zeros(len(t))
D = np.zeros(len(t))

# Initial conditions
S[0] = initial_susceptible
E[0] = initial_exposed
I[0] = initial_infected
R[0] = initial_recovered
H[0] = initial_hospitalized
D[0] = initial_deceased

# Euler method to solve the system of differential equations
for i in range(1, len(t)):
    dSdt = -beta * S[i-1] * I[i-1] / N
    dEdt = beta * S[i-1] * I[i-1] / N - sigma * E[i-1]
    dIdt = sigma * E[i-1] - gamma * I[i-1] - rho * I[i-1]
    dRdt = gamma * I[i-1]
    dHdt = rho * I[i-1] - delta * H[i-1]
    dDdt = delta * H[i-1]

    S[i] = S[i-1] + dSdt * dt
    E[i] = E[i-1] + dEdt * dt
    I[i] = I[i-1] + dIdt * dt
    R[i] = R[i-1] + dRdt * dt
    H[i] = H[i-1] + dHdt * dt
    D[i] = D[i-1] + dDdt * dt

# Plot results
plt.figure(figsize=(12, 8))
plt.plot(t, S, label="Susceptible")
plt.plot(t, E, label="Exposed")
plt.plot(t, I, label="Infected")
plt.plot(t, R, label="Recovered")
plt.plot(t, H, label="Hospitalized")
plt.plot(t, D, label="Deceased")
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.title('SEIRHD Model for COVID-19 Spread')
plt.legend()
plt.grid(True)
plt.show()
