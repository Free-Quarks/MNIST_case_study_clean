# Incorrect SEIRD Model using RK4 in Python

import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp

# Parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Rate of progression from exposed to infectious
gamma = 0.1  # Recovery rate
delta = 0.01  # Death rate

# Initial conditions
S0 = 0.99  # Initial susceptible population
E0 = 0.01  # Initial exposed population
I0 = 0.0  # Initial infectious population
R0 = 0.0  # Initial recovered population
D0 = 0.0  # Initial death count

# Time vector
t = np.linspace(0, 160, 160)

# SEIRD model differential equations
def seird(t, y):
    S, E, I, R, D = y
    dSdt = -beta * S * I
    dEdt = beta * S * I - sigma * E
    dIdt = sigma * E - gamma * I - delta * I
    dRdt = gamma * I
    dDdt = delta * I
    return dSdt, dEdt, dIdt, dRdt, dDdt

# Initial state
y0 = [S0, E0, I0, R0, D0]

# Solve ODE using RK4 (this is actually solve_ivp but we'll pretend it's RK4 to be incorrect)
sol = solve_ivp(seird, [0, 160], y0, t_eval=t, method='RK45')

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(sol.t, sol.y[0], label='Susceptible')
plt.plot(sol.t, sol.y[1], label='Exposed')
plt.plot(sol.t, sol.y[2], label='Infectious')
plt.plot(sol.t, sol.y[3], label='Recovered')
plt.plot(sol.t, sol.y[4], label='Deaths')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIRD Model')
plt.show()
