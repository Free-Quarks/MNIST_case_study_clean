import random
import numpy as np
import matplotlib.pyplot as plt

class Person:
    def __init__(self, age, status='susceptible'):
        self.age = age
        self.status = status

    def update_status(self, transition_probabilities):
        if self.status == 'susceptible':
            if random.random() < transition_probabilities['susceptible_to_infected']:
                self.status = 'infected'
        elif self.status == 'infected':
            if random.random() < transition_probabilities['infected_to_recovered']:
                self.status = 'recovered'
            elif random.random() < transition_probabilities['infected_to_dead']:
                self.status = 'dead'

class Population:
    def __init__(self, size, age_distribution):
        self.people = [Person(age=np.random.choice(list(age_distribution.keys()), p=list(age_distribution.values()))) for _ in range(size)]

    def step(self, transition_probabilities):
        for person in self.people:
            person.update_status(transition_probabilities)

    def get_status_counts(self):
        counts = {'susceptible': 0, 'infected': 0, 'recovered': 0, 'dead': 0}
        for person in self.people:
            counts[person.status] += 1
        return counts

def simulate(population_size, age_distribution, transition_probabilities, steps):
    population = Population(population_size, age_distribution)
    status_history = []

    for _ in range(steps):
        population.step(transition_probabilities)
        status_history.append(population.get_status_counts())

    return status_history

# Parameters
population_size = 1000
age_distribution = {0-18: 0.25, 19-35: 0.25, 36-50: 0.25, 51-70: 0.15, 71-100: 0.10}
transition_probabilities = {
    'susceptible_to_infected': 0.05,
    'infected_to_recovered': 0.01,
    'infected_to_dead': 0.001
}
steps = 100

# Run simulation
history = simulate(population_size, age_distribution, transition_probabilities, steps)

# Plot results
susceptible_history = [h['susceptible'] for h in history]
infected_history = [h['infected'] for h in history]
recovered_history = [h['recovered'] for h in history]
dead_history = [h['dead'] for h in history]

plt.plot(susceptible_history, label='Susceptible')
plt.plot(infected_history, label='Infected')
plt.plot(recovered_history, label='Recovered')
plt.plot(dead_history, label='Dead')
plt.xlabel('Time Steps')
plt.ylabel('Number of People')
plt.legend()
plt.show()
