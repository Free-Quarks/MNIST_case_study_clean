import numpy as np

# SEIRD model parameters
beta = 0.3  # infection rate
sigma = 1/5.2  # rate of progression from exposed to infected
gamma = 1/2.9  # recovery rate
mu = 0.01  # mortality rate
N = 1000  # total population

# Initial conditions
S0, E0, I0, R0, D0 = 999, 1, 0, 0, 0

# Time parameters
t = 160  # number of days
dt = 1  # time step

# Initialize arrays to store results
S = np.zeros(t)
E = np.zeros(t)
I = np.zeros(t)
R = np.zeros(t)
D = np.zeros(t)

# Set initial values
S[0], E[0], I[0], R[0], D[0] = S0, E0, I0, R0, D0

# Runge-Kutta 3rd order (RK3) method for solving ODEs
def rk3_step(S, E, I, R, D, dt):
    def derivs(S, E, I, R, D):
        dSdt = -beta * S * I / N
        dEdt = beta * S * I / N - sigma * E
        dIdt = sigma * E - gamma * I - mu * I
        dRdt = gamma * I
        dDdt = mu * I
        return dSdt, dEdt, dIdt, dRdt, dDdt
    
    k1 = derivs(S, E, I, R, D)
    k2 = derivs(S + 0.5 * dt * k1[0], E + 0.5 * dt * k1[1], I + 0.5 * dt * k1[2], R + 0.5 * dt * k1[3], D + 0.5 * dt * k1[4])
    k3 = derivs(S - dt * k1[0] + 2 * dt * k2[0], E - dt * k1[1] + 2 * dt * k2[1], I - dt * k1[2] + 2 * dt * k2[2], R - dt * k1[3] + 2 * dt * k2[3], D - dt * k1[4] + 2 * dt * k2[4])
    
    S_next = S + dt * (k1[0] + 4 * k2[0] + k3[0]) / 6
    E_next = E + dt * (k1[1] + 4 * k2[1] + k3[1]) / 6
    I_next = I + dt * (k1[2] + 4 * k2[2] + k3[2]) / 6
    R_next = R + dt * (k1[3] + 4 * k2[3] + k3[3]) / 6
    D_next = D + dt * (k1[4] + 4 * k2[4] + k3[4]) / 6
    
    return S_next, E_next, I_next, R_next, D_next

# Time-stepping loop
for i in range(1, t):
    S[i], E[i], I[i], R[i], D[i] = rk3_step(S[i-1], E[i-1], I[i-1], R[i-1], D[i-1], dt)

# Print the results
print('Susceptible:', S)
print('Exposed:', E)
print('Infected:', I)
print('Recovered:', R)
print('Deceased:', D)
