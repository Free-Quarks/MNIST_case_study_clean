import numpy as np
import networkx as nx
import matplotlib.pyplot as plt

# Parameters
population_size = 1000
initial_infected = 10
infection_probability = 0.03
recovery_probability = 0.1
sex_ratio = 0.5  # proportion of males

# Initialize population with sex stratification
population = np.random.choice(['M', 'F'], size=population_size, p=[sex_ratio, 1 - sex_ratio])

# Create a network
G = nx.erdos_renyi_graph(population_size, 0.1)

# Initialize states: 0 = Susceptible, 1 = Infected, 2 = Recovered
states = np.zeros(population_size, dtype=int)
infected_indices = np.random.choice(population_size, initial_infected, replace=False)
states[infected_indices] = 1

# Simulation function
def simulate_step(G, states, infection_probability, recovery_probability):
    new_states = states.copy()
    for node in G.nodes():
        if states[node] == 1:  # Infected
            if np.random.rand() < recovery_probability:
                new_states[node] = 2  # Recovered
            else:
                for neighbor in G.neighbors(node):
                    if states[neighbor] == 0 and np.random.rand() < infection_probability:
                        new_states[neighbor] = 1  # New infection
    return new_states

# Run simulation
time_steps = 50
history = [states.copy()]
for _ in range(time_steps):
    states = simulate_step(G, states, infection_probability, recovery_probability)
    history.append(states.copy())

# Plot results
def plot_results(history, population):
    susceptible_counts = [np.sum(h == 0) for h in history]
    infected_counts = [np.sum(h == 1) for h in history]
    recovered_counts = [np.sum(h == 2) for h in history]
    male_counts = [np.sum((h == 1) & (population == 'M')) for h in history]
    female_counts = [np.sum((h == 1) & (population == 'F')) for h in history]

    plt.figure(figsize=(12, 8))
    plt.plot(susceptible_counts, label='Susceptible')
    plt.plot(infected_counts, label='Infected')
    plt.plot(recovered_counts, label='Recovered')
    plt.plot(male_counts, label='Infected Males', linestyle='--')
    plt.plot(female_counts, label='Infected Females', linestyle='--')
    plt.xlabel('Time Step')
    plt.ylabel('Number of Individuals')
    plt.legend()
    plt.title('COVID-19 Simulation with Sex Stratification')
    plt.show()

plot_results(history, population)
