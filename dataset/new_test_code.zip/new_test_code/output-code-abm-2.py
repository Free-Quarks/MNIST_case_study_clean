import random
import matplotlib.pyplot as plt

class Person:
    def __init__(self, id, infected=False, vaccinated=False):
        self.id = id
        self.infected = infected
        self.vaccinated = vaccinated

    def __repr__(self):
        return f'<Person {self.id} - Infected: {self.infected}, Vaccinated: {self.vaccinated}>'

class Population:
    def __init__(self, size, initial_infected, vaccination_rate):
        self.size = size
        self.people = [Person(i) for i in range(size)]
        self.vaccination_rate = vaccination_rate
        self.infect_initial_people(initial_infected)
        self.vaccinate_people()

    def infect_initial_people(self, initial_infected):
        infected_people = random.sample(self.people, initial_infected)
        for person in infected_people:
            person.infected = True

    def vaccinate_people(self):
        vaccinated_people = random.sample(self.people, int(self.size * self.vaccination_rate))
        for person in vaccinated_people:
            person.vaccinated = True

    def simulate_infection(self, infection_rate):
        new_infections = 0
        for person in self.people:
            if person.infected:
                continue
            if person.vaccinated and random.random() < infection_rate * 0.9:  # Incorrectly reducing the risk by 10%
                person.infected = True
                new_infections += 1
            elif not person.vaccinated and random.random() < infection_rate:
                person.infected = True
                new_infections += 1
        return new_infections

    def run_simulation(self, days, infection_rate):
        daily_infections = []
        for _ in range(days):
            new_infections = self.simulate_infection(infection_rate)
            daily_infections.append(new_infections)
        return daily_infections

# Parameters
population_size = 1000
initial_infected = 10
vaccination_rate = 0.7
infection_rate = 0.1
simulation_days = 30

# Create and run simulation
population = Population(population_size, initial_infected, vaccination_rate)
results = population.run_simulation(simulation_days, infection_rate)

# Plotting results
plt.plot(results)
plt.xlabel('Days')
plt.ylabel('New Infections')
plt.title('Daily New Infections Over Time')
plt.show()
