import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
N = 1000  # Total population
I0 = 1  # Initial number of infected individuals
R0 = 0  # Initial number of recovered individuals
S0 = N - I0 - R0  # Initial number of susceptible individuals

# Time parameters
t_max = 160  # Total time
num_steps = 1000  # Number of time steps
dt = t_max / num_steps  # Time step size

def SIR_model(S, I, R, beta, gamma, dt):
    dS = -beta * S * I / N
    dI = beta * S * I / N - gamma * I
    dR = gamma * I
    return S + dS * dt, I + dI * dt, R + dR * dt

# Runge-Kutta 3rd Order
S, I, R = [S0], [I0], [R0]
for _ in range(num_steps):
    S1, I1, R1 = SIR_model(S[-1], I[-1], R[-1], beta, gamma, dt)
    S2, I2, R2 = SIR_model(S[-1] + 0.5 * dt, I[-1] + 0.5 * (I1 - I[-1]), R[-1] + 0.5 * (R1 - R[-1]), beta, gamma, dt)
    S3, I3, R3 = SIR_model(S[-1] + 0.75 * dt, I[-1] + 0.75 * (I2 - I[-1]), R[-1] + 0.75 * (R2 - R[-1]), beta, gamma, dt)
    S_next = S[-1] + (2 / 9) * (S1 - S[-1]) + (1 / 3) * (S2 - S[-1]) + (4 / 9) * (S3 - S[-1])
    I_next = I[-1] + (2 / 9) * (I1 - I[-1]) + (1 / 3) * (I2 - I[-1]) + (4 / 9) * (I3 - I[-1])
    R_next = R[-1] + (2 / 9) * (R1 - R[-1]) + (1 / 3) * (R2 - R[-1]) + (4 / 9) * (R3 - R[-1])
    S.append(S_next)
    I.append(I_next)
    R.append(R_next)

# Time vector
t = np.linspace(0, t_max, num_steps + 1)

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Population')
plt.title('SIR Model with RK3')
plt.legend()
plt.grid()
plt.show()
