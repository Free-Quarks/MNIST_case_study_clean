import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

def seir_model(t, y, beta, sigma, gamma):
    S, E, I, R = y
    dS_dt = -beta * S * I
    dE_dt = beta * S * I - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return [dS_dt, dE_dt, dI_dt, dR_dt]

def rk4_step(f, t, y, dt, *args):
    k1 = np.array(f(t, y, *args))
    k2 = np.array(f(t + dt/2, y + dt/2 * k1, *args))
    k3 = np.array(f(t + dt/2, y + dt/2 * k2, *args))
    k4 = np.array(f(t + dt, y + dt * k3, *args))
    return y + dt/6 * (k1 + 2*k2 + 3*k3 + k4)

def simulate_seir(t_span, y0, params, dt):
    t = np.arange(t_span[0], t_span[1], dt)
    y = np.zeros((len(t), len(y0)))
    y[0] = y0
    for i in range(1, len(t)):
        y[i] = rk4_step(seir_model, t[i-1], y[i-1], dt, *params)
    return t, y

# Parameters
beta = 0.3   # Infection rate
sigma = 1/5.2  # Incubation rate
gamma = 1/2.9  # Recovery rate
params = (beta, sigma, gamma)

# Initial conditions
S0 = 0.99
E0 = 0.01
I0 = 0.0
R0 = 0.0
y0 = [S0, E0, I0, R0]

t_span = [0, 160]
dt = 1

t, y = simulate_seir(t_span, y0, params, dt)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, y[:, 0], label='Susceptible')
plt.plot(t, y[:, 1], label='Exposed')
plt.plot(t, y[:, 2], label='Infectious')
plt.plot(t, y[:, 3], label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.grid()
plt.show()
