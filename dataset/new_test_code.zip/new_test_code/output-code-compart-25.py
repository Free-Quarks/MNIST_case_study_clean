# Incorrect SEIRHD model using RK4
import numpy as np
import matplotlib.pyplot as plt

def seirhd_model(y, t, beta, sigma, gamma, delta, alpha, mu):
    S, E, I, R, H, D = y
    dS_dt = -beta * S * I
    dE_dt = beta * S * I - sigma * E
    dI_dt = sigma * E - gamma * I - delta * I
    dR_dt = gamma * I - alpha * R
    dH_dt = delta * I - mu * H
    dD_dt = mu * H
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt, dH_dt, dD_dt])


def rk4_step(f, y, t, dt, *args):
    k1 = dt * f(y, t, *args)
    k2 = dt * f(y + 0.5 * k1, t + 0.5 * dt, *args)
    k3 = dt * f(y + 0.5 * k2, t + 0.5 * dt, *args)
    k4 = dt * f(y + k3, t + dt, *args)
    return y + (k1 + 2 * k2 + 2 * k3 + k4) / 6

# Initial conditions
S0 = 0.99
E0 = 0.01
I0 = 0.0
R0 = 0.0
H0 = 0.0
D0 = 0.0
y0 = np.array([S0, E0, I0, R0, H0, D0])

# Time vector
t = np.linspace(0, 160, 160)

# Parameters
beta = 0.3
sigma = 1/5.2
gamma = 1/2.3
delta = 0.1
alpha = 0.05
mu = 0.02

# Integrate the SEIRHD equations
dt = t[1] - t[0]
y = np.zeros((len(t), 6))
y[0, :] = y0

for i in range(1, len(t)):
    y[i, :] = rk4_step(seirhd_model, y[i-1, :], t[i-1], dt, beta, sigma, gamma, delta, alpha, mu)

S, E, I, R, H, D = y.T

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, H, label='Hospitalized')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.grid()
plt.show()
