# SEIRHD Model with RK3 (Runge-Kutta 3rd Order) Method

import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # infection rate
sigma = 1/5.2  # incubation rate (1/incubation period)
gamma = 1/12.39  # recovery rate (1/infectious period)
delta = 0.01  # death rate

# Initial number of individuals in each compartment
S0 = 999
E0 = 1
I0 = 0
R0 = 0
H0 = 0
D0 = 0

# Total population
N = S0 + E0 + I0 + R0 + H0 + D0

# Time parameters
t_start = 0
t_end = 160
dt = 0.1
t = np.arange(t_start, t_end + dt, dt)

# SEIRHD model differential equations
def deriv(SEIRHD, t, N, beta, sigma, gamma, delta):
    S, E, I, R, H, D = SEIRHD
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - delta * I
    dRdt = gamma * I
    dHdt = gamma * I
    dDdt = delta * I
    return np.array([dSdt, dEdt, dIdt, dRdt, dHdt, dDdt])

# Initialize compartments
SEIRHD = np.array([S0, E0, I0, R0, H0, D0])

# Function to apply the RK3 method

def rk3_step(f, y, t, dt):
    k1 = f(y, t, N, beta, sigma, gamma, delta)
    k2 = f(y + dt * k1 / 2, t + dt / 2, N, beta, sigma, gamma, delta)
    k3 = f(y - dt * k1 + 2 * dt * k2, t + dt, N, beta, sigma, gamma, delta)
    return y + dt * (k1 + 4 * k2 + k3) / 6

# Arrays to store the results
results = np.zeros((len(t), 6))
results[0] = SEIRHD

# Time-stepping using RK3
for i in range(1, len(t)):
    SEIRHD = rk3_step(deriv, SEIRHD, t[i-1], dt)
    results[i] = SEIRHD

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(t, results[:, 0], label='Susceptible')
plt.plot(t, results[:, 1], label='Exposed')
plt.plot(t, results[:, 2], label='Infectious')
plt.plot(t, results[:, 3], label='Recovered')
plt.plot(t, results[:, 4], label='Hospitalized')
plt.plot(t, results[:, 5], label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.title('SEIRHD Model Simulation')
plt.legend()
plt.grid()
plt.show()

