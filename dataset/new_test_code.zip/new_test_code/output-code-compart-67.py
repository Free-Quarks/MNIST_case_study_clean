import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SIDARTHE model
def sidarthe_model(y, t, alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E
    dSdt = -alpha * S * I / N - beta * S * D / N - gamma * S * A / N - delta * S * R / N
    dIdt = alpha * S * I / N + epsilon * D * I / N + zeta * A * I / N + eta * R * I / N - (lambda_ + beta + mu) * I
    dDdt = beta * S * D / N + epsilon * D * I / N + theta * A * D / N + eta * R * D / N - (lambda_ + gamma + nu) * D
    dAdt = gamma * S * A / N + zeta * A * I / N + theta * A * D / N + eta * R * A / N - (lambda_ + delta + tau) * A
    dRdt = delta * S * R / N + eta * R * I / N + eta * R * D / N + eta * R * A / N - (lambda_ + epsilon + mu) * R
    dTdt = lambda_ * (I + D + A + R) - (nu + tau + mu) * T
    dHdt = mu * (I + D + A + R + T)
    dEdt = nu * (I + D + A + R + T)
    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Initial conditions
S0 = 0.99
I0 = 0.01
D0 = 0.0
A0 = 0.0
R0 = 0.0
T0 = 0.0
H0 = 0.0
E0 = 0.0

# Total population
N = 1

# Initial number of infected and recovered individuals
initial_conditions = [S0, I0, D0, A0, R0, T0, H0, E0]

# Parameters
alpha = 0.1
beta = 0.05
gamma = 0.05
delta = 0.03
epsilon = 0.02
theta = 0.01
zeta = 0.01
eta = 0.01
mu = 0.01
nu = 0.01
tau = 0.01
lambda_ = 0.1

# Time points (in days)
t = np.linspace(0, 160, 160)

# Integrate the SIDARTHE equations over the time grid, t.
solution = odeint(sidarthe_model, initial_conditions, t, args=(alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_))
S, I, D, A, R, T, H, E = solution.T

# Plot the data
plt.figure(figsize=(10,6))
plt.plot(t, S, 'b', label='Susceptible')
plt.plot(t, I, 'r', label='Infected')
plt.plot(t, D, 'g', label='Diagnosed')
plt.plot(t, A, 'y', label='Ailing')
plt.plot(t, R, 'c', label='Recognized')
plt.plot(t, T, 'm', label='Threatened')
plt.plot(t, H, 'k', label='Healed')
plt.plot(t, E, 'orange', label='Extinct')
plt.xlabel('Time /days')
plt.ylabel('Number (proportion)')
plt.legend()
plt.title('SIDARTHE Model Simulation')
plt.show()
