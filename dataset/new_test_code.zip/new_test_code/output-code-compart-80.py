import numpy as np

class SIRModel:
    def __init__(self, beta, gamma, S0, I0, R0):
        self.beta = beta
        self.gamma = gamma
        self.S = S0
        self.I = I0
        self.R = R0

    def derivatives(self, S, I, R):
        dSdt = -self.beta * S * I
        dIdt = self.beta * S * I - self.gamma * I
        dRdt = self.gamma * I
        return dSdt, dIdt, dRdt

    def rk4_step(self, h):
        S, I, R = self.S, self.I, self.R
        k1_S, k1_I, k1_R = self.derivatives(S, I, R)
        k2_S, k2_I, k2_R = self.derivatives(S + h/2 * k1_S, I + h/2 * k1_I, R + h/2 * k1_R)
        k3_S, k3_I, k3_R = self.derivatives(S + h/2 * k2_S, I + h/2 * k2_I, R + h/2 * k2_R)
        k4_S, k4_I, k4_R = self.derivatives(S + h * k3_S, I + h * k3_I, R + h * k3_R)
        self.S += h/6 * (k1_S + 2*k2_S + 2*k3_S + k4_S)
        self.I += h/6 * (k1_I + 2*k2_I + 2*k3_I + k4_I)
        self.R += h/6 * (k1_R + 2*k2_R + 2*k3_R + k4_R)

    def run(self, steps, h):
        S_vals = [self.S]
        I_vals = [self.I]
        R_vals = [self.R]
        for _ in range(steps):
            self.rk4_step(h)
            S_vals.append(self.S)
            I_vals.append(self.I)
            R_vals.append(self.R)
        return S_vals, I_vals, R_vals

# Example usage
if __name__ == '__main__':
    beta = 0.3
    gamma = 0.1
    S0 = 0.99
    I0 = 0.01
    R0 = 0.0
    steps = 160
    h = 0.1
    model = SIRModel(beta, gamma, S0, I0, R0)
    S_vals, I_vals, R_vals = model.run(steps, h)
    print({'S': S_vals, 'I': I_vals, 'R': R_vals})

