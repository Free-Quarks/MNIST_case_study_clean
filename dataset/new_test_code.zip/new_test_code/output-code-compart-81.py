# SEIR Model using Euler's Method
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # infection rate
sigma = 0.1  # rate of progression from exposed to infected
gamma = 0.1  # recovery rate

# Initial conditions
S0 = 0.99  # initial proportion of susceptible individuals
E0 = 0.01  # initial proportion of exposed individuals
I0 = 0.0   # initial proportion of infected individuals
R0 = 0.0   # initial proportion of recovered individuals

# Total population (for simplicity, we consider it as 1)
N = 1.0

# Time parameters
T = 160  # total time
dt = 1.0  # time step

# Number of time steps
steps = int(T/dt)

# Initialize arrays to store results
S = np.zeros(steps)
E = np.zeros(steps)
I = np.zeros(steps)
R = np.zeros(steps)
t = np.linspace(0, T, steps)

# Set initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# Euler's Method to solve the SEIR model
for step in range(1, steps):
    dS = -beta * S[step-1] * I[step-1] * dt
    dE = (beta * S[step-1] * I[step-1] - sigma * E[step-1]) * dt
    dI = (sigma * E[step-1] - gamma * I[step-1]) * dt
    dR = gamma * I[step-1] * dt
    
    S[step] = S[step-1] + dS
    E[step] = E[step-1] + dE
    I[step] = I[step-1] + dI
    R[step] = R[step-1] + dR

# Plot the results
plt.figure(figsize=(10,6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of population')
plt.title('SEIR Model using Euler\'s Method')
plt.legend()
plt.grid()
plt.show()

