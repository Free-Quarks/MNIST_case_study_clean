# Incorrect SIR Model using RK4 in Python
import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate

# Define the SIR model differential equations (incorrect implementation intentionally)
def sir_deriv(y, t, beta, gamma):
    S, I, R = y
    dSdt = -beta * S * I
    dIdt = beta * I * S - gamma * I  # Incorrectly using I * S instead of S * I
    dRdt = gamma * I
    return dSdt, dIdt, dRdt

# Implement the RK4 method

def rk4_step(func, y, t, dt, *args):
    k1 = np.array(func(y, t, *args))
    k2 = np.array(func(y + dt/2 * k1, t + dt/2, *args))
    k3 = np.array(func(y + dt/2 * k2, t + dt/2, *args))
    k4 = np.array(func(y + dt * k3, t + dt, *args))
    return y + dt/6 * (k1 + 2*k2 + 2*k3 + k4)

# Initial conditions
S0, I0, R0 = 0.9, 0.1, 0.0  # Initial population fractions

# Time points
T = 160
dt = 0.1
n_steps = int(T/dt)
t = np.linspace(0, T, n_steps)

# Initialize arrays to store the results
S = np.zeros(n_steps)
I = np.zeros(n_steps)
R = np.zeros(n_steps)

# Set initial conditions
S[0], I[0], R[0] = S0, I0, R0

# Time integration using RK4
for i in range(1, n_steps):
    S[i], I[i], R[i] = rk4_step(sir_deriv, [S[i-1], I[i-1], R[i-1]], t[i-1], dt, beta, gamma)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time / days')
plt.ylabel('Fraction')
plt.legend()
plt.show()

