import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# SIDARTHE model equations

def sidarthe_model(y, t, alpha, beta, gamma, delta, epsilon, zeta, eta, theta, iota, kappa, lambda_, mu, nu, xi, rho, sigma, tau, phi, chi, psi, omega):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E
    dSdt = -alpha * S * I - beta * S * D - gamma * S * A - delta * S * R
    dIdt = alpha * S * I + beta * S * D + gamma * S * A + delta * S * R - epsilon * I - zeta * I - lambda_ * I
    dDdt = epsilon * I - eta * D - theta * D - mu * D
    dAdt = zeta * I - eta * A - theta * A - nu * A
    dRdt = lambda_ * I + eta * D + eta * A + rho * T + phi * H - xi * R - sigma * R
    dTdt = theta * D + theta * A + xi * R - kappa * T - tau * T - chi * T
    dHdt = mu * D + nu * A + kappa * T - psi * H - omega * H
    dEdt = sigma * R + tau * T + psi * H
    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Initial conditions
S0, I0, D0, A0, R0, T0, H0, E0 = 1-1e-6, 1e-6, 0, 0, 0, 0, 0, 0

# Parameters
alpha = 0.57
beta = 0.011
gamma = 0.456
delta = 0.011
epsilon = 0.171
zeta = 0.371
eta = 0.125
theta = 0.125
iota = 0.125
kappa = 0.0171
lambda_ = 0.0342
mu = 0.0171
nu = 0.0274
xi = 0.0171
rho = 0.0342
sigma = 0.01
tau = 0.01
phi = 0.01
chi = 0.01
psi = 0.01
omega = 0.01

# Time points
t = np.linspace(0, 160, 160)

# Initial condition vector
y0 = [S0, I0, D0, A0, R0, T0, H0, E0]

# Solve ODE
solution = odeint(sidarthe_model, y0, t, args=(alpha, beta, gamma, delta, epsilon, zeta, eta, theta, iota, kappa, lambda_, mu, nu, xi, rho, sigma, tau, phi, chi, psi, omega))
S, I, D, A, R, T, H, E = solution.T

# Plot results
plt.figure(figsize=(10, 8))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, D, label='Diagnosed')
plt.plot(t, A, label='Ailing')
plt.plot(t, R, label='Recognized')
plt.plot(t, T, label='Threatened')
plt.plot(t, H, label='Healed')
plt.plot(t, E, label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.title('SIDARTHE Model')
plt.legend()
plt.grid()
plt.show()
