# SEIRHD Model with RK3 Integration
import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Rate of progression from exposed to infectious (inverse of incubation period)
gamma = 1/2.3  # Recovery rate (inverse of infectious period)
delta = 0.01  # Mortality rate
rho = 0.05  # Hospitalization rate
alpha = 0.1  # Recovery rate from hospital

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
H0 = 0
D0 = 0

# Time parameters
days = 160

# Runge-Kutta 3rd order method (RK3)
def rk3_step(f, y, t, dt):
    k1 = f(y, t)
    k2 = f(y + dt/2 * k1, t + dt/2)
    k3 = f(y - dt * k1 + 2 * dt * k2, t + dt)
    return y + dt/6 * (k1 + 4 * k2 + k3)

# SEIRHD model
def seirhd_model(y, t):
    S, E, I, R, H, D = y
    N = S + E + I + R + H
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - delta * I - rho * I
    dRdt = gamma * I
    dHdt = rho * I - alpha * H
    dDdt = delta * I
    return np.array([dSdt, dEdt, dIdt, dRdt, dHdt, dDdt])

# Time array
t = np.linspace(0, days, days)

# Initial conditions vector
y0 = np.array([S0, E0, I0, R0, H0, D0])

# Storage for results
y = np.zeros((days, 6))
y[0, :] = y0

# Time-stepping with RK3
dt = t[1] - t[0]
for i in range(1, days):
    y[i, :] = rk3_step(seirhd_model, y[i-1, :], t[i-1], dt)

# Plotting results
labels = ['Susceptible', 'Exposed', 'Infectious', 'Recovered', 'Hospitalized', 'Dead']
for i in range(6):
    plt.plot(t, y[:, i], label=labels[i])

plt.xlabel('Days')
plt.ylabel('Number of individuals')
plt.legend()
plt.title('SEIRHD Model with RK3 Integration')
plt.show()

