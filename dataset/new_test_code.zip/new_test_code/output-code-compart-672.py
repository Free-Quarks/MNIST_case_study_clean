# Import necessary libraries
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SEIRHD model

def SEIRHD_model(y, t, beta, sigma, gamma, mu, delta, alpha):
    S, E, I, R, H, D = y
    N = S + E + I + R + H + D
    
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - (gamma + mu + delta) * I
    dRdt = gamma * I
    dHdt = delta * I - alpha * H
    dDdt = mu * I + alpha * H
    
    return [dSdt, dEdt, dIdt, dRdt, dHdt, dDdt]

# Total population, N.
N = 1000
# Initial number of infected and recovered individuals, I0 and R0.
I0 = 1
R0 = 0
H0 = 0
D0 = 0
# Everyone else, S0, is susceptible to infection initially.
S0 = N - I0 - R0 - H0 - D0
# Initial number of exposed individuals, E0.
E0 = 0
# Initial conditions vector
initial_conditions = [S0, E0, I0, R0, H0, D0]

# Contact rate, beta, incubation rate, sigma, mean recovery rate, gamma, death rate, mu, hospitalization rate, delta, and hospital death rate, alpha.
beta = 0.3
sigma = 1./5.2
gamma = 1./18
mu = 0.01
delta = 0.05
alpha = 0.02

# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# Integrate the SEIRHD equations over the time grid, t.
result = odeint(SEIRHD_model, initial_conditions, t, args=(beta, sigma, gamma, mu, delta, alpha))
S, E, I, R, H, D = result.T

# Plot the data
plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', label='Susceptible')
plt.plot(t, E, 'y', label='Exposed')
plt.plot(t, I, 'r', label='Infected')
plt.plot(t, R, 'g', label='Recovered')
plt.plot(t, H, 'purple', label='Hospitalized')
plt.plot(t, D, 'k', label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend(loc='best')
plt.title('SEIRHD Model')
plt.grid(True)
plt.show()
