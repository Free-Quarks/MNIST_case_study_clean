# Importing necessary libraries
import random
import matplotlib.pyplot as plt

# Define the Agent class
class Agent:
    def __init__(self, id, vaccinated, infected=False):
        self.id = id
        self.vaccinated = vaccinated
        self.infected = infected
        self.days_infected = 0

    def infect(self):
        if not self.vaccinated:
            self.infected = True

    def recover(self):
        self.infected = False
        self.days_infected = 0

# Simulation parameters
POPULATION_SIZE = 1000
INFECTION_PROBABILITY = 0.05
RECOVERY_DAYS = 14
VACCINATION_RATE = 0.7
INITIAL_INFECTED = 10
SIMULATION_DAYS = 100

# Initialize the population
population = []
for i in range(POPULATION_SIZE):
    vaccinated = random.random() < VACCINATION_RATE
    population.append(Agent(id=i, vaccinated=vaccinated))

# Infect initial agents
initial_infected_agents = random.sample(population, INITIAL_INFECTED)
for agent in initial_infected_agents:
    agent.infect()

# Record data for plotting
infected_counts = []
vaccinated_counts = []

# Run the simulation
for day in range(SIMULATION_DAYS):
    daily_infected = 0
    daily_vaccinated = 0

    for agent in population:
        if agent.infected:
            daily_infected += 1
            agent.days_infected += 1

            if agent.days_infected >= RECOVERY_DAYS:
                agent.recover()

            for other_agent in population:
                if other_agent.id != agent.id and not other_agent.infected:
                    if random.random() < INFECTION_PROBABILITY:
                        other_agent.infect()

        if agent.vaccinated:
            daily_vaccinated += 1

    infected_counts.append(daily_infected)
    vaccinated_counts.append(daily_vaccinated)

# Plot the results
plt.figure(figsize=(10, 5))
plt.plot(infected_counts, label='Infected')
plt.plot(vaccinated_counts, label='Vaccinated')
plt.xlabel('Day')
plt.ylabel('Count')
plt.title('COVID-19 Simulation')
plt.legend()
plt.show()

