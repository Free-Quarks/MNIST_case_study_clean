import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.3  # infection rate
sigma = 1/5.2  # incubation rate
gamma = 1/2.9  # recovery rate
mu = 0.01  # mortality rate
N = 1000  # total population

# Initial conditions
S0 = 999
E0 = 0
I0 = 1
R0 = 0
H0 = 0
D0 = 0

# Time points (days)
t = np.linspace(0, 160, 160)

# SEIRHD model differential equations
def deriv(y, t, N, beta, sigma, gamma, mu):
    S, E, I, R, H, D = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - (1-gamma - mu) * I
    dRdt = gamma * I
    dHdt = mu * I
    dDdt = mu * H
    return dSdt, dEdt, dIdt, dRdt, dHdt, dDdt

# Runge-Kutta 3rd order method (RK3)

def rk3_step(y, t, dt, deriv, N, beta, sigma, gamma, mu):
    k1 = np.array(deriv(y, t, N, beta, sigma, gamma, mu))
    k2 = np.array(deriv(y + dt/2 * k1, t + dt/2, N, beta, sigma, gamma, mu))
    k3 = np.array(deriv(y - dt * k1 + 2 * dt * k2, t + dt, N, beta, sigma, gamma, mu))
    return y + dt * (k1 + 4 * k2 + k3) / 6

# Initial conditions vector
y0 = S0, E0, I0, R0, H0, D0

# Integrate the SEIRHD equations over the time grid, t.
ret = np.zeros((len(t), 6))
ret[0] = y0

dt = t[1] - t[0]

for i in range(1, len(t)):
    ret[i] = rk3_step(ret[i-1], t[i-1], dt, deriv, N, beta, sigma, gamma, mu)

S, E, I, R, H, D = ret.T

# Plot the data
fig = plt.figure(figsize=(10, 6))
plt.plot(t, S/N, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, E/N, 'y', alpha=0.7, linewidth=2, label='Exposed')
plt.plot(t, I/N, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, R/N, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.plot(t, H/N, 'c', alpha=0.7, linewidth=2, label='Hospitalized')
plt.plot(t, D/N, 'k', alpha=0.7, linewidth=2, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Fraction of population')
plt.legend()
plt.grid(True)
plt.show()
