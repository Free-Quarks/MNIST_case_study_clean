import numpy as np

# SEIRD Model Parameters
beta = 0.3    # Infection rate
sigma = 1/5.2  # Incubation rate
gamma = 1/2.9  # Recovery rate
delta = 0.01  # Death rate

# Initial Population
S0 = 990
E0 = 10
I0 = 0
R0 = 0
D0 = 0
N = S0 + E0 + I0 + R0 + D0  # Total population

# Time Parameters
t0 = 0
t_end = 160
dt = 1

# Time Vector
t = np.arange(t0, t_end + dt, dt)

# Initialize compartments
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))
D = np.zeros(len(t))

# Set initial values
S[0], E[0], I[0], R[0], D[0] = S0, E0, I0, R0, D0

# Runge-Kutta 3rd Order Method
for i in range(1, len(t)):
    k1S = -beta * S[i-1] * I[i-1] / N
    k1E = beta * S[i-1] * I[i-1] / N - sigma * E[i-1]
    k1I = sigma * E[i-1] - gamma * I[i-1] - delta * I[i-1]
    k1R = gamma * I[i-1]
    k1D = delta * I[i-1]

    S1 = S[i-1] + k1S * dt
    E1 = E[i-1] + k1E * dt
    I1 = I[i-1] + k1I * dt
    R1 = R[i-1] + k1R * dt
    D1 = D[i-1] + k1D * dt

    k2S = -beta * S1 * I1 / N
    k2E = beta * S1 * I1 / N - sigma * E1
    k2I = sigma * E1 - gamma * I1 - delta * I1
    k2R = gamma * I1
    k2D = delta * I1

    S2 = S[i-1] + 0.75 * k2S * dt
    E2 = E[i-1] + 0.75 * k2E * dt
    I2 = I[i-1] + 0.75 * k2I * dt
    R2 = R[i-1] + 0.75 * k2R * dt
    D2 = D[i-1] + 0.75 * k2D * dt

    k3S = -beta * S2 * I2 / N
    k3E = beta * S2 * I2 / N - sigma * E2
    k3I = sigma * E2 - gamma * I2 - delta * I2
    k3R = gamma * I2
    k3D = delta * I2

    S[i] = S[i-1] + (2/9 * k1S + 1/3 * k2S + 4/9 * k3S) * dt
    E[i] = E[i-1] + (2/9 * k1E + 1/3 * k2E + 4/9 * k3E) * dt
    I[i] = I[i-1] + (2/9 * k1I + 1/3 * k2I + 4/9 * k3I) * dt
    R[i] = R[i-1] + (2/9 * k1R + 1/3 * k2R + 4/9 * k3R) * dt
    D[i] = D[i-1] + (2/9 * k1D + 1/3 * k2D + 4/9 * k3D) * dt

# Output results
results = {
    'time': t.tolist(),
    'S': S.tolist(),
    'E': E.tolist(),
    'I': I.tolist(),
    'R': R.tolist(),
    'D': D.tolist()
}

import json
print(json.dumps(results, indent=4))
