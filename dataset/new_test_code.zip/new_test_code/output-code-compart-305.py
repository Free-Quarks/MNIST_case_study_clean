import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp

# Define the system of differential equations for SIR model

def SIR_model(t, y, beta, gamma):
    S, I, R = y
    dS_dt = -beta * S * I
    dI_dt = beta * S * I - gamma * I
    dR_dt = gamma * I
    return [dS_dt, dI_dt, dR_dt]

# Define the parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate

# Initial conditions: 99% susceptible, 1% infected, 0% recovered
S0 = 0.99
I0 = 0.01
R0 = 0.0

# Time points where solution is computed
t = np.linspace(0, 160, 160)

# Solve the system of differential equations using RK4
sol = solve_ivp(SIR_model, [t[0], t[-1]], [S0, I0, R0], args=(beta, gamma), t_eval=t, method='RK45')

# Extract the results
S, I, R = sol.y

# Plot the results
plt.figure(figsize=(10,6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SIR Model Simulation')
plt.grid(True)
plt.show()
