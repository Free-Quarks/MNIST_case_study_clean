# SEIRHD Compartmental Model using odeint
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SEIRHD model

def seirhd_model(y, t, beta, sigma, gamma, delta, mu):
    S, E, I, R, H, D = y
    N = S + E + I + R + H + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - delta * I
    dRdt = gamma * I
    dHdt = delta * I - mu * H
    dDdt = mu * H
    return [dSdt, dEdt, dIdt, dRdt, dHdt, dDdt]

# Initial conditions
N = 1000  # Total population
E0 = 1    # Initial number of exposed individuals
I0 = 0    # Initial number of infectious individuals
R0 = 0    # Initial number of recovered individuals
H0 = 0    # Initial number of hospitalized individuals
D0 = 0    # Initial number of dead individuals
S0 = N - E0 - I0 - R0 - H0 - D0  # Initial number of susceptible individuals

# Initial condition vector
y0 = [S0, E0, I0, R0, H0, D0]

# Contact rate, incubation rate, recovery rate, hospitalization rate, mortality rate
beta = 0.3  # Contact rate
sigma = 1/5.2  # Incubation rate
gamma = 1/12.39  # Recovery rate
delta = 1/9  # Hospitalization rate
mu = 1/7  # Mortality rate

# Time grid
t = np.linspace(0, 160, 160)

# Integrate the SEIRHD equations over the time grid, t
ret = odeint(seirhd_model, y0, t, args=(beta, sigma, gamma, delta, mu))
S, E, I, R, H, D = ret.T

# Plot the data
fig = plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infectious')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.plot(t, H, 'm', alpha=0.7, linewidth=2, label='Hospitalized')
plt.plot(t, D, 'k', alpha=0.7, linewidth=2, label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.grid(True)
plt.title('SEIRHD Model')
plt.show()

