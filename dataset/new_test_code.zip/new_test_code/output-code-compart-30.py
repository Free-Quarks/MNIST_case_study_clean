# SIR model with RK4 method in Python
import numpy as np
import matplotlib.pyplot as plt

# Define the SIR model equations
def sir_model(y, beta, gamma):
    S, I, R = y
    dS_dt = -beta * S * I
    dI_dt = beta * S * I - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dI_dt, dR_dt])

# Runge-Kutta 4th Order method
def rk4_step(f, y, t, dt, *args):
    k1 = dt * f(y, *args)
    k2 = dt * f(y + 0.5 * k1, *args)
    k3 = dt * f(y + 0.5 * k2, *args)
    k4 = dt * f(y + k3, *args)
    return y + (k1 + 2 * k2 + 2 * k3 + k4) / 6

# Simulation parameters
beta = 0.3  # infection rate
gamma = 0.1  # recovery rate
S0 = 0.99  # initial susceptible fraction
I0 = 0.01  # initial infected fraction
R0 = 0.0  # initial recovered fraction

T = 160  # total time
dt = 0.1  # time step

# Time points
t = np.arange(0, T, dt)

# Initialize arrays to store results
S = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

# Initial conditions
S[0], I[0], R[0] = S0, I0, R0

# Run the simulation
for i in range(1, len(t)):
    S[i], I[i], R[i] = rk4_step(sir_model, [S[i-1], I[i-1], R[i-1]], t[i-1], dt, beta, gamma)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible', color='blue')
plt.plot(t, I, label='Infected', color='red')
plt.plot(t, R, label='Recovered', color='green')
plt.xlabel('Time')
plt.ylabel('Fraction of Population')
plt.legend()
plt.title('SIR Model with RK4 Method')
plt.grid()
plt.show()
