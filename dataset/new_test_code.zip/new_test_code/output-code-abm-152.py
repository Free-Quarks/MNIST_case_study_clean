# Import necessary libraries
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

# Define parameters
N = 1000  # Total population
initial_infected = 10  # Initial number of infected individuals
beta = 0.3  # Transmission rate
gamma = 0.1  # Recovery rate
sex_ratio = 0.5  # Proportion of males in the population

time_steps = 160  # Number of time steps to simulate

# Create a graph
G = nx.erdos_renyi_graph(N, p=0.1)

# Assign sex to each node
sex = np.random.choice(['Male', 'Female'], size=N, p=[sex_ratio, 1 - sex_ratio])
nx.set_node_attributes(G, dict(enumerate(sex)), 'sex')

# Initialize the status of each individual
status = {i: 'Susceptible' for i in range(N)}
initial_infected_indices = np.random.choice(range(N), size=initial_infected, replace=False)
for idx in initial_infected_indices:
    status[idx] = 'Infected'
nx.set_node_attributes(G, status, 'status')

# Function to update the status of each node

def update_status(G):
    new_status = nx.get_node_attributes(G, 'status').copy()
    for node in G.nodes():
        if G.nodes[node]['status'] == 'Infected':
            if np.random.rand() < gamma:
                new_status[node] = 'Recovered'
            else:
                for neighbor in G.neighbors(node):
                    if G.nodes[neighbor]['status'] == 'Susceptible':
                        if np.random.rand() < beta:
                            new_status[neighbor] = 'Infected'
    nx.set_node_attributes(G, new_status, 'status')

# Simulate the epidemic

time_series = []
for t in range(time_steps):
    update_status(G)
    status_count = {'Susceptible': 0, 'Infected': 0, 'Recovered': 0}
    for node in G.nodes():
        status_count[G.nodes[node]['status']] += 1
    time_series.append(status_count)

# Plot the results

time_series = np.array([[status_count['Susceptible'], status_count['Infected'], status_count['Recovered']] for status_count in time_series])
plt.figure(figsize=(10, 6))
plt.plot(time_series[:, 0], label='Susceptible')
plt.plot(time_series[:, 1], label='Infected')
plt.plot(time_series[:, 2], label='Recovered')
plt.xlabel('Time Steps')
plt.ylabel('Number of Individuals')
plt.legend()
plt.title('Simulation of COVID-19 Epidemic')
plt.show()
