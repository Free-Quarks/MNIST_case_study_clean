import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint

# SIDARTHE model parameters
alpha, beta, gamma, delta = 0.5, 0.2, 0.1, 0.05
epsilon, zeta, eta, theta = 0.1, 0.1, 0.1, 0.1
mu, nu, tau, lambda_ = 0.1, 0.1, 0.1, 0.1

# Initial conditions
S0 = 0.99
I0 = 0.01
D0, A0, R0, T0, H0, E0 = 0, 0, 0, 0, 0, 0

y0 = [S0, I0, D0, A0, R0, T0, H0, E0]

# Time vector
t = np.linspace(0, 100, 101)

# SIDARTHE model differential equations
def deriv(y, t, alpha, beta, gamma, delta, epsilon, zeta, eta, theta, mu, nu, tau, lambda_):
    S, I, D, A, R, T, H, E = y
    dSdt = -alpha * S * I - beta * S * D - gamma * S * A - delta * S * R
    dIdt = alpha * S * I + beta * S * D + gamma * S * A + delta * S * R - epsilon * I - zeta * I - eta * I
    dDdt = epsilon * I + nu * T - zeta * D - theta * D
    dAdt = eta * I - theta * A - mu * A
    dRdt = zeta * I + theta * D + mu * A - nu * R - tau * R
    dTdt = nu * R - lambda_ * T
    dHdt = nu * T - lambda_ * H
    dEdt = lambda_ * T + lambda_ * H
    return dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt

# RK2 method for solving ODEs
def rk2(f, y0, t, args):
    dt = t[1] - t[0]
    y = np.zeros((len(t), len(y0)))
    y[0] = y0
    for i in range(1, len(t)):
        k1 = f(y[i-1], t[i-1], *args)
        y_mid = y[i-1] + np.array(k1) * dt / 2.0
        k2 = f(y_mid, t[i-1] + dt / 2.0, *args)
        y[i] = y[i-1] + np.array(k2) * dt
    return y

# Solving the SIDARTHE model
y = rk2(deriv, y0, t, (alpha, beta, gamma, delta, epsilon, zeta, eta, theta, mu, nu, tau, lambda_))

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(t, y[:, 0], label='Susceptible')
plt.plot(t, y[:, 1], label='Infected')
plt.plot(t, y[:, 2], label='Diagnosed')
plt.plot(t, y[:, 3], label='Ailing')
plt.plot(t, y[:, 4], label='Recognized')
plt.plot(t, y[:, 5], label='Threatened')
plt.plot(t, y[:, 6], label='Healed')
plt.plot(t, y[:, 7], label='Extinct')
plt.xlabel('Time / days')
plt.ylabel('Fraction')
plt.legend()
plt.title('SIDARTHE Model with RK2')
plt.show()
