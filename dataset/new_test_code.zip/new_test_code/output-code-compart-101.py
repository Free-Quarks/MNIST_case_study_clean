# Incorrect SIR model using Euler's method
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
S0 = 0.9  # Initial susceptible population
I0 = 0.1  # Initial infected population
R0 = 0.0  # Initial recovered population

# Time parameters
T = 160  # Total time
dt = 1.0  # Time step

# Time array
num_steps = int(T/dt)
t = np.linspace(0, T, num_steps)

# Initialize arrays
S = np.zeros(num_steps)
I = np.zeros(num_steps)
R = np.zeros(num_steps)

# Initial conditions
S[0] = S0
I[0] = I0
R[0] = R0

# Euler's method
for i in range(num_steps-1):
    dS = -beta * S[i] * I[i] * dt
    dI = (beta * S[i] * I[i] + gamma * I[i]) * dt  # Incorrect term
    dR = gamma * I[i] * dt
    
    S[i+1] = S[i] + dS
    I[i+1] = I[i] + dI
    R[i+1] = R[i] + dR

# Plotting results
plt.figure(figsize=(10,6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.title('Incorrect SIR Model using Euler\'s Method')
plt.show()

