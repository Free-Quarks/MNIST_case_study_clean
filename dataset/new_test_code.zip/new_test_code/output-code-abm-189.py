import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

# Parameters
population_size = 1000
initial_infected = 10
transmission_prob = 0.05
recovery_prob = 0.01
strata = ['young', 'adult', 'senior']
strata_distribution = [0.4, 0.5, 0.1]

# Initialize Network
G = nx.erdos_renyi_graph(population_size, 0.1)

# Assign strata to nodes
strata_assignments = np.random.choice(strata, population_size, p=strata_distribution)
for i, node in enumerate(G.nodes()):
    G.nodes[node]['strata'] = strata_assignments[i]
    G.nodes[node]['state'] = 'susceptible'

# Initial Infection
initial_infected_nodes = np.random.choice(G.nodes(), initial_infected, replace=False)
for node in initial_infected_nodes:
    G.nodes[node]['state'] = 'infected'

# Simulation Function
def simulate_step(G):
    new_infected = []
    new_recovered = []
    for node in G.nodes():
        if G.nodes[node]['state'] == 'infected':
            if np.random.rand() < recovery_prob:
                new_recovered.append(node)
            else:
                for neighbor in G.neighbors(node):
                    if G.nodes[neighbor]['state'] == 'susceptible' and np.random.rand() < transmission_prob:
                        new_infected.append(neighbor)
    for node in new_infected:
        G.nodes[node]['state'] = 'infected'
    for node in new_recovered:
        G.nodes[node]['state'] = 'recovered'

# Run Simulation
steps = 100
data = {'susceptible': [], 'infected': [], 'recovered': []}
for step in range(steps):
    simulate_step(G)
    susceptible_count = sum(1 for node in G.nodes if G.nodes[node]['state'] == 'susceptible')
    infected_count = sum(1 for node in G.nodes if G.nodes[node]['state'] == 'infected')
    recovered_count = sum(1 for node in G.nodes if G.nodes[node]['state'] == 'recovered')
    data['susceptible'].append(susceptible_count)
    data['infected'].append(infected_count)
    data['recovered'].append(recovered_count)

# Plot Results
plt.figure(figsize=(10, 6))
plt.plot(data['susceptible'], label='Susceptible')
plt.plot(data['infected'], label='Infected')
plt.plot(data['recovered'], label='Recovered')
plt.xlabel('Steps')
plt.ylabel('Number of Individuals')
plt.legend()
plt.show()
