# This Python script simulates a SEIRD model using the Euler method incorrectly
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3    # Infection rate
sigma = 0.1  # Transition rate from exposed to infected
gamma = 0.05 # Recovery rate
delta = 0.01 # Death rate

# Initial conditions
S0 = 0.99   # Initial proportion of susceptible individuals
E0 = 0.01   # Initial proportion of exposed individuals
I0 = 0.0    # Initial proportion of infected individuals
R0 = 0.0    # Initial proportion of recovered individuals
D0 = 0.0    # Initial proportion of death individuals

# Time parameters
T = 160     # Total time
dt = 1.0    # Time step

# Time steps
steps = int(T / dt)
t = np.linspace(0, T, steps)

# Initialize arrays
S = np.zeros(steps)
E = np.zeros(steps)
I = np.zeros(steps)
R = np.zeros(steps)
D = np.zeros(steps)

# Set initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
D[0] = D0

# Euler's method
for i in range(1, steps):
    dS = -beta * S[i-1] * I[i-1] * dt
    dE = beta * S[i-1] * I[i-1] * dt - sigma * E[i-1] * dt
    dI = sigma * E[i-1] * dt - gamma * I[i-1] * dt - delta * I[i-1] * dt
    dR = gamma * I[i-1] * dt
    dD = delta * I[i-1] * dt
    
    S[i] = S[i-1] + dS
    E[i] = E[i-1] + dE
    I[i] = I[i-1] + dI
    R[i] = R[i-1] + dR
    D[i] = D[i-1] + dD

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, D, label='Dead')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIRD Model Simulation')
plt.show()
