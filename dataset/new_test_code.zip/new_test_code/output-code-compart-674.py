# SEIRHD Model with RK3
import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Rate of progression from exposed to infectious
gamma = 1/14  # Recovery rate
h_rate = 0.05  # Hospitalization rate
d_rate = 0.01  # Death rate

# Initial conditions
S0 = 990
E0 = 10
I0 = 0
R0 = 0
H0 = 0
D0 = 0

# Time parameters
t_max = 160
dt = 0.1
n_steps = int(t_max / dt)

t = np.linspace(0, t_max, n_steps)

# Initialize arrays to store results
S = np.zeros(n_steps)
E = np.zeros(n_steps)
I = np.zeros(n_steps)
R = np.zeros(n_steps)
H = np.zeros(n_steps)
D = np.zeros(n_steps)

# Set initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
H[0] = H0
D[0] = D0

# Define the SEIRHD model
def seirhd_model(y, t, beta, sigma, gamma, h_rate, d_rate):
    S, E, I, R, H, D = y
    N = S + E + I + R + H + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - h_rate * I - d_rate * I
    dRdt = gamma * I
    dHdt = h_rate * I
    dDdt = d_rate * I
    return np.array([dSdt, dEdt, dIdt, dRdt, dHdt, dDdt])

# Runge-Kutta 3rd order method (RK3)
def rk3_step(y, t, dt, model, *args):
    k1 = dt * model(y, t, *args)
    k2 = dt * model(y + 0.5 * k1, t + 0.5 * dt, *args)
    k3 = dt * model(y - k1 + 2 * k2, t + dt, *args)
    return y + (k1 + 4 * k2 + k3) / 6

# Simulate the model
for i in range(1, n_steps):
    y = np.array([S[i-1], E[i-1], I[i-1], R[i-1], H[i-1], D[i-1]])
    y_next = rk3_step(y, t[i-1], dt, seirhd_model, beta, sigma, gamma, h_rate, d_rate)
    S[i], E[i], I[i], R[i], H[i], D[i] = y_next

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.plot(t, H, label='Hospitalized')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRHD Model Simulation using RK3')
plt.show()

