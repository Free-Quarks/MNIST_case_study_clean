# Import necessary libraries
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

# Define parameters
num_nodes = 1000  # Total population size
initial_infected = 10  # Initial number of infected individuals
initial_vaccinated = 200  # Initial number of vaccinated individuals
infection_rate = 0.05  # Probability of infection per contact
recovery_rate = 0.01  # Probability of recovery per time step
vaccination_rate = 0.02  # Probability of vaccination per time step

# Initialize the network
G = nx.erdos_renyi_graph(num_nodes, 0.1)

# Initialize the status of the nodes
status = {node: 'S' for node in G.nodes()}

# Infect initial nodes
infected_nodes = np.random.choice(G.nodes(), initial_infected, replace=False)
for node in infected_nodes:
    status[node] = 'I'

# Vaccinate initial nodes
vaccinated_nodes = np.random.choice(G.nodes(), initial_vaccinated, replace=False)
for node in vaccinated_nodes:
    if status[node] == 'S':
        status[node] = 'V'

# Simulation function
def simulate_covid(G, status, infection_rate, recovery_rate, vaccination_rate, steps):
    for step in range(steps):
        new_status = status.copy()

        # Process each node
        for node in G.nodes():
            if status[node] == 'I':
                # Recovery step
                if np.random.rand() < recovery_rate:
                    new_status[node] = 'R'

                # Infection step
                for neighbor in G.neighbors(node):
                    if status[neighbor] == 'S' and np.random.rand() < infection_rate:
                        new_status[neighbor] = 'I'
            elif status[node] == 'S':
                # Vaccination step
                if np.random.rand() < vaccination_rate:
                    new_status[node] = 'V'

        status = new_status

    return status

# Run the simulation
final_status = simulate_covid(G, status, infection_rate, recovery_rate, vaccination_rate, 100)

# Count the final numbers of each status
counts = {"S": 0, "I": 0, "R": 0, "V": 0}
for node_status in final_status.values():
    counts[node_status] += 1

print(counts)

# Plot the final status of the network
color_map = []
for node in G:
    if final_status[node] == 'S':
        color_map.append('blue')
    elif final_status[node] == 'I':
        color_map.append('red')
    elif final_status[node] == 'R':
        color_map.append('green')
    elif final_status[node] == 'V':
        color_map.append('yellow')

nx.draw(G, node_color=color_map, with_labels=True)
plt.show()

