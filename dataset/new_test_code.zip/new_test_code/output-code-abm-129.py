import random

class Person:
    def __init__(self, age_group):
        self.age_group = age_group
        self.infected = False

    def infect(self):
        self.infected = True

class CovidSimulation:
    def __init__(self, population_size):
        self.population = []
        self.create_population(population_size)

    def create_population(self, population_size):
        age_groups = ['child', 'adult', 'senior']
        for _ in range(population_size):
            age_group = random.choice(age_groups)
            self.population.append(Person(age_group))

    def run_simulation(self, initial_infection_rate):
        # Incorrectly infect people based solely on initial infection rate
        for person in self.population:
            if random.random() < initial_infection_rate:
                person.infect()

    def get_infection_stats(self):
        stats = {'child': 0, 'adult': 0, 'senior': 0}
        for person in self.population:
            if person.infected:
                stats[person.age_group] += 1
        return stats

if __name__ == '__main__':
    simulation = CovidSimulation(population_size=1000)
    simulation.run_simulation(initial_infection_rate=0.1)
    print(simulation.get_infection_stats())
