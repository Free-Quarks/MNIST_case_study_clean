import numpy as np
import matplotlib.pyplot as plt

class SEIRDModel:
    def __init__(self, S0, E0, I0, R0, D0, beta, sigma, gamma, mu, days):
        self.S = [S0]
        self.E = [E0]
        self.I = [I0]
        self.R = [R0]
        self.D = [D0]
        self.beta = beta
        self.sigma = sigma
        self.gamma = gamma
        self.mu = mu
        self.days = days

    def deriv(self, S, E, I, R, D, beta, sigma, gamma, mu):
        N = S + E + I + R + D
        dSdt = -beta * S * I / N
        dEdt = beta * S * I / N - sigma * E
        dIdt = sigma * E - gamma * I - mu * I
        dRdt = gamma * I
        dDdt = mu * I
        return dSdt, dEdt, dIdt, dRdt, dDdt

    def runge_kutta_step(self, S, E, I, R, D, h):
        k1 = self.deriv(S, E, I, R, D, self.beta, self.sigma, self.gamma, self.mu)
        k2 = self.deriv(S + h * k1[0] / 2, E + h * k1[1] / 2, I + h * k1[2] / 2, R + h * k1[3] / 2, D + h * k1[4] / 2, self.beta, self.sigma, self.gamma, self.mu)
        S_next = S + h * k2[0]
        E_next = E + h * k2[1]
        I_next = I + h * k2[2]
        R_next = R + h * k2[3]
        D_next = D + h * k2[4]
        return S_next, E_next, I_next, R_next, D_next

    def simulate(self):
        for day in range(1, self.days + 1):
            S_next, E_next, I_next, R_next, D_next = self.runge_kutta_step(self.S[-1], self.E[-1], self.I[-1], self.R[-1], self.D[-1], 1)
            self.S.append(S_next)
            self.E.append(E_next)
            self.I.append(I_next)
            self.R.append(R_next)
            self.D.append(D_next)
        return np.array(self.S), np.array(self.E), np.array(self.I), np.array(self.R), np.array(self.D)

# Parameters
S0 = 9990
E0 = 10
I0 = 0
R0 = 0
D0 = 0
beta = 0.3
sigma = 1/5.1
gamma = 1/12.5
mu = 0.01

# Number of days to simulate
days = 160

# Create and run the model
model = SEIRDModel(S0, E0, I0, R0, D0, beta, sigma, gamma, mu, days)
S, E, I, R, D = model.simulate()

# Plot results
plt.figure(figsize=(10,6))
plt.plot(S, label='Susceptible')
plt.plot(E, label='Exposed')
plt.plot(I, label='Infected')
plt.plot(R, label='Recovered')
plt.plot(D, label='Deceased')
plt.xlabel('Days')
plt.ylabel('Population')
plt.title('SEIRD Model Simulation')
plt.legend()
plt.show()
