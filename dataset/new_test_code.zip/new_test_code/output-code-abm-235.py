import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

class Agent:
    def __init__(self, age_group):
        self.age_group = age_group
        self.infected = False
        self.days_infected = 0

    def infect(self):
        self.infected = True
        self.days_infected = 0

    def recover(self):
        self.infected = False
        self.days_infected = 0

    def update(self):
        if self.infected:
            self.days_infected += 1
            if self.days_infected > 14:  # assume recovery in 14 days
                self.recover()

class CovidSimulation:
    def __init__(self, num_agents, ages_distribution):
        self.agents = []
        for age_group, proportion in ages_distribution.items():
            n = int(num_agents * proportion)
            self.agents.extend([Agent(age_group) for _ in range(n)])
        self.num_agents = num_agents

    def initial_infection(self, initial_infected):
        initially_infected_agents = np.random.choice(self.agents, initial_infected, replace=False)
        for agent in initially_infected_agents:
            agent.infect()

    def step(self):
        new_infections = 0
        for agent in self.agents:
            if agent.infected:
                for other_agent in np.random.choice(self.agents, 10):  # each infected agent contacts 10 others
                    if not other_agent.infected:
                        other_agent.infect()
                        new_infections += 1
            agent.update()
        return new_infections

    def run(self, steps):
        daily_infections = []
        for _ in range(steps):
            daily_infections.append(self.step())
        return daily_infections

# Parameters
total_agents = 1000
age_distribution = {'0-19': 0.2, '20-39': 0.3, '40-59': 0.3, '60+': 0.2}
initial_infected = 10
simulation_steps = 50

# Initialize and run the simulation
simulation = CovidSimulation(total_agents, age_distribution)
simulation.initial_infection(initial_infected)
daily_infections = simulation.run(simulation_steps)

# Plotting results
plt.plot(daily_infections)
plt.xlabel('Day')
plt.ylabel('New Infections')
plt.title('Daily New Infections Over Time')
plt.show()
