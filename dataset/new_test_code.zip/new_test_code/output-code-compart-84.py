import numpy as np
import matplotlib.pyplot as plt

# SEIR Model Parameters
beta = 0.3    # Infection rate
sigma = 0.1   # Rate of progression from exposed to infected
gamma = 0.1   # Recovery rate

# Initial Conditions
S0 = 0.99     # Initial proportion of susceptible individuals
E0 = 0.01     # Initial proportion of exposed individuals
I0 = 0.0      # Initial proportion of infected individuals
R0 = 0.0      # Initial proportion of recovered individuals

# Time parameters
t_max = 160    # Total time
dt = 0.1      # Time step

# Number of steps
n_steps = int(t_max / dt)

# Arrays to store the results
S = np.zeros(n_steps)
E = np.zeros(n_steps)
I = np.zeros(n_steps)
R = np.zeros(n_steps)
t = np.zeros(n_steps)

# Initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
t[0] = 0

# RK3 implementation
for step in range(1, n_steps):
    t[step] = t[step - 1] + dt
    
    # Slopes for S, E, I, R
    def dS_dt(S, I):
        return -beta * S * I
    
    def dE_dt(S, I, E):
        return beta * S * I - sigma * E
    
    def dI_dt(E, I):
        return sigma * E - gamma * I
    
    def dR_dt(I):
        return gamma * I
    
    # Step 1
    k1_S = dS_dt(S[step-1], I[step-1]) * dt
    k1_E = dE_dt(S[step-1], I[step-1], E[step-1]) * dt
    k1_I = dI_dt(E[step-1], I[step-1]) * dt
    k1_R = dR_dt(I[step-1]) * dt
    
    # Step 2
    k2_S = dS_dt(S[step-1] + 0.5 * k1_S, I[step-1] + 0.5 * k1_I) * dt
    k2_E = dE_dt(S[step-1] + 0.5 * k1_S, I[step-1] + 0.5 * k1_I, E[step-1] + 0.5 * k1_E) * dt
    k2_I = dI_dt(E[step-1] + 0.5 * k1_E, I[step-1] + 0.5 * k1_I) * dt
    k2_R = dR_dt(I[step-1] + 0.5 * k1_I) * dt
    
    # Step 3
    k3_S = dS_dt(S[step-1] - k1_S + 2 * k2_S, I[step-1] - k1_I + 2 * k2_I) * dt
    k3_E = dE_dt(S[step-1] - k1_S + 2 * k2_S, I[step-1] - k1_I + 2 * k2_I, E[step-1] - k1_E + 2 * k2_E) * dt
    k3_I = dI_dt(E[step-1] - k1_E + 2 * k2_E, I[step-1] - k1_I + 2 * k2_I) * dt
    k3_R = dR_dt(I[step-1] - k1_I + 2 * k2_I) * dt
    
    # Update the values
    S[step] = S[step-1] + (k1_S + 4 * k2_S + k3_S) / 6
    E[step] = E[step-1] + (k1_E + 4 * k2_E + k3_E) / 6
    I[step] = I[step-1] + (k1_I + 4 * k2_I + k3_I) / 6
    R[step] = R[step-1] + (k1_R + 4 * k2_R + k3_R) / 6

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIR Model using RK3 Method')
plt.grid()
plt.show()
