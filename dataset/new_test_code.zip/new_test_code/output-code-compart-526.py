# SIR model using Euler's method
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
S0 = 0.99  # Initial susceptible population
I0 = 0.01  # Initial infected population
R0 = 0.0  # Initial recovered population

# Simulation settings
T = 160  # Total time
dt = 0.1  # Time step

# Time array
time = np.arange(0, T, dt)

# Initialize arrays
S = np.zeros(len(time))
I = np.zeros(len(time))
R = np.zeros(len(time))

# Initial values
S[0] = S0
I[0] = I0
R[0] = R0

# Euler's method
for t in range(1, len(time)):
    dSdt = -beta * S[t-1] * I[t-1]
    dIdt = beta * S[t-1] * I[t-1] - gamma * I[t-1]
    dRdt = gamma * I[t-1]

    S[t] = S[t-1] + dSdt * dt
    I[t] = I[t-1] + dIdt * dt
    R[t] = R[t-1] + dRdt * dt

# Plot results
plt.figure(figsize=(10,6))
plt.plot(time, S, label='Susceptible')
plt.plot(time, I, label='Infected')
plt.plot(time, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.title('SIR Model Simulation')
plt.grid()
plt.show()
