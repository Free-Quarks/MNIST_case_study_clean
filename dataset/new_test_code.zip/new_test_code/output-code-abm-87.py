# Import necessary libraries
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import random

# Define parameters
num_nodes = 1000
num_edges = 3000
initial_infected = 10
beta = 0.3  # Transmission rate
gamma = 0.1  # Recovery rate

# Stratify by age
age_groups = {
    '0-19': 0.2,
    '20-39': 0.3,
    '40-59': 0.3,
    '60+': 0.2
}

# Create network
G = nx.gnm_random_graph(num_nodes, num_edges)

# Assign age group to each node
age_distribution = np.random.choice(list(age_groups.keys()), num_nodes, p=list(age_groups.values()))
nx.set_node_attributes(G, {i: age_distribution[i] for i in range(num_nodes)}, 'age_group')

# Initialize state of nodes
for node in G.nodes():
    G.nodes[node]['state'] = 'S'  # Susceptible

# Infect initial set of nodes
initial_infected_nodes = random.sample(list(G.nodes()), initial_infected)
for node in initial_infected_nodes:
    G.nodes[node]['state'] = 'I'  # Infected

# Define function to simulate one step of the epidemic

def simulate_step(G):
    new_infected = []
    new_recovered = []
    for node in G.nodes():
        if G.nodes[node]['state'] == 'I':
            for neighbor in G.neighbors(node):
                if G.nodes[neighbor]['state'] == 'S':
                    if random.random() < beta:
                        new_infected.append(neighbor)
            if random.random() < gamma:
                new_recovered.append(node)
    for node in new_infected:
        G.nodes[node]['state'] = 'I'
    for node in new_recovered:
        G.nodes[node]['state'] = 'R'  # Recovered

# Simulate the epidemic
num_steps = 100
susceptible_counts = []
infected_counts = []
recovered_counts = []

for step in range(num_steps):
    susceptible_counts.append(sum(1 for node in G.nodes() if G.nodes[node]['state'] == 'S'))
    infected_counts.append(sum(1 for node in G.nodes() if G.nodes[node]['state'] == 'I'))
    recovered_counts.append(sum(1 for node in G.nodes() if G.nodes[node]['state'] == 'R'))
    simulate_step(G)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(susceptible_counts, label='Susceptible')
plt.plot(infected_counts, label='Infected')
plt.plot(recovered_counts, label='Recovered')
plt.xlabel('Time Steps')
plt.ylabel('Number of Individuals')
plt.legend()
plt.title('SIR Model Simulation of COVID-19')
plt.show()

