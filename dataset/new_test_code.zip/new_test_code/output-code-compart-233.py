# SEIR Compartmental Model with RK2 (Runge-Kutta 2nd Order) in Python

import numpy as np
import matplotlib.pyplot as plt

# Define the SEIR model differential equations
def seir_deriv(y, beta, gamma, sigma):
    S, E, I, R = y
    N = S + E + I + R
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I
    dRdt = gamma * I
    return np.array([dSdt, dEdt, dIdt, dRdt])

# RK2 integration step
def rk2_step(y, beta, gamma, sigma, dt):
    k1 = seir_deriv(y, beta, gamma, sigma)
    y_temp = y + 0.5 * dt * k1
    k2 = seir_deriv(y_temp, beta, gamma, sigma)
    return y + dt * k2

# Simulation parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Transition rate from exposed to infected
gamma = 0.1  # Recovery rate
S0 = 999    # Initial susceptible population
E0 = 1      # Initial exposed population
I0 = 0      # Initial infected population
R0 = 0      # Initial recovered population
T = 160     # Total time in days
dt = 1.0    # Time step in days

# Initialize arrays to store results
S = [S0]
E = [E0]
I = [I0]
R = [R0]
t = [0]

# Run simulation
while t[-1] < T:
    y = np.array([S[-1], E[-1], I[-1], R[-1]])
    y_next = rk2_step(y, beta, gamma, sigma, dt)
    S.append(y_next[0])
    E.append(y_next[1])
    I.append(y_next[2])
    R.append(y_next[3])
    t.append(t[-1] + dt)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.grid()
plt.title('SEIR Model with RK2 Integration')
plt.show()
