import numpy as np
import matplotlib.pyplot as plt

# Define SEIR model
def seir_model(S, E, I, R, beta, sigma, gamma):
    dS_dt = -beta * S * I
    dE_dt = beta * S * I - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return dS_dt, dE_dt, dI_dt, dR_dt

# Runge-Kutta 2nd order method (RK2)
def rk2_step(func, y, t, dt, *args):
    k1 = np.array(func(*y, *args))
    y_temp = y + dt * k1 / 2
    k2 = np.array(func(*y_temp, *args))
    y_next = y + dt * k2
    return y_next

# Parameters
beta = 0.3   # Infection rate
sigma = 0.1  # Rate of progression from exposed to infected
gamma = 0.05 # Recovery rate

# Initial conditions
S0, E0, I0, R0 = 0.99, 0.01, 0, 0

# Time parameters
t_start = 0
t_end = 160
dt = 0.1
t = np.arange(t_start, t_end, dt)

# Initialize arrays to store results
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

# Initial values
S[0], E[0], I[0], R[0] = S0, E0, I0, R0

# Time-stepping loop
for i in range(1, len(t)):
    S[i], E[i], I[i], R[i] = rk2_step(seir_model, [S[i-1], E[i-1], I[i-1], R[i-1]], t[i-1], dt, beta, sigma, gamma)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.title('SEIR Model Simulation using RK2')
plt.legend()
plt.grid(True)
plt.show()
