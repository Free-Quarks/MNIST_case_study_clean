# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRHD model using Runge-Kutta 2nd order (RK2) method
class SEIRHDModel:
    def __init__(self, beta, sigma, gamma, delta, alpha, rho, population, initial_conditions):
        self.beta = beta        # Transmission rate
        self.sigma = sigma      # Rate of progression from exposed to infected
        self.gamma = gamma      # Recovery rate
        self.delta = delta      # Death rate
        self.alpha = alpha      # Hospitalization rate
        self.rho = rho          # Rate from hospital to death/recovery
        self.N = population     # Total population
        self.initial_conditions = initial_conditions  # Initial conditions [S, E, I, R, H, D]

    def _derivatives(self, S, E, I, R, H, D):
        dS_dt = -self.beta * S * I / self.N
        dE_dt = self.beta * S * I / self.N - self.sigma * E
        dI_dt = self.sigma * E - (self.gamma + self.delta + self.alpha) * I
        dR_dt = self.gamma * I + (1 - self.rho) * H
        dH_dt = self.alpha * I - self.rho * H
        dD_dt = self.delta * I + self.rho * H
        return dS_dt, dE_dt, dI_dt, dR_dt, dH_dt, dD_dt

    def rk2_step(self, S, E, I, R, H, D, dt):
        k1 = self._derivatives(S, E, I, R, H, D)
        S1, E1, I1, R1, H1, D1 = S + k1[0] * dt / 2, E + k1[1] * dt / 2, I + k1[2] * dt / 2, R + k1[3] * dt / 2, H + k1[4] * dt / 2, D + k1[5] * dt / 2
        k2 = self._derivatives(S1, E1, I1, R1, H1, D1)
        S2, E2, I2, R2, H2, D2 = S + k2[0] * dt, E + k2[1] * dt, I + k2[2] * dt, R + k2[3] * dt, H + k2[4] * dt, D + k2[5] * dt
        return S2, E2, I2, R2, H2, D2

    def run_simulation(self, days, dt=1):
        num_steps = int(days / dt)  # Calculate the number of time steps
        S, E, I, R, H, D = self.initial_conditions
        results = np.zeros((num_steps, 6))

        for step in range(num_steps):
            results[step] = [S, E, I, R, H, D]
            S, E, I, R, H, D = self.rk2_step(S, E, I, R, H, D, dt)

        return results

# Example usage
if __name__ == '__main__':
    beta = 0.3
    sigma = 0.1
    gamma = 0.1
    delta = 0.01
    alpha = 0.05
    rho = 0.02
    population = 10000
    initial_conditions = [9990, 10, 0, 0, 0, 0]
    days = 160

    model = SEIRHDModel(beta, sigma, gamma, delta, alpha, rho, population, initial_conditions)
    results = model.run_simulation(days)

    plt.plot(results)
    plt.legend(['Susceptible', 'Exposed', 'Infected', 'Recovered', 'Hospitalized', 'Dead'])
    plt.xlabel('Days')
    plt.ylabel('Number of individuals')
    plt.title('SEIRHD Model Simulation')
    plt.show()
