# SEIRD model using Runge-Kutta 2nd Order (RK2) Method
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3     # Infection rate
sigma = 0.1    # Rate of incubation
gamma = 0.05   # Recovery rate
mu = 0.01      # Mortality rate

# Initial conditions
S0 = 0.99      # Initial susceptible proportion
E0 = 0.01      # Initial exposed proportion
I0 = 0.0       # Initial infected proportion
R0 = 0.0       # Initial recovered proportion
D0 = 0.0       # Initial deceased proportion
N = 1000       # Total number of time steps
step_size = 0.1 # Size of each time step

# Time array
T = np.linspace(0, N*step_size, N)

# Arrays to store results
S = np.zeros(N)
E = np.zeros(N)
I = np.zeros(N)
R = np.zeros(N)
D = np.zeros(N)

# Initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
D[0] = D0

# SEIRD model equations
def derivs(S, E, I, R, D):
    dSdt = -beta * S * I
    dEdt = beta * S * I - sigma * E
    dIdt = sigma * E - (gamma + mu) * I
    dRdt = gamma * I
    dDdt = mu * I
    return dSdt, dEdt, dIdt, dRdt, dDdt

# RK2 method
for t in range(1, N):
    S1, E1, I1, R1, D1 = derivs(S[t-1], E[t-1], I[t-1], R[t-1], D[t-1])
    S2, E2, I2, R2, D2 = derivs(
        S[t-1] + step_size * S1 / 2,
        E[t-1] + step_size * E1 / 2,
        I[t-1] + step_size * I1 / 2,
        R[t-1] + step_size * R1 / 2,
        D[t-1] + step_size * D1 / 2
    )

    S[t] = S[t-1] + step_size * S2
    E[t] = E[t-1] + step_size * E2
    I[t] = I[t-1] + step_size * I2
    R[t] = R[t-1] + step_size * R2
    D[t] = D[t-1] + step_size * D2

# Plot results
plt.plot(T, S, label='Susceptible')
plt.plot(T, E, label='Exposed')
plt.plot(T, I, label='Infected')
plt.plot(T, R, label='Recovered')
plt.plot(T, D, label='Deceased')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIRD Model using RK2')
plt.show()
