import numpy as np
import matplotlib.pyplot as plt

# SEIRD Model Parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Rate of progression from exposed to infectious
gamma = 0.05  # Recovery rate
mu = 0.01  # Mortality rate

# Initial conditions
S0 = 0.99  # Initial proportion of susceptible individuals
E0 = 0.01  # Initial proportion of exposed individuals
I0 = 0.0  # Initial proportion of infectious individuals
R0 = 0.0  # Initial proportion of recovered individuals
D0 = 0.0  # Initial proportion of deceased individuals
initial_conditions = [S0, E0, I0, R0, D0]

# Time parameters
T = 160  # Total time in days
dt = 1.0  # Time step
timesteps = int(T / dt)
t = np.linspace(0, T, timesteps)

# RK2 Method for SEIRD model
def rk2_seird_step(S, E, I, R, D, beta, sigma, gamma, mu, dt):
    def seird_derivatives(S, E, I, R, D):
        dSdt = -beta * S * I
        dEdt = beta * S * I - sigma * E
        dIdt = sigma * E - gamma * I - mu * I
        dRdt = gamma * I
        dDdt = mu * I
        return np.array([dSdt, dEdt, dIdt, dRdt, dDdt])

    k1 = seird_derivatives(S, E, I, R, D)
    k2 = seird_derivatives(S + 0.5 * dt * k1[0], E + 0.5 * dt * k1[1], I + 0.5 * dt * k1[2], R + 0.5 * dt * k1[3], D + 0.5 * dt * k1[4])

    S_new = S + dt * k2[0]
    E_new = E + dt * k2[1]
    I_new = I + dt * k2[2]
    R_new = R + dt * k2[3]
    D_new = D + dt * k2[4]

    return S_new, E_new, I_new, R_new, D_new

# Simulation
S, E, I, R, D = initial_conditions
results = np.zeros((timesteps, 5))
results[0] = [S, E, I, R, D]

for i in range(1, timesteps):
    S, E, I, R, D = rk2_seird_step(S, E, I, R, D, beta, sigma, gamma, mu, dt)
    results[i] = [S, E, I, R, D]

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(t, results[:, 0], label='Susceptible')
plt.plot(t, results[:, 1], label='Exposed')
plt.plot(t, results[:, 2], label='Infectious')
plt.plot(t, results[:, 3], label='Recovered')
plt.plot(t, results[:, 4], label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of Population')
plt.title('SEIRD Model Simulation using RK2 Method')
plt.legend()
plt.grid(True)
plt.show()
