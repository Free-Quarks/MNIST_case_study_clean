# Import necessary libraries
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import random

# Define parameters
population_size = 1000
initial_infected = 10
infection_rate = 0.05
recovery_rate = 0.01
time_steps = 100

# Create a network
G = nx.erdos_renyi_graph(population_size, 0.1)

# Stratify by sex
sex = ['male', 'female']
sex_distribution = np.random.choice(sex, population_size)

# Initialize states: S (susceptible), I (infected), R (recovered)
states = {node: 'S' for node in G.nodes()}
initial_infected_nodes = random.sample(G.nodes(), initial_infected)
for node in initial_infected_nodes:
    states[node] = 'I'

# Function to update the state of the network
def update_states(G, states, infection_rate, recovery_rate):
    new_states = states.copy()
    for node in G.nodes():
        if states[node] == 'I':
            # Infected nodes can recover
            if random.random() < recovery_rate:
                new_states[node] = 'R'
        elif states[node] == 'S':
            # Susceptible nodes can get infected
            neighbors = list(G.neighbors(node))
            infected_neighbors = [n for n in neighbors if states[n] == 'I']
            if len(infected_neighbors) > 0:
                if random.random() < 1 - (1 - infection_rate) ** len(infected_neighbors):
                    new_states[node] = 'I'
    return new_states

# Run the simulation
def simulate(G, states, infection_rate, recovery_rate, time_steps):
    history = []
    for step in range(time_steps):
        states = update_states(G, states, infection_rate, recovery_rate)
        history.append(states.copy())
    return history

# Initialize and run simulation
history = simulate(G, states, infection_rate, recovery_rate, time_steps)

# Plot the results
def plot_results(history, sex_distribution):
    time_series = {'male': {'S': [], 'I': [], 'R': []}, 'female': {'S': [], 'I': [], 'R': []}}
    for time_step in history:
        male_counts = {'S': 0, 'I': 0, 'R': 0}
        female_counts = {'S': 0, 'I': 0, 'R': 0}
        for node, state in time_step.items():
            if sex_distribution[node] == 'male':
                male_counts[state] += 1
            else:
                female_counts[state] += 1
        for state in ['S', 'I', 'R']:
            time_series['male'][state].append(male_counts[state])
            time_series['female'][state].append(female_counts[state])
    plt.figure(figsize=(12, 6))
    for sex in ['male', 'female']:
        for state in ['S', 'I', 'R']:
            plt.plot(time_series[sex][state], label=f'{sex} {state}')
    plt.xlabel('Time Steps')
    plt.ylabel('Number of Individuals')
    plt.legend()
    plt.title('COVID-19 Simulation by Sex')
    plt.show()

plot_results(history, sex_distribution)
