import random
import matplotlib.pyplot as plt

class Person:
    def __init__(self, unique_id, vaccinated=False, infected=False, recovered=False):
        self.id = unique_id
        self.vaccinated = vaccinated
        self.infected = infected
        self.recovered = recovered

class Simulation:
    def __init__(self, population_size, initial_infected, vaccination_rate, transmission_rate, recovery_rate):
        self.population_size = population_size
        self.initial_infected = initial_infected
        self.vaccination_rate = vaccination_rate
        self.transmission_rate = transmission_rate
        self.recovery_rate = recovery_rate
        self.population = self.create_population()

    def create_population(self):
        population = []
        for i in range(self.population_size):
            vaccinated = random.random() < self.vaccination_rate
            infected = i < self.initial_infected
            population.append(Person(i, vaccinated=vaccinated, infected=infected))
        return population

    def step(self):
        new_infections = []
        new_recoveries = []
        for person in self.population:
            if person.infected:
                # Recovery
                if random.random() < self.recovery_rate:
                    person.infected = False
                    person.recovered = True
                    new_recoveries.append(person.id)
                # Transmission
                for other in self.population:
                    if (not other.infected and not other.recovered and not other.vaccinated and
                        random.random() < self.transmission_rate):
                        new_infections.append(other.id)
        for i in new_infections:
            self.population[i].infected = True
        return len(new_infections), len(new_recoveries)

    def run(self, steps):
        infections = []
        recoveries = []
        for _ in range(steps):
            new_infections, new_recoveries = self.step()
            infections.append(new_infections)
            recoveries.append(new_recoveries)
        return infections, recoveries

# Parameters
population_size = 1000
initial_infected = 10
vaccination_rate = 0.7
transmission_rate = 0.1
recovery_rate = 0.05
steps = 100

# Run Simulation
sim = Simulation(population_size, initial_infected, vaccination_rate, transmission_rate, recovery_rate)
infections, recoveries = sim.run(steps)

# Plot Results
plt.figure(figsize=(10, 5))
plt.plot(range(steps), infections, label='New Infections')
plt.plot(range(steps), recoveries, label='New Recoveries')
plt.xlabel('Time Steps')
plt.ylabel('Number of People')
plt.title('COVID-19 Simulation')
plt.legend()
plt.show()
