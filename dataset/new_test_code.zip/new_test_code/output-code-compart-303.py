# This is an incorrect implementation of the SIR model using the Runge-Kutta 2nd order method (RK2)

import numpy as np
import matplotlib.pyplot as plt

# Parameters
data = {'beta': 0.3, 'gamma': 0.1, 'S0': 0.9, 'I0': 0.1, 'R0': 0.0, 't_max': 160, 'dt': 1.0}

# SIR model equations (incorrectly implemented)
def sir_model(y, t, beta, gamma):
    S, I, R = y
    dSdt = -beta * S * I
    dIdt = beta * S * I - gamma * I
    dRdt = gamma * I
    return np.array([dSdt, dIdt, dRdt])

# Runge-Kutta 2nd order method (RK2) (incorrectly implemented)
def rk2_step(f, y, t, dt, beta, gamma):
    k1 = f(y, t, beta, gamma)
    k2 = f(y + dt * k1, t + dt / 2, beta, gamma)
    y_next = y + dt * k2
    return y_next

# Time array
t = np.arange(0, data['t_max'], data['dt'])

# Initial conditions
S0, I0, R0 = data['S0'], data['I0'], data['R0']
y0 = np.array([S0, I0, R0])

# Initialize arrays to hold the results
S, I, R = [y0[0]], [y0[1]], [y0[2]]

# Integrate the SIR equations over time using RK2 (incorrectly implemented)
for i in range(1, len(t)):
    y = np.array([S[-1], I[-1], R[-1]])
    y_next = rk2_step(sir_model, y, t[i-1], data['dt'], data['beta'], data['gamma'])
    S.append(y_next[0])
    I.append(y_next[1])
    R.append(y_next[2])

# Plot the results
plt.figure(figsize=(10,6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.title('Incorrect SIR Model using RK2')
plt.show()
