# COVID-19 Agent-Based Model with Age Stratification

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

class Person:
    def __init__(self, age, state='susceptible'):
        self.age = age
        self.state = state

    def infect(self):
        if self.state == 'susceptible':
            self.state = 'infected'

    def recover(self):
        if self.state == 'infected':
            self.state = 'recovered'

class COVIDModel:
    def __init__(self, population_size, age_distribution, initial_infected=1):
        self.population_size = population_size
        self.age_distribution = age_distribution
        self.initial_infected = initial_infected
        self.population = self.initialize_population()

    def initialize_population(self):
        population = []
        for age, proportion in self.age_distribution.items():
            num_people = int(proportion * self.population_size)
            for _ in range(num_people):
                population.append(Person(age))
        for _ in range(self.initial_infected):
            population[np.random.randint(0, len(population))].infect()
        return population

    def step(self, infection_rate, recovery_rate):
        new_infections = []
        for person in self.population:
            if person.state == 'infected':
                if np.random.rand() < recovery_rate:
                    person.recover()
                for _ in range(int(infection_rate * self.population_size)):
                    other_person = self.population[np.random.randint(0, len(self.population))]
                    if other_person.state == 'susceptible':
                        new_infections.append(other_person)
        for person in new_infections:
            person.infect()

    def run(self, steps, infection_rate, recovery_rate):
        history = []
        for _ in range(steps):
            self.step(infection_rate, recovery_rate)
            history.append(self.get_stats())
        return history

    def get_stats(self):
        stats = {'susceptible': 0, 'infected': 0, 'recovered': 0}
        for person in self.population:
            stats[person.state] += 1
        return stats

    def plot_stats(self, history):
        df = pd.DataFrame(history)
        df.plot()
        plt.xlabel('Time (steps)')
        plt.ylabel('Number of People')
        plt.title('COVID-19 Simulation')
        plt.show()

age_distribution = {
    '0-19': 0.24,
    '20-39': 0.32,
    '40-59': 0.28,
    '60+': 0.16
}

model = COVIDModel(population_size=1000, age_distribution=age_distribution, initial_infected=10)
history = model.run(steps=100, infection_rate=0.1, recovery_rate=0.03)
model.plot_stats(history)

