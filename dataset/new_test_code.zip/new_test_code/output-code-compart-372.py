import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SEIRHD model

def seirhd_model(y, t, beta, gamma, delta, alpha, mu):
    S, E, I, R, H, D = y
    N = S + E + I + R + H + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - delta * E
    dIdt = delta * E - (alpha + gamma + mu) * I
    dRdt = gamma * I
    dHdt = alpha * I
    dDdt = mu * I
    return [dSdt, dEdt, dIdt, dRdt, dHdt, dDdt]

# Initial number of individuals in each compartment
S0 = 999
E0 = 1
I0 = 0
R0 = 0
H0 = 0
D0 = 0

# Total population
N = S0 + E0 + I0 + R0 + H0 + D0

# Initial conditions vector
initial_conditions = [S0, E0, I0, R0, H0, D0]

# Time points (in days)
t = np.linspace(0, 160, 160)

# Parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
delta = 0.1  # Incubation rate
alpha = 0.05  # Hospitalization rate
mu = 0.01  # Mortality rate

# Integrate the SEIRHD equations over the time grid, t.
solution = odeint(seirhd_model, initial_conditions, t, args=(beta, gamma, delta, alpha, mu))
S, E, I, R, H, D = solution.T

# Plot the data
plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infectious')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.plot(t, H, 'c', alpha=0.7, linewidth=2, label='Hospitalized')
plt.plot(t, D, 'k', alpha=0.7, linewidth=2, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.title('SEIRHD Model')
plt.legend()
plt.grid(True)
plt.show()
