import networkx as nx
import random

# Create a NetworkX graph
g = nx.erdos_renyi_graph(100, 0.05)

# Initialize node attributes
for node in g.nodes:
    g.nodes[node]['sex'] = random.choice(['male', 'female'])
    g.nodes[node]['status'] = 'susceptible'
    g.nodes[node]['days_infected'] = 0

# Randomly infect one node
g.nodes[random.choice(list(g.nodes))]['status'] = 'infected'

# Parameters
infection_probability = 0.1
recovery_days = 14

# Simulate spread over 30 days
for day in range(30):
    new_infections = []
    for node in g.nodes:
        if g.nodes[node]['status'] == 'infected':
            for neighbor in g.neighbors(node):
                if g.nodes[neighbor]['status'] == 'susceptible' and random.random() < infection_probability:
                    new_infections.append(neighbor)
            g.nodes[node]['days_infected'] += 1
            if g.nodes[node]['days_infected'] >= recovery_days:
                g.nodes[node]['status'] = 'recovered'
    for node in new_infections:
        g.nodes[node]['status'] = 'infected'

# Output the final state of each node
final_states = {node: g.nodes[node]['status'] for node in g.nodes}
print(final_states)
