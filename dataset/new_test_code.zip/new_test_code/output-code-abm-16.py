# Import necessary libraries
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

# Parameters
population_size = 1000
initial_infected = 10
transmission_probability = 0.1
recovery_rate = 0.05
sex_ratio = 0.5  # Proportion of males in the population

# Create a random network
G = nx.erdos_renyi_graph(population_size, 0.1)

# Initialize node attributes
for i in G.nodes:
    G.nodes[i]['state'] = 'S'  # Susceptible
    G.nodes[i]['sex'] = 'M' if np.random.rand() < sex_ratio else 'F'

# Infect initial nodes
initial_infected_nodes = np.random.choice(G.nodes(), initial_infected, replace=False)
for node in initial_infected_nodes:
    G.nodes[node]['state'] = 'I'  # Infected

# Function to update the network state
def update_network(G):
    new_G = G.copy()
    for node in G.nodes:
        if G.nodes[node]['state'] == 'I':
            for neighbor in G.neighbors(node):
                if G.nodes[neighbor]['state'] == 'S' and np.random.rand() < transmission_probability:
                    new_G.nodes[neighbor]['state'] = 'I'
            if np.random.rand() < recovery_rate:
                new_G.nodes[node]['state'] = 'R'  # Recovered
    return new_G

# Simulate over time
time_steps = 50
results = []
for t in range(time_steps):
    G = update_network(G)
    states = {'S': 0, 'I': 0, 'R': 0}
    for node in G.nodes:
        states[G.nodes[node]['state']] += 1
    results.append(states)

# Plot results
susceptible = [result['S'] for result in results]
infected = [result['I'] for result in results]
recovered = [result['R'] for result in results]
plt.plot(susceptible, label='Susceptible')
plt.plot(infected, label='Infected')
plt.plot(recovered, label='Recovered')
plt.xlabel('Time Steps')
plt.ylabel('Number of Individuals')
plt.legend()
plt.show()

