import numpy as np
import matplotlib.pyplot as plt

# Define the SIDARTHE model parameters
def sidarthe_model(y, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E
    dS_dt = -beta * S * (I + D + A + R) / N
    dI_dt = beta * S * (I + D + A + R) / N - gamma * I - delta * I - epsilon * I
    dD_dt = delta * I - zeta * D - eta * D
    dA_dt = epsilon * I - theta * A - mu * A
    dR_dt = gamma * I + theta * A - nu * R
    dT_dt = zeta * D + mu * A - tau * T
    dH_dt = eta * D - lambda_ * H
    dE_dt = tau * T + lambda_ * H + nu * R
    return np.array([dS_dt, dI_dt, dD_dt, dA_dt, dR_dt, dT_dt, dH_dt, dE_dt])

# Define the Runge-Kutta 3rd order method
def rk3_step(f, y0, t0, dt, *args):
    k1 = f(y0, *args)
    k2 = f(y0 + 0.5 * dt * k1, *args)
    k3 = f(y0 - dt * k1 + 2 * dt * k2, *args)
    return y0 + (dt / 6) * (k1 + 4 * k2 + k3)

# Initialize parameters
beta = 0.5
gamma = 0.1
delta = 0.05
epsilon = 0.02
theta = 0.01
zeta = 0.03
eta = 0.01
mu = 0.02
nu = 0.01
tau = 0.01
lambda_ = 0.005
dt = 0.1
t_max = 100

# Initial conditions
S0 = 0.99
I0 = 0.01
D0 = 0.0
A0 = 0.0
R0 = 0.0
T0 = 0.0
H0 = 0.0
E0 = 0.0
y0 = np.array([S0, I0, D0, A0, R0, T0, H0, E0])

t_values = np.arange(0, t_max, dt)
results = np.zeros((len(t_values), len(y0)))
results[0] = y0

# Integrate the model over time
for i in range(1, len(t_values)):
    results[i] = rk3_step(sidarthe_model, results[i-1], t_values[i-1], dt, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_)

# Plot results
plt.figure(figsize=(10, 8))
plt.plot(t_values, results[:, 0], label='Susceptible')
plt.plot(t_values, results[:, 1], label='Infected')
plt.plot(t_values, results[:, 2], label='Diagnosed')
plt.plot(t_values, results[:, 3], label='Ailing')
plt.plot(t_values, results[:, 4], label='Recognized')
plt.plot(t_values, results[:, 5], label='Threatened')
plt.plot(t_values, results[:, 6], label='Healed')
plt.plot(t_values, results[:, 7], label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of population')
plt.legend()
plt.title('SIDARTHE Model Simulation')
plt.grid(True)
plt.show()
