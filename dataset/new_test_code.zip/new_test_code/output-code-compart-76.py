# SIR Model Using Euler's Method

import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # infection rate
gamma = 0.1  # recovery rate
S0 = 0.99  # initial proportion of susceptible individuals
I0 = 0.01  # initial proportion of infected individuals
R0 = 0.0  # initial proportion of recovered individuals

# Time parameters
T = 160  # total time
dt = 0.1  # time step
timesteps = int(T / dt)

# Initialize arrays
S = np.zeros(timesteps)
I = np.zeros(timesteps)
R = np.zeros(timesteps)

time = np.linspace(0, T, timesteps)

# Initial conditions
S[0] = S0
I[0] = I0
R[0] = R0

# Euler's method
for t in range(1, timesteps):
    dS = -beta * S[t-1] * I[t-1] * dt
    dI = (beta * S[t-1] * I[t-1] - gamma * I[t-1]) * dt
    dR = gamma * I[t-1] * dt
    S[t] = S[t-1] + dS
    I[t] = I[t-1] + dI
    R[t] = R[t-1] + dR

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(time, S, label='Susceptible')
plt.plot(time, I, label='Infected')
plt.plot(time, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.title('SIR Model Using Euler Method')
plt.grid(True)
plt.show()
