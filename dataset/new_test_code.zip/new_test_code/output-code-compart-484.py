import numpy as np
import matplotlib.pyplot as plt

# SEIR model differential equations
def SEIR_model(y, beta, gamma, delta):
    S, E, I, R = y
    N = S + E + I + R
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - delta * E
    dI_dt = delta * E - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt])

# Runge-Kutta 3rd Order (RK3) method
def RK3_step(f, y, dt, *args):
    k1 = dt * f(y, *args)
    k2 = dt * f(y + 0.5 * k1, *args)
    k3 = dt * f(y - k1 + 2 * k2, *args)
    return y + (k1 + 4 * k2 + k3) / 6

# Parameters
beta = 0.3   # infection rate
gamma = 0.1  # recovery rate
delta = 0.1  # incubation rate

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
y0 = np.array([S0, E0, I0, R0])

# Time parameters
days = 160
dt = 1.0
steps = int(days / dt)

# Initialize arrays to store results
S = np.zeros(steps)
E = np.zeros(steps)
I = np.zeros(steps)
R = np.zeros(steps)
time = np.zeros(steps)

# Initial values
S[0], E[0], I[0], R[0] = y0

# Time integration using RK3
for t in range(1, steps):
    y0 = RK3_step(SEIR_model, y0, dt, beta, gamma, delta)
    S[t], E[t], I[t], R[t] = y0
    time[t] = t * dt

# Plotting the results
plt.figure(figsize=(10,6))
plt.plot(time, S, label='Susceptible')
plt.plot(time, E, label='Exposed')
plt.plot(time, I, label='Infected')
plt.plot(time, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIR Model using RK3')
plt.grid()
plt.show()
