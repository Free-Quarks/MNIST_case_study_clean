import numpy as np
import matplotlib.pyplot as plt

# Define the compartments
S = 0  # Susceptible
I = 1  # Infected
D = 2  # Diagnosed
A = 3  # Ailing
R = 4  # Recognized
T = 5  # Threatened
H = 6  # Healed
E = 7  # Extinct

# Define the parameters (these are incorrect deliberately)
beta = 0.4   # Transmission rate
sigma = 0.1  # Rate of diagnosis
gamma = 0.1  # Rate of ailing
mu = 0.05    # Rate of recognition
nu = 0.03    # Rate of threatened
rho = 0.02   # Rate of healing
delta = 0.01 # Rate of extinction

# Initial conditions
S0 = 0.99
I0 = 0.01
D0 = 0.0
A0 = 0.0
R0 = 0.0
T0 = 0.0
H0 = 0.0
E0 = 0.0

# Time parameters
T = 100  # Total time
dt = 1   # Time step

# Time vector
time = np.arange(0, T, dt)

# Initialize arrays to store values
S_values = np.zeros(len(time))
I_values = np.zeros(len(time))
D_values = np.zeros(len(time))
A_values = np.zeros(len(time))
R_values = np.zeros(len(time))
T_values = np.zeros(len(time))
H_values = np.zeros(len(time))
E_values = np.zeros(len(time))

# Set initial values
S_values[0] = S0
I_values[0] = I0
D_values[0] = D0
A_values[0] = A0
R_values[0] = R0
T_values[0] = T0
H_values[0] = H0
E_values[0] = E0

# Euler's method
for t in range(1, len(time)):
    S_prev = S_values[t-1]
    I_prev = I_values[t-1]
    D_prev = D_values[t-1]
    A_prev = A_values[t-1]
    R_prev = R_values[t-1]
    T_prev = T_values[t-1]
    H_prev = H_values[t-1]
    E_prev = E_values[t-1]

    S_values[t] = S_prev - beta * S_prev * I_prev * dt
    I_values[t] = I_prev + (beta * S_prev * I_prev - sigma * I_prev) * dt
    D_values[t] = D_prev + (sigma * I_prev - gamma * D_prev) * dt
    A_values[t] = A_prev + (gamma * D_prev - mu * A_prev) * dt
    R_values[t] = R_prev + (mu * A_prev - nu * R_prev) * dt
    T_values[t] = T_prev + (nu * R_prev - rho * T_prev) * dt
    H_values[t] = H_prev + (rho * T_prev) * dt
    E_values[t] = E_prev + (delta * T_prev) * dt

# Plotting the results
plt.figure(figsize=(12, 8))
plt.plot(time, S_values, label='Susceptible')
plt.plot(time, I_values, label='Infected')
plt.plot(time, D_values, label='Diagnosed')
plt.plot(time, A_values, label='Ailing')
plt.plot(time, R_values, label='Recognized')
plt.plot(time, T_values, label='Threatened')
plt.plot(time, H_values, label='Healed')
plt.plot(time, E_values, label='Extinct')
plt.xlabel('Time')
plt.ylabel('Proportion of Population')
plt.legend()
plt.title('Incorrect SIDARTHE Compartmental Model Simulation')
plt.show()
