import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3   # Infection rate
sigma = 0.1  # Rate of progression from exposed to infectious
gamma = 0.1  # Recovery rate
delta = 0.01 # Death rate

# Initial conditions
S0 = 0.99
E0 = 0.01
I0 = 0.0
R0 = 0.0
D0 = 0.0

# Time parameters
t_max = 160
n_steps = 1600

t = np.linspace(0, t_max, n_steps)
dt = t[1] - t[0]

# SEIRD model differential equations
def SEIRD_model(y, t, beta, sigma, gamma, delta):
    S, E, I, R, D = y
    dSdt = -beta * S * I
    dEdt = beta * S * I - sigma * E
    dIdt = sigma * E - gamma * I - delta * I
    dRdt = gamma * I
    dDdt = delta * I
    return np.array([dSdt, dEdt, dIdt, dRdt, dDdt])

# Runge-Kutta 2nd order method (RK2)
def runge_kutta_2nd_order(model, y0, t, beta, sigma, gamma, delta):
    y = np.zeros((len(t), len(y0)))
    y[0] = y0
    for i in range(1, len(t)):
        k1 = model(y[i-1], t[i-1], beta, sigma, gamma, delta)
        k2 = model(y[i-1] + dt * k1 / 2, t[i-1] + dt / 2, beta, sigma, gamma, delta)
        y[i] = y[i-1] + dt * k2
    return y

# Integrate the SEIRD equations over the time grid, t.
y0 = [S0, E0, I0, R0, D0]
solution = runge_kutta_2nd_order(SEIRD_model, y0, t, beta, sigma, gamma, delta)
S, E, I, R, D = solution.T

# Plot the data
plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infectious')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.plot(t, D, 'k', alpha=0.7, linewidth=2, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIRD Model Simulation')
plt.grid(True)
plt.show()
