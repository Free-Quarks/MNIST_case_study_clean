import numpy as np

# Parameters
beta = 0.3    # Infection rate
sigma = 0.1   # Rate of progression from exposed to infectious
gamma = 0.05  # Recovery rate
N = 1000      # Total population

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0

# Time step
dt = 0.1

# Number of steps
num_steps = 160

# Arrays to store results
S = np.zeros(num_steps)
E = np.zeros(num_steps)
I = np.zeros(num_steps)
R = np.zeros(num_steps)

# Initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# RK2 method (Incorrect Implementation)
for t in range(1, num_steps):
    dSdt = -beta * S[t-1] * I[t-1] / N
    dEdt = beta * S[t-1] * I[t-1] / N - sigma * E[t-1]
    dIdt = sigma * E[t-1] - gamma * I[t-1]
    dRdt = gamma * I[t-1]

    S_half = S[t-1] + dSdt * dt / 2
    E_half = E[t-1] + dEdt * dt / 2
    I_half = I[t-1] + dIdt * dt / 2
    R_half = R[t-1] + dRdt * dt / 2

    dSdt_half = -beta * S_half * I_half / N
    dEdt_half = beta * S_half * I_half / N - sigma * E_half
    dIdt_half = sigma * E_half - gamma * I_half
    dRdt_half = gamma * I_half

    S[t] = S[t-1] + dSdt_half * dt
    E[t] = E[t-1] + dEdt_half * dt
    I[t] = I[t-1] + dIdt_half * dt
    R[t] = R[t-1] + dRdt_half * dt

# Output results (code does not include plotting or further analysis)
print("S:", S)
print("E:", E)
print("I:", I)
print("R:", R)
