import numpy as np
import matplotlib.pyplot as plt

# Parameters
total_population = 1000   # Total population
initial_infected = 1      # Initial number of infected individuals
initial_exposed = 0       # Initial number of exposed individuals
initial_recovered = 0     # Initial number of recovered individuals
initial_susceptible = total_population - initial_infected - initial_exposed - initial_recovered
beta = 0.3                # Transmission rate
sigma = 1/5.2             # Rate of moving from exposed to infected
gamma = 1/12.39           # Recovery rate
T = 160                   # Total time in days
dt = 1                    # Time step

# Initialize arrays
S = [initial_susceptible]
E = [initial_exposed]
I = [initial_infected]
R = [initial_recovered]
t = [0]

# Euler method implementation
for _ in range(int(T/dt)):
    S_new = S[-1] - dt * beta * S[-1] * I[-1] / total_population
    E_new = E[-1] + dt * (beta * S[-1] * I[-1] / total_population - sigma * E[-1])
    I_new = I[-1] + dt * (sigma * E[-1] - gamma * I[-1])
    R_new = R[-1] + dt * gamma * I[-1]
    
    S.append(S_new)
    E.append(E_new)
    I.append(I_new)
    R.append(R_new)
    t.append(t[-1] + dt)

# Plot results
plt.figure(figsize=(10,6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.title('SEIR Model')
plt.legend()
plt.grid(True)
plt.show()
