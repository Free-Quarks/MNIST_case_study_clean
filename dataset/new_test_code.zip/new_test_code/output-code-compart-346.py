# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRHD model
class SEIRHDModel:
    def __init__(self, beta, sigma, gamma, delta, alpha, mu, N, S0, E0, I0, R0, H0, D0, dt):
        self.beta = beta
        self.sigma = sigma
        self.gamma = gamma
        self.delta = delta
        self.alpha = alpha
        self.mu = mu
        self.N = N
        self.dt = dt
        
        # Initial state
        self.S = S0
        self.E = E0
        self.I = I0
        self.R = R0
        self.H = H0
        self.D = D0
        
    def step(self):
        dS = -self.beta * self.S * self.I / self.N * self.dt
        dE = (self.beta * self.S * self.I / self.N - self.sigma * self.E) * self.dt
        dI = (self.sigma * self.E - self.gamma * self.I - self.alpha * self.I - self.mu * self.I) * self.dt
        dR = self.gamma * self.I * self.dt
        dH = (self.alpha * self.I - self.delta * self.H) * self.dt
        dD = self.mu * self.I * self.dt
        
        self.S += dS
        self.E += dE
        self.I += dI
        self.R += dR
        self.H += dH
        self.D += dD

    def run(self, days):
        S, E, I, R, H, D = [self.S], [self.E], [self.I], [self.R], [self.H], [self.D]
        for _ in range(days):
            self.step()
            S.append(self.S)
            E.append(self.E)
            I.append(self.I)
            R.append(self.R)
            H.append(self.H)
            D.append(self.D)
        return np.array(S), np.array(E), np.array(I), np.array(R), np.array(H), np.array(D)

# Parameters
beta = 0.3  # Transmission rate
sigma = 1/5.2  # Rate at which exposed individuals become infectious
gamma = 1/2.3  # Recovery rate
delta = 1/10  # Hospital discharge rate
alpha = 0.01  # Hospitalization rate
mu = 0.005  # Mortality rate
N = 1000000  # Total population
S0 = 999000  # Initial susceptible population
E0 = 1000  # Initial exposed population
I0 = 0  # Initial infectious population
R0 = 0  # Initial recovered population
H0 = 0  # Initial hospitalized population
D0 = 0  # Initial deceased population
dt = 1  # Time step (in days)
days = 160  # Number of days to simulate

# Run the model
model = SEIRHDModel(beta, sigma, gamma, delta, alpha, mu, N, S0, E0, I0, R0, H0, D0, dt)
S, E, I, R, H, D = model.run(days)

# Plot the results
plt.figure(figsize=(10,6))
plt.plot(S, label='Susceptible')
plt.plot(E, label='Exposed')
plt.plot(I, label='Infectious')
plt.plot(R, label='Recovered')
plt.plot(H, label='Hospitalized')
plt.plot(D, label='Deceased')
plt.xlabel('Days')
plt.ylabel('Population')
plt.title('SEIRHD Model Simulation')
plt.legend()
plt.grid()
plt.show()
