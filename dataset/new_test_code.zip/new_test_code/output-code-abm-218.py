import random

class Person:
    def __init__(self, is_vaccinated=False):
        self.is_vaccinated = is_vaccinated
        self.is_infected = False
        self.days_infected = 0

    def infect(self):
        if not self.is_vaccinated:
            self.is_infected = True
            self.days_infected = 1

    def progress_infection(self):
        if self.is_infected:
            self.days_infected += 1
            if self.days_infected > 14:  # Assuming a 14-day infection period
                self.is_infected = False
                self.days_infected = 0

class Population:
    def __init__(self, size, vaccination_rate):
        self.people = [Person(is_vaccinated=(random.random() < vaccination_rate)) for _ in range(size)]
        self.infect_random_person()

    def infect_random_person(self):
        random.choice(self.people).infect()

    def simulate_day(self):
        for person in self.people:
            if person.is_infected:
                for _ in range(5):  # Each infected person can infect up to 5 others per day
                    random.choice(self.people).infect()
            person.progress_infection()

    def simulate(self, days):
        for day in range(days):
            self.simulate_day()
            self.report(day)

    def report(self, day):
        total_infected = sum(person.is_infected for person in self.people)
        print(f"Day {day}: {total_infected} people are currently infected.")

# Example usage:
population_size = 1000
vaccination_rate = 0.7  # 70% of the population is vaccinated
simulation_days = 30

population = Population(population_size, vaccination_rate)
population.simulate(simulation_days)
