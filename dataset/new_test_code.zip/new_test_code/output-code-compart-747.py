import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# SEIRHD compartmental model differential equations
def seirhd_model(y, t, beta, sigma, gamma, delta, alpha, mu):
    S, E, I, R, H, D = y
    N = S + E + I + R + H + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - delta * I - alpha * I
    dRdt = gamma * I
    dHdt = delta * I - mu * H
    dDdt = alpha * I + mu * H
    return [dSdt, dEdt, dIdt, dRdt, dHdt, dDdt]

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
H0 = 0
D0 = 0
initial_conditions = [S0, E0, I0, R0, H0, D0]

# Time points (days)
t = np.linspace(0, 160, 160)

# Parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Incubation rate
gamma = 1/14  # Recovery rate
delta = 0.05  # Hospitalization rate
alpha = 0.02  # Mortality rate
mu = 0.01  # Death rate in hospital

# Integrate the SEIRHD equations
result = odeint(seirhd_model, initial_conditions, t, args=(beta, sigma, gamma, delta, alpha, mu))

# Plot the results
S, E, I, R, H, D = result.T
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, H, label='Hospitalized')
plt.plot(t, D, label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Number of people')
plt.legend()
plt.title('SEIRHD Model')
plt.show()
