# Agent-based model to simulate COVID-19 with age stratification

import random

class Person:
    def __init__(self, age_group):
        self.age_group = age_group
        self.infected = False
        self.recovered = False
        self.dead = False

    def infect(self):
        if not self.infected and not self.recovered and not self.dead:
            self.infected = True

    def recover_or_die(self):
        if self.infected:
            if random.random() < mortality_rate[self.age_group]:
                self.dead = True
            else:
                self.recovered = True
            self.infected = False

# Stratification by age groups
age_groups = ['0-17', '18-49', '50-64', '65+']

# Mortality rates for each age group (example rates, not real data)
mortality_rate = {
    '0-17': 0.001,
    '18-49': 0.01,
    '50-64': 0.03,
    '65+': 0.1
}

# Population size
population_size = 1000

# Initialize the population
population = [Person(random.choice(age_groups)) for _ in range(population_size)]

# Infect a few initial individuals
initial_infected = 10
for i in range(initial_infected):
    population[i].infect()

# Simulation parameters
num_days = 100
infection_rate = 0.05  # Probability of infection from an infected person to a susceptible person

for day in range(num_days):
    # Spread infection
    for person in population:
        if person.infected:
            for other_person in population:
                if not other_person.infected and not other_person.recovered and not other_person.dead:
                    if random.random() < infection_rate:
                        other_person.infect()

    # Recover or die
    for person in population:
        if person.infected:
            person.recover_or_die()

    # Print daily statistics
    num_infected = sum(1 for person in population if person.infected)
    num_recovered = sum(1 for person in population if person.recovered)
    num_dead = sum(1 for person in population if person.dead)
    print(f"Day {day}: Infected: {num_infected}, Recovered: {num_recovered}, Dead: {num_dead}")

