import numpy as np
import networkx as nx
import matplotlib.pyplot as plt

# Parameters
N = 1000  # Total population
initial_infected = 10
beta = 0.3  # Transmission rate
gamma = 0.1  # Recovery rate
steps = 160

# Stratification
age_brackets = {'0-19': 0.2, '20-39': 0.3, '40-59': 0.3, '60+': 0.2}
age_distribution = np.random.choice(list(age_brackets.keys()), size=N, p=list(age_brackets.values()))

# Create a network
G = nx.erdos_renyi_graph(N, 0.1)

# Initialize states: S (0) - Susceptible, I (1) - Infected, R (2) - Recovered
states = np.zeros(N)
initial_infected_individuals = np.random.choice(N, initial_infected, replace=False)
states[initial_infected_individuals] = 1

# Simulation
for step in range(steps):
    new_states = states.copy()
    for node in G.nodes:
        if states[node] == 1:  # If infected
            # Try to infect neighbors
            for neighbor in G.neighbors(node):
                if states[neighbor] == 0 and np.random.rand() < beta:
                    new_states[neighbor] = 1
            # Try to recover
            if np.random.rand() < gamma:
                new_states[node] = 2
    states = new_states
    # Optional: Collect data for plotting or further analysis
    # num_susceptible = np.sum(states == 0)
    # num_infected = np.sum(states == 1)
    # num_recovered = np.sum(states == 2)
    # print(f'Step {step}: S={num_susceptible}, I={num_infected}, R={num_recovered}')

# Plot final state
color_map = {0: 'blue', 1: 'red', 2: 'green'}
node_colors = [color_map[state] for state in states]
plt.figure(figsize=(12, 8))
nx.draw(G, node_color=node_colors, with_labels=False, node_size=50)
plt.title('Final state of the network')
plt.show()
