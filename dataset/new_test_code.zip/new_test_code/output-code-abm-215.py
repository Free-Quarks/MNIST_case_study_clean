# Network Model to Simulate COVID-19 with Age Stratification

import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import random

# Define age stratification
age_groups = {
    '0-19': {'susceptibility': 0.5, 'population': 20},
    '20-39': {'susceptibility': 0.7, 'population': 30},
    '40-59': {'susceptibility': 0.9, 'population': 25},
    '60+': {'susceptibility': 1.0, 'population': 15}
}

# Parameters
transmission_probability = 0.1
initial_infected = 5
simulation_steps = 50

# Creating the network
G = nx.erdos_renyi_graph(sum([group['population'] for group in age_groups.values()]), 0.05)

# Assign age groups to nodes
age_group_labels = []
for age_group, data in age_groups.items():
    age_group_labels.extend([age_group] * data['population'])
random.shuffle(age_group_labels)
nx.set_node_attributes(G, {i: age_group_labels[i] for i in range(len(age_group_labels))}, 'age_group')

# Initialize infection status
for node in G.nodes():
    G.nodes[node]['status'] = 'S'  # Susceptible
initial_infected_nodes = random.sample(G.nodes(), initial_infected)
for node in initial_infected_nodes:
    G.nodes[node]['status'] = 'I'  # Infected

# Simulation
for step in range(simulation_steps):
    new_infections = []
    for node in G.nodes():
        if G.nodes[node]['status'] == 'I':
            neighbors = list(G.neighbors(node))
            for neighbor in neighbors:
                if G.nodes[neighbor]['status'] == 'S':
                    age_group = G.nodes[neighbor]['age_group']
                    susceptibility = age_groups[age_group]['susceptibility']
                    if random.random() < transmission_probability * susceptibility:
                        new_infections.append(neighbor)
    for node in new_infections:
        G.nodes[node]['status'] = 'I'

# Plotting the results
colors = {'S': 'blue', 'I': 'red'}
node_colors = [colors[G.nodes[node]['status']] for node in G.nodes()]

plt.figure(figsize=(10, 8))

pos = nx.spring_layout(G)
nx.draw_networkx(G, pos, node_color=node_colors, with_labels=False, node_size=50)
plt.title(f'COVID-19 Simulation Step {simulation_steps}')
plt.show()
