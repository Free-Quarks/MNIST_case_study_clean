import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Rate of progression from exposed to infectious
gamma = 1/2.9  # Recovery rate
N = 1000  # Total population

# Initial conditions
I0 = 1  # Initial number of infectious individuals
E0 = 0  # Initial number of exposed individuals
R0 = 0  # Initial number of recovered individuals
S0 = N - I0 - E0 - R0  # Initial number of susceptible individuals

# Time parameters
t_max = 160  # Total time
dt = 0.1  # Time step
n_steps = int(t_max / dt)  # Number of steps

def SEIR_derivatives(S, E, I, R, beta, sigma, gamma, N):
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return dS_dt, dE_dt, dI_dt, dR_dt

# Initialize arrays to store results
S = np.zeros(n_steps)
E = np.zeros(n_steps)
I = np.zeros(n_steps)
R = np.zeros(n_steps)
t = np.linspace(0, t_max, n_steps)

# Set initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# Runge-Kutta 2nd order method
for step in range(1, n_steps):
    S_inter, E_inter, I_inter, R_inter = SEIR_derivatives(S[step-1], E[step-1], I[step-1], R[step-1], beta, sigma, gamma, N)
    S_inter = S[step-1] + S_inter * dt / 2
    E_inter = E[step-1] + E_inter * dt / 2
    I_inter = I[step-1] + I_inter * dt / 2
    R_inter = R[step-1] + R_inter * dt / 2

    dS_inter, dE_inter, dI_inter, dR_inter = SEIR_derivatives(S_inter, E_inter, I_inter, R_inter, beta, sigma, gamma, N)
    S[step] = S[step-1] + dS_inter * dt
    E[step] = E[step-1] + dE_inter * dt
    I[step] = I[step-1] + dI_inter * dt
    R[step] = R[step-1] + dR_inter * dt

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.title('SEIR Model Simulation using Runge-Kutta 2nd Order Method')
plt.legend()
plt.grid()
plt.show()
