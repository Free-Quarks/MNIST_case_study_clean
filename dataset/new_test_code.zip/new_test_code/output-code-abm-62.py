# Import necessary libraries
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

# Define the parameters of the simulation
population_size = 1000
initial_infected = 10
infection_probability = 0.1
vaccination_rate = 0.05
recovery_rate = 0.02
vaccination_effectiveness = 0.9
simulation_steps = 100

# Create a random graph to simulate the population network
G = nx.erdos_renyi_graph(population_size, 0.1)

# Initialize the state of each node in the network
# 0: Susceptible, 1: Infected, 2: Recovered, 3: Vaccinated
state = np.zeros(population_size)

# Infect some initial individuals
initial_infections = np.random.choice(population_size, initial_infected, replace=False)
state[initial_infections] = 1

# Function to simulate a single step of the epidemic
def simulate_step(G, state, infection_probability, recovery_rate, vaccination_rate, vaccination_effectiveness):
    new_state = state.copy()
    for node in G.nodes():
        if state[node] == 0:  # Susceptible
            neighbors = list(G.neighbors(node))
            infected_neighbors = [n for n in neighbors if state[n] == 1]
            if np.random.rand() < 1 - (1 - infection_probability) ** len(infected_neighbors):
                new_state[node] = 1
        elif state[node] == 1:  # Infected
            if np.random.rand() < recovery_rate:
                new_state[node] = 2
        elif state[node] == 0 or state[node] == 2:  # Susceptible or Recovered
            if np.random.rand() < vaccination_rate:
                new_state[node] = 3 if np.random.rand() < vaccination_effectiveness else new_state[node]
    return new_state

# Run the simulation
history = [state.copy()]
for step in range(simulation_steps):
    state = simulate_step(G, state, infection_probability, recovery_rate, vaccination_rate, vaccination_effectiveness)
    history.append(state.copy())

# Plot the results
susceptible_counts = [np.sum(h == 0) for h in history]
infected_counts = [np.sum(h == 1) for h in history]
recovered_counts = [np.sum(h == 2) for h in history]
vaccinated_counts = [np.sum(h == 3) for h in history]

plt.figure(figsize=(10, 6))
plt.plot(susceptible_counts, label='Susceptible')
plt.plot(infected_counts, label='Infected')
plt.plot(recovered_counts, label='Recovered')
plt.plot(vaccinated_counts, label='Vaccinated')
plt.xlabel('Time Steps')
plt.ylabel('Number of Individuals')
plt.legend()
plt.title('COVID-19 Simulation with Vaccination')
plt.show()
