import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the differential equations for the SIDARTHE model
def sidarthe_model(y, t, alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E
    dSdt = -beta * S * (I + A + D) / N
    dIdt = beta * S * (I + A + D) / N - gamma * I - delta * I
    dDdt = delta * I - epsilon * D - zeta * D
    dAdt = gamma * I - eta * A - theta * A
    dRdt = eta * A + mu * T - lambda_ * R
    dTdt = epsilon * D - mu * T - nu * T
    dHdt = theta * A + nu * T - tau * H
    dEdt = zeta * D + tau * H
    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Initial conditions
S0 = 0.99
I0 = 0.01
D0 = 0.0
A0 = 0.0
R0 = 0.0
T0 = 0.0
H0 = 0.0
E0 = 0.0
initial_conditions = [S0, I0, D0, A0, R0, T0, H0, E0]

# Parameters
alpha = 0.2
beta = 0.5
gamma = 0.1
delta = 0.1
epsilon = 0.1
theta = 0.1
zeta = 0.1
eta = 0.1
mu = 0.1
nu = 0.1
tau = 0.1
lambda_ = 0.1
params = (alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_)

# Time points (in days)
t = np.linspace(0, 160, 160)

# Integrate the SIDARTHE equations over the time grid, t
y = odeint(sidarthe_model, initial_conditions, t, args=params)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, y[:, 0], 'b', label='Susceptible')
plt.plot(t, y[:, 1], 'r', label='Infected')
plt.plot(t, y[:, 2], 'g', label='Diagnosed')
plt.plot(t, y[:, 3], 'y', label='Ailing')
plt.plot(t, y[:, 4], 'c', label='Recognized')
plt.plot(t, y[:, 5], 'm', label='Threatened')
plt.plot(t, y[:, 6], 'k', label='Healed')
plt.plot(t, y[:, 7], 'orange', label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Proportions')
plt.title('SIDARTHE Model for COVID-19')
plt.legend()
plt.grid(True)
plt.show()

