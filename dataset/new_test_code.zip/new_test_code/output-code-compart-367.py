import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the system of differential equations based on SIDARTHE model
# S: Susceptible
# I: Infected (undocumented)
# D: Diagnosed (documented)
# A: Ailing (symptomatic)
# R: Recognized (severe symptoms)
# T: Threatened (critical)
# H: Healed (recovered)
# E: Extinct (dead)
def sidarthe(y, t, alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E
    dSdt = -alpha * S * I / N - beta * S * D / N - gamma * S * A / N - delta * S * R / N
    dIdt = alpha * S * I / N + beta * S * D / N + gamma * S * A / N + delta * S * R / N - epsilon * I - zeta * I - theta * I
    dDdt = epsilon * I - eta * D - mu * D
    dAdt = zeta * I - nu * A - tau * A - lambda * A
    dRdt = eta * D - nu * R - tau * R - lambda * R
    dTdt = theta * I + mu * D + nu * A + nu * R - tau * T
    dHdt = tau * A + tau * R + tau * T
    dEdt = lambda * A + lambda * R + lambda * T
    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Initial conditions
S0 = 1e6 - 1
I0 = 1
D0 = 0
A0 = 0
R0 = 0
T0 = 0
H0 = 0
E0 = 0

# Initial number of individuals in each compartment
y0 = [S0, I0, D0, A0, R0, T0, H0, E0]

# Time points (in days)
t = np.linspace(0, 365, 365)

# Parameters (these would need to be adjusted based on real data)
alpha = 0.57
beta = 0.011
gamma = 0.456
delta = 0.011
epsilon = 0.171
theta = 0.370
zeta = 0.125
eta = 0.125
mu = 0.125
nu = 0.027
tau = 0.027
lambda_ = 0.034

# Integrate the SIDARTHE equations over the time grid, t.
solution = odeint(sidarthe, y0, t, args=(alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_))

# Plot the data
plt.figure(figsize=(10, 5))
plt.plot(t, solution[:, 0], label='Susceptible')
plt.plot(t, solution[:, 1], label='Infected (undocumented)')
plt.plot(t, solution[:, 2], label='Diagnosed (documented)')
plt.plot(t, solution[:, 3], label='Ailing (symptomatic)')
plt.plot(t, solution[:, 4], label='Recognized (severe symptoms)')
plt.plot(t, solution[:, 5], label='Threatened (critical)')
plt.plot(t, solution[:, 6], label='Healed (recovered)')
plt.plot(t, solution[:, 7], label='Extinct (dead)')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.show()
