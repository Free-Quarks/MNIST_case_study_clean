# Import necessary libraries
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

# Parameters
population_size = 1000
initial_infected = 10
infection_prob = 0.05
recovery_prob = 0.01
male_ratio = 0.5

# Initialize population
population = []
for i in range(population_size):
    sex = 'male' if np.random.rand() < male_ratio else 'female'
    status = 'infected' if i < initial_infected else 'susceptible'
    population.append({'id': i, 'sex': sex, 'status': status})

# Create network
G = nx.erdos_renyi_graph(population_size, 0.1)

# Simulation function
def simulate_step(population, G):
    new_population = []
    for person in population:
        if person['status'] == 'infected':
            if np.random.rand() < recovery_prob:
                person['status'] = 'recovered'
            else:
                neighbors = list(G.neighbors(person['id']))
                for neighbor in neighbors:
                    if population[neighbor]['status'] == 'susceptible' and np.random.rand() < infection_prob:
                        population[neighbor]['status'] = 'infected'
        new_population.append(person)
    return new_population

# Run simulation
num_steps = 50
for step in range(num_steps):
    population = simulate_step(population, G)

# Output the results
num_infected = sum(1 for person in population if person['status'] == 'infected')
num_recovered = sum(1 for person in population if person['status'] == 'recovered')
num_susceptible = sum(1 for person in population if person['status'] == 'susceptible')

print(f'Infected: {num_infected}, Recovered: {num_recovered}, Susceptible: {num_susceptible}')

# Plot the network
color_map = []
for person in population:
    if person['status'] == 'susceptible':
        color_map.append('blue')
    elif person['status'] == 'infected':
        color_map.append('red')
    else:
        color_map.append('green')

nx.draw(G, node_color=color_map, with_labels=True)
plt.show()
