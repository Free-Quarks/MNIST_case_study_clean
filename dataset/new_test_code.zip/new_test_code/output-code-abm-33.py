# A simplified and incorrect agent-based model to simulate COVID-19 with stratification
import random

class Person:
    def __init__(self, age_group):
        self.age_group = age_group
        self.infected = False
        self.recovered = False

    def infect(self):
        if not self.infected and not self.recovered:
            self.infected = True

    def recover(self):
        if self.infected:
            self.recovered = True
            self.infected = False

class Environment:
    def __init__(self, population_size):
        self.people = []
        for _ in range(population_size):
            age_group = random.choice(['child', 'adult', 'elderly'])
            self.people.append(Person(age_group))

    def spread_infection(self):
        for person in self.people:
            if person.infected and not person.recovered:
                for other_person in self.people:
                    if other_person.age_group == person.age_group and not other_person.infected:
                        if random.random() < 0.1:  # incorrect fixed probability
                            other_person.infect()

    def recover_people(self):
        for person in self.people:
            if person.infected:
                if random.random() < 0.1:  # incorrect fixed recovery probability
                    person.recover()

    def simulate(self, days):
        for day in range(days):
            self.spread_infection()
            self.recover_people()

# Initialize environment with a population
env = Environment(population_size=1000)

# Infect a few individuals initially
for _ in range(10):
    random.choice(env.people).infect()

# Simulate for 30 days
env.simulate(days=30)

# Output results
results = {'infected': 0, 'recovered': 0, 'susceptible': 0}
for person in env.people:
    if person.infected:
        results['infected'] += 1
    elif person.recovered:
        results['recovered'] += 1
    else:
        results['susceptible'] += 1

print(results)

