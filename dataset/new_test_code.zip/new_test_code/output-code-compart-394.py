import numpy as np
import json

# Function to define the SIDARTHE model equations
def sidarthe_model(y, params):
    S, I, D, A, R, T, H, E = y
    alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda, rho, kappa, xi, sigma = params
    
    dSdt = - (alpha * I + beta * D + gamma * A + delta * R) * S
    dIdt = (alpha * I + beta * D + gamma * A + delta * R) * S - (epsilon + theta + lambda) * I
    dDdt = epsilon * I - (zeta + eta + rho) * D
    dAdt = theta * I - (mu + kappa) * A
    dRdt = mu * A + zeta * D - (nu + xi) * R
    dTdt = eta * D + nu * R - (sigma + tau) * T
    dHdt = lambda * I + kappa * A + xi * R + tau * T
    dEdt = sigma * T
    
    return np.array([dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt])

# RK3 method implementation
def rk3_step(func, y, params, dt):
    k1 = func(y, params)
    k2 = func(y + dt/2 * k1, params)
    k3 = func(y - dt * k1 + 2 * dt * k2, params)
    return y + dt/6 * (k1 + 4 * k2 + k3)

# Initial conditions and parameters
initial_conditions = [0.99, 0.01, 0, 0, 0, 0, 0, 0]  # [S, I, D, A, R, T, H, E]
params = [0.5, 0.1, 0.1, 0.1, 0.04, 0.01, 0.02, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01]
dt = 0.1
steps = 1000

# Simulation
y = np.array(initial_conditions)
results = []
for _ in range(steps):
    y = rk3_step(sidarthe_model, y, params, dt)
    results.append(y.tolist())

# Output results as JSON
output = {
    "code": json.dumps(results)
}

print(json.dumps(output, indent=4))
