# This script simulates the spread of COVID-19 in a population stratified by age groups.

import numpy as np
import matplotlib.pyplot as plt

# Define parameters
age_groups = ['0-19', '20-39', '40-59', '60+']
population_sizes = [1000, 2000, 1500, 800]  # Example population sizes for each age group
transmission_rates = [0.1, 0.15, 0.2, 0.25]  # Example transmission rates for each age group
initial_infected = [5, 10, 8, 4]  # Initial number of infected individuals in each age group

# Simulation parameters
days = 100

# Initialize arrays to hold the number of infected individuals over time
infected = np.zeros((len(age_groups), days))
for i in range(len(age_groups)):
    infected[i, 0] = initial_infected[i]

# Run the simulation
def simulate_spread(infected, transmission_rates, population_sizes, days):
    for day in range(1, days):
        for i in range(len(age_groups)):
            new_infections = transmission_rates[i] * infected[i, day-1] * (1 - infected[i, day-1] / population_sizes[i])
            infected[i, day] = infected[i, day-1] + new_infections
    return infected

infected = simulate_spread(infected, transmission_rates, population_sizes, days)

# Plot the results
plt.figure(figsize=(10, 6))
for i in range(len(age_groups)):
    plt.plot(infected[i], label=f'Age group {age_groups[i]}')
plt.xlabel('Days')
plt.ylabel('Number of Infected Individuals')
plt.title('COVID-19 Spread Simulation by Age Group')
plt.legend()
plt.show()
