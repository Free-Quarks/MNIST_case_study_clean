# Import necessary libraries
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import random

# Set random seed for reproducibility
random.seed(42)
np.random.seed(42)

# Parameters
population_size = 1000
initial_infected = 10
transmission_prob = 0.05
recovery_prob = 0.01
steps = 100

# Stratification: Age groups
age_groups = ['child', 'adult', 'senior']
age_distribution = [0.3, 0.5, 0.2]  # Probability distribution for age groups

# Initialize the network
G = nx.erdos_renyi_graph(population_size, 0.1)

# Initialize node attributes
for node in G.nodes():
    G.nodes[node]['state'] = 'S'
    G.nodes[node]['age_group'] = np.random.choice(age_groups, p=age_distribution)

# Infect initial set of nodes
initial_infected_nodes = random.sample(G.nodes(), initial_infected)
for node in initial_infected_nodes:
    G.nodes[node]['state'] = 'I'

# Function to simulate one step of the epidemic

def simulate_step(G):
    new_states = {}
    for node in G.nodes():
        if G.nodes[node]['state'] == 'I':
            # Attempt to infect neighbors
            for neighbor in G.neighbors(node):
                if G.nodes[neighbor]['state'] == 'S' and random.random() < transmission_prob:
                    new_states[neighbor] = 'I'
            # Attempt to recover
            if random.random() < recovery_prob:
                new_states[node] = 'R'
    for node, state in new_states.items():
        G.nodes[node]['state'] = state

# Run the simulation
susceptible_counts = []
infected_counts = []
recovered_counts = []

for step in range(steps):
    susceptible_counts.append(sum(1 for node in G.nodes() if G.nodes[node]['state'] == 'S'))
    infected_counts.append(sum(1 for node in G.nodes() if G.nodes[node]['state'] == 'I'))
    recovered_counts.append(sum(1 for node in G.nodes() if G.nodes[node]['state'] == 'R'))
    simulate_step(G)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(susceptible_counts, label='Susceptible')
plt.plot(infected_counts, label='Infected')
plt.plot(recovered_counts, label='Recovered')
plt.xlabel('Time Steps')
plt.ylabel('Number of Individuals')
plt.legend()
plt.title('COVID-19 Simulation')
plt.show()

