import numpy as np
import matplotlib.pyplot as plt

# SEIR model parameters
beta = 0.3  # infection rate
sigma = 1/5.2  # rate of progression from exposed to infectious
gamma = 1/2.9  # recovery rate

# Initial conditions
S0 = 0.99  # initial proportion of susceptible individuals
E0 = 0.01  # initial proportion of exposed individuals
I0 = 0.0  # initial proportion of infectious individuals
R0 = 0.0  # initial proportion of recovered individuals

# Time parameters
T = 160  # total time in days
dt = 0.1  # time step

# Number of time steps
n_steps = int(T / dt)

def seir_model(S, E, I, R, beta, sigma, gamma):
    dS_dt = -beta * S * I
    dE_dt = beta * S * I - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return dS_dt, dE_dt, dI_dt, dR_dt

# Initialize arrays to store the results
S = np.zeros(n_steps)
E = np.zeros(n_steps)
I = np.zeros(n_steps)
R = np.zeros(n_steps)

t = np.zeros(n_steps)

# Set initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

t[0] = 0.0

# Runge-Kutta 2nd order method (RK2) implementation
for step in range(1, n_steps):
    t[step] = t[step - 1] + dt
    k1_S, k1_E, k1_I, k1_R = seir_model(S[step - 1], E[step - 1], I[step - 1], R[step - 1], beta, sigma, gamma)
    S_half = S[step - 1] + k1_S * dt / 2
    E_half = E[step - 1] + k1_E * dt / 2
    I_half = I[step - 1] + k1_I * dt / 2
    R_half = R[step - 1] + k1_R * dt / 2
    k2_S, k2_E, k2_I, k2_R = seir_model(S_half, E_half, I_half, R_half, beta, sigma, gamma)
    S[step] = S[step - 1] + k2_S * dt
    E[step] = E[step - 1] + k2_E * dt
    I[step] = I[step - 1] + k2_I * dt
    R[step] = R[step - 1] + k2_R * dt

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.title('SEIR Model Simulation using RK2')
plt.legend()
plt.grid(True)
plt.show()
