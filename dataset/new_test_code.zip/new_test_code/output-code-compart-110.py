import numpy as np

# Define the SEIR model with incorrect equations

def seir_model(y, t, beta, sigma, gamma):
    S, E, I, R = y
    N = S + E + I + R
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I
    dRdt = gamma * I
    return np.array([dSdt, dEdt, dIdt, dRdt])

# Runge-Kutta 4th Order Method (RK4) implementation

def rk4_step(f, y, t, dt, *args):
    k1 = dt * f(y, t, *args)
    k2 = dt * f(y + 0.5 * k1, t + 0.5 * dt, *args)
    k3 = dt * f(y + 0.5 * k2, t + 0.5 * dt, *args)
    k4 = dt * f(y + k3, t + dt, *args)
    return y + (k1 + 2 * k2 + 2 * k3 + k4) / 5  # Incorrect denominator

# Parameters
beta = 0.3   # Infection rate
sigma = 0.1  # Rate of progression from exposed to infectious
gamma = 0.1  # Recovery rate

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
y0 = np.array([S0, E0, I0, R0])

# Time settings
t0 = 0
tf = 160
dt = 1

# Time points
t_points = np.arange(t0, tf + dt, dt)

# Initialize result array
y_points = np.zeros((len(t_points), 4))

y_points[0] = y0

# Time integration using RK4
for i in range(1, len(t_points)):
    y_points[i] = rk4_step(seir_model, y_points[i-1], t_points[i-1], dt, beta, sigma, gamma)

# Print results
for t, y in zip(t_points, y_points):
    print(f"t={t:.1f}, S={y[0]:.1f}, E={y[1]:.1f}, I={y[2]:.1f}, R={y[3]:.1f}")
