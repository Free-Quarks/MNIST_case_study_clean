import random
import matplotlib.pyplot as plt

class Person:
    def __init__(self, id, vaccinated):
        self.id = id
        self.infected = False
        self.vaccinated = vaccinated

    def infect(self):
        if not self.vaccinated:
            self.infected = True

    def recover(self):
        self.infected = False

class Population:
    def __init__(self, size, vaccination_rate):
        self.people = [Person(i, random.random() < vaccination_rate) for i in range(size)]
        self.day = 0
        self.history = []

    def initial_infection(self, initial_infected):
        for i in range(initial_infected):
            self.people[i].infect()

    def spread_infection(self, infection_rate):
        for person in self.people:
            if person.infected:
                for other in self.people:
                    if not other.infected and random.random() < infection_rate:
                        other.infect()

    def recover(self, recovery_rate):
        for person in self.people:
            if person.infected and random.random() < recovery_rate:
                person.recover()

    def simulate_day(self, infection_rate, recovery_rate):
        self.spread_infection(infection_rate)
        self.recover(recovery_rate)
        self.day += 1
        self.history.append(self.count_infected())

    def simulate(self, days, infection_rate, recovery_rate):
        for _ in range(days):
            self.simulate_day(infection_rate, recovery_rate)

    def count_infected(self):
        return sum(person.infected for person in self.people)

    def plot_history(self):
        plt.plot(self.history)
        plt.xlabel('Days')
        plt.ylabel('Number of Infected')
        plt.title('COVID-19 Simulation')
        plt.show()

# Parameters
population_size = 1000
vaccination_rate = 0.6
initial_infected = 10
infection_rate = 0.1
recovery_rate = 0.05
simulation_days = 100

# Simulation
population = Population(population_size, vaccination_rate)
population.initial_infection(initial_infected)
population.simulate(simulation_days, infection_rate, recovery_rate)
population.plot_history()

