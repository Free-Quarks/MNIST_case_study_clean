import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

# Define age groups
age_groups = {
    '0-17': {'size': 100, 'transmission_rate': 0.1},
    '18-49': {'size': 200, 'transmission_rate': 0.2},
    '50-64': {'size': 150, 'transmission_rate': 0.3},
    '65+': {'size': 100, 'transmission_rate': 0.4}
}

# Create a network
G = nx.Graph()

# Add nodes with age group attributes
node_id = 0
for age_group, params in age_groups.items():
    for _ in range(params['size']):
        G.add_node(node_id, age_group=age_group, infected=False)
        node_id += 1

# Add edges (connections) between nodes
for node in G.nodes():
    age_group = G.nodes[node]['age_group']
    transmission_rate = age_groups[age_group]['transmission_rate']
    for _ in range(int(transmission_rate * 10)):
        neighbor = np.random.choice(G.nodes())
        if node != neighbor:
            G.add_edge(node, neighbor)

# Initialize infection
initial_infected = np.random.choice(G.nodes(), size=10, replace=False)
for node in initial_infected:
    G.nodes[node]['infected'] = True

# Simulate the spread of COVID-19
def simulate_spread(G, steps=10):
    for _ in range(steps):
        new_infections = []
        for node in G.nodes():
            if G.nodes[node]['infected']:
                for neighbor in G.neighbors(node):
                    if not G.nodes[neighbor]['infected']:
                        transmission_probability = age_groups[G.nodes[neighbor]['age_group']]['transmission_rate']
                        if np.random.rand() < transmission_probability:
                            new_infections.append(neighbor)
        for node in new_infections:
            G.nodes[node]['infected'] = True

# Run the simulation
simulate_spread(G, steps=30)

# Plot the results
color_map = ['red' if G.nodes[node]['infected'] else 'blue' for node in G.nodes()]
plt.figure(figsize=(12, 12))
nx.draw(G, node_color=color_map, with_labels=False, node_size=50)
plt.show()
