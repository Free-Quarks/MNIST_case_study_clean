import numpy as np
from scipy.integrate import solve_ivp
import json

# Define the SEIR model differential equations
def SEIR_model(t, y, beta, sigma, gamma):
    S, E, I, R = y
    N = S + E + I + R
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return [dS_dt, dE_dt, dI_dt, dR_dt]

# Function to perform the Runge-Kutta 4th order method
def rk4_step(func, t, y, dt, *args):
    k1 = np.array(func(t, y, *args))
    k2 = np.array(func(t + 0.5 * dt, y + 0.5 * k1 * dt, *args))
    k3 = np.array(func(t + 0.5 * dt, y + 0.5 * k2 * dt, *args))
    k4 = np.array(func(t + dt, y + k3 * dt, *args))
    return y + (dt / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)

# Main function to simulate the SEIR model
def simulate_SEIR(S0, E0, I0, R0, beta, sigma, gamma, t_max, dt):
    t_values = np.arange(0, t_max, dt)
    results = []
    y = [S0, E0, I0, R0]
    for t in t_values:
        results.append([t] + y)
        y = rk4_step(SEIR_model, t, y, dt, beta, sigma, gamma)
    return np.array(results)

# Parameters
S0 = 990  # Initial susceptible population
E0 = 10   # Initial exposed population
I0 = 0    # Initial infectious population
R0 = 0    # Initial recovered population
beta = 0.3  # Infection rate
sigma = 1/5.2  # Rate of progression from exposed to infectious (1/incubation period)
gamma = 1/2.9  # Recovery rate (1/infectious period)
t_max = 160  # Simulation time

dt = 1  # Time step

# Run the simulation
results = simulate_SEIR(S0, E0, I0, R0, beta, sigma, gamma, t_max, dt)

# Convert results to a JSON instance
results_json = json.dumps(results.tolist())

# Print the JSON instance
print(results_json)
