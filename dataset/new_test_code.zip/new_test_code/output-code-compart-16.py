# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.5  # rate of infection from symptomatic
beta_d = 0.1  # rate of infection from diagnosed
beta_a = 0.3  # rate of infection from asymptomatic
beta_r = 0.2  # rate of infection from recovered
alpha = 0.1  # rate of becoming symptomatic
gamma = 0.05  # rate of becoming diagnosed
eta = 0.02  # rate of becoming asymptomatic
mu = 0.01  # rate of dying
nu = 0.03  # rate of recovering

# Initial conditions
S0 = 0.99  # susceptible
I0 = 0.01  # symptomatic
D0 = 0.0   # diagnosed
A0 = 0.0   # asymptomatic
R0 = 0.0   # recovered
H0 = 0.0   # isolated
E0 = 0.0   # extinct

# Time parameters
T = 100  # total time
dt = 1  # time step

# Initialize arrays to store results
S = [S0]
I = [I0]
D = [D0]
A = [A0]
R = [R0]
H = [H0]
E = [E0]

# Euler method loop
for t in range(1, T):
    S_new = S[-1] - dt * (beta * S[-1] * I[-1] + beta_d * S[-1] * D[-1] + beta_a * S[-1] * A[-1] + beta_r * S[-1] * R[-1])
    I_new = I[-1] + dt * (beta * S[-1] * I[-1] - alpha * I[-1])
    D_new = D[-1] + dt * (gamma * I[-1] - mu * D[-1])
    A_new = A[-1] + dt * (eta * S[-1] - nu * A[-1])
    R_new = R[-1] + dt * (nu * A[-1] - beta_r * S[-1] * R[-1])
    H_new = H[-1] + dt * (alpha * I[-1] - gamma * I[-1])
    E_new = E[-1] + dt * (mu * D[-1])
    
    S.append(S_new)
    I.append(I_new)
    D.append(D_new)
    A.append(A_new)
    R.append(R_new)
    H.append(H_new)
    E.append(E_new)

# Plot results
plt.figure(figsize=(10,6))
plt.plot(S, label='Susceptible')
plt.plot(I, label='Infected')
plt.plot(D, label='Diagnosed')
plt.plot(A, label='Asymptomatic')
plt.plot(R, label='Recovered')
plt.plot(H, label='Isolated')
plt.plot(E, label='Extinct')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.title('SIDARTHE Model Simulation')
plt.show()
