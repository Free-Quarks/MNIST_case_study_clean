import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model parameters
beta = 0.3  # Transmission rate
sigma = 0.1  # Rate of progression from exposed to infectious
gamma = 0.1  # Recovery rate
mu = 0.01    # Mortality rate

# Initial conditions
S0 = 0.99  # Susceptible
E0 = 0.01  # Exposed
I0 = 0.0   # Infectious
R0 = 0.0   # Recovered
D0 = 0.0   # Deceased

# Time parameters
T = 160    # Total time
N = 160    # Number of time steps

# Time step size
dt = T / N

# Initialize the arrays
S = np.zeros(N)
E = np.zeros(N)
I = np.zeros(N)
R = np.zeros(N)
D = np.zeros(N)
t = np.zeros(N)

# Initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
D[0] = D0

t[0] = 0

# RK2 method
for k in range(0, N-1):
    t[k+1] = t[k] + dt
    k1_S = -beta * S[k] * I[k]
    k1_E = beta * S[k] * I[k] - sigma * E[k]
    k1_I = sigma * E[k] - gamma * I[k]
    k1_R = gamma * I[k]
    k1_D = mu * I[k]

    S_half = S[k] + k1_S * dt / 2
    E_half = E[k] + k1_E * dt / 2
    I_half = I[k] + k1_I * dt / 2
    R_half = R[k] + k1_R * dt / 2
    D_half = D[k] + k1_D * dt / 2

    k2_S = -beta * S_half * I_half
    k2_E = beta * S_half * I_half - sigma * E_half
    k2_I = sigma * E_half - gamma * I_half
    k2_R = gamma * I_half
    k2_D = mu * I_half

    S[k+1] = S[k] + k2_S * dt
    E[k+1] = E[k] + k2_E * dt
    I[k+1] = I[k] + k2_I * dt
    R[k+1] = R[k] + k2_R * dt
    D[k+1] = D[k] + k2_D * dt

# Plot the results
plt.figure(figsize=(12, 8))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.title('SEIRD Model')
plt.legend()
plt.grid()
plt.show()
