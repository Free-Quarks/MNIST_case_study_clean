import random

class Person:
    def __init__(self, sex):
        self.sex = sex
        self.infected = False
        self.days_infected = 0

    def infect(self):
        self.infected = True
        self.days_infected = 1

    def progress_infection(self):
        if self.infected:
            self.days_infected += 1

    def recover_or_die(self):
        if self.infected and self.days_infected > 14:
            if random.random() < 0.02:  # 2% mortality rate
                return 'died'
            else:
                self.infected = False
                self.days_infected = 0
                return 'recovered'
        return 'still_infected'

class Population:
    def __init__(self, size):
        self.people = [Person(random.choice(['male', 'female'])) for _ in range(size)]

    def initial_infection(self, number):
        infected_people = random.sample(self.people, number)
        for person in infected_people:
            person.infect()

    def simulate_day(self):
        for person in self.people:
            person.progress_infection()
            outcome = person.recover_or_die()
            if outcome == 'died':
                self.people.remove(person)

    def count_infected(self):
        return sum(1 for person in self.people if person.infected)

    def count_by_sex(self):
        males = sum(1 for person in self.people if person.sex == 'male')
        females = sum(1 for person in self.people if person.sex == 'female')
        return {'male': males, 'female': females}

# Example usage:
population = Population(1000)
population.initial_infection(10)

for day in range(30):
    print(f"Day {day}: {population.count_infected()} infected")
    population.simulate_day()

print(f"Final count by sex: {population.count_by_sex()}")
