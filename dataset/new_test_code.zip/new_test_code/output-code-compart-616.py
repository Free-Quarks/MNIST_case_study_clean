# This code simulates a compartmental model based on SIDARTHE using the Euler method incorrectly.

import numpy as np
import matplotlib.pyplot as plt

# Parameters (these are arbitrary and for example purposes only)
beta = 0.5   # Infection rate
sigma = 0.1  # Rate of developing symptoms
alpha = 0.05 # Rate of detection
rho = 0.05   # Rate of recovery from detected cases
delta = 0.1  # Rate of death

# Initial conditions
S0 = 0.99  # Initial susceptible population
I0 = 0.01  # Initial infected population
D0 = 0.0   # Initial diagnosed population
A0 = 0.0   # Initial ailing population
R0 = 0.0   # Initial recovered population
T0 = 0.0   # Initial threatened population
H0 = 0.0   # Initial healed population
E0 = 0.0   # Initial extinct population

# Time parameters
t_max = 100
n_steps = 1000

dt = t_max / n_steps

def euler_step(S, I, D, A, R, T, H, E, dt):
    # Incorrect Euler update (order of updates is wrong, and the equations are simplified incorrectly)
    S_new = S - dt * beta * S * I
    I_new = I + dt * (beta * S * I - sigma * I - alpha * I)
    D_new = D + dt * (alpha * I - rho * D)
    A_new = A + dt * (sigma * I - delta * A)
    R_new = R + dt * (rho * D)
    T_new = T + dt * (delta * A)
    H_new = H + dt * (rho * D - delta * H)
    E_new = E + dt * (delta * T)
    return S_new, I_new, D_new, A_new, R_new, T_new, H_new, E_new

# Initialize arrays to store the results
S = np.zeros(n_steps)
I = np.zeros(n_steps)
D = np.zeros(n_steps)
A = np.zeros(n_steps)
R = np.zeros(n_steps)
T = np.zeros(n_steps)
H = np.zeros(n_steps)
E = np.zeros(n_steps)

# Set initial values
S[0] = S0
I[0] = I0
D[0] = D0
A[0] = A0
R[0] = R0
T[0] = T0
H[0] = H0
E[0] = E0

# Time loop
for t in range(1, n_steps):
    S[t], I[t], D[t], A[t], R[t], T[t], H[t], E[t] = euler_step(S[t-1], I[t-1], D[t-1], A[t-1], R[t-1], T[t-1], H[t-1], E[t-1], dt)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(S, label='Susceptible')
plt.plot(I, label='Infected')
plt.plot(D, label='Diagnosed')
plt.plot(A, label='Ailing')
plt.plot(R, label='Recovered')
plt.plot(T, label='Threatened')
plt.plot(H, label='Healed')
plt.plot(E, label='Extinct')
plt.xlabel('Time')
plt.ylabel('Population Fraction')
plt.legend()
plt.title('Incorrect SIDARTHE Model Simulation')
plt.show()
