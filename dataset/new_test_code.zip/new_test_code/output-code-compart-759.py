# Import necessary libraries
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# Define the SEIR model equations
def seir_model(t, y, beta, sigma, gamma):
    S, E, I, R = y
    N = S + E + I + R
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return [dS_dt, dE_dt, dI_dt, dR_dt]

# Define function to implement the Runge-Kutta 3rd order method
def rk3_step(func, t, y, dt, *args):
    k1 = dt * np.array(func(t, y, *args))
    k2 = dt * np.array(func(t + dt / 2, y + k1 / 2, *args))
    k3 = dt * np.array(func(t + dt, y - k1 + 2 * k2, *args))
    return y + (k1 + 4 * k2 + k3) / 6

# Define parameters
t_max = 160  # Maximum time
n_steps = t_max * 10  # Number of steps
dt = t_max / n_steps  # Time step size
beta = 0.3  # Infection rate
sigma = 1/5.2  # Incubation rate
gamma = 1/14  # Recovery rate

# Initial conditions
S0 = 999  # Initial susceptible population
E0 = 1    # Initial exposed population
I0 = 0    # Initial infected population
R0 = 0    # Initial recovered population

y0 = [S0, E0, I0, R0]

t_vals = np.linspace(0, t_max, n_steps)

# Initialize array to store results
results = np.zeros((n_steps, 4))
results[0] = y0

y = y0
for i in range(1, n_steps):
    y = rk3_step(seir_model, t_vals[i - 1], y, dt, beta, sigma, gamma)
    results[i] = y

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t_vals, results[:, 0], label='Susceptible')
plt.plot(t_vals, results[:, 1], label='Exposed')
plt.plot(t_vals, results[:, 2], label='Infected')
plt.plot(t_vals, results[:, 3], label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.title('SEIR Model using RK3 Method')
plt.legend()
plt.grid()
plt.show()
