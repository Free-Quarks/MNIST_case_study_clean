import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model
class SEIRDModel:
    def __init__(self, beta, sigma, gamma, mu, delta, S0, E0, I0, R0, D0, T):
        self.beta = beta  # Infection rate
        self.sigma = sigma  # Rate at which exposed individuals become infectious
        self.gamma = gamma  # Recovery rate
        self.mu = mu  # Natural death rate
        self.delta = delta  # Death rate due to disease
        self.S0 = S0  # Initial susceptible population
        self.E0 = E0  # Initial exposed population
        self.I0 = I0  # Initial infectious population
        self.R0 = R0  # Initial recovered population
        self.D0 = D0  # Initial dead population
        self.T = T  # Total time for simulation
        self.N = S0 + E0 + I0 + R0 + D0  # Total population

    def derivatives(self, S, E, I, R, D):
        dS = -self.beta * S * I / self.N
        dE = self.beta * S * I / self.N - self.sigma * E
        dI = self.sigma * E - (self.gamma + self.delta + self.mu) * I
        dR = self.gamma * I
        dD = self.delta * I
        return dS, dE, dI, dR, dD

    def euler(self):
        S, E, I, R, D = self.S0, self.E0, self.I0, self.R0, self.D0
        dt = 1.0
        S_list, E_list, I_list, R_list, D_list = [S], [E], [I], [R], [D]

        for t in range(1, self.T + 1):
            dS, dE, dI, dR, dD = self.derivatives(S, E, I, R, D)
            S += dS * dt
            E += dE * dt
            I += dI * dt
            R += dR * dt
            D += dD * dt

            S_list.append(S)
            E_list.append(E)
            I_list.append(I)
            R_list.append(R)
            D_list.append(D)

        return S_list, E_list, I_list, R_list, D_list

# Parameters
beta = 0.3
sigma = 1/5.2
gamma = 1/12.39
mu = 1/(70*365)
delta = 0.02
S0 = 999
E0 = 1
I0 = 0
R0 = 0
D0 = 0
T = 160

# Initialize and run the model
model = SEIRDModel(beta, sigma, gamma, mu, delta, S0, E0, I0, R0, D0, T)
S, E, I, R, D = model.euler()

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(S, label='Susceptible')
plt.plot(E, label='Exposed')
plt.plot(I, label='Infectious')
plt.plot(R, label='Recovered')
plt.plot(D, label='Dead')
plt.xlabel('Days')
plt.ylabel('Population')
plt.legend()
plt.show()
