# SIDARTHE Model with RK2 Method

import numpy as np
import matplotlib.pyplot as plt

# Parameters (example values, should be adjusted based on real data)
alpha = 0.5  # Transmission rate of susceptible to infected (asymptomatic)
beta = 0.2   # Transmission rate of susceptible to infected (symptomatic)
gamma = 0.1  # Detection rate of infected (asymptomatic) to diagnosed
delta = 0.05 # Detection rate of infected (symptomatic) to diagnosed
epsilon = 0.01 # Recovery rate of diagnosed (asymptomatic) to recovered
zeta = 0.02   # Recovery rate of diagnosed (symptomatic) to recovered
eta = 0.01    # Death rate of diagnosed (asymptomatic)
theta = 0.01  # Death rate of diagnosed (symptomatic)

# Initial conditions
S0 = 0.99  # Initial proportion of susceptible
I0 = 0.01  # Initial proportion of infected (asymptomatic)
D0 = 0.0   # Initial proportion of diagnosed (asymptomatic)
A0 = 0.0   # Initial proportion of infected (symptomatic)
R0 = 0.0   # Initial proportion of recovered (asymptomatic)
T0 = 0.0   # Initial proportion of recovered (symptomatic)
H0 = 0.0   # Initial proportion of deceased (asymptomatic)
E0 = 0.0   # Initial proportion of deceased (symptomatic)

# Time parameters
T = 100  # Total time
dt = 0.1  # Time step

# Number of steps
steps = int(T/dt)

# Arrays to store the results
S = np.zeros(steps)
I = np.zeros(steps)
D = np.zeros(steps)
A = np.zeros(steps)
R = np.zeros(steps)
T = np.zeros(steps)
H = np.zeros(steps)
E = np.zeros(steps)

# Initial values
S[0] = S0
I[0] = I0
D[0] = D0
A[0] = A0
R[0] = R0
T[0] = T0
H[0] = H0
E[0] = E0

# RK2 Method
for i in range(steps-1):
    k1_S = -alpha * S[i] * (I[i] + D[i]) - beta * S[i] * (A[i] + R[i])
    k1_I = alpha * S[i] * (I[i] + D[i]) - gamma * I[i] - delta * I[i]
    k1_D = gamma * I[i] - epsilon * D[i] - eta * D[i]
    k1_A = beta * S[i] * (A[i] + R[i]) - zeta * A[i] - theta * A[i]
    k1_R = epsilon * D[i] + zeta * A[i]
    k1_T = 0
    k1_H = eta * D[i]
    k1_E = theta * A[i]
    
    S_half = S[i] + k1_S * dt / 2
    I_half = I[i] + k1_I * dt / 2
    D_half = D[i] + k1_D * dt / 2
    A_half = A[i] + k1_A * dt / 2
    R_half = R[i] + k1_R * dt / 2
    T_half = T[i] + k1_T * dt / 2
    H_half = H[i] + k1_H * dt / 2
    E_half = E[i] + k1_E * dt / 2

    k2_S = -alpha * S_half * (I_half + D_half) - beta * S_half * (A_half + R_half)
    k2_I = alpha * S_half * (I_half + D_half) - gamma * I_half - delta * I_half
    k2_D = gamma * I_half - epsilon * D_half - eta * D_half
    k2_A = beta * S_half * (A_half + R_half) - zeta * A_half - theta * A_half
    k2_R = epsilon * D_half + zeta * A_half
    k2_T = 0
    k2_H = eta * D_half
    k2_E = theta * A_half

    S[i+1] = S[i] + k2_S * dt
    I[i+1] = I[i] + k2_I * dt
    D[i+1] = D[i] + k2_D * dt
    A[i+1] = A[i] + k2_A * dt
    R[i+1] = R[i] + k2_R * dt
    T[i+1] = T[i] + k2_T * dt
    H[i+1] = H[i] + k2_H * dt
    E[i+1] = E[i] + k2_E * dt

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(S, label='Susceptible')
plt.plot(I, label='Infected (Asymptomatic)')
plt.plot(D, label='Diagnosed (Asymptomatic)')
plt.plot(A, label='Infected (Symptomatic)')
plt.plot(R, label='Recovered (Asymptomatic)')
plt.plot(T, label='Recovered (Symptomatic)')
plt.plot(H, label='Deceased (Asymptomatic)')
plt.plot(E, label='Deceased (Symptomatic)')
plt.xlabel('Time')
plt.ylabel('Proportion of Population')
plt.legend()
plt.title('SIDARTHE Model with RK2 Method')
plt.show()
