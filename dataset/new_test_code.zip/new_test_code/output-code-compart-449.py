import numpy as np
from scipy.integrate import solve_ivp

# SEIRHD model parameters
def SEIRHD_model(t, y, beta, sigma, gamma, delta, alpha, mu):
    S, E, I, R, H, D = y
    N = S + E + I + R + H
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I - delta * I - alpha * I
    dR_dt = gamma * I
    dH_dt = delta * I - mu * H
    dD_dt = alpha * I + mu * H
    return [dS_dt, dE_dt, dI_dt, dR_dt, dH_dt, dD_dt]

# Runge-Kutta 3rd order (RK3) integrator
def rk3_step(func, t, y, dt, *args):
    k1 = np.array(func(t, y, *args))
    k2 = np.array(func(t + dt/2, y + dt/2 * k1, *args))
    k3 = np.array(func(t + dt, y - dt * k1 + 2 * dt * k2, *args))
    return y + dt/6 * (k1 + 4 * k2 + k3)

# Simulation function
def simulate_SEIRHD(t_span, y0, params, dt):
    t0, tf = t_span
    t = t0
    y = np.array(y0)
    results = [[t] + list(y)]
    while t < tf:
        y = rk3_step(SEIRHD_model, t, y, dt, *params)
        t += dt
        results.append([t] + list(y))
    return np.array(results)

# Example usage
params = (0.3, 1/5.2, 1/2.3, 0.1, 0.01, 0.005)  # beta, sigma, gamma, delta, alpha, mu
y0 = [999, 1, 0, 0, 0, 0]  # Initial conditions: S, E, I, R, H, D
t_span = (0, 160)  # Time span for the simulation
dt = 1  # Time step

results = simulate_SEIRHD(t_span, y0, params, dt)
print(results)
