import numpy as np
import matplotlib.pyplot as plt

# Define the Euler method
def euler_step(system, state, dt):
    return state + dt * system(state)

# Define the SIDARTHE model
def sidarthe_system(state, params):
    S, I, D, A, R, T, H, E = state
    alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_, rho, kappa, xi, sigma, phi, chi, psi, omega = params

    dS = -alpha * S * I - beta * S * D - gamma * S * A - delta * S * R
    dI = alpha * S * I + beta * S * D + gamma * S * A + delta * S * R - epsilon * I - zeta * I - lambda_ * I
    dD = epsilon * I - eta * D - rho * D
    dA = zeta * I - theta * A - kappa * A - mu * A
    dR = eta * D + theta * A - nu * R - xi * R - sigma * R
    dT = mu * A + nu * R - tau * T - phi * T
    dH = lambda_ * I + rho * D + kappa * A + xi * R + tau * T - chi * H - psi * H
    dE = chi * H + phi * T + sigma * R + psi * H - omega * E

    return np.array([dS, dI, dD, dA, dR, dT, dH, dE])

# Parameters (example values)
params = [0.5, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1]

# Initial state (example values)
initial_state = [0.99, 0.01, 0, 0, 0, 0, 0, 0]

# Time parameters
T = 100  # total time
dt = 0.1  # time step

# Initialize arrays to store the results
num_steps = int(T / dt)
states = np.zeros((num_steps, len(initial_state)))
states[0] = initial_state

def simulate():
    for t in range(1, num_steps):
        states[t] = euler_step(lambda state: sidarthe_system(state, params), states[t - 1], dt)

    # Plotting the results
    plt.figure(figsize=(12, 8))
    labels = ['S', 'I', 'D', 'A', 'R', 'T', 'H', 'E']
    for i in range(len(initial_state)):
        plt.plot(np.arange(num_steps) * dt, states[:, i], label=labels[i])
    plt.xlabel('Time')
    plt.ylabel('Proportion')
    plt.legend()
    plt.title('SIDARTHE Model Simulation')
    plt.show()

# Run the simulation
simulate()
