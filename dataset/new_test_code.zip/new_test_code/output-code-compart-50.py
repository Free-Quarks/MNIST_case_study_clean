import numpy as np
from scipy.integrate import solve_ivp

# SEIRHD model parameters
def SEIRHD_model(t, y, beta, sigma, gamma, mu, delta):
    S, E, I, R, H, D = y
    N = S + E + I + R + H + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - mu * I - delta * I
    dRdt = gamma * I
    dHdt = mu * I
    dDdt = delta * I
    return [dSdt, dEdt, dIdt, dRdt, dHdt, dDdt]

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
H0 = 0
D0 = 0
initial_conditions = [S0, E0, I0, R0, H0, D0]

# Parameters
beta = 0.3
sigma = 1/5.2
gamma = 1/2.3
mu = 0.03
delta = 0.01

# Time points where solution is computed
t = np.linspace(0, 160, 160)

# Solving the system using RK4 method via solve_ivp
solution = solve_ivp(SEIRHD_model, [t[0], t[-1]], initial_conditions, args=(beta, sigma, gamma, mu, delta), t_eval=t, method='RK45')

# Extracting solutions
S, E, I, R, H, D = solution.y

# Output results
results = {
    'time': t.tolist(),
    'S': S.tolist(),
    'E': E.tolist(),
    'I': I.tolist(),
    'R': R.tolist(),
    'H': H.tolist(),
    'D': D.tolist()
}

import json
print(json.dumps(results, indent=4))
