import random
import matplotlib.pyplot as plt

class Person:
    def __init__(self, sex, infected=False):
        self.sex = sex
        self.infected = infected

    def infect(self):
        self.infected = True

class Population:
    def __init__(self, size):
        self.people = [Person(sex=random.choice(['male', 'female'])) for _ in range(size)]
        self.infect_random_person()

    def infect_random_person(self):
        random.choice(self.people).infect()

    def simulate_step(self, infection_rate):
        for person in self.people:
            if person.infected:
                for other_person in self.people:
                    if not other_person.infected and random.random() < infection_rate:
                        other_person.infect()

    def count_infected(self):
        return sum(person.infected for person in self.people)

    def stratified_count_infected(self):
        males_infected = sum(person.infected for person in self.people if person.sex == 'male')
        females_infected = sum(person.infected for person in self.people if person.sex == 'female')
        return males_infected, females_infected

# Parameters
population_size = 1000
infection_rate = 0.05
simulation_steps = 10

# Initialize population
population = Population(population_size)

# Run simulation
infected_counts = []
male_infected_counts = []
female_infected_counts = []
for _ in range(simulation_steps):
    population.simulate_step(infection_rate)
    infected_counts.append(population.count_infected())
    males, females = population.stratified_count_infected()
    male_infected_counts.append(males)
    female_infected_counts.append(females)

# Plot results
plt.plot(range(simulation_steps), infected_counts, label='Total Infected')
plt.plot(range(simulation_steps), male_infected_counts, label='Male Infected')
plt.plot(range(simulation_steps), female_infected_counts, label='Female Infected')
plt.xlabel('Simulation Step')
plt.ylabel('Number of Infected Individuals')
plt.legend()
plt.show()

