import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SIDARTHE model differential equations.
def sidarthe_deriv(y, t, alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E  # Total population
    dSdt = -beta * S * I / N - zeta * S * A / N - epsilon * S * D / N
    dIdt = beta * S * I / N - gamma * I - delta * I
    dDdt = epsilon * S * D / N - theta * D - lambda_ * D
    dAdt = zeta * S * A / N - eta * A - mu * A
    dRdt = gamma * I + eta * A
    dTdt = delta * I + theta * D - nu * T
    dHdt = mu * A + nu * T - tau * H
    dEdt = lambda_ * D + tau * H
    return dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt

# Initial number of infected and recovered individuals, everyone else is susceptible to infection initially.
I0, D0, A0, R0, T0, H0, E0 = 1, 0, 0, 0, 0, 0, 0
S0 = 1000 - (I0 + D0 + A0 + R0 + T0 + H0 + E0)  # Initial number of susceptible individuals

# Initial conditions vector
y0 = S0, I0, D0, A0, R0, T0, H0, E0

# Contact rate, beta, and other parameters
alpha = 0.2  # Transmission rate
beta = 0.5  # Infection rate
gamma = 0.1  # Recovery rate (from I to R)
delta = 0.1  # Detection rate
epsilon = 0.1  # Detection rate (from S to D)
theta = 0.1  # Infection rate (from D to T)
zeta = 0.1  # Infection rate (from S to A)
eta = 0.1  # Recovery rate (from A to R)
mu = 0.1  # Infection rate (from A to H)
nu = 0.1  # Recovery rate (from T to H)
tau = 0.1  # Recovery rate (from H to E)
lambda_ = 0.1  # Death rate (from D to E)

# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# Integrate the SIDARTHE equations over the time grid, t.
ret = odeint(sidarthe_deriv, y0, t, args=(alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_))
S, I, D, A, R, T, H, E = ret.T

# Plot the data on separate curves for S(t), I(t), D(t), A(t), R(t), T(t), H(t) and E(t)
fig = plt.figure(facecolor='w')
ax = fig.add_subplot(111, facecolor='#dddddd', axisbelow=True)
ax.plot(t, S, 'b', alpha=0.5, lw=2, label='Susceptible')
ax.plot(t, I, 'r', alpha=0.5, lw=2, label='Infected (undetected)')
ax.plot(t, D, 'orange', alpha=0.5, lw=2, label='Detected infected')
ax.plot(t, A, 'y', alpha=0.5, lw=2, label='Ailing')
ax.plot(t, R, 'g', alpha=0.5, lw=2, label='Recovered')
ax.plot(t, T, 'purple', alpha=0.5, lw=2, label='Threatened')
ax.plot(t, H, 'brown', alpha=0.5, lw=2, label='Healed')
ax.plot(t, E, 'k', alpha=0.5, lw=2, label='Extinct')

ax.set_xlabel('Time /days')
ax.set_ylabel('Number')
ax.set_ylim(0, 1200)
ax.set_xlim(0, 160)
ax.yaxis.set_tick_params(length=0)
ax.xaxis.set_tick_params(length=0)
ax.grid(b=True, which='major', c='w', lw=2, ls='-')
legend = ax.legend()
legend.get_frame().set_alpha(0.5)
for spine in ('top', 'right', 'bottom', 'left'):
    ax.spines[spine].set_visible(False)
plt.show()
