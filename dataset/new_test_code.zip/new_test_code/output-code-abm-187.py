# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt
import random

# Define the population size and number of days for the simulation
population_size = 1000
num_days = 160

# Define age stratification
age_groups = {
    '0-19': {'population': 200, 'infection_rate': 0.05, 'recovery_rate': 0.01, 'mortality_rate': 0.0001},
    '20-39': {'population': 300, 'infection_rate': 0.1, 'recovery_rate': 0.02, 'mortality_rate': 0.0002},
    '40-59': {'population': 300, 'infection_rate': 0.15, 'recovery_rate': 0.015, 'mortality_rate': 0.001},
    '60+': {'population': 200, 'infection_rate': 0.2, 'recovery_rate': 0.01, 'mortality_rate': 0.01}
}

# Initialize the population
population = []
for age_group, params in age_groups.items():
    for _ in range(params['population']):
        person = {
            'age_group': age_group,
            'infected': False,
            'recovered': False,
            'dead': False
        }
        population.append(person)

# Function to simulate one day
def simulate_day(population):
    new_infections = 0
    new_recoveries = 0
    new_deaths = 0

    for person in population:
        if person['infected'] and not person['recovered'] and not person['dead']:
            # Check for recovery
            if random.random() < age_groups[person['age_group']]['recovery_rate']:
                person['recovered'] = True
                new_recoveries += 1
            # Check for death
            elif random.random() < age_groups[person['age_group']]['mortality_rate']:
                person['dead'] = True
                new_deaths += 1

    for person in population:
        if not person['infected'] and not person['recovered'] and not person['dead']:
            # Check for new infection
            if random.random() < age_groups[person['age_group']]['infection_rate']:
                person['infected'] = True
                new_infections += 1

    return new_infections, new_recoveries, new_deaths

# Simulate the epidemic
daily_infections = []
daily_recoveries = []
daily_deaths = []

for day in range(num_days):
    new_infections, new_recoveries, new_deaths = simulate_day(population)
    daily_infections.append(new_infections)
    daily_recoveries.append(new_recoveries)
    daily_deaths.append(new_deaths)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(daily_infections, label='Daily Infections')
plt.plot(daily_recoveries, label='Daily Recoveries')
plt.plot(daily_deaths, label='Daily Deaths')
plt.legend()
plt.xlabel('Day')
plt.ylabel('Number of People')
plt.title('COVID-19 Simulation')
plt.show()
