import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the compartments
S, I, D, A, R, T, H, E = 0, 1, 2, 3, 4, 5, 6, 7

# Total population
N = 1000000

# Initial conditions: one infected, rest susceptible
initial_conditions = [N-1, 1, 0, 0, 0, 0, 0, 0]

# Parameters
alpha = 0.1   # Rate of transmission
beta = 0.05   # Rate of progression from infected to diagnosed
gamma = 0.03  # Rate of progression from diagnosed to ailing
eta = 0.04    # Rate of progression from ailing to recognized
theta = 0.01  # Rate of progression from recognized to hospitalized
kappa = 0.02  # Rate of progression from hospitalized to extinct
lambda_ = 0.01# Rate of recovery
mu = 0.01     # Rate of re-susceptibility

# Time points (in days)
t = np.linspace(0, 160, 160)

# The SIDARTHE model differential equations
def deriv(y, t, N, alpha, beta, gamma, eta, theta, kappa, lambda_, mu):
    S, I, D, A, R, T, H, E = y
    dSdt = -alpha * S * I / N
    dIdt = alpha * S * I / N - beta * I
    dDdt = beta * I - gamma * D
    dAdt = gamma * D - eta * A
    dRdt = eta * A - theta * R
    dTdt = theta * R - kappa * T
    dHdt = kappa * T - lambda_ * H
    dEdt = lambda_ * H - mu * E
    return dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt

# Integrate the SIDARTHE equations over the time grid, t.
ret = odeint(deriv, initial_conditions, t, args=(N, alpha, beta, gamma, eta, theta, kappa, lambda_, mu))
S, I, D, A, R, T, H, E = ret.T

# Plot the data
plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, D, 'c', alpha=0.7, linewidth=2, label='Diagnosed')
plt.plot(t, A, 'm', alpha=0.7, linewidth=2, label='Ailing')
plt.plot(t, R, 'y', alpha=0.7, linewidth=2, label='Recognized')
plt.plot(t, T, 'k', alpha=0.7, linewidth=2, label='Threated')
plt.plot(t, H, 'g', alpha=0.7, linewidth=2, label='Healed')
plt.plot(t, E, 'orange', alpha=0.7, linewidth=2, label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Number of people')
plt.legend()
plt.show()
