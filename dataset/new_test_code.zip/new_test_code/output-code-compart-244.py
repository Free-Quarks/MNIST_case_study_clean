import numpy as np

# Define the SIDARTHE model parameters
params = {
    'alpha': 0.1,  # Infection rate
    'beta': 0.01,  # Detection rate
    'gamma': 0.05,  # Recovery rate
    'delta': 0.01,  # Worsening rate
    'epsilon': 0.01,  # Hospitalization rate
    'zeta': 0.01,  # Intensive care rate
    'eta': 0.01,  # Death rate
    'theta': 0.01,  # Recovery from intensive care rate
    'iota': 0.01,  # Recovery from severe cases rate
    'kappa': 0.01  # Recovery from mild cases rate
}

# Initial conditions
initial_conditions = {
    'S': 0.99,  # Susceptible
    'I': 0.01,  # Infected
    'D': 0.0,   # Diagnosed
    'A': 0.0,   # Ailing
    'R': 0.0,   # Recognized
    'T': 0.0,   # Threatened
    'H': 0.0,   # Healed
    'E': 0.0    # Extinct
}

time_step = 0.1  # Time step in days
num_steps = 160  # Number of time steps

def sidarthe_model(y, params):
    S, I, D, A, R, T, H, E = y
    dS_dt = -params['alpha'] * S * I
    dI_dt = params['alpha'] * S * I - params['beta'] * I - params['gamma'] * I
    dD_dt = params['beta'] * I - params['delta'] * D - params['epsilon'] * D
    dA_dt = params['gamma'] * I - params['zeta'] * A - params['eta'] * A
    dR_dt = params['delta'] * D - params['theta'] * R
    dT_dt = params['epsilon'] * D + params['zeta'] * A - params['iota'] * T
    dH_dt = params['theta'] * R + params['iota'] * T
    dE_dt = params['eta'] * A
    return np.array([dS_dt, dI_dt, dD_dt, dA_dt, dR_dt, dT_dt, dH_dt, dE_dt])

def rk3_step(y, params, dt):
    k1 = sidarthe_model(y, params)
    k2 = sidarthe_model(y + 0.5 * dt * k1, params)
    k3 = sidarthe_model(y - dt * k1 + 2 * dt * k2, params)
    return y + (dt / 6) * (k1 + 4 * k2 + k3)

def simulate_sidarthe(initial_conditions, params, time_step, num_steps):
    results = np.zeros((num_steps, len(initial_conditions)))
    y = np.array(list(initial_conditions.values()))
    for step in range(num_steps):
        results[step] = y
        y = rk3_step(y, params, time_step)
    return results

# Run the simulation
results = simulate_sidarthe(initial_conditions, params, time_step, num_steps)

# Print results
for step in range(num_steps):
    print(f"Day {step * time_step:.1f}: S={results[step, 0]:.4f}, I={results[step, 1]:.4f}, D={results[step, 2]:.4f}, A={results[step, 3]:.4f}, R={results[step, 4]:.4f}, T={results[step, 5]:.4f}, H={results[step, 6]:.4f}, E={results[step, 7]:.4f}")
