import numpy as np

# Define the SIDARTHE model
class SIDARTHEModel:
    def __init__(self, S0, I0, D0, A0, R0, T0, H0, E0, parameters):
        self.S = S0
        self.I = I0
        self.D = D0
        self.A = A0
        self.R = R0
        self.T = T0
        self.H = H0
        self.E = E0
        self.params = parameters

    def deriv(self, y, t, params):
        S, I, D, A, R, T, H, E = y
        alpha, beta, gamma, delta, epsilon, zeta, eta, theta, iota, kappa, lambda_, mu, nu, xi, rho, sigma = params

        dSdt = -beta * S * I - delta * S * D - epsilon * S * A - zeta * S * R
        dIdt = beta * S * I + eta * R * I - gamma * I - lambda_ * I - kappa * I - mu * I
        dDdt = delta * S * D + eta * R * D - theta * D - nu * D - xi * D - kappa * D
        dAdt = epsilon * S * A + eta * R * A - theta * A - nu * A - xi * A - sigma * A
        dRdt = zeta * S * R - eta * R * (I + D + A)
        dTdt = gamma * I + theta * D + theta * A - iota * T - rho * T
        dHdt = lambda_ * I + nu * D + nu * A - sigma * H
        dEdt = mu * I + xi * D + xi * A + rho * T + sigma * H

        return np.array([dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt])

    def rk4_step(self, y, t, dt, params):
        k1 = self.deriv(y, t, params)
        k2 = self.deriv(y + 0.5 * dt * k1, t + 0.5 * dt, params)
        k3 = self.deriv(y + 0.5 * dt * k2, t + 0.5 * dt, params)
        k4 = self.deriv(y + dt * k3, t + dt, params)
        return y + (dt / 6) * (k1 + 2*k2 + 2*k3 + k4)

    def simulate(self, days, dt):
        t = np.linspace(0, days, int(days/dt))
        y = np.zeros((len(t), 8))
        y[0] = [self.S, self.I, self.D, self.A, self.R, self.T, self.H, self.E]

        for i in range(1, len(t)):
            y[i] = self.rk4_step(y[i-1], t[i-1], dt, self.params)

        return y

# Initial conditions
S0, I0, D0, A0, R0, T0, H0, E0 = 0.99, 0.01, 0, 0, 0, 0, 0, 0
parameters = [0.5, 0.1, 0.05, 0.02, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01]

# Create the model
model = SIDARTHEModel(S0, I0, D0, A0, R0, T0, H0, E0, parameters)

# Simulate for 160 days with a time step of 1 day
results = model.simulate(160, 1)

# Print the results
days = np.linspace(0, 160, 160)
for day, result in zip(days, results):
    print(f"Day {int(day)}: S={result[0]:.6f}, I={result[1]:.6f}, D={result[2]:.6f}, A={result[3]:.6f}, R={result[4]:.6f}, T={result[5]:.6f}, H={result[6]:.6f}, E={result[7]:.6f}")
