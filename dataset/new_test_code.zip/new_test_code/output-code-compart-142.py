import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SIDARTHE model differential equations
def sidarthe(y, t, alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E
    dSdt = -alpha * S * I / N - beta * S * D / N - gamma * S * A / N - delta * S * R / N
    dIdt = alpha * S * I / N + beta * S * D / N + gamma * S * A / N + delta * S * R / N - epsilon * I - zeta * I - lambda_ * I
    dDdt = epsilon * I - eta * D - theta * D
    dAdt = zeta * I - nu * A - mu * A
    dRdt = eta * D + nu * A - tau * R - lambda_ * R
    dTdt = theta * D + mu * A - tau * T
    dHdt = tau * (R + T) - lambda_ * H
    dEdt = lambda_ * (I + R + H) - lambda_ * E
    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Parameters
alpha, beta, gamma, delta = 0.57, 0.11, 0.11, 0.11
epsilon, theta, zeta, eta = 0.45, 0.45, 0.45, 0.45
mu, nu, tau, lambda_ = 0.45, 0.45, 0.45, 0.45

# Initial conditions
S0, I0, D0, A0, R0, T0, H0, E0 = 0.99, 0.01, 0, 0, 0, 0, 0, 0
y0 = [S0, I0, D0, A0, R0, T0, H0, E0]

# Time points (in days)
t = np.linspace(0, 160, 160)

# Integrate the SIDARTHE equations over the time grid, t.
ret = odeint(sidarthe, y0, t, args=(alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_))
S, I, D, A, R, T, H, E = ret.T

# Plot the data
plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, D, 'y', alpha=0.7, linewidth=2, label='Diagnosed')
plt.plot(t, A, 'purple', alpha=0.7, linewidth=2, label='Ailing')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recognized')
plt.plot(t, T, 'orange', alpha=0.7, linewidth=2, label='Threatened')
plt.plot(t, H, 'brown', alpha=0.7, linewidth=2, label='Healed')
plt.plot(t, E, 'pink', alpha=0.7, linewidth=2, label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Fraction of population')
plt.legend()
plt.grid(True)
plt.show()
