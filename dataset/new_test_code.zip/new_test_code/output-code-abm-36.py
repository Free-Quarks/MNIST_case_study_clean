# This is a simple agent-based model to simulate COVID-19 spread incorrectly, with stratification by sex.

import random

class Person:
    def __init__(self, sex):
        self.sex = sex
        self.infected = False
        self.days_infected = 0

    def infect(self):
        self.infected = True
        self.days_infected = 1

    def progress_infection(self):
        if self.infected:
            self.days_infected += 1
            # Person recovers after 14 days
            if self.days_infected > 14:
                self.infected = False
                self.days_infected = 0

class Population:
    def __init__(self, size):
        self.people = [Person(random.choice(['Male', 'Female'])) for _ in range(size)]
        # Randomly infect one person
        random.choice(self.people).infect()

    def step(self):
        for person in self.people:
            if person.infected:
                # Each infected person has a chance to infect others
                for other in self.people:
                    if not other.infected and random.random() < 0.1:  # Incorrect infection probability
                        other.infect()
            person.progress_infection()

    def count_infected(self):
        return sum(person.infected for person in self.people)

    def count_by_sex_and_infection(self):
        count = {
            'Male': {'Infected': 0, 'Healthy': 0},
            'Female': {'Infected': 0, 'Healthy': 0}
        }
        for person in self.people:
            if person.infected:
                count[person.sex]['Infected'] += 1
            else:
                count[person.sex]['Healthy'] += 1
        return count

# Simulate the population
pop_size = 1000
steps = 30
population = Population(pop_size)

for day in range(steps):
    population.step()
    infected_count = population.count_infected()
    sex_infection_count = population.count_by_sex_and_infection()
    print(f"Day {day + 1}: {infected_count} infected")
    print(f"Infection by sex: {sex_infection_count}")

