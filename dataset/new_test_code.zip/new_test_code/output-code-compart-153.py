# Importing required libraries
import numpy as np
import matplotlib.pyplot as plt

# Define the SIR model differential equations
def sir_model(S, I, R, beta, gamma):
    N = S + I + R  # Total population
    dS_dt = -beta * S * I / N
    dI_dt = beta * S * I / N - gamma * I
    dR_dt = gamma * I
    return dS_dt, dI_dt, dR_dt

# Function to implement the RK2 method
def rk2_step(S, I, R, beta, gamma, dt):
    # Calculate k1 values
    dS1, dI1, dR1 = sir_model(S, I, R, beta, gamma)
    S1 = S + 0.5 * dS1 * dt
    I1 = I + 0.5 * dI1 * dt
    R1 = R + 0.5 * dR1 * dt

    # Calculate k2 values
    dS2, dI2, dR2 = sir_model(S1, I1, R1, beta, gamma)

    # Update variables
    S_next = S + dS2 * dt
    I_next = I + dI2 * dt
    R_next = R + dR2 * dt

    return S_next, I_next, R_next

# Main simulation function
def simulate_sir(S0, I0, R0, beta, gamma, days, dt):
    # Initialize arrays to store results
    S = [S0]
    I = [I0]
    R = [R0]
    t = [0]

    # Run the simulation
    for _ in range(int(days / dt)):
        S_next, I_next, R_next = rk2_step(S[-1], I[-1], R[-1], beta, gamma, dt)
        S.append(S_next)
        I.append(I_next)
        R.append(R_next)
        t.append(t[-1] + dt)

    return np.array(t), np.array(S), np.array(I), np.array(R)

# Parameters
S0 = 999  # Initial susceptible population
I0 = 1    # Initial infected population
R0 = 0    # Initial recovered population
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate

# Simulation settings
days = 160  # Total number of days to simulate
dt = 0.1    # Time step size

t, S, I, R = simulate_sir(S0, I0, R0, beta, gamma, days, dt)

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.title('SIR Model Simulation using RK2')
plt.legend()
plt.grid()
plt.show()
