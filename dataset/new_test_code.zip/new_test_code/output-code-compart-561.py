import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3   # Infection rate
sigma = 0.1  # Rate of progression from exposed to infectious
gamma = 0.05 # Recovery rate
mu = 0.01    # Mortality rate

# Initial conditions
S0 = 999    # Initial susceptible population
E0 = 1      # Initial exposed population
I0 = 0      # Initial infectious population
R0 = 0      # Initial recovered population
D0 = 0      # Initial deceased population

# Time parameters
T = 160     # Total time in days
dt = 1      # Time step in days

# Number of time steps
n_steps = int(T / dt)

# Initialize arrays to store results
S = np.zeros(n_steps)
E = np.zeros(n_steps)
I = np.zeros(n_steps)
R = np.zeros(n_steps)
D = np.zeros(n_steps)

t = np.linspace(0, T, n_steps)

# Set initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
D[0] = D0

# Euler method
for step in range(1, n_steps):
    S[step] = S[step-1] - (beta * S[step-1] * I[step-1] / S0) * dt
    E[step] = E[step-1] + (beta * S[step-1] * I[step-1] / S0 - sigma * E[step-1]) * dt
    I[step] = I[step-1] + (sigma * E[step-1] - gamma * I[step-1] - mu * I[step-1]) * dt
    R[step] = R[step-1] + (gamma * I[step-1]) * dt
    D[step] = D[step-1] + (mu * I[step-1]) * dt

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRD Model Simulation')
plt.grid(True)
plt.show()
