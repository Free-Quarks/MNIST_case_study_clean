# SEIRD Model using Euler Method

import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model
class SEIRD:
    def __init__(self, beta, sigma, gamma, mu, delta, S0, E0, I0, R0, D0, dt):
        self.beta = beta  # Infection rate
        self.sigma = sigma  # Rate of progression from exposed to infectious
        self.gamma = gamma  # Recovery rate
        self.mu = mu  # Mortality rate
        self.delta = delta  # Rate at which deaths occur
        self.S = [S0]  # Susceptible
        self.E = [E0]  # Exposed
        self.I = [I0]  # Infectious
        self.R = [R0]  # Recovered
        self.D = [D0]  # Dead
        self.dt = dt  # Time step

    def step(self):
        S, E, I, R, D = self.S[-1], self.E[-1], self.I[-1], self.R[-1], self.D[-1]
        N = S + E + I + R + D  # Total population

        dS = -self.beta * S * I / N * self.dt
        dE = (self.beta * S * I / N - self.sigma * E) * self.dt
        dI = (self.sigma * E - (self.gamma + self.mu) * I) * self.dt
        dR = self.gamma * I * self.dt
        dD = self.mu * I * self.delta * self.dt

        self.S.append(S + dS)
        self.E.append(E + dE)
        self.I.append(I + dI)
        self.R.append(R + dR)
        self.D.append(D + dD)

    def run(self, days):
        steps = int(days / self.dt)
        for _ in range(steps):
            self.step()

    def plot(self):
        t = np.arange(0, len(self.S) * self.dt, self.dt)
        plt.plot(t, self.S, label='Susceptible')
        plt.plot(t, self.E, label='Exposed')
        plt.plot(t, self.I, label='Infectious')
        plt.plot(t, self.R, label='Recovered')
        plt.plot(t, self.D, label='Dead')
        plt.xlabel('Time (days)')
        plt.ylabel('Population')
        plt.legend()
        plt.show()

# Parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Incubation rate (1/average incubation period)
gamma = 1/10  # Recovery rate (1/average infectious period)
mu = 0.01  # Mortality rate
delta = 1  # Rate at which deaths occur
S0 = 999  # Initial susceptible population
E0 = 1  # Initial exposed population
I0 = 0  # Initial infectious population
R0 = 0  # Initial recovered population
D0 = 0  # Initial dead population
dt = 0.1  # Time step

days = 160  # Duration of simulation

# Run the model
model = SEIRD(beta, sigma, gamma, mu, delta, S0, E0, I0, R0, D0, dt)
model.run(days)
model.plot()
