# Compartmental Model based on SIR using Euler's method

import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
S0 = 0.9  # Initial proportion of susceptible individuals
I0 = 0.1  # Initial proportion of infected individuals
R0 = 0.0  # Initial proportion of recovered individuals

# Time parameters
T = 160  # Total time
dt = 1  # Time step

# Initialize arrays
S = [S0]
I = [I0]
R = [R0]

t = np.linspace(0, T, int(T/dt))

# Euler's method
for _ in t[:-1]:
    S_new = S[-1] - beta * S[-1] * I[-1] * dt
    I_new = I[-1] + (beta * S[-1] * I[-1] - gamma * I[-1]) * dt
    R_new = R[-1] + gamma * I[-1] * dt
    
    # Incorrectly implemented: no bound checks for S, I, R being negative or exceeding 1
    S.append(S_new)
    I.append(I_new)
    R.append(R_new)

# Plot results
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.show()
