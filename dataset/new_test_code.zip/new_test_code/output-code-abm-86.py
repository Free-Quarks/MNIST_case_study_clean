import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

# Parameters
num_nodes = 1000
initial_infected = 10
infection_rate = 0.05
recovery_rate = 0.01
vaccination_rate = 0.01
simulation_steps = 100

# Create a random graph
G = nx.erdos_renyi_graph(num_nodes, 0.1)

# State definitions
SUSCEPTIBLE = 0
INFECTED = 1
RECOVERED = 2
VACCINATED = 3

# Initialize the states
states = [SUSCEPTIBLE] * num_nodes
initial_infected_nodes = np.random.choice(num_nodes, initial_infected, replace=False)
for node in initial_infected_nodes:
    states[node] = INFECTED

# Function to simulate one step
def simulate_step(G, states, infection_rate, recovery_rate, vaccination_rate):
    new_states = states.copy()
    for node in G.nodes():
        if states[node] == INFECTED:
            # Infected nodes may recover
            if np.random.rand() < recovery_rate:
                new_states[node] = RECOVERED
            # Infected nodes may infect their neighbors
            for neighbor in G.neighbors(node):
                if states[neighbor] == SUSCEPTIBLE and np.random.rand() < infection_rate:
                    new_states[neighbor] = INFECTED
        elif states[node] == SUSCEPTIBLE:
            # Susceptible nodes may get vaccinated
            if np.random.rand() < vaccination_rate:
                new_states[node] = VACCINATED
    return new_states

# Simulate over time
history = []
for step in range(simulation_steps):
    states = simulate_step(G, states, infection_rate, recovery_rate, vaccination_rate)
    history.append(states)

# Plot the results
susceptible_count = [sum(1 for state in step if state == SUSCEPTIBLE) for step in history]
infected_count = [sum(1 for state in step if state == INFECTED) for step in history]
recovered_count = [sum(1 for state in step if state == RECOVERED) for step in history]
vaccinated_count = [sum(1 for state in step if state == VACCINATED) for step in history]

plt.plot(susceptible_count, label='Susceptible')
plt.plot(infected_count, label='Infected')
plt.plot(recovered_count, label='Recovered')
plt.plot(vaccinated_count, label='Vaccinated')
plt.xlabel('Time Step')
plt.ylabel('Number of Individuals')
plt.legend()
plt.show()
