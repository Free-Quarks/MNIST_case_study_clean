import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.4
sigma = 0.1
epsilon = 0.1
rho = 0.05
gamma = 0.1
alpha = 0.1
kappa = 0.05
tau = 0.05
lambda_ = 0.05

# Initial conditions
S0 = 0.99
I0 = 0.01
D0 = 0
A0 = 0
R0 = 0
T0 = 0
H0 = 0
E0 = 0

# Time parameters
T = 100
dt = 1

# Time steps
N = int(T / dt)
t = np.linspace(0, T, N)

# Initialize arrays
S = np.zeros(N)
I = np.zeros(N)
D = np.zeros(N)
A = np.zeros(N)
R = np.zeros(N)
T = np.zeros(N)
H = np.zeros(N)
E = np.zeros(N)

# Set initial conditions
S[0] = S0
I[0] = I0
D[0] = D0
A[0] = A0
R[0] = R0
T[0] = T0
H[0] = H0
E[0] = E0

# Euler method
for n in range(1, N):
    S[n] = S[n-1] - dt * beta * S[n-1] * (I[n-1] + D[n-1] + A[n-1])
    I[n] = I[n-1] + dt * (beta * S[n-1] * (I[n-1] + D[n-1] + A[n-1]) - sigma * I[n-1] - rho * I[n-1] - gamma * I[n-1])
    D[n] = D[n-1] + dt * (sigma * I[n-1] - epsilon * D[n-1] - alpha * D[n-1] - kappa * D[n-1])
    A[n] = A[n-1] + dt * (rho * I[n-1] - tau * A[n-1] - lambda_ * A[n-1])
    R[n] = R[n-1] + dt * (gamma * I[n-1] + epsilon * D[n-1] + tau * A[n-1])
    T[n] = T[n-1] + dt * (alpha * D[n-1] + lambda_ * A[n-1])
    H[n] = H[n-1] + dt * (kappa * D[n-1])
    E[n] = E[n-1] + dt * 0  # No evolution for E compartment

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, D, label='Diagnosed')
plt.plot(t, A, label='Ailing')
plt.plot(t, R, label='Recovered')
plt.plot(t, T, label='Threatened')
plt.plot(t, H, label='Healed')
plt.plot(t, E, label='Extinct')
plt.xlabel('Time')
plt.ylabel('Population')
plt.legend()
plt.title('Incorrect SIDARTHE Model using Euler Method')
plt.show()
