import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SEIRHD model

def seirhd_model(y, t, beta, sigma, gamma, delta, mu):
    S, E, I, R, H, D = y
    N = S + E + I + R + H
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - (gamma + delta) * I
    dRdt = gamma * I
    dHdt = delta * I - mu * H
    dDdt = mu * H
    return [dSdt, dEdt, dIdt, dRdt, dHdt, dDdt]

# Initial conditions
N = 1000  # Total population
I0 = 1    # Initial number of infected individuals
E0 = 0    # Initial number of exposed individuals
R0 = 0    # Initial number of recovered individuals
H0 = 0    # Initial number of hospitalized individuals
D0 = 0    # Initial number of deaths
S0 = N - I0 - E0 - R0 - H0 - D0  # Initial number of susceptible individuals

# Initial conditions vector
y0 = [S0, E0, I0, R0, H0, D0]

# Time points (in days)
t = np.linspace(0, 160, 160)

# Parameters
beta = 0.3  # Transmission rate
sigma = 1/5.2  # Rate of progression from exposed to infected (1/incubation period)
gamma = 1/14  # Recovery rate (1/infectious period)
delta = 0.1  # Hospitalization rate
mu = 0.02  # Death rate

# Integrate the SEIRHD equations over the time grid, t.
ret = odeint(seirhd_model, y0, t, args=(beta, sigma, gamma, delta, mu))
S, E, I, R, H, D = ret.T

# Plot the data
plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.plot(t, H, 'c', alpha=0.7, linewidth=2, label='Hospitalized')
plt.plot(t, D, 'k', alpha=0.7, linewidth=2, label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.title('SEIRHD Model')
plt.grid(True)
plt.show()
