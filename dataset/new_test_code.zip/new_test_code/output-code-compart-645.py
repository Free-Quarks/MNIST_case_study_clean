# SIDARTHE Model with RK4 in Python
import numpy as np

# Parameters for the SIDARTHE model
params = {
    'alpha': 0.1, 'beta': 0.05, 'gamma': 0.03, 'delta': 0.01,
    'epsilon': 0.1, 'theta': 0.05, 'zeta': 0.03, 'eta': 0.01,
    'mu': 0.01, 'nu': 0.01, 'tau': 0.01, 'lambda': 0.01
}

# Initial conditions: S, I, D, A, R, T, H, E
initial_conditions = np.array([0.99, 0.01, 0, 0, 0, 0, 0, 0])

# Time parameters
t0, tf, dt = 0, 160, 0.1

# SIDARTHE model differential equations
def sidarthe_derivatives(y, t, params):
    S, I, D, A, R, T, H, E = y
    alpha, beta, gamma, delta = params['alpha'], params['beta'], params['gamma'], params['delta']
    epsilon, theta, zeta, eta = params['epsilon'], params['theta'], params['zeta'], params['eta']
    mu, nu, tau, lambda_ = params['mu'], params['nu'], params['tau'], params['lambda']
    dSdt = -alpha*S*I - beta*S*D - gamma*S*A - delta*S*R
    dIdt = alpha*S*I + beta*S*D + gamma*S*A + delta*S*R - epsilon*I - zeta*I - lambda_*I
    dDdt = epsilon*I - theta*D - eta*D
    dAdt = zeta*I - theta*A - mu*A
    dRdt = eta*D + mu*A - nu*R
    dTdt = theta*(D + A) - tau*T
    dHdt = tau*T
    dEdt = lambda_*I + nu*R
    return np.array([dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt])

# Runge-Kutta 4th order method
def rk4_step(f, y, t, dt, params):
    k1 = f(y, t, params)
    k2 = f(y + 0.5*dt*k1, t + 0.5*dt, params)
    k3 = f(y + 0.5*dt*k2, t + 0.5*dt, params)
    k4 = f(y + dt*k3, t + dt, params)
    return y + (dt/6)*(k1 + 2*k2 + 2*k3 + k4)

# Time integration
num_steps = int((tf - t0) / dt)
times = np.linspace(t0, tf, num_steps + 1)
results = np.zeros((num_steps + 1, len(initial_conditions)))
results[0] = initial_conditions

# Perform the integration
for i in range(num_steps):
    results[i + 1] = rk4_step(sidarthe_derivatives, results[i], times[i], dt, params)

# Output the results
def output_results(times, results):
    for t, result in zip(times, results):
        print(f"Time {t:.1f}: {result}")

output_results(times, results)

