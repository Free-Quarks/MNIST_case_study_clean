# SEIRHD Model using Runge-Kutta 4th Order Method (RK4)

import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Rate of progression from exposed to infected
gamma = 1/12.39  # Recovery rate
mu = 0.005  # Mortality rate

# Initial conditions
S0 = 0.99  # Initial susceptible population
E0 = 0.01  # Initial exposed population
I0 = 0.0  # Initial infected population
R0 = 0.0  # Initial recovered population
H0 = 0.0  # Initial hospitalized population
D0 = 0.0  # Initial deceased population

# Time parameters
T = 160  # Total time in days
dt = 0.1  # Time step

# Function defining the SEIRHD model
def seirhd_model(t, y):
    S, E, I, R, H, D = y
    dS_dt = -beta * S * I
    dE_dt = beta * S * I - sigma * E
    dI_dt = sigma * E - gamma * I - mu * I
    dR_dt = gamma * I
    dH_dt = mu * I
    dD_dt = mu * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt, dH_dt, dD_dt])

# Runge-Kutta 4th Order Method (RK4)
def rk4_step(func, t, y, dt):
    k1 = func(t, y)
    k2 = func(t + 0.5*dt, y + 0.5*dt*k1)
    k3 = func(t + 0.5*dt, y + 0.5*dt*k2)
    k4 = func(t + dt, y + dt*k3)
    return y + (dt/6)*(k1 + 2*k2 + 2*k3 + k4)

# Initialize arrays
num_steps = int(T / dt)
t = np.linspace(0, T, num_steps)
solution = np.zeros((num_steps, 6))
solution[0] = [S0, E0, I0, R0, H0, D0]

# Perform RK4 integration
for i in range(1, num_steps):
    solution[i] = rk4_step(seirhd_model, t[i-1], solution[i-1], dt)

# Extract results
S, E, I, R, H, D = solution.T

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, H, label='Hospitalized')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIRHD Model using RK4')
plt.grid(True)
plt.show()
