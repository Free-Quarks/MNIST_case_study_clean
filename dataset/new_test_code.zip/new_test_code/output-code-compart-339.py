# SEIRD Model using Runge-Kutta 3 (RK3) Method
import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model
def seird_model(t, y, beta, gamma, delta, alpha):
    S, E, I, R, D = y
    N = S + E + I + R + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - delta * E
    dIdt = delta * E - gamma * I - alpha * I
    dRdt = gamma * I
    dDdt = alpha * I
    return np.array([dSdt, dEdt, dIdt, dRdt, dDdt])

# RK3 integration step
def rk3_step(f, t, y, dt, *args):
    k1 = f(t, y, *args)
    k2 = f(t + dt / 2, y + dt / 2 * k1, *args)
    k3 = f(t + dt, y - dt * k1 + 2 * dt * k2, *args)
    return y + dt / 6 * (k1 + 4 * k2 + k3)

# Parameters
beta = 0.3   # Infection rate
gamma = 0.1  # Recovery rate
delta = 0.1  # Incubation rate
alpha = 0.01 # Mortality rate

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
D0 = 0
y0 = np.array([S0, E0, I0, R0, D0])

# Time vector
t = np.linspace(0, 160, 160)
dt = t[1] - t[0]

# Initialize arrays to store results
results = np.zeros((len(t), len(y0)))
results[0] = y0

# Perform RK3 integration
y = y0
for i in range(1, len(t)):
    y = rk3_step(seird_model, t[i - 1], y, dt, beta, gamma, delta, alpha)
    results[i] = y

# Plot results
plt.plot(t, results[:, 0], label='Susceptible')
plt.plot(t, results[:, 1], label='Exposed')
plt.plot(t, results[:, 2], label='Infected')
plt.plot(t, results[:, 3], label='Recovered')
plt.plot(t, results[:, 4], label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRD Model using RK3 Method')
plt.show()
