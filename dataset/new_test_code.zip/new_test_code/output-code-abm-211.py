import numpy as np
import matplotlib.pyplot as plt

class Person:
    def __init__(self, age_group):
        self.age_group = age_group
        self.infected = False
        self.recovered = False

class Simulation:
    def __init__(self, num_people, transmission_prob, recovery_prob, age_distribution):
        self.num_people = num_people
        self.transmission_prob = transmission_prob
        self.recovery_prob = recovery_prob
        self.age_distribution = age_distribution
        self.people = self.create_population()

    def create_population(self):
        people = []
        for i in range(self.num_people):
            age_group = np.random.choice(list(self.age_distribution.keys()), p=list(self.age_distribution.values()))
            people.append(new Person(age_group))
        return people

    def run_step(self):
        new_infections = []
        for person in self.people:
            if person.infected and not person.recovered:
                for other in self.people:
                    if not other.infected and not other.recovered:
                        if np.random.rand() < self.transmission_prob:
                            new_infections.append(other)
                if np.random.rand() < self.recovery_prob:
                    person.recovered = True
        for person in new_infections:
            person.infected = True

    def run(self, steps):
        history = []
        for step in range(steps):
            self.run_step()
            history.append(self.get_status())
        return history

    def get_status(self):
        status = {'infected': 0, 'recovered': 0, 'susceptible': 0}
        for person in self.people:
            if person.infected:
                status['infected'] += 1
            elif person.recovered:
                status['recovered'] += 1
            else:
                status['susceptible'] += 1
        return status

# Parameters
num_people = 1000
transmission_prob = 0.05
recovery_prob = 0.01
age_distribution = {'0-18': 0.2, '19-35': 0.3, '36-50': 0.3, '51+': 0.2}
steps = 100

# Run simulation
sim = Simulation(num_people, transmission_prob, recovery_prob, age_distribution)
history = sim.run(steps)

# Plot results
infected = [h['infected'] for h in history]
recovered = [h['recovered'] for h in history]
susceptible = [h['susceptible'] for h in history]
plt.plot(infected, label='Infected')
plt.plot(recovered, label='Recovered')
plt.plot(susceptible, label='Susceptible')
plt.xlabel('Steps')
plt.ylabel('Number of People')
plt.legend()
plt.show()
