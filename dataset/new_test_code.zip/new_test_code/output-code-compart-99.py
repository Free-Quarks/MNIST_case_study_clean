# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRHD model
def SEIRHD_model(t, y, beta, sigma, gamma, delta, alpha, mu):
    S, E, I, R, H, D = y
    N = S + E + I + R + H
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I - delta * I - alpha * I
    dR_dt = gamma * I
    dH_dt = delta * I - mu * H
    dD_dt = alpha * I + mu * H
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt, dH_dt, dD_dt])

# Runge-Kutta 3rd order (RK3) method
def RK3_step(f, t, y, dt, *args):
    k1 = f(t, y, *args)
    k2 = f(t + dt/2, y + dt/2 * k1, *args)
    k3 = f(t + dt, y - dt * k1 + 2 * dt * k2, *args)
    return y + dt/6 * (k1 + 4 * k2 + k3)

# Simulation parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Incubation rate
gamma = 1/2.9  # Recovery rate
delta = 0.1  # Hospitalization rate
alpha = 0.01  # Death rate
mu = 0.05  # Death rate in hospital

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
H0 = 0
D0 = 0
initial_conditions = np.array([S0, E0, I0, R0, H0, D0])

# Time vector
t0 = 0
T = 160
dt = 0.1
num_steps = int(T / dt)
time_points = np.linspace(t0, T, num_steps)

# Arrays to store results
results = np.zeros((num_steps, 6))
results[0] = initial_conditions

# Time integration using RK3
for step in range(1, num_steps):
    results[step] = RK3_step(SEIRHD_model, time_points[step-1], results[step-1], dt, beta, sigma, gamma, delta, alpha, mu)

# Plot results
plt.figure(figsize=(12, 8))
plt.plot(time_points, results[:, 0], label='Susceptible')
plt.plot(time_points, results[:, 1], label='Exposed')
plt.plot(time_points, results[:, 2], label='Infectious')
plt.plot(time_points, results[:, 3], label='Recovered')
plt.plot(time_points, results[:, 4], label='Hospitalized')
plt.plot(time_points, results[:, 5], label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRHD Model using RK3')
plt.grid(True)
plt.show()
