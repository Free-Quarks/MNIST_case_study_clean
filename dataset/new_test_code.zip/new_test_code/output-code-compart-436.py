# SEIRD Model Using Euler's Method
import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.3  # infection rate
sigma = 0.1  # incubation rate
gamma = 0.05  # recovery rate
mu = 0.01  # mortality rate
N = 1000  # total population

# Initial conditions
S0 = 999  # susceptible individuals
E0 = 1  # exposed individuals
I0 = 0  # infectious individuals
R0 = 0  # recovered individuals
D0 = 0  # deceased individuals

# Time parameters
T = 160  # days
dt = 1  # time step

# Initialize arrays
S = np.zeros(T)
E = np.zeros(T)
I = np.zeros(T)
R = np.zeros(T)
D = np.zeros(T)

t = np.arange(0, T, dt)

# Initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
D[0] = D0

# Euler's method for SEIRD model
def SEIRD_euler(S, E, I, R, D, beta, sigma, gamma, mu, N, dt):
    for i in range(1, len(t)):
        dS = -beta * S[i-1] * I[i-1] / N
        dE = beta * S[i-1] * I[i-1] / N - sigma * E[i-1]
        dI = sigma * E[i-1] - gamma * I[i-1] - mu * I[i-1]
        dR = gamma * I[i-1]
        dD = mu * I[i-1]
        S[i] = S[i-1] + dS * dt
        E[i] = E[i-1] + dE * dt
        I[i] = I[i-1] + dI * dt
        R[i] = R[i-1] + dR * dt
        D[i] = D[i-1] + dD * dt
    return S, E, I, R, D

# Run the SEIRD model
S, E, I, R, D = SEIRD_euler(S, E, I, R, D, beta, sigma, gamma, mu, N, dt)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.plot(t, D, label='Deceased')
plt.xlabel('Days')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRD Model Using Euler\'s Method')
plt.show()
