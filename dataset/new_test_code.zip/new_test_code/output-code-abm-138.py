# Simulate COVID-19 spread with vaccination using an agent-based model
import numpy as np
import random

class Person:
    def __init__(self, vaccinated=False):
        self.infected = False
        self.vaccinated = vaccinated
        self.days_infected = 0

    def infect(self):
        if not self.vaccinated:
            self.infected = True

    def update(self):
        if self.infected:
            self.days_infected += 1
            if self.days_infected > 14:  # Assume recovery or death after 14 days
                self.infected = False
                self.days_infected = 0

class Simulation:
    def __init__(self, population_size, initial_infected, vaccination_rate):
        self.population = [Person(vaccinated=random.random() < vaccination_rate) for _ in range(population_size)]
        initial_infected_people = random.sample(self.population, initial_infected)
        for person in initial_infected_people:
            person.infect()

    def step(self):
        for person in self.population:
            if person.infected:
                for _ in range(10):  # Each infected person has a chance to infect others
                    other = random.choice(self.population)
                    if not other.infected:
                        other.infect()
            person.update()

    def run(self, steps):
        for _ in range(steps):
            self.step()

if __name__ == '__main__':
    population_size = 1000
    initial_infected = 10
    vaccination_rate = 0.7
    steps = 100

    sim = Simulation(population_size, initial_infected, vaccination_rate)
    sim.run(steps)

    infected_count = sum(p.infected for p in sim.population)
    print(f'Infected after {steps} steps: {infected_count}')

