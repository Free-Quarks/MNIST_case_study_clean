# Agent-Based Model to Simulate COVID-19 with Stratification by Sex

import random
import numpy as np
import matplotlib.pyplot as plt

class Person:
    def __init__(self, sex):
        self.sex = sex
        self.infected = False
        self.days_infected = 0
        self.recovered = False

    def infect(self):
        if not self.recovered and not self.infected:
            self.infected = True
            self.days_infected = 1

    def progress_disease(self):
        if self.infected:
            self.days_infected += 1
            if self.days_infected > 14:  # Assume recovery after 14 days
                self.infected = False
                self.recovered = True

class CovidModel:
    def __init__(self, population_size, initial_infected, transmission_rate, sex_ratio):
        self.population = []
        self.transmission_rate = transmission_rate
        self.day = 0
        self.history = {'male': [], 'female': []}
        self.create_population(population_size, initial_infected, sex_ratio)

    def create_population(self, population_size, initial_infected, sex_ratio):
        for _ in range(population_size):
            sex = 'male' if random.random() < sex_ratio else 'female'
            person = Person(sex)
            self.population.append(person)

        for _ in range(initial_infected):
            self.population[random.randint(0, population_size - 1)].infect()

    def step(self):
        for person in self.population:
            if person.infected:
                for other_person in self.population:
                    if not other_person.infected and not other_person.recovered:
                        if random.random() < self.transmission_rate:
                            other_person.infect()
            person.progress_disease()
        self.record_history()
        self.day += 1

    def record_history(self):
        male_infected = sum(1 for p in self.population if p.sex == 'male' and p.infected)
        female_infected = sum(1 for p in self.population if p.sex == 'female' and p.infected)
        self.history['male'].append(male_infected)
        self.history['female'].append(female_infected)

    def run(self, days):
        for _ in range(days):
            self.step()

    def plot_results(self):
        plt.plot(self.history['male'], label='Male')
        plt.plot(self.history['female'], label='Female')
        plt.xlabel('Days')
        plt.ylabel('Infected Individuals')
        plt.legend()
        plt.show()

# Parameters
population_size = 1000
initial_infected = 10
transmission_rate = 0.03
sex_ratio = 0.5  # Ratio of males in the population

# Running the model
model = CovidModel(population_size, initial_infected, transmission_rate, sex_ratio)
model.run(100)
model.plot_results()

