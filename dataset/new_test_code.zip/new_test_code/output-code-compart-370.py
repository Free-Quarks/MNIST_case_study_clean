import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# Define the SIDARTHE model with compartments S, I, D, A, R, T, H, E
def sidarthe_model(t, y, alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E

    dSdt = - (alpha * S * I + beta * S * D + gamma * S * A + delta * S * R)
    dIdt = (alpha * S * I + beta * S * D + gamma * S * A + delta * S * R) - (epsilon * I + zeta * I + lambda_ * I)
    dDdt = epsilon * I - (eta * D + theta * D + mu * D)
    dAdt = eta * D - (nu * A + tau * A)
    dRdt = zeta * I - (lambda_ * R + theta * R + tau * R)
    dTdt = theta * D + theta * R - (nu * T + tau * T)
    dHdt = nu * A + nu * T + nu * R
    dEdt = lambda_ * I + lambda_ * R + lambda_ * H

    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Initial conditions
S0 = 0.99
I0 = 0.01
D0 = 0.0
A0 = 0.0
R0 = 0.0
T0 = 0.0
H0 = 0.0
E0 = 0.0

# Parameters
alpha = 0.5
beta = 0.1
gamma = 0.1
delta = 0.1
epsilon = 0.1
theta = 0.1
zeta = 0.1
eta = 0.1
mu = 0.1
nu = 0.1
tau = 0.1
lambda_ = 0.1

# Time span
t_span = (0, 160)
# Time points
t_eval = np.linspace(t_span[0], t_span[1], 1000)

# Initial state
y0 = [S0, I0, D0, A0, R0, T0, H0, E0]

# Solve the differential equations using RK4 method
sol = solve_ivp(sidarthe_model, t_span, y0, args=(alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_), t_eval=t_eval, method='RK45')

# Plot the results
plt.figure(figsize=(10, 8))
plt.plot(sol.t, sol.y[0], label='Susceptible')
plt.plot(sol.t, sol.y[1], label='Infected')
plt.plot(sol.t, sol.y[2], label='Diagnosed')
plt.plot(sol.t, sol.y[3], label='Ailing')
plt.plot(sol.t, sol.y[4], label='Recognized')
plt.plot(sol.t, sol.y[5], label='Threatened')
plt.plot(sol.t, sol.y[6], label='Healed')
plt.plot(sol.t, sol.y[7], label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of population')
plt.legend()
plt.title('SIDARTHE Model')
plt.grid(True)
plt.show()
