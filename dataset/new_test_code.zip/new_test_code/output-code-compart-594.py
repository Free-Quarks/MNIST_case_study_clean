# SIDARTHE Model Simulation using Runge-Kutta 3rd Order (RK3) Method

import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.5  # Infection rate
sigma = 0.1  # Detection rate
eta = 0.05  # Death rate
rho = 0.05  # Recovery rate
alpha = 0.1  # Transition to symptomatic
gamma = 0.05  # Transition to severe symptomatic
mu = 0.01  # Transition to hospitalized

# Time-step and duration
dt = 0.1
T = 160

# Initial conditions
S0 = 0.99
I0 = 0.01
D0 = 0.0
A0 = 0.0
R0 = 0.0
T0 = 0.0
H0 = 0.0
E0 = 0.0

# Number of steps
N = int(T / dt)

# Arrays to store the results
S = np.zeros(N)
I = np.zeros(N)
D = np.zeros(N)
A = np.zeros(N)
R = np.zeros(N)
T = np.zeros(N)
H = np.zeros(N)
E = np.zeros(N)

# Initial conditions
S[0] = S0
I[0] = I0
D[0] = D0
A[0] = A0
R[0] = R0
T[0] = T0
H[0] = H0
E[0] = E0

# SIDARTHE model equations
def sidarthe(S, I, D, A, R, T, H, E):
    dS = -beta * S * I
    dI = beta * S * I - sigma * I - alpha * I
    dD = sigma * I - eta * D - rho * D
    dA = alpha * I - gamma * A - mu * A
    dR = rho * D
    dT = gamma * A
    dH = mu * A
    dE = eta * D
    return dS, dI, dD, dA, dR, dT, dH, dE

# Runge-Kutta 3rd Order method
for n in range(N - 1):
    dS1, dI1, dD1, dA1, dR1, dT1, dH1, dE1 = sidarthe(S[n], I[n], D[n], A[n], R[n], T[n], H[n], E[n])
    dS2, dI2, dD2, dA2, dR2, dT2, dH2, dE2 = sidarthe(S[n] + 0.5 * dt * dS1, I[n] + 0.5 * dt * dI1, D[n] + 0.5 * dt * dD1, A[n] + 0.5 * dt * dA1, R[n] + 0.5 * dt * dR1, T[n] + 0.5 * dt * dT1, H[n] + 0.5 * dt * dH1, E[n] + 0.5 * dt * dE1)
    dS3, dI3, dD3, dA3, dR3, dT3, dH3, dE3 = sidarthe(S[n] + 0.75 * dt * dS2, I[n] + 0.75 * dt * dI2, D[n] + 0.75 * dt * dD2, A[n] + 0.75 * dt * dA2, R[n] + 0.75 * dt * dR2, T[n] + 0.75 * dt * dT2, H[n] + 0.75 * dt * dH2, E[n] + 0.75 * dt * dE2)

    S[n + 1] = S[n] + dt * (2 * dS1 + 3 * dS2 + 4 * dS3) / 9
    I[n + 1] = I[n] + dt * (2 * dI1 + 3 * dI2 + 4 * dI3) / 9
    D[n + 1] = D[n] + dt * (2 * dD1 + 3 * dD2 + 4 * dD3) / 9
    A[n + 1] = A[n] + dt * (2 * dA1 + 3 * dA2 + 4 * dA3) / 9
    R[n + 1] = R[n] + dt * (2 * dR1 + 3 * dR2 + 4 * dR3) / 9
    T[n + 1] = T[n] + dt * (2 * dT1 + 3 * dT2 + 4 * dT3) / 9
    H[n + 1] = H[n] + dt * (2 * dH1 + 3 * dH2 + 4 * dH3) / 9
    E[n + 1] = E[n] + dt * (2 * dE1 + 3 * dE2 + 4 * dE3) / 9

# Plot the results
plt.figure(figsize=(12, 6))
plt.plot(np.arange(N) * dt, S, label='Susceptible')
plt.plot(np.arange(N) * dt, I, label='Infected')
plt.plot(np.arange(N) * dt, D, label='Diagnosed')
plt.plot(np.arange(N) * dt, A, label='Ailing')
plt.plot(np.arange(N) * dt, R, label='Recognized')
plt.plot(np.arange(N) * dt, T, label='Threatened')
plt.plot(np.arange(N) * dt, H, label='Healed')
plt.plot(np.arange(N) * dt, E, label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SIDARTHE Model Simulation')
plt.grid(True)
plt.show()
