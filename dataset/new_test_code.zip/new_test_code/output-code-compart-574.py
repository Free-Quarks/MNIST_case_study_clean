# SEIRHD model simulation using Runge-Kutta 3rd order (RK3) method

import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Rate of progression from exposed to infectious
gamma = 1/2.3  # Recovery rate
mu = 0.01  # Mortality rate
N = 1000  # Total population
I0 = 1  # Initial number of infectious individuals
E0 = 0  # Initial number of exposed individuals
R0 = 0  # Initial number of recovered individuals
H0 = 0  # Initial number of hospitalized individuals
D0 = 0  # Initial number of deceased individuals
S0 = N - I0 - E0 - R0 - H0 - D0  # Initial number of susceptible individuals

# Time parameters
T = 160  # Total time in days
dt = 0.1  # Time step

# SEIRHD model equations
def deriv(y, t, beta, sigma, gamma, mu, N):
    S, E, I, R, H, D = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - mu * I
    dRdt = gamma * I
    dHdt = mu * I
    dDdt = mu * I
    return dSdt, dEdt, dIdt, dRdt, dHdt, dDdt

# Runge-Kutta 3rd order method (RK3)
def rk3_step(y, t, dt, deriv, *args):
    k1 = np.array(deriv(y, t, *args))
    k2 = np.array(deriv(y + 0.5 * dt * k1, t + 0.5 * dt, *args))
    k3 = np.array(deriv(y - dt * k1 + 2 * dt * k2, t + dt, *args))
    return y + (dt / 6) * (k1 + 4 * k2 + k3)

# Initial conditions vector
y0 = S0, E0, I0, R0, H0, D0

# Time points
t = np.arange(0, T, dt)

# Initialize result arrays
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))
H = np.zeros(len(t))
D = np.zeros(len(t))

# Initial conditions
S[0], E[0], I[0], R[0], H[0], D[0] = y0

# Integrate the SEIRHD equations over the time grid, t.
for i in range(1, len(t)):
    y0 = rk3_step(y0, t[i-1], dt, deriv, beta, sigma, gamma, mu, N)
    S[i], E[i], I[i], R[i], H[i], D[i] = y0

# Plot the data
plt.figure(figsize=(10,6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infectious')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.plot(t, H, 'c', alpha=0.7, linewidth=2, label='Hospitalized')
plt.plot(t, D, 'k', alpha=0.7, linewidth=2, label='Deceased')
plt.xlabel('Time /days')
plt.ylabel('Number (1000s)')
plt.legend(loc='best')
plt.title('SEIRHD model simulation using RK3')
plt.show()

