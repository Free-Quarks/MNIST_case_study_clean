# Agent-based Model to Simulate COVID-19 with Stratification

import random
import numpy as np
import matplotlib.pyplot as plt

# Define the population size and initial conditions
population_size = 1000
initial_infected = 10
initial_recovered = 0
initial_susceptible = population_size - initial_infected - initial_recovered

# Define disease parameters
infection_rate = 0.05
recovery_rate = 0.01

# Stratification: Age groups (0-18, 19-65, 65+)
age_groups = {'0-18': 0.2, '19-65': 0.6, '65+': 0.2}
age_group_population = {key: int(population_size * proportion) for key, proportion in age_groups.items()}

# Initialize the population: status can be 'susceptible', 'infected', or 'recovered'
population = []
for age_group, count in age_group_population.items():
    for _ in range(count):
        if initial_infected > 0:
            population.append({'age_group': age_group, 'status': 'infected'})
            initial_infected -= 1
        elif initial_recovered > 0:
            population.append({'age_group': age_group, 'status': 'recovered'})
            initial_recovered -= 1
        else:
            population.append({'age_group': age_group, 'status': 'susceptible'})

# Function to simulate a single day
def simulate_day(population, infection_rate, recovery_rate):
    new_infected = []
    new_recovered = []
    for person in population:
        if person['status'] == 'infected':
            if random.random() < recovery_rate:
                new_recovered.append(person)
        elif person['status'] == 'susceptible':
            if random.random() < infection_rate:
                new_infected.append(person)
    for person in new_infected:
        person['status'] = 'infected'
    for person in new_recovered:
        person['status'] = 'recovered'

# Simulation for a certain number of days
def run_simulation(days, infection_rate, recovery_rate):
    susceptible_count = []
    infected_count = []
    recovered_count = []
    for _ in range(days):
        susceptible_count.append(sum(1 for person in population if person['status'] == 'susceptible'))
        infected_count.append(sum(1 for person in population if person['status'] == 'infected'))
        recovered_count.append(sum(1 for person in population if person['status'] == 'recovered'))
        simulate_day(population, infection_rate, recovery_rate)
    return susceptible_count, infected_count, recovered_count

# Run the simulation
susceptible_count, infected_count, recovered_count = run_simulation(160, infection_rate, recovery_rate)

# Plot the results
plt.plot(susceptible_count, label='Susceptible')
plt.plot(infected_count, label='Infected')
plt.plot(recovered_count, label='Recovered')
plt.xlabel('Days')
plt.ylabel('Number of people')
plt.legend()
plt.show()
