# SIDARTHE Model with RK4 Method

import numpy as np
import matplotlib.pyplot as plt

# Define the SIDARTHE model differential equations
def sidarthe_model(t, y, alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_, kappa, xi, rho, sigma, phi, chi, psi, omega):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E

    dS_dt = -alpha * S * I / N - beta * S * D / N - gamma * S * A / N - delta * S * R / N
    dI_dt = alpha * S * I / N + beta * S * D / N + gamma * S * A / N + delta * S * R / N - epsilon * I - zeta * I - lambda_ * I
    dD_dt = epsilon * I - eta * D - theta * D - mu * D
    dA_dt = zeta * I - eta * A - nu * A - kappa * A
    dR_dt = eta * D + eta * A - theta * R - rho * R - sigma * R
    dT_dt = theta * D + theta * R - chi * T - phi * T - psi * T
    dH_dt = nu * A + rho * R - chi * H - omega * H
    dE_dt = lambda_ * I + mu * D + kappa * A + sigma * R + phi * T + omega * H + psi * T

    return np.array([dS_dt, dI_dt, dD_dt, dA_dt, dR_dt, dT_dt, dH_dt, dE_dt])

# Runge-Kutta 4th Order Method (RK4)
def rk4_step(f, t, y, dt, *args):
    k1 = dt * f(t, y, *args)
    k2 = dt * f(t + dt / 2, y + k1 / 2, *args)
    k3 = dt * f(t + dt / 2, y + k2 / 2, *args)
    k4 = dt * f(t + dt, y + k3, *args)
    return y + (k1 + 2 * k2 + 2 * k3 + k4) / 6

# Parameters (these values should be adjusted based on real data)
alpha = 0.2
beta = 0.1
gamma = 0.05
delta = 0.01
epsilon = 0.1
theta = 0.1
zeta = 0.05
eta = 0.1
mu = 0.01
nu = 0.02
tau = 0.01
lambda_ = 0.01
kappa = 0.01
xi = 0.01
rho = 0.01
sigma = 0.01
phi = 0.01
chi = 0.01
psi = 0.01
omega = 0.01

# Initial conditions (these values should be adjusted based on real data)
S0 = 0.99
I0 = 0.01
D0 = 0
A0 = 0
R0 = 0
T0 = 0
H0 = 0
E0 = 0

# Time settings
t0 = 0
t_end = 160
dt = 0.1
t = np.arange(t0, t_end, dt)

# Initial state vector
y0 = np.array([S0, I0, D0, A0, R0, T0, H0, E0])

# Integrate the SIDARTHE equations over time using RK4
y = np.zeros((len(t), len(y0)))
y[0] = y0
for i in range(1, len(t)):
    y[i] = rk4_step(sidarthe_model, t[i-1], y[i-1], dt, alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_, kappa, xi, rho, sigma, phi, chi, psi, omega)

# Plot the results
plt.figure(figsize=(12, 8))
plt.plot(t, y[:, 0], label='Susceptible (S)')
plt.plot(t, y[:, 1], label='Infected (I)')
plt.plot(t, y[:, 2], label='Diagnosed (D)')
plt.plot(t, y[:, 3], label='Ailing (A)')
plt.plot(t, y[:, 4], label='Recognized (R)')
plt.plot(t, y[:, 5], label='Threatened (T)')
plt.plot(t, y[:, 6], label='Healed (H)')
plt.plot(t, y[:, 7], label='Extinct (E)')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of Population')
plt.legend()
plt.title('SIDARTHE Model Simulation')
plt.grid()
plt.show()
