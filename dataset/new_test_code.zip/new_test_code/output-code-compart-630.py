import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # infection rate
gamma = 0.1  # recovery rate

# Initial conditions
S0 = 0.99  # initial susceptible fraction
I0 = 0.01  # initial infected fraction
R0 = 0.0  # initial recovered fraction

# Total population, N.
N = 1.0

# Time points
T = 160  # total time
dt = 0.1  # time step

# Initialize arrays
S = np.zeros(int(T/dt))
I = np.zeros(int(T/dt))
R = np.zeros(int(T/dt))

t = np.linspace(0, T, int(T/dt))

# Initial values
S[0] = S0
I[0] = I0
R[0] = R0

# SIR model differential equations
def deriv(S, I, R, beta, gamma):
    dSdt = -beta * S * I
    dIdt = beta * S * I - gamma * I
    dRdt = gamma * I
    return dSdt, dIdt, dRdt

# Runge-Kutta 4th order method (RK4)
for i in range(1, len(t)):
    k1_S, k1_I, k1_R = deriv(S[i-1], I[i-1], R[i-1], beta, gamma)
    k2_S, k2_I, k2_R = deriv(S[i-1] + k1_S*dt/2, I[i-1] + k1_I*dt/2, R[i-1] + k1_R*dt/2, beta, gamma)
    k3_S, k3_I, k3_R = deriv(S[i-1] + k2_S*dt/2, I[i-1] + k2_I*dt/2, R[i-1] + k2_R*dt/2, beta, gamma)
    k4_S, k4_I, k4_R = deriv(S[i-1] + k3_S*dt, I[i-1] + k3_I*dt, R[i-1] + k3_R*dt, beta, gamma)

    S[i] = S[i-1] + (k1_S + 2*k2_S + 2*k3_S + k4_S) * dt / 6
    I[i] = I[i-1] + (k1_I + 2*k2_I + 2*k3_I + k4_I) * dt / 6
    R[i] = R[i-1] + (k1_R + 2*k2_R + 2*k3_R + k4_R) * dt / 6

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', label='Susceptible')
plt.plot(t, I, 'r', label='Infected')
plt.plot(t, R, 'g', label='Recovered')
plt.xlabel('Time /days')
plt.ylabel('Fraction')
plt.legend()
plt.title('SIR Model using RK4')
plt.show()
