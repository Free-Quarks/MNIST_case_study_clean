# Import necessary libraries
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import random

# Define the parameters
population_size = 1000
initial_infected = 10
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
stratification = ['age', 'comorbidity']
age_groups = {'child': 0.2, 'adult': 0.5, 'elderly': 0.3}
comorbidity_rate = 0.2

def create_population(population_size, age_groups, comorbidity_rate):
    population = []
    for _ in range(population_size):
        age_group = np.random.choice(list(age_groups.keys()), p=list(age_groups.values()))
        has_comorbidity = np.random.rand() < comorbidity_rate
        population.append({'age_group': age_group, 'comorbidity': has_comorbidity, 'state': 'S'})
    return population

# Initialize the population
def initialize_infection(population, initial_infected):
    infected_indices = random.sample(range(len(population)), initial_infected)
    for idx in infected_indices:
        population[idx]['state'] = 'I'

# Create a network
G = nx.erdos_renyi_graph(population_size, 0.1)

# Create the population and initialize infection
population = create_population(population_size, age_groups, comorbidity_rate)
initialize_infection(population, initial_infected)

# Function to simulate one time step
def simulate_step(G, population, beta, gamma):
    new_population = population.copy()
    for node in G.nodes:
        if population[node]['state'] == 'I':
            for neighbor in G.neighbors(node):
                if population[neighbor]['state'] == 'S' and random.random() < beta:
                    new_population[neighbor]['state'] = 'I'
            if random.random() < gamma:
                new_population[node]['state'] = 'R'
    return new_population

# Run the simulation for a given number of steps
def run_simulation(G, population, beta, gamma, steps):
    history = []
    for _ in range(steps):
        population = simulate_step(G, population, beta, gamma)
        history.append(population)
    return history

# Run the simulation
steps = 100
history = run_simulation(G, population, beta, gamma, steps)

# Visualize the results
def visualize(history):
    S = [sum(1 for person in step if person['state'] == 'S') for step in history]
    I = [sum(1 for person in step if person['state'] == 'I') for step in history]
    R = [sum(1 for person in step if person['state'] == 'R') for step in history]
    plt.plot(S, label='Susceptible')
    plt.plot(I, label='Infected')
    plt.plot(R, label='Recovered')
    plt.xlabel('Time Steps')
    plt.ylabel('Number of People')
    plt.legend()
    plt.show()

# Visualize the simulation results
visualize(history)

