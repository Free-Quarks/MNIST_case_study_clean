# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Define the SIDARTHE model equations
def SIDARTHE(t, y, beta, gamma, delta, alpha, theta, eta, mu, nu, tau, lambda_):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E
    dSdt = -beta * S * (I + D + A) / N
    dIdt = beta * S * (I + D + A) / N - gamma * I - delta * I
    dDdt = delta * I - alpha * D - theta * D
    dAdt = alpha * D - eta * A - mu * A
    dRdt = gamma * I + theta * D + nu * A - tau * R
    dTdt = tau * R - lambda_ * T
    dHdt = eta * A + mu * A - nu * H
    dEdt = lambda_ * T
    return np.array([dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt])

# Define the RK3 method
def RK3_step(f, t, y, h, *args):
    k1 = h * f(t, y, *args)
    k2 = h * f(t + h/2, y + k1/2, *args)
    k3 = h * f(t + h, y - k1 + 2*k2, *args)
    return y + (k1 + 4*k2 + k3) / 6

# Initial conditions and parameters
S0, I0, D0, A0, R0, T0, H0, E0 = 0.99, 0.01, 0, 0, 0, 0, 0, 0
initial_conditions = np.array([S0, I0, D0, A0, R0, T0, H0, E0])

beta, gamma, delta, alpha, theta, eta, mu, nu, tau, lambda_ = 0.5, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1
params = (beta, gamma, delta, alpha, theta, eta, mu, nu, tau, lambda_)

# Time settings
t0, tf, h = 0, 160, 0.1
num_steps = int((tf - t0) / h)
t_values = np.linspace(t0, tf, num_steps)

# Arrays to store solutions
y_values = np.zeros((num_steps, len(initial_conditions)))
y_values[0] = initial_conditions

t = t0

# Run the RK3 method
y = initial_conditions
for i in range(1, num_steps):
    y = RK3_step(SIDARTHE, t, y, h, *params)
    t += h
    y_values[i] = y

# Plot the results
plt.figure(figsize=(12, 8))
labels = ["S", "I", "D", "A", "R", "T", "H", "E"]
for i in range(len(initial_conditions)):
    plt.plot(t_values, y_values[:, i], label=labels[i])
plt.xlabel("Time (days)")
plt.ylabel("Proportion of population")
plt.title("SIDARTHE model simulation using RK3")
plt.legend()
plt.show()
