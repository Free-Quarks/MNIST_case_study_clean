# Import necessary libraries
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt

# Define the SEIR model parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
sigma = 0.1  # Rate at which exposed individuals become infectious

# Define the population size and initial conditions
N = 1000  # Total population
initial_infected = 10
initial_exposed = 5
initial_recovered = 0
initial_susceptible = N - initial_infected - initial_exposed - initial_recovered

# Create a network
G = nx.erdos_renyi_graph(N, 0.1)  # Random graph

# Stratify the population (e.g., by age group)
stratification = {'young': 0.4, 'adult': 0.5, 'elderly': 0.1}
stratified_population = {
    'young': int(N * stratification['young']),
    'adult': int(N * stratification['adult']),
    'elderly': int(N * stratification['elderly'])
}

# Initialize the state of each node (S, E, I, R)
state = {i: 'S' for i in range(N)}
for i in np.random.choice(N, initial_infected, replace=False):
    state[i] = 'I'
for i in np.random.choice(N, initial_exposed, replace=False):
    state[i] = 'E'

# Function to simulate one time step
def simulate_step(state):
    new_state = state.copy()
    for node in G.nodes():
        if state[node] == 'I':
            for neighbor in G.neighbors(node):
                if state[neighbor] == 'S' and np.random.rand() < beta:
                    new_state[neighbor] = 'E'
            if np.random.rand() < gamma:
                new_state[node] = 'R'
        elif state[node] == 'E':
            if np.random.rand() < sigma:
                new_state[node] = 'I'
    return new_state

# Simulate the epidemic
num_steps = 160
states_over_time = [state]
for _ in range(num_steps):
    new_state = simulate_step(states_over_time[-1])
    states_over_time.append(new_state)

# Plot the results
susceptible = [sum(1 for s in state.values() if s == 'S') for state in states_over_time]
exposed = [sum(1 for s in state.values() if s == 'E') for state in states_over_time]
infected = [sum(1 for s in state.values() if s == 'I') for state in states_over_time]
recovered = [sum(1 for s in state.values() if s == 'R') for state in states_over_time]

plt.plot(susceptible, label='Susceptible')
plt.plot(exposed, label='Exposed')
plt.plot(infected, label='Infected')
plt.plot(recovered, label='Recovered')
plt.legend()
plt.xlabel('Time Steps')
plt.ylabel('Number of Individuals')
plt.title('SEIR Model Simulation on a Network')
plt.show()
