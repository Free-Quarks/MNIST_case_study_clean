# SIDARTHE model simulation using Runge-Kutta 2 (RK2) method
import numpy as np
import matplotlib.pyplot as plt

# Define the model parameters
params = {
    'alpha': 0.57,  # infection rate
    'beta': 0.011,   # detection rate
    'gamma': 0.456,  # recovery rate (diagnosed)
    'delta': 0.011,  # mortality rate (diagnosed)
    'epsilon': 0.171, # infection rate (undetected)
    'zeta': 0.370,   # detection rate (undetected)
    'eta': 0.125,    # recovery rate (undetected)
    'theta': 0.125   # mortality rate (undetected)
}

# Initial conditions
initial_conditions = {
    'S': 0.999,  # susceptible
    'I': 0.001,  # infected (undetected)
    'D': 0.0,    # diagnosed
    'A': 0.0,    # ailing
    'R': 0.0,    # recognized
    'T': 0.0,    # threatened
    'H': 0.0,    # healed
    'E': 0.0     # extinct
}

# Time span (in days)
t_max = 100
h = 0.1  # time step

# Function to compute the derivatives

def derivatives(S, I, D, A, R, T, H, E, params):
    dS_dt = -params['alpha']*S*(I + D + A + R) - params['epsilon']*S*(I + D + A + R)
    dI_dt = params['alpha']*S*(I + D + A + R) - params['beta']*I - params['epsilon']*S*(I + D + A + R)
    dD_dt = params['beta']*I - params['gamma']*D - params['delta']*D
    dA_dt = params['gamma']*D - params['eta']*A - params['theta']*A
    dR_dt = params['eta']*A - params['zeta']*R - params['theta']*R
    dT_dt = params['zeta']*R - params['theta']*T
    dH_dt = params['theta']*T
    dE_dt = params['delta']*D + params['theta']*A + params['theta']*R + params['theta']*T
    return dS_dt, dI_dt, dD_dt, dA_dt, dR_dt, dT_dt, dH_dt, dE_dt

# Runge-Kutta 2 (RK2) method

def rk2_step(S, I, D, A, R, T, H, E, h, params):
    k1 = derivatives(S, I, D, A, R, T, H, E, params)
    k2 = derivatives(S + h*k1[0]/2, I + h*k1[1]/2, D + h*k1[2]/2, A + h*k1[3]/2, R + h*k1[4]/2, T + h*k1[5]/2, H + h*k1[6]/2, E + h*k1[7]/2, params)
    S_next = S + h * k2[0]
    I_next = I + h * k2[1]
    D_next = D + h * k2[2]
    A_next = A + h * k2[3]
    R_next = R + h * k2[4]
    T_next = T + h * k2[5]
    H_next = H + h * k2[6]
    E_next = E + h * k2[7]
    return S_next, I_next, D_next, A_next, R_next, T_next, H_next, E_next

# Simulation

# Initialize values
S = initial_conditions['S']
I = initial_conditions['I']
D = initial_conditions['D']
A = initial_conditions['A']
R = initial_conditions['R']
T = initial_conditions['T']
H = initial_conditions['H']
E = initial_conditions['E']

# Time points
time_points = np.arange(0, t_max, h)

# Arrays to store the results
S_values = []
I_values = []
D_values = []
A_values = []
R_values = []
T_values = []
H_values = []
E_values = []

# Run the simulation
for t in time_points:
    S_values.append(S)
    I_values.append(I)
    D_values.append(D)
    A_values.append(A)
    R_values.append(R)
    T_values.append(T)
    H_values.append(H)
    E_values.append(E)
    S, I, D, A, R, T, H, E = rk2_step(S, I, D, A, R, T, H, E, h, params)

# Plotting the results
plt.figure(figsize=(12, 8))
plt.plot(time_points, S_values, label='Susceptible')
plt.plot(time_points, I_values, label='Infected (undetected)')
plt.plot(time_points, D_values, label='Diagnosed')
plt.plot(time_points, A_values, label='Ailing')
plt.plot(time_points, R_values, label='Recognized')
plt.plot(time_points, T_values, label='Threatened')
plt.plot(time_points, H_values, label='Healed')
plt.plot(time_points, E_values, label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Population Fraction')
plt.legend()
plt.title('SIDARTHE Model Simulation')
plt.grid(True)
plt.show()
