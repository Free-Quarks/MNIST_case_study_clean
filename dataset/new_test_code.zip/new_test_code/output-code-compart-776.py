# SIR Model using Euler's Method

import numpy as np
import matplotlib.pyplot as plt

# Total population, N.
N = 1000
# Initial number of infected and recovered individuals, I0 and R0.
I0, R0 = 1, 0
# Everyone else, S0, is susceptible to infection initially.
S0 = N - I0 - R0
# Contact rate, beta, and mean recovery rate, gamma, (in 1/days).
beta, gamma = 0.3, 1./10 
# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# SIR model differential equations.
def deriv(S, I, R, beta, gamma):
    dSdt = -beta * S * I / N
    dIdt = beta * S * I / N - gamma * I
    dRdt = gamma * I
    return dSdt, dIdt, dRdt

# Initial conditions vector
S, I, R = S0, I0, R0

# Lists to store the results
S_list = [S]
I_list = [I]
R_list = [R]

# Integrate the SIR equations over the time grid.
for _ in range(1, len(t)):
    dSdt, dIdt, dRdt = deriv(S, I, R, beta, gamma)
    S += dSdt
    I += dIdt
    R += dRdt
    S_list.append(S)
    I_list.append(I)
    R_list.append(R)

# Plot the data on three separate curves for S(t), I(t) and R(t)
plt.figure(figsize=(10, 6))
plt.plot(t, S_list, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, I_list, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, R_list, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.xlabel('Time /days')
plt.ylabel('Number')
plt.legend()
plt.show()

