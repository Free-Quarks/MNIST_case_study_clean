# This code simulates the SIR model using the Runge-Kutta 4th order (RK4) method
import numpy as np
import matplotlib.pyplot as plt

# Define the SIR model differential equations
def sir_model(y, beta, gamma):
    S, I, R = y
    dS_dt = -beta * S * I
    dI_dt = beta * S * I - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dI_dt, dR_dt])

# Runge-Kutta 4th order method
def rk4_step(func, y, dt, *args):
    k1 = dt * func(y, *args)
    k2 = dt * func(y + 0.5 * k1, *args)
    k3 = dt * func(y + 0.5 * k2, *args)
    k4 = dt * func(y + k3, *args)
    return y + (k1 + 2 * k2 + 2 * k3 + k4) / 6

# Initial conditions
def run_simulation(S0, I0, R0, beta, gamma, days):
    dt = 1.0  # time step (days)
    t = np.linspace(0, days, int(days/dt))
    y = np.zeros((len(t), 3))
    y[0] = [S0, I0, R0]

    # Run the RK4 integration
    for i in range(1, len(t)):
        y[i] = rk4_step(sir_model, y[i-1], dt, beta, gamma)

    # Plot the results
    plt.figure(figsize=(10, 6))
    plt.plot(t, y[:, 0], label='Susceptible')
    plt.plot(t, y[:, 1], label='Infected')
    plt.plot(t, y[:, 2], label='Recovered')
    plt.xlabel('Days')
    plt.ylabel('Population')
    plt.legend()
    plt.title('SIR Model Simulation')
    plt.grid()
    plt.show()

    return y

# Example usage
S0 = 0.99  # Initial susceptible population
I0 = 0.01  # Initial infected population
R0 = 0.0   # Initial recovered population
beta = 0.3 # Infection rate
gamma = 0.1 # Recovery rate

# Run the simulation for 160 days
results = run_simulation(S0, I0, R0, beta, gamma, 160)
