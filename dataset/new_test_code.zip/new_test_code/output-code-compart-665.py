import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model differential equations
def SEIRD(t, y, beta, sigma, gamma, delta):
    S, E, I, R, D = y
    N = S + E + I + R + D
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I - delta * I
    dR_dt = gamma * I
    dD_dt = delta * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt, dD_dt])

# Implement the Runge-Kutta 4th order method
def rk4_step(f, t, y, dt, *args):
    k1 = dt * f(t, y, *args)
    k2 = dt * f(t + 0.5 * dt, y + 0.5 * k1, *args)
    k3 = dt * f(t + 0.5 * dt, y + 0.5 * k2, *args)
    k4 = dt * f(t + dt, y + k3, *args)
    return y + (k1 + 2 * k2 + 2 * k3 + k4) / 6

# Simulate the SEIRD model
def simulate_SEIRD(beta, sigma, gamma, delta, S0, E0, I0, R0, D0, t_max, dt):
    t_values = np.arange(0, t_max, dt)
    S_values = [S0]
    E_values = [E0]
    I_values = [I0]
    R_values = [R0]
    D_values = [D0]
    y = np.array([S0, E0, I0, R0, D0])
    for t in t_values[:-1]:
        y = rk4_step(SEIRD, t, y, dt, beta, sigma, gamma, delta)
        S_values.append(y[0])
        E_values.append(y[1])
        I_values.append(y[2])
        R_values.append(y[3])
        D_values.append(y[4])
    return t_values, S_values, E_values, I_values, R_values, D_values

# Parameters
beta = 0.3  # Infection rate
sigma = 0.2  # Inverse of incubation period
gamma = 0.1  # Recovery rate
delta = 0.01  # Mortality rate
S0 = 999  # Initial number of susceptible individuals
E0 = 1    # Initial number of exposed individuals
I0 = 0    # Initial number of infectious individuals
R0 = 0    # Initial number of recovered individuals
D0 = 0    # Initial number of deceased individuals
t_max = 160  # Time to run the simulation
dt = 1  # Time step

t_values, S_values, E_values, I_values, R_values, D_values = simulate_SEIRD(
    beta, sigma, gamma, delta, S0, E0, I0, R0, D0, t_max, dt
)

# Plot the results
plt.plot(t_values, S_values, label='Susceptible')
plt.plot(t_values, E_values, label='Exposed')
plt.plot(t_values, I_values, label='Infectious')
plt.plot(t_values, R_values, label='Recovered')
plt.plot(t_values, D_values, label='Deceased')
plt.xlabel('Time')
plt.ylabel('Population')
plt.legend()
plt.show()
