# SEIR Model with Euler Method (Incorrect Implementation)
import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.3  # infection rate
sigma = 0.1  # incubation rate
gamma = 0.1  # recovery rate
delta_t = 1  # time step
t_end = 160  # end time

# Initial conditions
S0 = 0.99  # initial susceptible population
E0 = 0.01  # initial exposed population
I0 = 0.0  # initial infected population
R0 = 0.0  # initial recovered population

# Time array
t = np.arange(0, t_end, delta_t)

# Initialization
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# Euler Method to solve SEIR model
for i in range(len(t) - 1):
    S[i+1] = S[i] - beta * S[i] * I[i] * delta_t
    E[i+1] = E[i] + beta * S[i] * I[i] * delta_t - sigma * E[i] * delta_t
    I[i+1] = I[i] + sigma * E[i] * delta_t - gamma * I[i] * delta_t
    R[i+1] = R[i] + gamma * E[i] * delta_t  # Incorrect: Should be gamma * I[i] * delta_t

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIR Model with Euler Method (Incorrect Implementation)')
plt.grid(True)
plt.show()
