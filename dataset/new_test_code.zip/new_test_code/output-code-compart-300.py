
import numpy as np

class SEIRHDModel:
    def __init__(self, S0, E0, I0, R0, H0, D0, beta, sigma, gamma, delta, mu):
        self.S = S0
        self.E = E0
        self.I = I0
        self.R = R0
        self.H = H0
        self.D = D0
        self.beta = beta
        self.sigma = sigma
        self.gamma = gamma
        self.delta = delta
        self.mu = mu

    def derivatives(self, y):
        S, E, I, R, H, D = y
        N = S + E + I + R + H + D

        dS = -self.beta * S * I / N
        dE = self.beta * S * I / N - self.sigma * E
        dI = self.sigma * E - (self.gamma + self.delta + self.mu) * I
        dR = self.gamma * I
        dH = self.delta * I
        dD = self.mu * I

        return np.array([dS, dE, dI, dR, dH, dD])

    def rk4_step(self, y, dt):
        k1 = self.derivatives(y)
        k2 = self.derivatives(y + dt / 2 * k1)
        k3 = self.derivatives(y + dt / 2 * k2)
        k4 = self.derivatives(y + dt * k3)

        return y + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)

    def run(self, days, dt=1):
        results = []
        y = np.array([self.S, self.E, self.I, self.R, self.H, self.D])

        for _ in range(days):
            results.append(y)
            y = self.rk4_step(y, dt)

        return np.array(results)

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
H0 = 0
D0 = 0

# Parameters
beta = 0.3
sigma = 1/5.2
gamma = 1/2.9
delta = 1/10
mu = 0.01

# Simulation
model = SEIRHDModel(S0, E0, I0, R0, H0, D0, beta, sigma, gamma, delta, mu)
results = model.run(160)

# Print results
for day, (S, E, I, R, H, D) in enumerate(results):
    print(f"Day {day}: S={S:.2f}, E={E:.2f}, I={I:.2f}, R={R:.2f}, H={H:.2f}, D={D:.2f}")
  
