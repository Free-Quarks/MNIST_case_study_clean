import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# SEIRD model differential equations.
def deriv(y, t, N, beta, gamma, delta, alpha):
    S, E, I, R, D = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - delta * E
    dIdt = delta * E - (gamma + alpha) * I
    dRdt = gamma * I
    dDdt = alpha * I
    return dSdt, dEdt, dIdt, dRdt, dDdt

# Initial number of infected and recovered individuals, everyone else is susceptible to infection initially.
N = 1000
E0, I0, R0, D0 = 1, 1, 0, 0
S0 = N - E0 - I0 - R0 - D0

# Contact rate, beta, mean recovery rate, gamma, mean incubation rate, delta, and mortality rate, alpha (in 1/days).
beta, gamma, delta, alpha = 0.3, 1./10, 1./5, 0.01

# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# Initial conditions vector
y0 = S0, E0, I0, R0, D0

# Integrate the SEIRD equations over the time grid, t.
ret = odeint(deriv, y0, t, args=(N, beta, gamma, delta, alpha))
S, E, I, R, D = ret.T

# Plot the data on three separate curves for S(t), E(t), I(t), R(t) and D(t)
fig = plt.figure(facecolor='w')
ax = fig.add_subplot(111, facecolor='#dddddd', axisbelow=True)
ax.plot(t, S, 'b', alpha=0.5, lw=2, label='Susceptible')
ax.plot(t, E, 'y', alpha=0.5, lw=2, label='Exposed')
ax.plot(t, I, 'r', alpha=0.5, lw=2, label='Infected')
ax.plot(t, R, 'g', alpha=0.5, lw=2, label='Recovered')
ax.plot(t, D, 'k', alpha=0.5, lw=2, label='Deceased')
ax.set_xlabel('Time /days')
ax.set_ylabel('Number')
ax.set_ylim(0, N)
ax.legend()

plt.show()
