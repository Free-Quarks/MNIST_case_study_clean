# Import necessary libraries
import random
import numpy as np
import matplotlib.pyplot as plt

# Define constants
POPULATION_SIZE = 1000
INITIAL_INFECTED = 10
INFECTION_PROBABILITY = 0.1
RECOVERY_PROBABILITY = 0.01
SIMULATION_DAYS = 160

# Define the population
class Person:
    def __init__(self, sex):
        self.sex = sex
        self.infected = False
        self.recovered = False

    def infect(self):
        if not self.infected and not self.recovered:
            if random.random() < INFECTION_PROBABILITY:
                self.infected = True

    def recover(self):
        if self.infected:
            if random.random() < RECOVERY_PROBABILITY:
                self.infected = False
                self.recovered = True

# Initialize the population
population = [Person(sex=random.choice(['male', 'female'])) for _ in range(POPULATION_SIZE)]

# Infect some initial people
initial_infected = random.sample(population, INITIAL_INFECTED)
for person in initial_infected:
    person.infected = True

# Simulation
infected_counts = []
recovered_counts = []
for day in range(SIMULATION_DAYS):
    infected_count = sum(person.infected for person in population)
    recovered_count = sum(person.recovered for person in population)
    infected_counts.append(infected_count)
    recovered_counts.append(recovered_count)

    # Each person can infect others
    for person in population:
        if person.infected:
            for other_person in random.sample(population, k=10):  # assuming each person interacts with 10 others daily
                person.infect()

    # Each person can recover
    for person in population:
        person.recover()

# Plotting results
plt.figure(figsize=(10, 6))
plt.plot(infected_counts, label='Infected')
plt.plot(recovered_counts, label='Recovered')
plt.xlabel('Days')
plt.ylabel('Number of People')
plt.title('COVID-19 Simulation')
plt.legend()
plt.grid(True)
plt.show()

