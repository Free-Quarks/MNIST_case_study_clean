import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.57  # Transmission rate
sigma = 0.1  # Rate of symptom onset
alpha = 0.1  # Detection rate
rho = 0.1    # Isolation rate
psi = 0.05   # Recovery rate
phi = 0.05   # Death rate

# Initial conditions
S0 = 0.99   # Susceptible
I0 = 0.01   # Infected
D0 = 0.0    # Diagnosed
A0 = 0.0    # Ailing
R0 = 0.0    # Recognized
T0 = 0.0    # Threatened
H0 = 0.0    # Healed
E0 = 0.0    # Extinct

# Time parameters
T = 160  # Total time
dt = 1   # Time step

# RK2 Method for SIDARTHE model
S, I, D, A, R, T, H, E = [S0], [I0], [D0], [A0], [R0], [T0], [H0], [E0]
for t in range(1, T+1):
    S_half = S[-1] - dt/2 * beta * S[-1] * (I[-1] + D[-1] + A[-1] + R[-1])
    I_half = I[-1] + dt/2 * (beta * S[-1] * (I[-1] + D[-1] + A[-1] + R[-1]) - sigma * I[-1])
    D_half = D[-1] + dt/2 * (sigma * I[-1] - alpha * D[-1] - rho * D[-1])
    A_half = A[-1] + dt/2 * (alpha * D[-1] - psi * A[-1] - phi * A[-1])
    R_half = R[-1] + dt/2 * (rho * D[-1] - psi * R[-1] - phi * R[-1])
    T_half = T[-1] + dt/2 * (psi * (A[-1] + R[-1]) - phi * T[-1] - phi * T[-1])
    H_half = H[-1] + dt/2 * phi * (I[-1] + A[-1] + R[-1] + T[-1])
    E_half = E[-1] + dt/2 * phi * (A[-1] + R[-1] + T[-1])

    S_next = S[-1] - dt * beta * S_half * (I_half + D_half + A_half + R_half)
    I_next = I[-1] + dt * (beta * S_half * (I_half + D_half + A_half + R_half) - sigma * I_half)
    D_next = D[-1] + dt * (sigma * I_half - alpha * D_half - rho * D_half)
    A_next = A[-1] + dt * (alpha * D_half - psi * A_half - phi * A_half)
    R_next = R[-1] + dt * (rho * D_half - psi * R_half - phi * R_half)
    T_next = T[-1] + dt * (psi * (A_half + R_half) - phi * T_half - phi * T_half)
    H_next = H[-1] + dt * phi * (I_half + A_half + R_half + T_half)
    E_next = E[-1] + dt * phi * (A_half + R_half + T_half)

    S.append(S_next)
    I.append(I_next)
    D.append(D_next)
    A.append(A_next)
    R.append(R_next)
    T.append(T_next)
    H.append(H_next)
    E.append(E_next)

# Plotting
plt.figure(figsize=(12, 8))
plt.plot(S, label='Susceptible')
plt.plot(I, label='Infected')
plt.plot(D, label='Diagnosed')
plt.plot(A, label='Ailing')
plt.plot(R, label='Recognized')
plt.plot(T, label='Threatened')
plt.plot(H, label='Healed')
plt.plot(E, label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of Population')
plt.legend()
plt.grid()
plt.show()
