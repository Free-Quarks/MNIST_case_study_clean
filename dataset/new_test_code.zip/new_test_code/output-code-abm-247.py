# Import necessary libraries
import networkx as nx
import numpy as np
import pandas as pd
import random

# Define parameters
num_nodes = 1000  # Total number of individuals
initial_infected = 10  # Initial number of infected individuals
transmission_probability = 0.05  # Probability of transmission per contact
days = 160  # Duration of the simulation in days

# Age stratification
age_groups = {'0-19': 0.2, '20-39': 0.3, '40-59': 0.2, '60+': 0.3}  # Proportion of population in each age group

# Generate population with age groups
population = []
for age_group, proportion in age_groups.items():
    num_in_group = int(proportion * num_nodes)
    population.extend([age_group] * num_in_group)
random.shuffle(population)

# Create a network
G = nx.erdos_renyi_graph(num_nodes, 0.1)  # Using Erdős-Rényi model for simplicity

# Initialize status of the nodes
status = {node: 'S' for node in G.nodes()}  # 'S' for susceptible
initial_infected_nodes = random.sample(G.nodes(), initial_infected)
for node in initial_infected_nodes:
    status[node] = 'I'  # 'I' for infected

# Store the age group of each individual
age_group_mapping = {node: population[node] for node in G.nodes()}

# Simulation function
def simulate_covid(G, status, transmission_probability, days):
    results = []
    for day in range(days):
        new_status = status.copy()
        for node in G.nodes():
            if status[node] == 'I':
                for neighbor in G.neighbors(node):
                    if status[neighbor] == 'S' and random.random() < transmission_probability:
                        new_status[neighbor] = 'I'
        status = new_status
        counts = {'S': list(status.values()).count('S'), 'I': list(status.values()).count('I'), 'R': list(status.values()).count('R')}
        results.append(counts)
    return results

# Run the simulation
results = simulate_covid(G, status, transmission_probability, days)

# Convert results to DataFrame for better visualization
results_df = pd.DataFrame(results)
print(results_df)

