# SIR Model Simulation using Runge-Kutta 2nd Order (RK2)

import numpy as np
import matplotlib.pyplot as plt

# SIR Model Differential Equations
def SIR_model(S, I, R, beta, gamma):
    dS_dt = -beta * S * I
    dI_dt = beta * S * I - gamma * I
    dR_dt = gamma * I
    return dS_dt, dI_dt, dR_dt

# Runge-Kutta 2nd Order Method (RK2)
def RK2_step(S, I, R, beta, gamma, dt):
    dS1, dI1, dR1 = SIR_model(S, I, R, beta, gamma)
    S_half = S + dS1 * dt / 2
    I_half = I + dI1 * dt / 2
    R_half = R + dR1 * dt / 2
    dS2, dI2, dR2 = SIR_model(S_half, I_half, R_half, beta, gamma)
    S_next = S + dS2 * dt
    I_next = I + dI2 * dt
    R_next = R + dR2 * dt
    return S_next, I_next, R_next

# Simulation Parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
S0 = 0.99  # Initial proportion of susceptible individuals
I0 = 0.01  # Initial proportion of infected individuals
R0 = 0.0  # Initial proportion of recovered individuals
total_time = 160  # Total simulation time
dt = 0.1  # Time step

# Time points
num_steps = int(total_time / dt)
t = np.linspace(0, total_time, num_steps)

# Initialize arrays to store results
S = np.zeros(num_steps)
I = np.zeros(num_steps)
R = np.zeros(num_steps)

# Initial conditions
S[0] = S0
I[0] = I0
R[0] = R0

# Run the simulation
for step in range(1, num_steps):
    S[step], I[step], R[step] = RK2_step(S[step-1], I[step-1], R[step-1], beta, gamma, dt)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.title('SIR Model Simulation using RK2')
plt.legend()
plt.grid()
plt.show()
