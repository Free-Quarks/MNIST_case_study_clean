# Agent-Based Model to Simulate COVID-19 with Vaccination
import random

class Person:
    def __init__(self, vaccinated=False, infected=False):
        self.vaccinated = vaccinated
        self.infected = infected

    def interact(self, other):
        if self.infected and not other.vaccinated and not other.infected:
            other.infected = True
        elif other.infected and not self.vaccinated and not self.infected:
            self.infected = True

class Population:
    def __init__(self, size, vaccination_rate, initial_infected):
        self.people = [Person(vaccinated=(random.random() < vaccination_rate)) for _ in range(size)]
        for _ in range(initial_infected):
            self.people[random.randint(0, size-1)].infected = True

    def simulate_interactions(self, interactions_per_day):
        for _ in range(interactions_per_day):
            p1, p2 = random.sample(self.people, 2)
            p1.interact(p2)

    def count_infected(self):
        return sum(person.infected for person in self.people)

    def count_vaccinated(self):
        return sum(person.vaccinated for person in self.people)

# Parameters
population_size = 1000
vaccination_rate = 0.7
initial_infected = 10
interactions_per_day = 10000
days = 30

# Simulation
population = Population(population_size, vaccination_rate, initial_infected)

for day in range(days):
    population.simulate_interactions(interactions_per_day)
    infected_count = population.count_infected()
    vaccinated_count = population.count_vaccinated()
    print(f"Day {day+1}: Infected = {infected_count}, Vaccinated = {vaccinated_count}")

