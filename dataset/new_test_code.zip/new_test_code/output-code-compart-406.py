import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Rate of progression from exposed to infected
gamma = 0.05  # Recovery rate

# Define initial conditions
S0 = 0.99  # Initial proportion of susceptible individuals
E0 = 0.01  # Initial proportion of exposed individuals
I0 = 0.0   # Initial proportion of infectious individuals
R0 = 0.0   # Initial proportion of recovered individuals

# Time parameters
T = 160  # Total time
dt = 1  # Time step

t = np.arange(0, T+dt, dt)

# Initialize arrays
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

# Set initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# Incorrect SEIR model using Euler's method
for i in range(1, len(t)):
    dS = -beta * S[i-1] * I[i-1] * dt
    dE = beta * S[i-1] * I[i-1] * dt - sigma * E[i-1] * dt
    dI = sigma * E[i-1] * dt - gamma * I[i-1] * dt
    dR = gamma * I[i-1] * dt
    S[i] = S[i-1] + dS
    E[i] = E[i-1] + dE
    I[i] = I[i-1] + dI
    R[i] = R[i-1] + dR

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIR Model Simulation')
plt.show()
