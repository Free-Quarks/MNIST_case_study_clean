import random
import matplotlib.pyplot as plt

class Person:
    def __init__(self, vaccinated=False):
        self.infected = False
        self.vaccinated = vaccinated

    def infect(self):
        if not self.vaccinated:
            self.infected = True

class Population:
    def __init__(self, size, vaccination_rate):
        self.people = [Person(vaccinated=random.random() < vaccination_rate) for _ in range(size)]

    def spread_infection(self, initial_infected):
        for _ in range(initial_infected):
            random.choice(self.people).infect()
        for person in self.people:
            if person.infected:
                for _ in range(2):  # Each infected person spreads to 2 others
                    random.choice(self.people).infect()

    def count_infected(self):
        return sum(person.infected for person in self.people)

# Parameters
population_size = 1000
vaccination_rate = 0.7  # 70% of the population is vaccinated
initial_infected = 10

# Create Population
population = Population(population_size, vaccination_rate)

# Spread Infection
population.spread_infection(initial_infected)

# Count Infected
infected_count = population.count_infected()

print(f'Total Infected: {infected_count}')

# Plot Results
labels = ['Infected', 'Not Infected']
sizes = [infected_count, population_size - infected_count]
colors = ['red', 'green']

plt.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=140)
plt.axis('equal')
plt.title('COVID-19 Infection Spread')
plt.show()
