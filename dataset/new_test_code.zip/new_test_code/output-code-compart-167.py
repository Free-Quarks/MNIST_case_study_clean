# This Python script models the spread of COVID-19 using the SIDARTHE model
# The model simulates the population dynamics over time using a system of ODEs
# The ODEs are solved using the odeint function from scipy.integrate

import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SIDARTHE model equations
def sidarthe(y, t, alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_, kappa, xi, rho, sigma, phi, psi, omega):
    S, I, D, A, R, T, H, E = y

    dSdt = -alpha*S*I - beta*S*D - gamma*S*A - delta*S*R
    dIdt = alpha*S*I + beta*S*D + gamma*S*A + delta*S*R - epsilon*I - zeta*I - lambda_*I
    dDdt = epsilon*I - eta*D - theta*D - mu*D
    dAdt = zeta*I - eta*A - theta*A - nu*A
    dRdt = eta*D + eta*A - kappa*R - rho*R
    dTdt = theta*D + theta*A - sigma*T - phi*T
    dHdt = lambda_*I + kappa*R + sigma*T - psi*H - omega*H
    dEdt = phi*T + rho*R + psi*H + omega*H

    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Initial conditions
S0 = 0.99  # Initial susceptible population
I0 = 0.01  # Initial infected population
D0 = 0.0   # Initial diagnosed population
A0 = 0.0   # Initial ailing population
R0 = 0.0   # Initial recognized population
T0 = 0.0   # Initial threatened population
H0 = 0.0   # Initial healed population
E0 = 0.0   # Initial extinct population

# Initial state vector
y0 = [S0, I0, D0, A0, R0, T0, H0, E0]

# Time vector (in days)
t = np.linspace(0, 160, 160)

# Parameters
alpha = 0.57
beta = 0.011
gamma = 0.456
delta = 0.011
epsilon = 0.171
zeta = 0.171
eta = 0.34
theta = 0.34
mu = 0.017
nu = 0.017
lambda_ = 0.034
kappa = 0.017
xi = 0.017
rho = 0.017
sigma = 0.017
phi = 0.017
psi = 0.017
omega = 0.017

# Integrate the ODEs using odeint
solution = odeint(sidarthe, y0, t, args=(alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_, kappa, xi, rho, sigma, phi, psi, omega))

# Extract the results
S, I, D, A, R, T, H, E = solution.T

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, D, label='Diagnosed')
plt.plot(t, A, label='Ailing')
plt.plot(t, R, label='Recognized')
plt.plot(t, T, label='Threatened')
plt.plot(t, H, label='Healed')
plt.plot(t, E, label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of Population')
plt.title('SIDARTHE Model of COVID-19 Spread')
plt.legend()
plt.grid()
plt.show()
