import numpy as np
import matplotlib.pyplot as plt

# Compartmental Model Parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Rate of progression from exposed to infectious
gamma = 1/2.3  # Recovery rate
mu = 0.01  # Mortality rate
alpha = 0.01  # Hospitalization rate
rho = 0.05  # Rate of progression from hospitalized to death or recovery

# Initial Conditions
S0 = 0.99  # Initial proportion of susceptible individuals
E0 = 0.01  # Initial proportion of exposed individuals
I0 = 0.0  # Initial proportion of infectious individuals
R0 = 0.0  # Initial proportion of recovered individuals
H0 = 0.0  # Initial proportion of hospitalized individuals
D0 = 0.0  # Initial proportion of deceased individuals

# Time Parameters
T = 160  # Total time in days
dt = 0.1  # Time step

# Number of steps
N = int(T / dt)

# Initialize arrays
S = np.zeros(N)
E = np.zeros(N)
I = np.zeros(N)
R = np.zeros(N)
H = np.zeros(N)
D = np.zeros(N)

# Set initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
H[0] = H0
D[0] = D0

# Euler method to solve the differential equations
for t in range(1, N):
    S[t] = S[t-1] - beta * S[t-1] * I[t-1] * dt
    E[t] = E[t-1] + (beta * S[t-1] * I[t-1] - sigma * E[t-1]) * dt
    I[t] = I[t-1] + (sigma * E[t-1] - gamma * I[t-1] - mu * I[t-1] - alpha * I[t-1]) * dt
    R[t] = R[t-1] + (gamma * I[t-1] + (1 - rho) * H[t-1]) * dt
    H[t] = H[t-1] + (alpha * I[t-1] - rho * H[t-1]) * dt
    D[t] = D[t-1] + (mu * I[t-1] + rho * H[t-1]) * dt

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(np.linspace(0, T, N), S, label='Susceptible')
plt.plot(np.linspace(0, T, N), E, label='Exposed')
plt.plot(np.linspace(0, T, N), I, label='Infectious')
plt.plot(np.linspace(0, T, N), R, label='Recovered')
plt.plot(np.linspace(0, T, N), H, label='Hospitalized')
plt.plot(np.linspace(0, T, N), D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIRHD Model Simulation')
plt.show()
