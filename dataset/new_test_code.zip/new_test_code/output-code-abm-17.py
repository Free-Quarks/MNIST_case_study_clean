# Agent-Based Model to Simulate COVID-19 Spread

import random
import numpy as np
import matplotlib.pyplot as plt

class Person:
    def __init__(self, age, health_status='susceptible'):
        self.age = age
        self.health_status = health_status
        self.days_infected = 0

    def update_status(self, infection_probability):
        if self.health_status == 'infected':
            self.days_infected += 1
            if self.days_infected > 14:  # assume recovery or death in 14 days
                self.health_status = 'recovered' if random.random() > 0.02 else 'dead'  # 2% death rate
        elif self.health_status == 'susceptible':
            if random.random() < infection_probability:
                self.health_status = 'infected'

class Community:
    def __init__(self, population_size, age_distribution):
        self.population = self.create_population(population_size, age_distribution)

    def create_population(self, population_size, age_distribution):
        population = []
        for age, proportion in age_distribution.items():
            num_people = int(population_size * proportion)
            population.extend([Person(age) for _ in range(num_people)])
        return population

    def simulate_day(self, infection_probability):
        for person in self.population:
            person.update_status(infection_probability)

    def get_statistics(self):
        stats = {'susceptible': 0, 'infected': 0, 'recovered': 0, 'dead': 0}
        for person in self.population:
            stats[person.health_status] += 1
        return stats

# Parameters
population_size = 1000
age_distribution = {'0-19': 0.25, '20-39': 0.35, '40-59': 0.25, '60+': 0.15}
infection_probability = 0.01  # Initial infection probability

# Initialize community
community = Community(population_size, age_distribution)

# Simulate over time
days = 100
statistics = []
for day in range(days):
    community.simulate_day(infection_probability)
    stats = community.get_statistics()
    statistics.append(stats)

# Plot results
susceptible = [stat['susceptible'] for stat in statistics]
infected = [stat['infected'] for stat in statistics]
recovered = [stat['recovered'] for stat in statistics]
dead = [stat['dead'] for stat in statistics]

days = range(1, days+1)
plt.figure(figsize=(10, 6))
plt.plot(days, susceptible, label='Susceptible')
plt.plot(days, infected, label='Infected')
plt.plot(days, recovered, label='Recovered')
plt.plot(days, dead, label='Dead')
plt.xlabel('Days')
plt.ylabel('Number of People')
plt.title('COVID-19 Simulation')
plt.legend()
plt.show()

