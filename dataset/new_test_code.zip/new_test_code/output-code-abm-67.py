import random
import matplotlib.pyplot as plt

class Person:
    def __init__(self, age_group):
        self.age_group = age_group
        self.status = 'susceptible'

    def infect(self):
        if self.status == 'susceptible':
            self.status = 'infected'

    def recover(self):
        if self.status == 'infected':
            self.status = 'recovered'

class CovidSimulation:
    def __init__(self, population_size):
        self.population = self.create_population(population_size)
        self.time_step = 0

    def create_population(self, size):
        population = []
        for _ in range(size):
            age_group = random.choice(['child', 'adult', 'elderly'])
            person = Person(age_group)
            population.append(person)
        return population

    def spread_infection(self):
        for person in self.population:
            if person.status == 'infected':
                for other in self.population:
                    if other.status == 'susceptible' and random.random() < 0.1:
                        other.infect()

    def recover_people(self):
        for person in self.population:
            if person.status == 'infected' and random.random() < 0.05:
                person.recover()

    def run_simulation(self, days):
        for _ in range(days):
            self.spread_infection()
            self.recover_people()
            self.time_step += 1

    def count_statuses(self):
        counts = {'susceptible': 0, 'infected': 0, 'recovered': 0}
        for person in self.population:
            counts[person.status] += 1
        return counts

    def plot_results(self, days):
        susceptible_counts = []
        infected_counts = []
        recovered_counts = []

        for _ in range(days):
            self.run_simulation(1)
            counts = self.count_statuses()
            susceptible_counts.append(counts['susceptible'])
            infected_counts.append(counts['infected'])
            recovered_counts.append(counts['recovered'])

        plt.figure(figsize=(10, 6))
        plt.plot(range(days), susceptible_counts, label='Susceptible')
        plt.plot(range(days), infected_counts, label='Infected')
        plt.plot(range(days), recovered_counts, label='Recovered')
        plt.xlabel('Days')
        plt.ylabel('Number of People')
        plt.title('COVID-19 Simulation Over Time')
        plt.legend()
        plt.show()

if __name__ == '__main__':
    simulation = CovidSimulation(1000)
    simulation.population[0].status = 'infected'  # Start with one infected person
    simulation.plot_results(100)
