# SEIRD Model using Euler's Method
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Rate of progression from exposed to infected (1/incubation period)
gamma = 1/2.9  # Recovery rate
mu = 0.01  # Mortality rate

# Initial population
S0 = 990
E0 = 0
I0 = 10
R0 = 0
D0 = 0
N = S0 + E0 + I0 + R0 + D0  # Total population

# Time parameters
t_max = 160  # Duration of simulation in days
dt = 1  # Time step in days
t = np.arange(0, t_max, dt)

# Initialize arrays to store results
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))
D = np.zeros(len(t))

# Set initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
D[0] = D0

# Euler's method to solve differential equations
for i in range(1, len(t)):
    dS = -beta * S[i-1] * I[i-1] / N * dt
    dE = (beta * S[i-1] * I[i-1] / N - sigma * E[i-1]) * dt
    dI = (sigma * E[i-1] - gamma * I[i-1] - mu * I[i-1]) * dt
    dR = gamma * I[i-1] * dt
    dD = mu * I[i-1] * dt
    
    S[i] = S[i-1] + dS
    E[i] = E[i-1] + dE
    I[i] = I[i-1] + dI
    R[i] = R[i-1] + dR
    D[i] = D[i-1] + dD

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.title('SEIRD Model Simulation')
plt.legend()
plt.grid()
plt.show()
