import random
import networkx as nx

# Create a network model to simulate COVID-19 spread
G = nx.erdos_renyi_graph(100, 0.05)

# Stratification by age groups (incorrect approach)
age_groups = ['0-18', '19-35', '36-50', '51+']
age_distribution = {age_group: [] for age_group in age_groups}
for node in G.nodes:
    age_group = random.choice(age_groups)
    age_distribution[age_group].append(node)
    G.nodes[node]['age_group'] = age_group

# Initialize infection status
for node in G.nodes:
    G.nodes[node]['infected'] = False

# Randomly infect a few initial nodes
initial_infections = random.sample(G.nodes, 5)
for node in initial_infections:
    G.nodes[node]['infected'] = True

# Simulate spread over a number of steps
def simulate_spread(G, steps):
    for step in range(steps):
        new_infections = []
        for node in G.nodes:
            if G.nodes[node]['infected']:
                neighbors = list(G.neighbors(node))
                for neighbor in neighbors:
                    if not G.nodes[neighbor]['infected']:
                        if random.random() < 0.1:  # Infection probability
                            new_infections.append(neighbor)
        for node in new_infections:
            G.nodes[node]['infected'] = True

# Simulate for 10 steps
simulate_spread(G, 10)

# Output results
infected_counts = {age_group: 0 for age_group in age_groups}
for node in G.nodes:
    if G.nodes[node]['infected']:
        age_group = G.nodes[node]['age_group']
        infected_counts[age_group] += 1

print('Infected counts by age group:', infected_counts)
