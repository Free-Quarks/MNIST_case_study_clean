# Importing necessary libraries
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt

# Define population size and age stratification
population_size = 1000
age_groups = {"0-19": 0.25, "20-39": 0.35, "40-59": 0.25, "60+": 0.15}

# Generate population with age stratification
np.random.seed(42)
ages = np.random.choice(list(age_groups.keys()), size=population_size, p=list(age_groups.values()))

# Create a network graph
G = nx.erdos_renyi_graph(population_size, 0.05)

# Assign age groups to nodes
for i, age in enumerate(ages):
    G.nodes[i]['age_group'] = age
    G.nodes[i]['state'] = 'S'  # Susceptible state

# Define parameters
transmission_rate = 0.1
recovery_rate = 0.01
initial_infected = 5

# Infect initial individuals
initial_infected_nodes = np.random.choice(G.nodes, initial_infected, replace=False)
for node in initial_infected_nodes:
    G.nodes[node]['state'] = 'I'  # Infected state

# Simulation function
def simulate_epidemic(G, steps):
    for step in range(steps):
        new_infections = []
        for node in G.nodes:
            if G.nodes[node]['state'] == 'I':
                for neighbor in G.neighbors(node):
                    if G.nodes[neighbor]['state'] == 'S' and np.random.rand() < transmission_rate:
                        new_infections.append(neighbor)
                if np.random.rand() < recovery_rate:
                    G.nodes[node]['state'] = 'R'  # Recovered state
        for node in new_infections:
            G.nodes[node]['state'] = 'I'
    return G

# Run simulation
steps = 100
G = simulate_epidemic(G, steps)

# Plot results
node_colors = {'S': 'blue', 'I': 'red', 'R': 'green'}
colors = [node_colors[G.nodes[node]['state']] for node in G.nodes]
pos = nx.spring_layout(G)
nx.draw(G, pos, node_color=colors, with_labels=True)
plt.show()
