# SIDARTHE Model using RK2 Method
import numpy as np
import matplotlib.pyplot as plt

# Define the SIDARTHE model
def sidarthe_model(y, params):
    S, I, D, A, R, T, H, E = y
    alpha, beta, gamma, delta, epsilon, theta, eta, zeta, mu, nu, tau, lambda, kappa, xi, rho, sigma = params
    N = S + I + D + A + R + T + H + E
    dS = -alpha * S * I - beta * S * D - gamma * S * A - delta * S * R
    dI = alpha * S * I + epsilon * D * I + zeta * A * I + eta * R * I - (lambda + rho) * I
    dD = beta * S * D + theta * A * D + mu * R * D - (lambda + kappa) * D
    dA = gamma * S * A + delta * R * A + nu * H * A - (lambda + xi) * A
    dR = delta * S * R + sigma * H * R - (lambda + tau) * R
    dT = theta * A * T + mu * D * T + nu * H * T - (lambda + sigma) * T
    dH = epsilon * D * H + zeta * A * H + eta * R * H - (lambda + rho) * H
    dE = lambda * (I + D + A + R + T + H) - kappa * E
    return np.array([dS, dI, dD, dA, dR, dT, dH, dE])

# RK2 method implementation
def rk2_step(func, y, params, dt):
    k1 = func(y, params)
    k2 = func(y + dt * k1 / 2, params)
    return y + dt * k2

# Simulation parameters
params = [0.57, 0.011, 0.456, 0.011, 0.171, 0.370, 0.125, 0.125, 0.027, 0.034, 0.034, 0.034, 0.034, 0.017, 0.017, 0.017]
y0 = [0.999, 0.001, 0, 0, 0, 0, 0, 0]  # Initial conditions
T = 100  # Total time
dt = 0.1  # Time step

# Run the simulation
time_points = np.arange(0, T, dt)
results = np.zeros((len(time_points), len(y0)))
results[0] = y0
for i, t in enumerate(time_points[:-1]):
    results[i + 1] = rk2_step(sidarthe_model, results[i], params, dt)

# Plot the results
plt.figure(figsize=(12, 8))
labels = ['S', 'I', 'D', 'A', 'R', 'T', 'H', 'E']
for i, label in enumerate(labels):
    plt.plot(time_points, results[:, i], label=label)
plt.xlabel('Time')
plt.ylabel('Proportion of population')
plt.legend()
plt.title('SIDARTHE Model Simulation using RK2 Method')
plt.show()
