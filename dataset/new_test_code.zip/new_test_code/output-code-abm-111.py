# Simulate COVID-19 spread with stratification by age
import networkx as nx
import numpy as np
import random

# Define the population and age groups
age_groups = {'0-19': 0.25, '20-39': 0.25, '40-59': 0.25, '60+': 0.25}
population_size = 1000

# Define parameters
total_days = 100
transmission_rate = 0.03
initial_infected = 10

# Generate the network
G = nx.erdos_renyi_graph(population_size, 0.1)

# Assign age groups
ages = np.random.choice(list(age_groups.keys()), size=population_size, p=list(age_groups.values()))
nx.set_node_attributes(G, dict(enumerate(ages)), 'age_group')

# Initialize the state of each node
for node in G.nodes():
    G.nodes[node]['state'] = 'S'  # S: Susceptible, I: Infected, R: Recovered

# Infect initial nodes
initial_infected_nodes = random.sample(G.nodes(), initial_infected)
for node in initial_infected_nodes:
    G.nodes[node]['state'] = 'I'

# Simulation function
def simulate_day(G):
    new_infections = []
    for node in G.nodes():
        if G.nodes[node]['state'] == 'I':
            for neighbor in G.neighbors(node):
                if G.nodes[neighbor]['state'] == 'S' and random.random() < transmission_rate:
                    new_infections.append(neighbor)
            G.nodes[node]['state'] = 'R'
    for node in new_infections:
        G.nodes[node]['state'] = 'I'

# Run the simulation
daily_infections = []
for day in range(total_days):
    simulate_day(G)
    infected_count = sum(1 for node in G.nodes() if G.nodes[node]['state'] == 'I')
    daily_infections.append(infected_count)
    print(f"Day {day+1}: {infected_count} active infections")

