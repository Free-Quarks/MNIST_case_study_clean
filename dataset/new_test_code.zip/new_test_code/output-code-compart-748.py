# SEIRHD model using Runge-Kutta 2nd order (RK2) method
import numpy as np
import matplotlib.pyplot as plt

def rk2_step(y, t, dt, derivs):
    k1 = derivs(y, t)
    k2 = derivs(y + 0.5 * dt * k1, t + 0.5 * dt)
    y_next = y + dt * k2
    return y_next

def seirhd_derivs(y, t, beta, sigma, gamma, mu, delta):
    S, E, I, R, H, D = y
    N = S + E + I + R + H
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I - mu * I
    dR_dt = gamma * I
    dH_dt = mu * I - delta * H
    dD_dt = delta * H
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt, dH_dt, dD_dt])

def simulate_seirhd(S0, E0, I0, R0, H0, D0, beta, sigma, gamma, mu, delta, t_max, dt):
    t_values = np.arange(0, t_max, dt)
    y_values = np.zeros((len(t_values), 6))
    y_values[0] = [S0, E0, I0, R0, H0, D0]
    for i in range(1, len(t_values)):
        y_values[i] = rk2_step(y_values[i-1], t_values[i-1], dt, lambda y, t: seirhd_derivs(y, t, beta, sigma, gamma, mu, delta))
    return t_values, y_values

def plot_seirhd(t_values, y_values):
    S, E, I, R, H, D = y_values.T
    plt.figure(figsize=(10, 6))
    plt.plot(t_values, S, label='Susceptible')
    plt.plot(t_values, E, label='Exposed')
    plt.plot(t_values, I, label='Infected')
    plt.plot(t_values, R, label='Recovered')
    plt.plot(t_values, H, label='Hospitalized')
    plt.plot(t_values, D, label='Deceased')
    plt.xlabel('Time')
    plt.ylabel('Population')
    plt.legend()
    plt.grid()
    plt.show()

# Parameters
S0 = 999
E0 = 1
I0 = 0
R0 = 0
H0 = 0
D0 = 0
beta = 0.3
sigma = 0.1
gamma = 0.05
mu = 0.01
delta = 0.02
t_max = 160
dt = 1

t_values, y_values = simulate_seirhd(S0, E0, I0, R0, H0, D0, beta, sigma, gamma, mu, delta, t_max, dt)
plot_seirhd(t_values, y_values)

