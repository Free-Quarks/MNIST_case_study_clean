# Import necessary libraries
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# SEIRD model implementation
def SEIRD_model(y, t, beta, sigma, gamma, mu):
    S, E, I, R, D = y
    N = S + E + I + R + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - mu * I
    dRdt = gamma * I
    dDdt = mu * I
    return [dSdt, dEdt, dIdt, dRdt, dDdt]

# Initial conditions and parameters
N = 1000          # Total population
I0 = 1            # Initial number of infected individuals
E0 = 0            # Initial number of exposed individuals
R0 = 0            # Initial number of recovered individuals
D0 = 0            # Initial number of dead individuals
S0 = N - I0 - E0 - R0 - D0  # Initial number of susceptible individuals

beta = 0.3        # Infection rate
sigma = 1/5.2     # Rate at which exposed individuals become infectious
gamma = 1/10      # Recovery rate
mu = 0.01         # Mortality rate

# Time points (in days)
t = np.linspace(0, 160, 160)

# Initial conditions vector
y0 = [S0, E0, I0, R0, D0]

# Integrate the SEIRD equations over the time grid, t.
solution = odeint(SEIRD_model, y0, t, args=(beta, sigma, gamma, mu))
S, E, I, R, D = solution.T

# Plot the results
plt.figure(figsize=(10,6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.plot(t, D, 'k', alpha=0.7, linewidth=2, label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.grid(True)
plt.title('SEIRD Model Simulation')
plt.show()

