# Agent-Based Model to Simulate COVID-19 with Stratification
import random
import matplotlib.pyplot as plt

class Person:
    def __init__(self, age, initial_state='susceptible'):
        self.age = age
        self.state = initial_state

    def infect(self):
        if self.state == 'susceptible':
            self.state = 'infected'

    def recover_or_die(self, death_rate):
        if self.state == 'infected':
            if random.random() < death_rate:
                self.state = 'dead'
            else:
                self.state = 'recovered'

class COVIDSimulation:
    def __init__(self, population_size, initial_infected, death_rate, age_strata):
        self.population = [Person(random.choices(list(age_strata.keys()), list(age_strata.values()))[0]) for _ in range(population_size)]
        self.initial_infected = initial_infected
        self.death_rate = death_rate
        self.time_step = 0
        self.history = {'susceptible': [], 'infected': [], 'recovered': [], 'dead': []}
        # Infect initial people
        for _ in range(initial_infected):
            self.population[random.randint(0, population_size-1)].infect()

    def step(self):
        for person in self.population:
            if person.state == 'infected':
                # Infect others
                for _ in range(random.randint(0, 2)):
                    other = self.population[random.randint(0, len(self.population) - 1)]
                    other.infect()
                # Recover or die
                person.recover_or_die(self.death_rate)

        # Collect statistics
        states_count = {'susceptible': 0, 'infected': 0, 'recovered': 0, 'dead': 0}
        for person in self.population:
            states_count[person.state] += 1
        for state, count in states_count.items():
            self.history[state].append(count)
        self.time_step += 1

    def run(self, steps):
        for _ in range(steps):
            self.step()

    def plot(self):
        plt.figure(figsize=(10, 6))
        for state, counts in self.history.items():
            plt.plot(counts, label=state)
        plt.xlabel('Time Steps')
        plt.ylabel('Number of People')
        plt.title('COVID-19 Simulation')
        plt.legend()
        plt.show()

# Parameters
population_size = 1000
initial_infected = 10
death_rate = 0.01
age_strata = { '0-17': 0.2, '18-49': 0.5, '50-64': 0.2, '65+': 0.1 }

# Run simulation
simulation = COVIDSimulation(population_size, initial_infected, death_rate, age_strata)
simulation.run(steps=100)
simulation.plot()
