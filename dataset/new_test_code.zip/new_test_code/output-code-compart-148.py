import numpy as np

class SEIRHDModel:
    def __init__(self, beta, sigma, gamma, delta, alpha, population):
        self.beta = beta
        self.sigma = sigma
        self.gamma = gamma
        self.delta = delta
        self.alpha = alpha
        self.population = population

    def derivatives(self, y, t):
        S, E, I, R, H, D = y
        N = self.population

        dSdt = -self.beta * S * I / N
        dEdt = self.beta * S * I / N - self.sigma * E
        dIdt = self.sigma * E - (self.gamma + self.delta + self.alpha) * I
        dRdt = self.gamma * I
        dHdt = self.delta * I
        dDdt = self.alpha * I

        return np.array([dSdt, dEdt, dIdt, dRdt, dHdt, dDdt])

    def rk2_step(self, y, t, dt):
        k1 = self.derivatives(y, t)
        k2 = self.derivatives(y + dt / 2 * k1, t + dt / 2)
        return y + dt * k2

    def simulate(self, y0, t):
        dt = t[1] - t[0]
        solution = np.zeros((len(t), len(y0)))
        solution[0] = y0
        for i in range(1, len(t)):
            solution[i] = self.rk2_step(solution[i - 1], t[i - 1], dt)
        return solution

def main():
    # Parameters
    beta = 0.3
    sigma = 1/5.2
    gamma = 1/2.9
    delta = 0.1
    alpha = 0.01
    population = 10000

    # Initial conditions
    S0 = 9990
    E0 = 10
    I0 = 0
    R0 = 0
    H0 = 0
    D0 = 0
    y0 = np.array([S0, E0, I0, R0, H0, D0])

    # Time points
    t = np.linspace(0, 160, 160)

    # Create the model
    model = SEIRHDModel(beta, sigma, gamma, delta, alpha, population)

    # Run the simulation
    result = model.simulate(y0, t)

    # Print the results
    for i in range(len(t)):
        print(f"Day {int(t[i]):3d}: S={result[i, 0]:.1f}, E={result[i, 1]:.1f}, I={result[i, 2]:.1f}, R={result[i, 3]:.1f}, H={result[i, 4]:.1f}, D={result[i, 5]:.1f}")

if __name__ == "__main__":
    main()
