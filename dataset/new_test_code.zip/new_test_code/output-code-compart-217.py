# Import necessary libraries
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SIDARTHE model differential equations
# S: Susceptible
# I: Infected (asymptomatic, undetected)
# D: Diagnosed (infected, detected)
# A: Ailing (symptomatic, undetected)
# R: Recognized (symptomatic, detected)
# T: Threatened (with life-threatening symptoms, detected)
# H: Healed (recovered)
# E: Extinct (dead)
def deriv(y, t, alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_):
    S, I, D, A, R, T, H, E = y
    dSdt = -beta * S * (I + A + D + R + T)
    dIdt = beta * S * (I + A + D + R + T) - gamma * I - delta * I
    dDdt = gamma * I - epsilon * D - zeta * D
    dAdt = delta * I - eta * A - theta * A
    dRdt = epsilon * D + eta * A - mu * R - nu * R
    dTdt = theta * A + nu * R - tau * T - lambda_ * T
    dHdt = mu * R + tau * T
    dEdt = lambda_ * T + zeta * D
    return dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt

# Initial number of individuals in each compartment
S0, I0, D0, A0, R0, T0, H0, E0 = 1000, 1, 0, 0, 0, 0, 0, 0

# Total population, N
N = S0 + I0 + D0 + A0 + R0 + T0 + H0 + E0

# Initial conditions vector
y0 = S0, I0, D0, A0, R0, T0, H0, E0

# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# Parameters of the model
alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_ = 0.1, 0.5, 0.1, 0.05, 0.1, 0.05, 0.01, 0.1, 0.05, 0.01, 0.01, 0.01

# Integrate the SIR equations over the time grid, t.
ret = odeint(deriv, y0, t, args=(alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_))
S, I, D, A, R, T, H, E = ret.T

# Plot the data on three separate curves for S(t), I(t) and R(t)
fig = plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, I, 'y', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, D, 'g', alpha=0.7, linewidth=2, label='Diagnosed')
plt.plot(t, A, 'r', alpha=0.7, linewidth=2, label='Ailing')
plt.plot(t, R, 'c', alpha=0.7, linewidth=2, label='Recognized')
plt.plot(t, T, 'm', alpha=0.7, linewidth=2, label='Threatened')
plt.plot(t, H, 'k', alpha=0.7, linewidth=2, label='Healed')
plt.plot(t, E, 'orange', alpha=0.7, linewidth=2, label='Extinct')
plt.xlabel('Time /days')
plt.ylabel('Number')
plt.legend()
plt.show()
