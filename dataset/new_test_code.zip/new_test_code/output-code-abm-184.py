
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

class CovidSimulation:
    def __init__(self, population_size, initial_infected, transmission_probability, recovery_rate):
        self.population_size = population_size
        self.initial_infected = initial_infected
        self.transmission_probability = transmission_probability
        self.recovery_rate = recovery_rate
        self.graph = nx.erdos_renyi_graph(n=population_size, p=0.1)
        self.status = {node: 'S' for node in self.graph.nodes}
        self.sex = {node: np.random.choice(['M', 'F']) for node in self.graph.nodes}
        self.initialize_infection()

    def initialize_infection(self):
        infected_nodes = np.random.choice(self.graph.nodes, self.initial_infected, replace=False)
        for node in infected_nodes:
            self.status[node] = 'I'

    def step(self):
        new_status = self.status.copy()
        for node in self.graph.nodes:
            if self.status[node] == 'I':
                if np.random.rand() < self.recovery_rate:
                    new_status[node] = 'R'
                else:
                    neighbors = list(self.graph.neighbors(node))
                    for neighbor in neighbors:
                        if self.status[neighbor] == 'S' and np.random.rand() < self.transmission_probability:
                            new_status[neighbor] = 'I'
        self.status = new_status

    def run(self, steps):
        for _ in range(steps):
            self.step()
            self.plot_status()

    def plot_status(self):
        color_map = {'S': 'blue', 'I': 'red', 'R': 'green'}
        node_colors = [color_map[self.status[node]] for node in self.graph.nodes]
        sex_shapes = {node: 'o' if self.sex[node] == 'M' else 's' for node in self.graph.nodes}
        pos = nx.spring_layout(self.graph)
        nx.draw(self.graph, pos, node_color=node_colors, with_labels=True, node_shape=None)
        for node, (x, y) in pos.items():
            plt.scatter([x], [y], color=color_map[self.status[node]], marker=sex_shapes[node])
        plt.show()

# Parameters
total_population = 100
initial_infected = 5
transmission_probability = 0.05
recovery_rate = 0.01

# Simulation
simulation = CovidSimulation(total_population, initial_infected, transmission_probability, recovery_rate)
simulation.run(steps=50)

