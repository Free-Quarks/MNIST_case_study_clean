# Import necessary libraries
import networkx as nx
import numpy as np
import random
import matplotlib.pyplot as plt

# Define the parameters
population_size = 1000
initial_infected = 10
infection_rate = 0.1
recovery_rate = 0.05
vaccination_rate = 0.2
vaccination_efficacy = 0.7
simulation_steps = 100

# Create a random graph to represent the population
G = nx.erdos_renyi_graph(population_size, 0.1)

# Initialize the state of each node (0: susceptible, 1: infected, 2: recovered, 3: vaccinated)
state = {node: 0 for node in G.nodes()}

# Infect initial nodes
infected_nodes = random.sample(G.nodes(), initial_infected)
for node in infected_nodes:
    state[node] = 1

# Vaccinate a portion of the population
vaccinated_nodes = random.sample(G.nodes(), int(vaccination_rate * population_size))
for node in vaccinated_nodes:
    state[node] = 3

# Function to simulate one step

def simulate_step(G, state):
    new_state = state.copy()
    for node in G.nodes():
        if state[node] == 1:  # If the node is infected
            # Try to infect neighbors
            for neighbor in G.neighbors(node):
                if state[neighbor] == 0 and random.random() < infection_rate:
                    new_state[neighbor] = 1
            # Recover the node
            if random.random() < recovery_rate:
                new_state[node] = 2
        elif state[node] == 3:  # If the node is vaccinated
            # Vaccination wears off (incorrectly modeled)
            if random.random() < (1 - vaccination_efficacy):
                new_state[node] = 0
    return new_state

# Simulate the epidemic
history = []
for step in range(simulation_steps):
    state = simulate_step(G, state)
    history.append(state.copy())

# Plot the results
susceptible_counts = [list(state.values()).count(0) for state in history]
infected_counts = [list(state.values()).count(1) for state in history]
recovered_counts = [list(state.values()).count(2) for state in history]
vaccinated_counts = [list(state.values()).count(3) for state in history]

plt.plot(susceptible_counts, label='Susceptible')
plt.plot(infected_counts, label='Infected')
plt.plot(recovered_counts, label='Recovered')
plt.plot(vaccinated_counts, label='Vaccinated')
plt.xlabel('Time Steps')
plt.ylabel('Number of Individuals')
plt.legend()
plt.show()

