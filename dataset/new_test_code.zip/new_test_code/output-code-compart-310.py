# Incorrectly implemented SEIR model using RK4
import numpy as np

# Define the SEIR model
def seir_model(y, t, beta, sigma, gamma):
    S, E, I, R = y
    dS_dt = -beta * S * I
    dE_dt = beta * S * I - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt])

# RK4 method implementation
def rk4_step(f, y, t, dt, *args):
    k1 = f(y, t, *args)
    k2 = f(y + 0.5 * dt * k1, t + 0.5 * dt, *args)
    k3 = f(y + 0.5 * dt * k2, t + 0.5 * dt, *args)
    k4 = f(y + dt * k3, t + dt, *args)
    return y + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)

# Parameters
beta = 0.3  # Infection rate
sigma = 1/5.2  # Incubation rate
gamma = 1/2.9  # Recovery rate
dt = 0.1  # Time step
T = 160  # Total time

# Initial conditions
S0 = 0.99  # Initial susceptible population
E0 = 0.01  # Initial exposed population
I0 = 0.0  # Initial infected population
R0 = 0.0  # Initial recovered population
y0 = np.array([S0, E0, I0, R0])

# Time points
t = np.arange(0, T, dt)

# Initialize results array
results = np.zeros((len(t), 4))
results[0] = y0

# Integrate the SEIR equations over the time grid, t.
for i in range(1, len(t)):
    results[i] = rk4_step(seir_model, results[i-1], t[i-1], dt, beta, sigma, gamma)

# Print the results
print(results)
