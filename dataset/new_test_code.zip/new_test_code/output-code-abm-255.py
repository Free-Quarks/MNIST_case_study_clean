import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

# Parameters
num_nodes = 1000
num_edges = 3000
initial_infected = 10
prob_transmission = 0.05
recovery_time = 14

# Age stratification
age_groups = {
    '0-19': 0.25,
    '20-39': 0.30,
    '40-59': 0.25,
    '60+': 0.20
}

# Generate network
G = nx.gnm_random_graph(num_nodes, num_edges)

# Assign age groups to nodes
age_labels = []
for age_group, proportion in age_groups.items():
    num_in_group = int(proportion * num_nodes)
    age_labels.extend([age_group] * num_in_group)
np.random.shuffle(age_labels)

nx.set_node_attributes(G, {i: age_labels[i] for i in range(num_nodes)}, 'age')

# Initialize nodes
status = {node: 'S' for node in G.nodes()}
initial_infected_nodes = np.random.choice(G.nodes(), initial_infected, replace=False)
for node in initial_infected_nodes:
    status[node] = 'I'

nx.set_node_attributes(G, status, 'status')

# Simulation
days = 100
for day in range(days):
    new_status = status.copy()
    for node in G.nodes():
        if status[node] == 'I':
            for neighbor in G.neighbors(node):
                if status[neighbor] == 'S' and np.random.rand() < prob_transmission:
                    new_status[neighbor] = 'I'
            recovery_time -= 1
            if recovery_time <= 0:
                new_status[node] = 'R'
    status = new_status
    nx.set_node_attributes(G, status, 'status')

# Plotting
color_map = {'S': 'blue', 'I': 'red', 'R': 'green'}
colors = [color_map[status[node]] for node in G.nodes()]
pos = nx.spring_layout(G)
nx.draw(G, pos, node_color=colors, with_labels=False, node_size=20)
plt.show()
