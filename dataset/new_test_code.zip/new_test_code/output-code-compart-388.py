import numpy as np
import matplotlib.pyplot as plt

# SEIRD model parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Rate at which exposed individuals become infectious
gamma = 0.05  # Recovery rate
delta = 0.01  # Death rate

# Initial conditions: S, E, I, R, D
S0 = 0.99
E0 = 0.01
I0 = 0.0
R0 = 0.0
D0 = 0.0

# Time parameters
t_max = 160  # Total time
dt = 1.0  # Time step

# Using Runge-Kutta 2nd Order (RK2) method

def rk2_step(f, y, t, dt):
    k1 = f(y, t)
    k2 = f(y + dt * k1 / 2, t + dt / 2)
    return y + dt * k2

# SEIRD model equations
def seird_deriv(y, t):
    S, E, I, R, D = y
    dSdt = -beta * S * I
    dEdt = beta * S * I - sigma * E
    dIdt = sigma * E - gamma * I - delta * I
    dRdt = gamma * I
    dDdt = delta * I
    return np.array([dSdt, dEdt, dIdt, dRdt, dDdt])

# Time array
t = np.arange(0, t_max, dt)

# Initialize arrays to store results
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))
D = np.zeros(len(t))

# Initial values
y = np.array([S0, E0, I0, R0, D0])

# Integrate the SEIRD equations over time using RK2
for i in range(len(t)):
    S[i] = y[0]
    E[i] = y[1]
    I[i] = y[2]
    R[i] = y[3]
    D[i] = y[4]
    y = rk2_step(seird_deriv, y, t[i], dt)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.plot(t, D, label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIRD Model using RK2')
plt.grid(True)
plt.show()
