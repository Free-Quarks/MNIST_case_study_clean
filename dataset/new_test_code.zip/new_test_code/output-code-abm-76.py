import numpy as np
import matplotlib.pyplot as plt

class Individual:
    def __init__(self, sex, status='susceptible'):
        self.sex = sex
        self.status = status
        self.days_infected = 0

class Population:
    def __init__(self, size):
        self.individuals = []
        for _ in range(size // 2):
            self.individuals.append(Individual(sex='male'))
            self.individuals.append(Individual(sex='female'))
        np.random.shuffle(self.individuals)

    def infect_random(self, initial_infected=1):
        infected_indices = np.random.choice(len(self.individuals), initial_infected, replace=False)
        for idx in infected_indices:
            self.individuals[idx].status = 'infected'

    def step(self, transmission_rate=0.1, recovery_time=14):
        new_infections = []
        for individual in self.individuals:
            if individual.status == 'infected':
                individual.days_infected += 1
                if individual.days_infected > recovery_time:
                    individual.status = 'recovered'
                else:
                    if np.random.rand() < transmission_rate:
                        new_infections.append(individual)

        for infector in new_infections:
            susceptible_individuals = [ind for ind in self.individuals if ind.status == 'susceptible']
            if susceptible_individuals:
                new_infected = np.random.choice(susceptible_individuals)
                new_infected.status = 'infected'

    def count_status(self, status):
        return sum(1 for ind in self.individuals if ind.status == status)

# Simulation parameters
population_size = 1000
initial_infected = 10
steps = 100
transmission_rate = 0.05
recovery_time = 14

# Initialize population
population = Population(size=population_size)
population.infect_random(initial_infected=initial_infected)

# Data collection
susceptible_counts = []
infected_counts = []
recovered_counts = []

for _ in range(steps):
    population.step(transmission_rate=transmission_rate, recovery_time=recovery_time)
    susceptible_counts.append(population.count_status('susceptible'))
    infected_counts.append(population.count_status('infected'))
    recovered_counts.append(population.count_status('recovered'))

# Plotting results
plt.plot(susceptible_counts, label='Susceptible')
plt.plot(infected_counts, label='Infected')
plt.plot(recovered_counts, label='Recovered')
plt.xlabel('Days')
plt.ylabel('Number of Individuals')
plt.legend()
plt.show()
