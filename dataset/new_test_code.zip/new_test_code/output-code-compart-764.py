# SEIRD model using Runge-Kutta 3rd order (RK3) method

import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model differential equations
def SEIRD_model(t, y, beta, gamma, delta, alpha):
    S, E, I, R, D = y
    N = S + E + I + R + D
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - delta * E
    dI_dt = delta * E - (gamma + alpha) * I
    dR_dt = gamma * I
    dD_dt = alpha * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt, dD_dt])

# Runge-Kutta 3rd order (RK3) method
def RK3_step(f, t, y, h, *args):
    k1 = f(t, y, *args)
    k2 = f(t + h/2, y + h/2 * k1, *args)
    k3 = f(t + h, y - h * k1 + 2 * h * k2, *args)
    return y + h/6 * (k1 + 4 * k2 + k3)

# Parameters
beta = 0.3  # Infection rate
gamma = 0.1 # Recovery rate
delta = 0.1 # Incubation rate
alpha = 0.01 # Mortality rate

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
D0 = 0
y0 = np.array([S0, E0, I0, R0, D0])

# Time grid
t0 = 0
T = 160
h = 0.1
num_steps = int(T / h)
t = np.linspace(t0, T, num_steps)

# Initialize solution array
y = np.zeros((num_steps, 5))
y[0] = y0

# Time-stepping loop
for i in range(1, num_steps):
    y[i] = RK3_step(SEIRD_model, t[i-1], y[i-1], h, beta, gamma, delta, alpha)

# Plotting the results
plt.figure(figsize=(12, 8))
plt.plot(t, y[:, 0], label='Susceptible')
plt.plot(t, y[:, 1], label='Exposed')
plt.plot(t, y[:, 2], label='Infected')
plt.plot(t, y[:, 3], label='Recovered')
plt.plot(t, y[:, 4], label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRD Model Simulation using RK3')
plt.grid()
plt.show()
