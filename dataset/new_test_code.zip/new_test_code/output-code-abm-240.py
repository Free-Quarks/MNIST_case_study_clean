# COVID-19 Simulation Model with Stratification by Sex
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

# Parameters
population_size = 1000
initial_infected = 10
transmission_rate = 0.05
recovery_rate = 0.01

# Stratification by sex
sex_distribution = {'male': 0.5, 'female': 0.5}

# Create a network
G = nx.erdos_renyi_graph(population_size, 0.1)

# Initialize node attributes
for node in G.nodes:
    G.nodes[node]['sex'] = 'male' if np.random.rand() < sex_distribution['male'] else 'female'
    G.nodes[node]['status'] = 'infected' if np.random.rand() < initial_infected / population_size else 'susceptible'
    G.nodes[node]['days_infected'] = 0

# Simulation function
def simulate_step(G):
    new_infections = []
    for node in G.nodes:
        if G.nodes[node]['status'] == 'infected':
            G.nodes[node]['days_infected'] += 1
            if np.random.rand() < recovery_rate:
                G.nodes[node]['status'] = 'recovered'
            else:
                for neighbor in G.neighbors(node):
                    if G.nodes[neighbor]['status'] == 'susceptible' and np.random.rand() < transmission_rate:
                        new_infections.append(neighbor)
    for node in new_infections:
        G.nodes[node]['status'] = 'infected'
        G.nodes[node]['days_infected'] = 0
    return G

# Run simulation
steps = 100
infected_counts_male = []
infected_counts_female = []
for step in range(steps):
    G = simulate_step(G)
    infected_counts_male.append(sum(1 for node in G.nodes if G.nodes[node]['status'] == 'infected' and G.nodes[node]['sex'] == 'male'))
    infected_counts_female.append(sum(1 for node in G.nodes if G.nodes[node]['status'] == 'infected' and G.nodes[node]['sex'] == 'female'))

# Plot results
plt.plot(infected_counts_male, label='Male')
plt.plot(infected_counts_female, label='Female')
plt.xlabel('Time Steps')
plt.ylabel('Number of Infected Individuals')
plt.legend()
plt.title('COVID-19 Simulation with Sex Stratification')
plt.show()
