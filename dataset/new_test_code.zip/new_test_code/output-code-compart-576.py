# SIR Model using Euler's Method in Python

import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
S0 = 990  # Initial susceptible population
I0 = 10  # Initial infected population
R0 = 0  # Initial recovered population
N = S0 + I0 + R0  # Total population

# Time parameters
T = 160  # Total time
dt = 1  # Time step size

# Initialize arrays
S = np.zeros(T)
I = np.zeros(T)
R = np.zeros(T)
t = np.linspace(0, T-1, T)

# Initial conditions
S[0] = S0
I[0] = I0
R[0] = R0

# Euler's method
for t_step in range(1, T):
    S[t_step] = S[t_step-1] - (beta * S[t_step-1] * I[t_step-1] / N) * dt
    I[t_step] = I[t_step-1] + (beta * S[t_step-1] * I[t_step-1] / N - gamma * I[t_step-1]) * dt
    R[t_step] = R[t_step-1] + (gamma * I[t_step-1]) * dt

# Plotting
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Population')
plt.title('SIR Model using Euler\'s Method')
plt.legend()
plt.grid(True)
plt.show()
