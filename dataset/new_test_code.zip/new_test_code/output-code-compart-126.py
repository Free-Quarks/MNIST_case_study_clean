import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate
dt = 0.01  # Time step
T = 160  # Total time

# Initialize populations
S = [0.99]  # Susceptible
I = [0.01]  # Infected
R = [0.0]   # Recovered

# Time steps
n_steps = int(T / dt)

def euler_step(S, I, R, beta, gamma, dt):
    dS = -beta * S * I
    dI = beta * S * I - gamma * I
    dR = gamma * I
    S_next = S + dS * dt
    I_next = I + dI * dt
    R_next = R + dR * dt
    return S_next, I_next, R_next

# Run simulation
t = np.linspace(0, T, n_steps)
for _ in range(n_steps - 1):
    S_next, I_next, R_next = euler_step(S[-1], I[-1], R[-1], beta, gamma, dt)
    S.append(S_next)
    I.append(I_next)
    R.append(R_next)

# Plot results
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.show()
