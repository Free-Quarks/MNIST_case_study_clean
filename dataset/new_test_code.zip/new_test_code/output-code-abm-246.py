import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import random

# Parameters
population_size = 1000
initial_infected = 10
initial_vaccinated = 200
infection_rate = 0.1
recovery_rate = 0.05
vaccination_rate = 0.01
timesteps = 50

# Create the network
G = nx.erdos_renyi_graph(population_size, 0.1)

# Initialize node attributes
for node in G.nodes:
    G.nodes[node]['status'] = 'susceptible'
    G.nodes[node]['days_infected'] = 0
    G.nodes[node]['vaccinated'] = False

# Infect initial nodes
infected_nodes = random.sample(G.nodes(), initial_infected)
for node in infected_nodes:
    G.nodes[node]['status'] = 'infected'

# Vaccinate initial nodes
vaccinated_nodes = random.sample(set(G.nodes()) - set(infected_nodes), initial_vaccinated)
for node in vaccinated_nodes:
    G.nodes[node]['vaccinated'] = True

# Simulation function
def simulate(G, timesteps):
    for t in range(timesteps):
        new_infections = []
        new_recoveries = []
        new_vaccinations = []
        
        for node in G.nodes:
            if G.nodes[node]['status'] == 'infected':
                G.nodes[node]['days_infected'] += 1
                if random.random() < recovery_rate:
                    new_recoveries.append(node)
                # Infect neighbors
                for neighbor in G.neighbors(node):
                    if G.nodes[neighbor]['status'] == 'susceptible' and not G.nodes[neighbor]['vaccinated']:
                        if random.random() < infection_rate:
                            new_infections.append(neighbor)
            elif G.nodes[node]['status'] == 'susceptible' and not G.nodes[node]['vaccinated']:
                if random.random() < vaccination_rate:
                    new_vaccinations.append(node)
        
        for node in new_infections:
            G.nodes[node]['status'] = 'infected'
            G.nodes[node]['days_infected'] = 0
        for node in new_recoveries:
            G.nodes[node]['status'] = 'recovered'
        for node in new_vaccinations:
            G.nodes[node]['vaccinated'] = True
        
        # Collect data for plotting
        susceptible_count = len([n for n in G.nodes if G.nodes[n]['status'] == 'susceptible'])
        infected_count = len([n for n in G.nodes if G.nodes[n]['status'] == 'infected'])
        recovered_count = len([n for n in G.nodes if G.nodes[n]['status'] == 'recovered'])
        vaccinated_count = len([n for n in G.nodes if G.nodes[n]['vaccinated']])
        print(f"Day {t}: Susceptible: {susceptible_count}, Infected: {infected_count}, Recovered: {recovered_count}, Vaccinated: {vaccinated_count}")

# Run simulation
simulate(G, timesteps)

# Plotting
susceptible_counts = []
infected_counts = []
recovered_counts = []
vaccinated_counts = []
for node in G.nodes:
    if G.nodes[node]['status'] == 'susceptible':
        susceptible_counts.append(node)
    elif G.nodes[node]['status'] == 'infected':
        infected_counts.append(node)
    elif G.nodes[node]['status'] == 'recovered':
        recovered_counts.append(node)
    if G.nodes[node]['vaccinated']:
        vaccinated_counts.append(node)

plt.figure(figsize=(10,6))
plt.plot(range(timesteps), susceptible_counts, label='Susceptible')
plt.plot(range(timesteps), infected_counts, label='Infected')
plt.plot(range(timesteps), recovered_counts, label='Recovered')
plt.plot(range(timesteps), vaccinated_counts, label='Vaccinated')
plt.xlabel('Time')
plt.ylabel('Number of Individuals')
plt.legend()
plt.title('COVID-19 Simulation with Vaccination')
plt.show()
