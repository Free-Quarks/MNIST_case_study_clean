import random

class Individual:
    def __init__(self, age_group, initial_status):
        self.age_group = age_group
        self.status = initial_status  # susceptible, infected, recovered, or deceased
        self.days_infected = 0

    def update_status(self, transmission_rate, recovery_days, mortality_rate):
        if self.status == 'infected':
            self.days_infected += 1
            if self.days_infected >= recovery_days:
                if random.random() < mortality_rate[self.age_group]:
                    self.status = 'deceased'
                else:
                    self.status = 'recovered'

class CovidModel:
    def __init__(self, population_size, age_distribution, initial_infected, transmission_rate, recovery_days, mortality_rate):
        self.population = self.initialize_population(population_size, age_distribution, initial_infected)
        self.transmission_rate = transmission_rate
        self.recovery_days = recovery_days
        self.mortality_rate = mortality_rate

    def initialize_population(self, population_size, age_distribution, initial_infected):
        population = []
        for age_group, proportion in age_distribution.items():
            num_individuals = int(population_size * proportion)
            for _ in range(num_individuals):
                status = 'infected' if initial_infected > 0 else 'susceptible'
                if status == 'infected':
                    initial_infected -= 1
                population.append(Individual(age_group, status))
        return population

    def step(self):
        for individual in self.population:
            if individual.status == 'infected':
                for other in self.population:
                    if other.status == 'susceptible':
                        if random.random() < self.transmission_rate:
                            other.status = 'infected'
                individual.update_status(self.transmission_rate, self.recovery_days, self.mortality_rate)

    def run(self, days):
        results = []
        for day in range(days):
            self.step()
            results.append(self.get_statistics())
        return results

    def get_statistics(self):
        stats = {'susceptible': 0, 'infected': 0, 'recovered': 0, 'deceased': 0}
        for individual in self.population:
            stats[individual.status] += 1
        return stats

# Example usage
population_size = 1000
age_distribution = {'child': 0.2, 'adult': 0.6, 'senior': 0.2}
initial_infected = 10
transmission_rate = 0.1
recovery_days = 14
mortality_rate = {'child': 0.001, 'adult': 0.01, 'senior': 0.1}

model = CovidModel(population_size, age_distribution, initial_infected, transmission_rate, recovery_days, mortality_rate)
results = model.run(30)
for day, stats in enumerate(results):
    print(f"Day {day + 1}: {stats}")
