import random

class Person:
    def __init__(self, age_group):
        self.age_group = age_group
        self.infected = False
        self.days_infected = 0

    def infect(self):
        self.infected = True
        self.days_infected = 1

    def progress_disease(self):
        if self.infected:
            self.days_infected += 1
            if self.days_infected > 14:
                self.infected = False
                self.days_infected = 0

class CovidSimulation:
    def __init__(self, population_size):
        self.population = []
        age_groups = ['child', 'adult', 'elderly']
        for _ in range(population_size):
            age_group = random.choice(age_groups)
            self.population.append(Person(age_group))

    def introduce_infection(self, num_initial_infections):
        infected_people = random.sample(self.population, num_initial_infections)
        for person in infected_people:
            person.infect()

    def simulate_day(self):
        for person in self.population:
            if person.infected and random.random() < 0.1:  # Incorrectly high transmission chance
                potential_victims = [p for p in self.population if not p.infected]
                if potential_victims:
                    random.choice(potential_victims).infect()
            person.progress_disease()

    def run_simulation(self, days):
        for _ in range(days):
            self.simulate_day()
            infected_count = sum(p.infected for p in self.population)
            print(f'Day {_ + 1}: {infected_count} infected')

# Example usage
simulation = CovidSimulation(population_size=100)
simulation.introduce_infection(num_initial_infections=5)
simulation.run_simulation(days=30)
