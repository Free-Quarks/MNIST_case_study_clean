import numpy as np

# SEIR model parameters
beta = 0.3   # Infection rate
sigma = 1/5.2  # Rate of progression from exposed to infectious
gamma = 1/2.9  # Recovery rate
N = 1000       # Total population

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0

# Time parameters
t_max = 160
dt = 1

# Number of steps
num_steps = int(t_max / dt)

# Arrays to store the results
S = np.zeros(num_steps)
E = np.zeros(num_steps)
I = np.zeros(num_steps)
R = np.zeros(num_steps)

# Initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# Runge-Kutta 3rd order method (RK3)
for t in range(1, num_steps):
    S_n = S[t-1]
    E_n = E[t-1]
    I_n = I[t-1]
    R_n = R[t-1]

    k1_S = -beta * S_n * I_n / N
    k1_E = beta * S_n * I_n / N - sigma * E_n
    k1_I = sigma * E_n - gamma * I_n
    k1_R = gamma * I_n

    k2_S = -beta * (S_n + k1_S * dt/2) * (I_n + k1_I * dt/2) / N
    k2_E = beta * (S_n + k1_S * dt/2) * (I_n + k1_I * dt/2) / N - sigma * (E_n + k1_E * dt/2)
    k2_I = sigma * (E_n + k1_E * dt/2) - gamma * (I_n + k1_I * dt/2)
    k2_R = gamma * (I_n + k1_I * dt/2)

    k3_S = -beta * (S_n - k1_S * dt + 2*k2_S * dt) * (I_n - k1_I * dt + 2*k2_I * dt) / N
    k3_E = beta * (S_n - k1_S * dt + 2*k2_S * dt) * (I_n - k1_I * dt + 2*k2_I * dt) / N - sigma * (E_n - k1_E * dt + 2*k2_E * dt)
    k3_I = sigma * (E_n - k1_E * dt + 2*k2_E * dt) - gamma * (I_n - k1_I * dt + 2*k2_I * dt)
    k3_R = gamma * (I_n - k1_I * dt + 2*k2_I * dt)

    S[t] = S_n + (dt / 6) * (k1_S + 4*k2_S + k3_S)
    E[t] = E_n + (dt / 6) * (k1_E + 4*k2_E + k3_E)
    I[t] = I_n + (dt / 6) * (k1_I + 4*k2_I + k3_I)
    R[t] = R_n + (dt / 6) * (k1_R + 4*k2_R + k3_R)

# Print the results
for t in range(num_steps):
    print(f"Day {t}: S={S[t]}, E={E[t]}, I={I[t]}, R={R[t]}")
