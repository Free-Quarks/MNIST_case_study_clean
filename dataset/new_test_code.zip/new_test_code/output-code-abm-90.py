# Agent-Based Model to Simulate COVID-19 with Vaccination
import random

class Person:
    def __init__(self, unique_id, vaccinated, infected=False):
        self.unique_id = unique_id
        self.vaccinated = vaccinated
        self.infected = infected
        self.days_infected = 0

    def step(self, infection_rate, recovery_time):
        if self.infected:
            self.days_infected += 1
            if self.days_infected > recovery_time:
                self.infected = False
                self.days_infected = 0
        else:
            if not self.vaccinated and random.random() < infection_rate:
                self.infected = True

class COVIDSimulation:
    def __init__(self, population_size, initial_infected, vaccination_rate, infection_rate, recovery_time):
        self.population = []
        for i in range(population_size):
            vaccinated = random.random() < vaccination_rate
            infected = i < initial_infected
            self.population.append(Person(i, vaccinated, infected))
        self.infection_rate = infection_rate
        self.recovery_time = recovery_time

    def step(self):
        for person in self.population:
            person.step(self.infection_rate, self.recovery_time)

    def run(self, steps):
        for _ in range(steps):
            self.step()
            infected_count = sum([p.infected for p in self.population])
            print(f"Step {_ + 1}: {infected_count} infected")

# Parameters
population_size = 1000
initial_infected = 10
vaccination_rate = 0.7
infection_rate = 0.05
recovery_time = 14

# Create and run the simulation
simulation = COVIDSimulation(population_size, initial_infected, vaccination_rate, infection_rate, recovery_time)
simulation.run(50)

