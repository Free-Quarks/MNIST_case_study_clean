# SEIRD Compartmental Model using RK2 (Runge-Kutta 2nd Order)

import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model parameters
beta = 0.3      # Infection rate
sigma = 0.1     # Rate of progression from exposed to infectious
gamma = 0.05    # Recovery rate
mu = 0.01       # Mortality rate
N = 1000        # Total population

# Initial conditions
S0 = 999        # Initial susceptible population
E0 = 1          # Initial exposed population
I0 = 0          # Initial infectious population
R0 = 0          # Initial recovered population
D0 = 0          # Initial deceased population

# Time parameters
t_max = 160     # Total time
dt = 1          # Time step

# Initialize arrays to store results
t = np.arange(0, t_max, dt)
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))
D = np.zeros(len(t))

# Set initial values
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0
D[0] = D0

# Define the SEIRD model equations
def derivatives(S, E, I, R, D, beta, sigma, gamma, mu):
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I - mu * I
    dR_dt = gamma * I
    dD_dt = mu * I
    return dS_dt, dE_dt, dI_dt, dR_dt, dD_dt

# Implementing the RK2 method
def rk2_step(S, E, I, R, D, beta, sigma, gamma, mu, dt):
    k1_S, k1_E, k1_I, k1_R, k1_D = derivatives(S, E, I, R, D, beta, sigma, gamma, mu)
    k2_S, k2_E, k2_I, k2_R, k2_D = derivatives(S + k1_S * dt / 2, E + k1_E * dt / 2, I + k1_I * dt / 2, R + k1_R * dt / 2, D + k1_D * dt / 2, beta, sigma, gamma, mu)
    S_next = S + k2_S * dt
    E_next = E + k2_E * dt
    I_next = I + k2_I * dt
    R_next = R + k2_R * dt
    D_next = D + k2_D * dt
    return S_next, E_next, I_next, R_next, D_next

# Simulate the SEIRD model
for i in range(1, len(t)):
    S[i], E[i], I[i], R[i], D[i] = rk2_step(S[i-1], E[i-1], I[i-1], R[i-1], D[i-1], beta, sigma, gamma, mu, dt)

# Plot the results
plt.figure(figsize=(12, 6))
plt.plot(t, S, label='Susceptible', color='blue')
plt.plot(t, E, label='Exposed', color='orange')
plt.plot(t, I, label='Infectious', color='red')
plt.plot(t, R, label='Recovered', color='green')
plt.plot(t, D, label='Deceased', color='black')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.title('SEIRD Model Simulation using RK2')
plt.legend()
plt.grid()
plt.show()

