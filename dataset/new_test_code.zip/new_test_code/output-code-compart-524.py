import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SEIRHD model

def seirhd_model(y, t, beta, sigma, gamma, delta, alpha, mu):
    S, E, I, R, H, D = y
    N = S + E + I + R + H
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - delta * I
    dRdt = gamma * I
    dHdt = delta * I - alpha * H
    dDdt = alpha * H
    return [dSdt, dEdt, dIdt, dRdt, dHdt, dDdt]

# Initial conditions
N = 1000
E0 = 1
I0 = 1
R0 = 0
H0 = 0
D0 = 0
S0 = N - E0 - I0 - R0 - H0 - D0

# Parameters
beta = 0.3
sigma = 1/5.2
gamma = 1/5.2
delta = 1/10
alpha = 1/7
mu = 0.01

# Time points
T = 160
t = np.linspace(0, T, T)

# Runge-Kutta 3rd order (RK3) solver

# Define the step size
h = t[1] - t[0]

# Initialize solution array
y = np.zeros((len(t), 6))
y[0] = [S0, E0, I0, R0, H0, D0]

# RK3 method
for i in range(1, len(t)):
    k1 = h * np.array(seirhd_model(y[i-1], t[i-1], beta, sigma, gamma, delta, alpha, mu))
    k2 = h * np.array(seirhd_model(y[i-1] + 0.5 * k1, t[i-1] + 0.5 * h, beta, sigma, gamma, delta, alpha, mu))
    k3 = h * np.array(seirhd_model(y[i-1] - k1 + 2 * k2, t[i-1] + h, beta, sigma, gamma, delta, alpha, mu))
    y[i] = y[i-1] + (1/6)*(k1 + 4*k2 + k3)

# Plot the results
plt.figure(figsize=(12, 8))
plt.plot(t, y[:, 0], 'b', label='Susceptible')
plt.plot(t, y[:, 1], 'y', label='Exposed')
plt.plot(t, y[:, 2], 'r', label='Infected')
plt.plot(t, y[:, 3], 'g', label='Recovered')
plt.plot(t, y[:, 4], 'c', label='Hospitalized')
plt.plot(t, y[:, 5], 'k', label='Dead')
plt.xlabel('Time /days')
plt.ylabel('Number')
plt.legend(loc='best')
plt.title('SEIRHD Model using RK3 Method')
plt.show()
