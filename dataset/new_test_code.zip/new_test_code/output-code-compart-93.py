import numpy as np
import matplotlib.pyplot as plt

# Define the SIDARTHE model parameters
params = {
    'alpha': 0.57,  # Transmission rate
    'beta': 0.011,  # Rate of infection from asymptomatic
    'gamma': 0.456, # Rate of infection from diagnosed
    'delta': 0.011, # Rate of infection from ailing
    'epsilon': 0.171, # Rate of infection from recognized
    'theta': 0.370,  # Rate of infection from threatened
    'zeta': 0.125,   # Recovery rate
    'eta': 0.034,    # Recovery rate
    'mu': 0.017,     # Mortality rate
    'nu': 0.027,     # Mortality rate
    'tau': 0.045,    # Mortality rate
    'lambda': 0.034  # Mortality rate
}

# Initial conditions
initial_conditions = {
    'S': 0.99,
    'I': 0.01,
    'D': 0.0,
    'A': 0.0,
    'R': 0.0,
    'T': 0.0,
    'H': 0.0,
    'E': 0.0
}

# Time parameters
T = 160  # Total time
dt = 0.1  # Time step

# Define the SIDARTHE model equations

def sidarthe_model(y, params):
    S, I, D, A, R, T, H, E = y
    alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_ = (
        params['alpha'], params['beta'], params['gamma'], params['delta'],
        params['epsilon'], params['theta'], params['zeta'], params['eta'],
        params['mu'], params['nu'], params['tau'], params['lambda']
    )
    dS = -alpha * S * I - beta * S * D - gamma * S * A - delta * S * R - epsilon * S * T - theta * S * H
    dI = alpha * S * I + beta * S * D + gamma * S * A + delta * S * R + epsilon * S * T + theta * S * H - zeta * I - eta * I
    dD = zeta * I - mu * D - nu * D
    dA = eta * I - tau * A - lambda_ * A
    dR = tau * A
    dT = mu * D
    dH = nu * D
    dE = lambda_ * A
    return np.array([dS, dI, dD, dA, dR, dT, dH, dE])

# Implement the Runge-Kutta 2nd order method (RK2)
def rk2_step(y, dt, model, params):
    k1 = model(y, params)
    k2 = model(y + dt * k1, params)
    return y + (dt / 2) * (k1 + k2)

# Run the simulation
def run_simulation(T, dt, initial_conditions, params):
    n_steps = int(T / dt)
    y = np.array(list(initial_conditions.values()))
    results = np.zeros((n_steps + 1, len(y)))
    results[0] = y
    for step in range(1, n_steps + 1):
        y = rk2_step(y, dt, sidarthe_model, params)
        results[step] = y
    return results

# Main execution
if __name__ == '__main__':
    results = run_simulation(T, dt, initial_conditions, params)
    t = np.linspace(0, T, int(T / dt) + 1)

    # Plot the results
    plt.figure(figsize=(12, 8))
    plt.plot(t, results[:, 0], label='Susceptible')
    plt.plot(t, results[:, 1], label='Infected')
    plt.plot(t, results[:, 2], label='Diagnosed')
    plt.plot(t, results[:, 3], label='Ailing')
    plt.plot(t, results[:, 4], label='Recognized')
    plt.plot(t, results[:, 5], label='Threatened')
    plt.plot(t, results[:, 6], label='Healed')
    plt.plot(t, results[:, 7], label='Extinct')
    plt.xlabel('Time')
    plt.ylabel('Proportion')
    plt.legend()
    plt.title('SIDARTHE Model Simulation')
    plt.show()
