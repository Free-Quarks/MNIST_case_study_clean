# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Define the SIDARTHE model parameters
beta = 0.6  # Infection rate
sigma = 0.1  # Rate of detection
eta = 0.1    # Rate of symptomatic infection
rho = 0.1    # Rate of severe infection
alpha = 0.1  # Rate of recovery
nu = 0.1     # Rate of hospitalization
phi = 0.1    # Rate of death

# Define the initial conditions
S0 = 0.99  # Initial proportion of susceptible individuals
I0 = 0.01  # Initial proportion of infected individuals (undetected)
D0 = 0.0   # Initial proportion of detected individuals
A0 = 0.0   # Initial proportion of ailing individuals
R0 = 0.0   # Initial proportion of recognized individuals
T0 = 0.0   # Initial proportion of threatened individuals
H0 = 0.0   # Initial proportion of healed individuals
E0 = 0.0   # Initial proportion of extinct individuals

# Time parameters
T = 100   # Total time
dt = 1    # Time step

# Initialize arrays to store the results
S = np.zeros(T)
I = np.zeros(T)
D = np.zeros(T)
A = np.zeros(T)
R = np.zeros(T)
T = np.zeros(T)
H = np.zeros(T)
E = np.zeros(T)

# Set initial values
S[0] = S0
I[0] = I0
D[0] = D0
A[0] = A0
R[0] = R0
T[0] = T0
H[0] = H0
E[0] = E0

# Euler method implementation
for t in range(1, T):
    S[t] = S[t-1] - beta * S[t-1] * I[t-1] * dt
    I[t] = I[t-1] + (beta * S[t-1] * I[t-1] - sigma * I[t-1] - eta * I[t-1]) * dt
    D[t] = D[t-1] + (sigma * I[t-1] - rho * D[t-1] - alpha * D[t-1]) * dt
    A[t] = A[t-1] + (eta * I[t-1] - nu * A[t-1] - phi * A[t-1]) * dt
    R[t] = R[t-1] + (rho * D[t-1] - theta * R[t-1]) * dt
    T[t] = T[t-1] + (nu * A[t-1] - phi * T[t-1]) * dt
    H[t] = H[t-1] + (alpha * D[t-1] + theta * R[t-1]) * dt
    E[t] = E[t-1] + (phi * A[t-1] + phi * T[t-1]) * dt

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(S, label='Susceptible')
plt.plot(I, label='Infected (undetected)')
plt.plot(D, label='Detected')
plt.plot(A, label='Ailing')
plt.plot(R, label='Recognized')
plt.plot(T, label='Threatened')
plt.plot(H, label='Healed')
plt.plot(E, label='Extinct')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.title('SIDARTHE Model Simulation')
plt.legend()
plt.grid()
plt.show()

