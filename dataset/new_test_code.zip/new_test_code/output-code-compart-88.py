# SEIRD model using RK2
import numpy as np
import matplotlib.pyplot as plt

def seird_model(S, E, I, R, D, beta, sigma, gamma, mu):
    N = S + E + I + R + D
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - (gamma + mu) * I
    dR_dt = gamma * I
    dD_dt = mu * I
    return dS_dt, dE_dt, dI_dt, dR_dt, dD_dt

def rk2_step(S, E, I, R, D, beta, sigma, gamma, mu, dt):
    k1 = seird_model(S, E, I, R, D, beta, sigma, gamma, mu)
    S1 = S + k1[0] * dt
    E1 = E + k1[1] * dt
    I1 = I + k1[2] * dt
    R1 = R + k1[3] * dt
    D1 = D + k1[4] * dt

    k2 = seird_model(S1, E1, I1, R1, D1, beta, sigma, gamma, mu)

    S_next = S + (k1[0] + k2[0]) / 2 * dt
    E_next = E + (k1[1] + k2[1]) / 2 * dt
    I_next = I + (k1[2] + k2[2]) / 2 * dt
    R_next = R + (k1[3] + k2[3]) / 2 * dt
    D_next = D + (k1[4] + k2[4]) / 2 * dt

    return S_next, E_next, I_next, R_next, D_next

def simulate_seird(S0, E0, I0, R0, D0, beta, sigma, gamma, mu, days, dt):
    S, E, I, R, D = S0, E0, I0, R0, D0
    results = []
    for _ in range(int(days / dt)):
        results.append((S, E, I, R, D))
        S, E, I, R, D = rk2_step(S, E, I, R, D, beta, sigma, gamma, mu, dt)
    return np.array(results)

def plot_seird(results, dt):
    days = np.arange(0, len(results) * dt, dt)
    S, E, I, R, D = results.T
    plt.figure(figsize=(10,6))
    plt.plot(days, S, label='Susceptible')
    plt.plot(days, E, label='Exposed')
    plt.plot(days, I, label='Infected')
    plt.plot(days, R, label='Recovered')
    plt.plot(days, D, label='Deceased')
    plt.xlabel('Days')
    plt.ylabel('Population')
    plt.legend()
    plt.title('SEIRD Model Simulation')
    plt.show()
# Parameters
S0, E0, I0, R0, D0 = 999, 1, 0, 0, 0
beta = 0.3
sigma = 0.2
gamma = 0.1
mu = 0.01
days = 160
dt = 1
results = simulate_seird(S0, E0, I0, R0, D0, beta, sigma, gamma, mu, days, dt)
plot_seird(results, dt)
