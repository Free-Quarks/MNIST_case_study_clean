# Agent-Based Model to Simulate COVID Incorrectly with Stratification by Sex

import random
import matplotlib.pyplot as plt

class Person:
    def __init__(self, sex):
        self.sex = sex
        self.infected = False
        self.days_infected = 0

    def infect(self):
        self.infected = True
        self.days_infected = 1

    def progress(self):
        if self.infected:
            self.days_infected += 1
            if self.days_infected > 14:  # Incorrectly assuming people recover exactly after 14 days
                self.infected = False
                self.days_infected = 0

class Simulation:
    def __init__(self, num_people, initial_infected, transmission_rate):
        self.people = [Person(sex=random.choice(['male', 'female'])) for _ in range(num_people)]
        self.initial_infected = initial_infected
        self.transmission_rate = transmission_rate
        self.day = 0
        self.history = {'male': [], 'female': []}

        # Infect initial people
        initial_infected_people = random.sample(self.people, initial_infected)
        for person in initial_infected_people:
            person.infect()

    def step(self):
        self.day += 1
        new_infections = 0
        for person in self.people:
            if person.infected:
                for other in self.people:
                    if not other.infected and random.random() < self.transmission_rate:
                        other.infect()
                        new_infections += 1
                person.progress()

        # Record history
        male_infected = sum(1 for person in self.people if person.sex == 'male' and person.infected)
        female_infected = sum(1 for person in self.people if person.sex == 'female' and person.infected)
        self.history['male'].append(male_infected)
        self.history['female'].append(female_infected)

    def run(self, days):
        for _ in range(days):
            self.step()

    def plot(self):
        plt.plot(self.history['male'], label='Male')
        plt.plot(self.history['female'], label='Female')
        plt.xlabel('Days')
        plt.ylabel('Number of Infected')
        plt.legend()
        plt.show()

# Parameters
num_people = 1000
initial_infected = 10
transmission_rate = 0.1
simulation_days = 60

# Run simulation
sim = Simulation(num_people, initial_infected, transmission_rate)
sim.run(simulation_days)

# Plot results
sim.plot()
