import numpy as np
import matplotlib.pyplot as plt

# SEIR model differential equations
def deriv(y, t, N, beta, sigma, gamma):
    S, E, I, R = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I
    dRdt = gamma * I
    return dSdt, dEdt, dIdt, dRdt

# Runge-Kutta 4th order method for solving ODEs

def rk4_step(f, y, t, dt, *args):
    k1 = np.array(f(y, t, *args))
    k2 = np.array(f(y + dt/2 * k1, t + dt/2, *args))
    k3 = np.array(f(y + dt/2 * k2, t + dt/2, *args))
    k4 = np.array(f(y + dt * k3, t + dt, *args))
    return y + dt/6 * (k1 + 2*k2 + 2*k3 + k4)

# Total population, N.
N = 1000
# Initial number of infected and recovered individuals, I0 and R0.
I0, R0 = 1, 0
# Everyone else, S0, is susceptible to infection initially.
S0 = N - I0 - R0
# Initial number of exposed individuals, E0.
E0 = 0
# Contact rate, beta, mean recovery rate, gamma, and mean incubation rate, sigma (in 1/days).
beta, gamma, sigma = 0.3, 1./10, 1./5
# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# Initial conditions vector
y0 = S0, E0, I0, R0
# Integrate the SIR equations over the time grid, t.

S, E, I, R = np.zeros(len(t)), np.zeros(len(t)), np.zeros(len(t)), np.zeros(len(t))
S[0], E[0], I[0], R[0] = S0, E0, I0, R0

for i in range(1, len(t)):
    y = (S[i-1], E[i-1], I[i-1], R[i-1])
    S[i], E[i], I[i], R[i] = rk4_step(deriv, y, t[i-1], t[i]-t[i-1], N, beta, sigma, gamma)

# Plot the data
plt.figure(figsize=(10, 6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.grid(True)
plt.show()
