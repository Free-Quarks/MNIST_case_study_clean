import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

# Parameters
n_men = 500
n_women = 500
p_infection = 0.05
initial_infected = 10

# Create a network
G = nx.erdos_renyi_graph(n_men + n_women, 0.1)

# Add sex attribute
for i in range(n_men + n_women):
    G.nodes[i]['sex'] = 'male' if i < n_men else 'female'
    G.nodes[i]['status'] = 'susceptible'

# Initial infected nodes
infected_nodes = np.random.choice(n_men + n_women, initial_infected, replace=False)
for node in infected_nodes:
    G.nodes[node]['status'] = 'infected'

# Simulate the spread
def simulate_step(G, p_infection):
    new_infections = []
    for node in G.nodes():
        if G.nodes[node]['status'] == 'infected':
            for neighbor in G.neighbors(node):
                if G.nodes[neighbor]['status'] == 'susceptible' and np.random.rand() < p_infection:
                    new_infections.append(neighbor)
    for node in new_infections:
        G.nodes[node]['status'] = 'infected'

# Run simulation for 50 steps
steps = 50
for step in range(steps):
    simulate_step(G, p_infection)

# Count infections by sex
infected_men = sum(1 for i in range(n_men) if G.nodes[i]['status'] == 'infected')
infected_women = sum(1 for i in range(n_men, n_men + n_women) if G.nodes[i]['status'] == 'infected')

print(f"Infected men: {infected_men}")
print(f"Infected women: {infected_women}")
