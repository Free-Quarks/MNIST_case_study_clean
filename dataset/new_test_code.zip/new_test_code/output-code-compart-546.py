import numpy as np
import matplotlib.pyplot as plt

# SEIRHD model parameters
beta = 0.3  # Transmission rate
sigma = 1/5.2  # Rate of progression from exposed to infectious (1/incubation period)
gamma = 1/2.9  # Recovery rate
delta = 0.01  # Death rate
alpha = 0.005  # Hospitalization rate
rho = 0.02  # Discharge rate from hospital

# Initial conditions
S0 = 999.0
E0 = 1.0
I0 = 0.0
R0 = 0.0
H0 = 0.0
D0 = 0.0

# Total population
N = S0 + E0 + I0 + R0 + H0 + D0

# Time parameters
T = 160  # Total time
dt = 1.0  # Time step

# Time vector
t = np.arange(0, T, dt)

# Initialize compartments
def initialize_compartments(S0, E0, I0, R0, H0, D0):
    return np.array([S0, E0, I0, R0, H0, D0])

# SEIRHD model
def seirhd_model(y, beta, sigma, gamma, delta, alpha, rho, N):
    S, E, I, R, H, D = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - delta * I - alpha * I
    dRdt = gamma * I + rho * H
    dHdt = alpha * I - rho * H
    dDdt = delta * I
    return np.array([dSdt, dEdt, dIdt, dRdt, dHdt, dDdt])

# Euler method integration
def euler_integration(y, model, params, t):
    results = np.zeros((len(t), len(y)))
    results[0] = y
    for i in range(1, len(t)):
        results[i] = results[i-1] + dt * model(results[i-1], *params)
    return results

# Initial conditions
initial_conditions = initialize_compartments(S0, E0, I0, R0, H0, D0)

# Parameters for the model
params = (beta, sigma, gamma, delta, alpha, rho, N)

# Run the model
results = euler_integration(initial_conditions, seirhd_model, params, t)

# Extract results
S, E, I, R, H, D = results.T

# Plot the results
plt.figure(figsize=(12, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.plot(t, H, label='Hospitalized')
plt.plot(t, D, label='Deaths')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRHD Model Simulation')
plt.grid(True)
plt.show()
