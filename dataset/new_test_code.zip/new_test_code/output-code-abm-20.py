# Import necessary libraries
import random
import numpy as np
import matplotlib.pyplot as plt

class Person:
    def __init__(self, sex, infection_status=False):
        self.sex = sex
        self.infection_status = infection_status
        self.days_infected = 0

    def infect(self):
        if not self.infection_status:
            self.infection_status = True
            self.days_infected = 1

    def recover_or_die(self, recovery_rate, mortality_rate):
        if self.infection_status:
            if random.random() < recovery_rate:
                self.infection_status = False
                self.days_infected = 0
            elif random.random() < mortality_rate:
                return 'died'
        return 'recovered'

    def progress_disease(self):
        if self.infection_status:
            self.days_infected += 1

class Population:
    def __init__(self, size, initial_infected, recovery_rate, mortality_rate):
        self.people = self.create_population(size, initial_infected)
        self.recovery_rate = recovery_rate
        self.mortality_rate = mortality_rate

    def create_population(self, size, initial_infected):
        population = []
        for _ in range(size):
            sex = random.choice(['male', 'female'])
            infected = random.random() < (initial_infected / size)
            person = Person(sex, infected)
            population.append(person)
        return population

    def simulate_day(self, infection_rate):
        newly_infected = []
        for person in self.people:
            if person.infection_status:
                for other_person in self.people:
                    if not other_person.infection_status and random.random() < infection_rate:
                        newly_infected.append(other_person)

        for person in newly_infected:
            person.infect()

        for person in self.people:
            if person.infection_status:
                if person.recover_or_die(self.recovery_rate, self.mortality_rate) == 'died':
                    self.people.remove(person)
                else:
                    person.progress_disease()

    def count_infected(self):
        return sum(1 for person in self.people if person.infection_status)

    def count_by_sex(self):
        males = sum(1 for person in self.people if person.sex == 'male')
        females = sum(1 for person in self.people if person.sex == 'female')
        return males, females

    def count_infected_by_sex(self):
        infected_males = sum(1 for person in self.people if person.sex == 'male' and person.infection_status)
        infected_females = sum(1 for person in self.people if person.sex == 'female' and person.infection_status)
        return infected_males, infected_females

# Parameters
population_size = 1000
initial_infected = 10
recovery_rate = 0.1
mortality_rate = 0.01
infection_rate = 0.05
simulation_days = 100

# Initialize population
population = Population(population_size, initial_infected, recovery_rate, mortality_rate)

daily_infected = []
daily_infected_by_sex = []

# Run simulation
for day in range(simulation_days):
    population.simulate_day(infection_rate)
    daily_infected.append(population.count_infected())
    daily_infected_by_sex.append(population.count_infected_by_sex())

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(daily_infected, label='Total Infected')
plt.xlabel('Days')
plt.ylabel('Number of Infected Individuals')
plt.legend()
plt.show()

infected_males = [day[0] for day in daily_infected_by_sex]
infected_females = [day[1] for day in daily_infected_by_sex]

plt.figure(figsize=(10, 6))
plt.plot(infected_males, label='Infected Males')
plt.plot(infected_females, label='Infected Females')
plt.xlabel('Days')
plt.ylabel('Number of Infected Individuals by Sex')
plt.legend()
plt.show()
