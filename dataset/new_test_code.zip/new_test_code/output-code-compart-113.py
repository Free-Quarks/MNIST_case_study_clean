import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model differential equations

def seird_model(y, beta, gamma, delta, alpha):
    S, E, I, R, D = y
    N = S + E + I + R + D
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - delta * E
    dI_dt = delta * E - gamma * I - alpha * I
    dR_dt = gamma * I
    dD_dt = alpha * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt, dD_dt])

# Define the RK2 method

def rk2_step(f, y, t, dt, *args):
    k1 = f(y, *args)
    k2 = f(y + dt * k1, *args)
    y_next = y + dt * k2
    return y_next

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
D0 = 0
y0 = np.array([S0, E0, I0, R0, D0])

# Parameters
beta = 0.3
gamma = 0.1
delta = 0.1
alpha = 0.01
dt = 0.1
total_time = 160
t = np.arange(0, total_time, dt)

# Initialize arrays to store results
solution = np.zeros((len(t), len(y0)))
solution[0] = y0

# Time-stepping loop using RK2
for i in range(1, len(t)):
    solution[i] = rk2_step(seird_model, solution[i-1], t[i-1], dt, beta, gamma, delta, alpha)

# Plot results
plt.plot(t, solution[:, 0], label='Susceptible')
plt.plot(t, solution[:, 1], label='Exposed')
plt.plot(t, solution[:, 2], label='Infectious')
plt.plot(t, solution[:, 3], label='Recovered')
plt.plot(t, solution[:, 4], label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.show()
