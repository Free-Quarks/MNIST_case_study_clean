import numpy as np

class SEIRModel:
    def __init__(self, beta, sigma, gamma, S0, E0, I0, R0, t0, dt):
        self.beta = beta  # Transmission rate
        self.sigma = sigma  # Rate of progression from exposed to infectious
        self.gamma = gamma  # Recovery rate
        self.S = S0  # Initial number of susceptible individuals
        self.E = E0  # Initial number of exposed individuals
        self.I = I0  # Initial number of infectious individuals
        self.R = R0  # Initial number of recovered individuals
        self.t = t0  # Initial time
        self.dt = dt  # Time step

    def _derivatives(self, S, E, I, R):
        dS = -self.beta * S * I
        dE = self.beta * S * I - self.sigma * E
        dI = self.sigma * E - self.gamma * I
        dR = self.gamma * I
        return dS, dE, dI, dR

    def _rk4_step(self):
        S, E, I, R = self.S, self.E, self.I, self.R
        dt = self.dt

        k1_S, k1_E, k1_I, k1_R = self._derivatives(S, E, I, R)
        k2_S, k2_E, k2_I, k2_R = self._derivatives(S + k1_S * dt / 2, E + k1_E * dt / 2, I + k1_I * dt / 2, R + k1_R * dt / 2)
        k3_S, k3_E, k3_I, k3_R = self._derivatives(S + k2_S * dt / 2, E + k2_E * dt / 2, I + k2_I * dt / 2, R + k2_R * dt / 2)
        k4_S, k4_E, k4_I, k4_R = self._derivatives(S + k3_S * dt, E + k3_E * dt, I + k3_I * dt, R + k3_R * dt)

        self.S += (dt / 6) * (k1_S + 2 * k2_S + 2 * k3_S + k4_S)
        self.E += (dt / 6) * (k1_E + 2 * k2_E + 2 * k3_E + k4_E)
        self.I += (dt / 6) * (k1_I + 2 * k2_I + 2 * k3_I + k4_I)
        self.R += (dt / 6) * (k1_R + 2 * k2_R + 2 * k3_R + k4_R)
        self.t += dt

    def run(self, T):
        results = []
        n_steps = int(T / self.dt)
        for _ in range(n_steps):
            self._rk4_step()
            results.append((self.t, self.S, self.E, self.I, self.R))
        return results

# Example usage:
# model = SEIRModel(beta=0.3, sigma=0.1, gamma=0.1, S0=999, E0=1, I0=0, R0=0, t0=0, dt=1)
# results = model.run(T=160)
# for t, S, E, I, R in results:
#     print(f"t={t}, S={S}, E={E}, I={I}, R={R}")
