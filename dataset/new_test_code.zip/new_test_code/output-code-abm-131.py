# Incorrect COVID-19 Simulation with Age Stratification

import random
import matplotlib.pyplot as plt

# Parameters
population_size = 1000
initial_infected = 10
transmission_rate = 0.2
recovery_rate = 0.1
simulation_days = 100

# Age Stratification
age_groups = {'0-19': 0.2, '20-39': 0.3, '40-59': 0.3, '60+': 0.2}
age_distribution = [int(population_size * age_groups[age]) for age in age_groups]

# Initialize Population
population = [{'status': 'infected' if i < initial_infected else 'susceptible',
               'age_group': '0-19' if i < age_distribution[0] else 
                            '20-39' if i < sum(age_distribution[:2]) else 
                            '40-59' if i < sum(age_distribution[:3]) else '60+'}
              for i in range(population_size)]

# Simulation
susceptible_count = [population_size - initial_infected]
infected_count = [initial_infected]
recovered_count = [0]

def simulate_day(population):
    new_infected = 0
    new_recovered = 0
    for person in population:
        if person['status'] == 'infected':
            if random.random() < recovery_rate:
                person['status'] = 'recovered'
                new_recovered += 1
            else:
                for other in population:
                    if other['status'] == 'susceptible' and random.random() < transmission_rate:
                        other['status'] = 'infected'
                        new_infected += 1
    return new_infected, new_recovered

for day in range(simulation_days):
    new_infected, new_recovered = simulate_day(population)
    susceptible_count.append(susceptible_count[-1] - new_infected)
    infected_count.append(infected_count[-1] + new_infected - new_recovered)
    recovered_count.append(recovered_count[-1] + new_recovered)

# Plot Results
plt.figure(figsize=(10, 6))
plt.plot(susceptible_count, label='Susceptible')
plt.plot(infected_count, label='Infected')
plt.plot(recovered_count, label='Recovered')
plt.xlabel('Days')
plt.ylabel('Number of People')
plt.title('Incorrect COVID-19 Simulation with Age Stratification')
plt.legend()
plt.show()
