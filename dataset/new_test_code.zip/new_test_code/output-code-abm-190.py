import numpy as np
import networkx as nx
import matplotlib.pyplot as plt

# Parameters
population_size = 1000
initial_infected = 10
infection_rate = 0.05
vaccination_rate = 0.01
recovery_rate = 0.01
vaccination_effectiveness = 0.95

# Create a network
G = nx.erdos_renyi_graph(population_size, 0.1)

# Initialize node states: 0 = susceptible, 1 = infected, 2 = recovered, 3 = vaccinated
states = np.zeros(population_size)
infected_nodes = np.random.choice(population_size, initial_infected, replace=False)
states[infected_nodes] = 1

# Function to update the network state
def update_network(G, states, infection_rate, recovery_rate, vaccination_rate, vaccination_effectiveness):
    new_states = states.copy()
    for node in G.nodes():
        if states[node] == 1:  # Infected
            for neighbor in G.neighbors(node):
                if states[neighbor] == 0 and np.random.rand() < infection_rate:  # Susceptible
                    new_states[neighbor] = 1
            if np.random.rand() < recovery_rate:
                new_states[node] = 2  # Recovered
        elif states[node] == 0 and np.random.rand() < vaccination_rate:
            if np.random.rand() < vaccination_effectiveness:
                new_states[node] = 3  # Vaccinated
    return new_states

# Simulation function
def simulate(G, states, infection_rate, recovery_rate, vaccination_rate, vaccination_effectiveness, steps):
    history = [states.copy()]
    for _ in range(steps):
        states = update_network(G, states, infection_rate, recovery_rate, vaccination_rate, vaccination_effectiveness)
        history.append(states.copy())
    return history

# Run the simulation
steps = 50
history = simulate(G, states, infection_rate, recovery_rate, vaccination_rate, vaccination_effectiveness, steps)

# Plot the results
susceptible_count = [np.sum(state == 0) for state in history]
infected_count = [np.sum(state == 1) for state in history]
recovered_count = [np.sum(state == 2) for state in history]
vaccinated_count = [np.sum(state == 3) for state in history]

plt.figure(figsize=(10, 6))
plt.plot(susceptible_count, label='Susceptible')
plt.plot(infected_count, label='Infected')
plt.plot(recovered_count, label='Recovered')
plt.plot(vaccinated_count, label='Vaccinated')
plt.xlabel('Time Steps')
plt.ylabel('Count')
plt.legend()
plt.title('COVID-19 Simulation with Vaccination')
plt.show()
