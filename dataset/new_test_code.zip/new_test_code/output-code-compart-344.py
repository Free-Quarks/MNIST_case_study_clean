import numpy as np
from scipy.integrate import solve_ivp

# Parameters (example values; these should be set according to the specific scenario)
beta = 0.75    # Infection rate
sigma = 0.1    # Rate of developing symptoms
alpha = 0.12   # Rate of detection
gamma = 0.05   # Recovery rate
mu = 0.02      # Mortality rate
nu = 0.04      # Rate of isolation
rho = 0.02     # Rate of hospitalization

# SIDARTHE model compartments
def sidarthe(t, y):
    S, I, D, A, R, T, H, E = y
    dS_dt = -beta * S * (I + D + A + R)
    dI_dt = beta * S * (I + D + A + R) - sigma * I - nu * I
    dD_dt = sigma * I - alpha * D - rho * D
    dA_dt = alpha * D - gamma * A - mu * A
    dR_dt = gamma * A
    dT_dt = nu * I + rho * D
    dH_dt = mu * A
    dE_dt = H  # Exposed (dead) individuals
    return [dS_dt, dI_dt, dD_dt, dA_dt, dR_dt, dT_dt, dH_dt, dE_dt]

# Initial conditions
S0 = 0.99
I0 = 0.01
D0 = 0.0
A0 = 0.0
R0 = 0.0
T0 = 0.0
H0 = 0.0
E0 = 0.0
y0 = [S0, I0, D0, A0, R0, T0, H0, E0]

t_span = [0, 160]  # Time span for the simulation

def rk3_step(f, y, t, dt):
    k1 = f(t, y)
    k2 = f(t + dt/2, y + dt/2 * np.array(k1))
    k3 = f(t + dt, y - dt * np.array(k1) + 2 * dt * np.array(k2))
    return y + dt/6 * (np.array(k1) + 4 * np.array(k2) + np.array(k3))

def solve_rk3(f, y0, t_span, dt):
    t0, tf = t_span
    t_values = np.arange(t0, tf, dt)
    y_values = [y0]
    y = y0
    for t in t_values[:-1]:
        y = rk3_step(f, y, t, dt)
        y_values.append(y)
    return np.array(t_values), np.array(y_values)

# Solving the system using RK3
dt = 0.1  # Time step
t_values, y_values = solve_rk3(sidarthe, y0, t_span, dt)

# Output the results
for t, y in zip(t_values, y_values):
    print(f"t={t:.1f}, S={y[0]:.4f}, I={y[1]:.4f}, D={y[2]:.4f}, A={y[3]:.4f}, R={y[4]:.4f}, T={y[5]:.4f}, H={y[6]:.4f}, E={y[7]:.4f}")
