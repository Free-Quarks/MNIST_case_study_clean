import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp

# Define the SEIRHD model

def SEIRHD(t, y, beta, sigma, gamma, delta, alpha, rho):
    S, E, I, R, H, D = y
    N = S + E + I + R + H + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - delta * I - alpha * I
    dRdt = gamma * I
    dHdt = delta * I - rho * H
    dDdt = alpha * I + rho * H
    return [dSdt, dEdt, dIdt, dRdt, dHdt, dDdt]

# Initial conditions
S0, E0, I0, R0, H0, D0 = 999, 1, 0, 0, 0, 0
initial_conditions = [S0, E0, I0, R0, H0, D0]

# Parameters
beta = 0.3
sigma = 0.1
gamma = 0.05
delta = 0.01
alpha = 0.005
rho = 0.002

# Time points
t = np.linspace(0, 160, 160)

# Solve the ODEs
solution = solve_ivp(SEIRHD, [0, 160], initial_conditions, args=(beta, sigma, gamma, delta, alpha, rho), method='RK23', t_eval=t)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(solution.t, solution.y[0], label='Susceptible')
plt.plot(solution.t, solution.y[1], label='Exposed')
plt.plot(solution.t, solution.y[2], label='Infected')
plt.plot(solution.t, solution.y[3], label='Recovered')
plt.plot(solution.t, solution.y[4], label='Hospitalized')
plt.plot(solution.t, solution.y[5], label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRHD Model')
plt.show()
