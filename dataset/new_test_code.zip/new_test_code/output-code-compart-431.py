import numpy as np
import matplotlib.pyplot as plt

# SEIR model parameters
beta = 0.3  # infection rate
sigma = 1/5.2  # incubation rate
gamma = 1/12.9  # recovery rate

# Population
N = 1000

# Initial conditions
E0 = 1  # initial exposed individuals
I0 = 0  # initial infected individuals
R0 = 0  # initial recovered individuals
S0 = N - E0 - I0 - R0  # initial susceptible individuals

# Time parameters
T = 160  # total time
dt = 1  # time step

# Initialize arrays to store the values
S = np.zeros(T)
E = np.zeros(T)
I = np.zeros(T)
R = np.zeros(T)

# Set initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# Euler method to solve the SEIR model
for t in range(T - 1):
    S[t+1] = S[t] - dt * beta * S[t] * I[t] / N
    E[t+1] = E[t] + dt * (beta * S[t] * I[t] / N - sigma * E[t])
    I[t+1] = I[t] + dt * (sigma * E[t] - gamma * I[t])
    R[t+1] = R[t] + dt * gamma * I[t]

# Plotting the results
plt.figure(figsize=(12, 6))
plt.plot(S, label='Susceptible')
plt.plot(E, label='Exposed')
plt.plot(I, label='Infected')
plt.plot(R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.title('SEIR Model Simulation')
plt.grid(True)
plt.show()
