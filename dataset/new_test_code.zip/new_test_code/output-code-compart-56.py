import numpy as np
import matplotlib.pyplot as plt

# Parameters
N = 1000  # Total population
beta = 0.3  # Transmission rate
sigma = 1/5.2  # Rate of progression from exposed to infectious (1/incubation period)
gamma = 1/2.9  # Recovery rate (1/infectious period)

# Initial conditions
S0 = 999  # Initial susceptible population
E0 = 1  # Initial exposed population
I0 = 0  # Initial infectious population
R0 = 0  # Initial recovered population

# Time parameters
t_max = 160  # Total time in days
dt = 1  # Time step in days

t = np.arange(0, t_max, dt)

# Initialize arrays to store values
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

# Set initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# Euler method to solve the SEIR model
for i in range(1, len(t)):
    S[i] = S[i-1] - (beta * S[i-1] * I[i-1] / N) * dt
    E[i] = E[i-1] + (beta * S[i-1] * I[i-1] / N - sigma * E[i-1]) * dt
    I[i] = I[i-1] + (sigma * E[i-1] - gamma * I[i-1]) * dt
    R[i] = R[i-1] + (gamma * I[i-1]) * dt

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.title('SEIR Model Simulation')
plt.grid(True)
plt.show()
