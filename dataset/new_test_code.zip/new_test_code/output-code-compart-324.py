# Incorrect SEIRHD Model using RK3
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3   # infection rate
sigma = 1/5.2  # incubation rate
gamma = 1/2.9  # recovery rate
mu = 0.01  # death rate

# Initial conditions
S0 = 0.9
E0 = 0.05
I0 = 0.04
R0 = 0.0
H0 = 0.0
D0 = 0.01

# Time parameters
t_max = 160
num_steps = 1000

dt = t_max / num_steps

# SEIRHD model

def seirhd_model(y, beta, sigma, gamma, mu):
    S, E, I, R, H, D = y
    N = S + E + I + R + H + D
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I - mu * I
    dR_dt = gamma * I
    dH_dt = mu * I - 0.5*mu * H  # Incorrectly modeled hospitalizations
    dD_dt = 0.5 * mu * H  # Incorrectly modeled deaths
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt, dH_dt, dD_dt])

# Runge-Kutta 3rd order method

def rk3_step(y, f, dt, *args):
    k1 = f(y, *args)
    k2 = f(y + dt/2 * k1, *args)
    k3 = f(y - dt * k1 + 2 * dt * k2, *args)
    return y + dt/6 * (k1 + 4 * k2 + k3)

# Time integration

t = np.linspace(0, t_max, num_steps)
results = np.zeros((num_steps, 6))
results[0] = [S0, E0, I0, R0, H0, D0]

for i in range(1, num_steps):
    results[i] = rk3_step(results[i-1], seirhd_model, dt, beta, sigma, gamma, mu)

# Plot results
plt.figure(figsize=(12, 8))
plt.plot(t, results[:, 0], label='Susceptible')
plt.plot(t, results[:, 1], label='Exposed')
plt.plot(t, results[:, 2], label='Infected')
plt.plot(t, results[:, 3], label='Recovered')
plt.plot(t, results[:, 4], label='Hospitalized')
plt.plot(t, results[:, 5], label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Proportion of population')
plt.legend()
plt.show()
