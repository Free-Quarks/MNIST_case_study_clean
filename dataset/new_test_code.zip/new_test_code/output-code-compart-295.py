import numpy as np
from scipy.integrate import solve_ivp
import json

# Define the SIDARTHE model equations
def sidarthe_model(t, y, alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_):
    S, I, D, A, R, T, H, E = y
    N = S + I + D + A + R + T + H + E
    dSdt = -S * (beta * I + delta * D + zeta * A + mu * T)
    dIdt = S * (beta * I + delta * D + zeta * A + mu * T) - (alpha + gamma + lambda_) * I
    dDdt = alpha * I - (beta + epsilon + lambda_) * D
    dAdt = gamma * I + epsilon * D - (theta + lambda_) * A
    dRdt = theta * A + eta * T + nu * H - (tau + lambda_) * R
    dTdt = lambda_ * (I + D + A + E + H) - (eta + tau) * T
    dHdt = tau * R - (nu + lambda_) * H
    dEdt = lambda_ * E - lambda_ * H
    return [dSdt, dIdt, dDdt, dAdt, dRdt, dTdt, dHdt, dEdt]

# Define the RK4 method
def rk4(f, y0, t, args=()):
    n = len(t)
    y = np.zeros((n, len(y0)))
    y[0] = y0
    dt = t[1] - t[0]
    for i in range(1, n):
        k1 = f(t[i-1], y[i-1], *args)
        k2 = f(t[i-1] + dt/2, y[i-1] + dt/2 * np.array(k1), *args)
        k3 = f(t[i-1] + dt/2, y[i-1] + dt/2 * np.array(k2), *args)
        k4 = f(t[i-1] + dt, y[i-1] + dt * np.array(k3), *args)
        y[i] = y[i-1] + dt/6 * np.array(k1 + 2*k2 + 2*k3 + k4)
    return y

# Parameters
alpha = 0.57
beta = 0.011
gamma = 0.456
delta = 0.011
epsilon = 0.171
theta = 0.371
zeta = 0.125
eta = 0.125
mu = 0.016
nu = 0.027
tau = 0.02
lambda_ = 0.034

# Initial conditions
S0 = 0.99
I0 = 0.01
D0 = 0
A0 = 0
R0 = 0
T0 = 0
H0 = 0
E0 = 0
y0 = [S0, I0, D0, A0, R0, T0, H0, E0]

# Time vector
t = np.linspace(0, 100, 1001)

# Solve the SIDARTHE model using RK4 method
y = rk4(sidarthe_model, y0, t, args=(alpha, beta, gamma, delta, epsilon, theta, zeta, eta, mu, nu, tau, lambda_))

# Convert results to JSON format
results = {'time': t.tolist(), 'S': y[:,0].tolist(), 'I': y[:,1].tolist(), 'D': y[:,2].tolist(), 'A': y[:,3].tolist(), 'R': y[:,4].tolist(), 'T': y[:,5].tolist(), 'H': y[:,6].tolist(), 'E': y[:,7].tolist()}
json_results = json.dumps(results, indent=4)

# Output the JSON string
print(json_results)
