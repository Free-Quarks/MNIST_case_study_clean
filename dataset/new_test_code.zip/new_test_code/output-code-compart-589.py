import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRD model
class SEIRD:
    def __init__(self, S0, E0, I0, R0, D0, beta, sigma, gamma, mu, dt):
        self.S = S0
        self.E = E0
        self.I = I0
        self.R = R0
        self.D = D0
        self.beta = beta
        self.sigma = sigma
        self.gamma = gamma
        self.mu = mu
        self.dt = dt

    def derivatives(self, S, E, I, R, D):
        N = S + E + I + R + D
        dSdt = -self.beta * S * I / N
        dEdt = self.beta * S * I / N - self.sigma * E
        dIdt = self.sigma * E - (self.gamma + self.mu) * I
        dRdt = self.gamma * I
        dDdt = self.mu * I
        return dSdt, dEdt, dIdt, dRdt, dDdt

    def runge_kutta_3(self, S, E, I, R, D):
        k1 = self.derivatives(S, E, I, R, D)
        S1 = S + self.dt * k1[0] / 2
        E1 = E + self.dt * k1[1] / 2
        I1 = I + self.dt * k1[2] / 2
        R1 = R + self.dt * k1[3] / 2
        D1 = D + self.dt * k1[4] / 2
        k2 = self.derivatives(S1, E1, I1, R1, D1)
        S2 = S - self.dt * k1[0] + 2 * self.dt * k2[0]
        E2 = E - self.dt * k1[1] + 2 * self.dt * k2[1]
        I2 = I - self.dt * k1[2] + 2 * self.dt * k2[2]
        R2 = R - self.dt * k1[3] + 2 * self.dt * k2[3]
        D2 = D - self.dt * k1[4] + 2 * self.dt * k2[4]
        k3 = self.derivatives(S2, E2, I2, R2, D2)
        S_next = S + self.dt * (k1[0] + 4 * k2[0] + k3[0]) / 6
        E_next = E + self.dt * (k1[1] + 4 * k2[1] + k3[1]) / 6
        I_next = I + self.dt * (k1[2] + 4 * k2[2] + k3[2]) / 6
        R_next = R + self.dt * (k1[3] + 4 * k2[3] + k3[3]) / 6
        D_next = D + self.dt * (k1[4] + 4 * k2[4] + k3[4]) / 6
        return S_next, E_next, I_next, R_next, D_next

    def simulate(self, days):
        S_values = [self.S]
        E_values = [self.E]
        I_values = [self.I]
        R_values = [self.R]
        D_values = [self.D]
        for _ in range(days):
            self.S, self.E, self.I, self.R, self.D = self.runge_kutta_3(self.S, self.E, self.I, self.R, self.D)
            S_values.append(self.S)
            E_values.append(self.E)
            I_values.append(self.I)
            R_values.append(self.R)
            D_values.append(self.D)
        return S_values, E_values, I_values, R_values, D_values

# Parameters
S0 = 999
E0 = 1
I0 = 0
R0 = 0
D0 = 0
beta = 0.3
sigma = 0.1
gamma = 0.1
mu = 0.01
dt = 0.1

# Create the model
model = SEIRD(S0, E0, I0, R0, D0, beta, sigma, gamma, mu, dt)

# Simulate
days = 160
S_values, E_values, I_values, R_values, D_values = model.simulate(days)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(S_values, label='Susceptible')
plt.plot(E_values, label='Exposed')
plt.plot(I_values, label='Infected')
plt.plot(R_values, label='Recovered')
plt.plot(D_values, label='Deceased')
plt.xlabel('Days')
plt.ylabel('Population')
plt.legend()
plt.title('SEIRD Model Simulation')
plt.show()
