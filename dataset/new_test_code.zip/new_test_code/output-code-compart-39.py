# SEIRD model with RK3 integration
import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3   # infection rate
sigma = 0.1  # incubation rate
gamma = 0.05 # recovery rate
delta = 0.01 # mortality rate
N = 1000     # total population

# Initial conditions
S0 = 999
E0 = 1
I0 = 0
R0 = 0
D0 = 0

# Time parameters
T = 160  # total time
dt = 0.1 # time step

# SEIRD equations
def SEIRD(y, beta, sigma, gamma, delta, N):
    S, E, I, R, D = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I - delta * I
    dRdt = gamma * I
    dDdt = delta * I
    return np.array([dSdt, dEdt, dIdt, dRdt, dDdt])

# Runge-Kutta 3rd order

def rk3_step(y, f, dt, *args):
    k1 = f(y, *args)
    k2 = f(y + dt/2 * k1, *args)
    k3 = f(y - dt * k1 + 2 * dt * k2, *args)
    return y + dt/6 * (k1 + 4 * k2 + k3)

# Simulation
steps = int(T / dt)
results = np.zeros((steps, 5))
y = np.array([S0, E0, I0, R0, D0])
for i in range(steps):
    results[i] = y
    y = rk3_step(y, SEIRD, dt, beta, sigma, gamma, delta, N)

# Plot results
plt.plot(results)
plt.legend(['Susceptible', 'Exposed', 'Infected', 'Recovered', 'Deceased'])
plt.xlabel('Time')
plt.ylabel('Population')
plt.title('SEIRD Model Simulation')
plt.show()

