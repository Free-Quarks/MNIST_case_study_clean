import numpy as np
import matplotlib.pyplot as plt

# Define the SIR model
class SIRModel:
    def __init__(self, beta, gamma, S0, I0, R0):
        self.beta = beta
        self.gamma = gamma
        self.S = S0
        self.I = I0
        self.R = R0

    def derivatives(self, S, I, R):
        dSdt = -self.beta * S * I
        dIdt = self.beta * S * I - self.gamma * I
        dRdt = self.gamma * I
        return dSdt, dIdt, dRdt

    def step(self, dt):
        k1_S, k1_I, k1_R = self.derivatives(self.S, self.I, self.R)
        S_mid = self.S + k1_S * dt / 2
        I_mid = self.I + k1_I * dt / 2
        R_mid = self.R + k1_R * dt / 2
        k2_S, k2_I, k2_R = self.derivatives(S_mid, I_mid, R_mid)
        self.S += k2_S * dt
        self.I += k2_I * dt
        self.R += k2_R * dt

    def run(self, T, dt):
        t = np.arange(0, T, dt)
        S = np.zeros_like(t)
        I = np.zeros_like(t)
        R = np.zeros_like(t)
        for i in range(len(t)):
            S[i] = self.S
            I[i] = self.I
            R[i] = self.R
            self.step(dt)
        return t, S, I, R

# Parameters
beta = 0.3  # infection rate
gamma = 0.1  # recovery rate
S0 = 0.99  # initial susceptible population
I0 = 0.01  # initial infected population
R0 = 0.0  # initial recovered population
T = 160  # total time
dt = 0.1  # time step

# Simulation
sir_model = SIRModel(beta, gamma, S0, I0, R0)
t, S, I, R = sir_model.run(T, dt)

# Plotting
plt.figure(figsize=(10,6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.grid()
plt.title('SIR Model Simulation using RK2')
plt.show()
