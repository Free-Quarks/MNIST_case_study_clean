import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
sigma = 0.1  # Rate of progression from exposed to infected
gamma = 0.1  # Recovery rate
mu = 0.01  # Death rate
nu = 0.01  # Hospitalization rate
xi = 0.05  # Death in hospital rate
delta = 0.05  # Discharge from hospital rate

# Initial conditions
S0 = 0.99
E0 = 0.01
I0 = 0.0
R0 = 0.0
H0 = 0.0
D0 = 0.0

# Time parameters
T = 160  # Total time
dt = 1.0  # Time step

# Initialize arrays
S = [S0]
E = [E0]
I = [I0]
R = [R0]
H = [H0]
D = [D0]
t = np.arange(0, T, dt)

# Euler method
for _ in t[1:]:
    S_new = S[-1] - beta * S[-1] * I[-1] * dt
    E_new = E[-1] + beta * S[-1] * I[-1] * dt - sigma * E[-1] * dt
    I_new = I[-1] + sigma * E[-1] * dt - gamma * I[-1] * dt - mu * I[-1] * dt - nu * I[-1] * dt
    R_new = R[-1] + gamma * I[-1] * dt
    H_new = H[-1] + nu * I[-1] * dt - xi * H[-1] * dt - delta * H[-1] * dt
    D_new = D[-1] + mu * I[-1] * dt + xi * H[-1] * dt

    S.append(S_new)
    E.append(E_new)
    I.append(I_new)
    R.append(R_new)
    H.append(H_new)
    D.append(D_new)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible (S)')
plt.plot(t, E, label='Exposed (E)')
plt.plot(t, I, label='Infected (I)')
plt.plot(t, R, label='Recovered (R)')
plt.plot(t, H, label='Hospitalized (H)')
plt.plot(t, D, label='Deceased (D)')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.title('SEIRHD Model Simulation')
plt.show()
