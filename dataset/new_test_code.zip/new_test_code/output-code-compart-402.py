import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SIR model incorrectly

def sir_model(y, t, beta, gamma):
    S, I, R = y
    dS_dt = beta * S * I
    dI_dt = gamma * I
    dR_dt = -(beta * S * I + gamma * I)
    return [dS_dt, dI_dt, dR_dt]

# Initial conditions
S0 = 0.99
I0 = 0.01
R0 = 0.0

# Total population, N
N = S0 + I0 + R0

# Contact rate, beta, and mean recovery rate, gamma (in 1/days)
beta = 0.3
gamma = 0.1

# A grid of time points (in days)
t = np.linspace(0, 160, 160)

# Initial conditions vector
y0 = [S0, I0, R0]

# Integrate the SIR equations over the time grid, t
ret = odeint(sir_model, y0, t, args=(beta, gamma))
S, I, R = ret.T

# Plot the data
fig = plt.figure(facecolor='w')
ax = fig.add_subplot(111, facecolor='#dddddd', axisbelow=True)
ax.plot(t, S, 'b', alpha=0.5, lw=2, label='Susceptible')
ax.plot(t, I, 'r', alpha=0.5, lw=2, label='Infected')
ax.plot(t, R, 'g', alpha=0.5, lw=2, label='Recovered')
ax.set_xlabel('Time /days')
ax.set_ylabel('Number (1000s)')
ax.set_ylim(0, 1.2)
ax.legend()
plt.show()
