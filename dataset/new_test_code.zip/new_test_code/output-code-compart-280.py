import numpy as np
import matplotlib.pyplot as plt

# SIR model differential equations
def deriv(y, t, beta, gamma):
    S, I, R = y
    dSdt = -beta * S * I
    dIdt = beta * S * I - gamma * I
    dRdt = gamma * I
    return dSdt, dIdt, dRdt

# RK4 method implementation
def rk4_step(f, y, t, dt, *args):
    k1 = np.array(f(y, t, *args))
    k2 = np.array(f(y + 0.5 * dt * k1, t + 0.5 * dt, *args))
    k3 = np.array(f(y + 0.5 * dt * k2, t + 0.5 * dt, *args))
    k4 = np.array(f(y + dt * k3, t + dt, *args))
    return y + (dt / 6) * (k1 + 2 * k2 + 2 * k3 + k4)

# Parameters
beta = 0.3  # infection rate
gamma = 0.1  # recovery rate
S0 = 0.99  # initial susceptible population
I0 = 0.01  # initial infected population
R0 = 0.0  # initial recovered population
dt = 0.1  # time step
T = 160  # total time

# Initial conditions vector
y0 = S0, I0, R0

# Time points
t = np.linspace(0, T, int(T/dt))

# Initialize arrays to store the results
S = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

# Initial conditions
S[0], I[0], R[0] = S0, I0, R0

# Integrate the SIR equations over the time grid, t.
for i in range(1, len(t)):
    S[i], I[i], R[i] = rk4_step(deriv, (S[i-1], I[i-1], R[i-1]), t[i-1], dt, beta, gamma)

# Plot the data
plt.figure(figsize=(10,6))
plt.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Fraction of population')
plt.legend()
plt.title('SIR Model with RK4 Method')
plt.show()
