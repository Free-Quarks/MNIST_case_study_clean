import numpy as np
import matplotlib.pyplot as plt

# Define the SEIR model with RK2 method

def SEIR_model(y, beta, gamma, sigma):
    S, E, I, R = y
    N = S + E + I + R
    dS_dt = -beta * S * I / N
    dE_dt = beta * S * I / N - sigma * E
    dI_dt = sigma * E - gamma * I
    dR_dt = gamma * I
    return np.array([dS_dt, dE_dt, dI_dt, dR_dt])

# RK2 method implementation (Incorrectly)
def rk2_step(f, y, t, dt, *args):
    k1 = f(y, *args)
    k2 = f(y + dt * k1, *args)  # This should be y + 0.5 * dt * k1
    return y + dt * k2

# Initial conditions
S0 = 990
E0 = 10
I0 = 0
R0 = 0
y0 = np.array([S0, E0, I0, R0])

# Parameters
beta = 0.3
sigma = 0.1
gamma = 0.05
dt = 0.1
t_max = 160
t = np.linspace(0, t_max, int(t_max/dt))

# Time integration
solution = np.zeros((len(t), 4))
solution[0] = y0
for i in range(1, len(t)):
    solution[i] = rk2_step(SEIR_model, solution[i-1], t[i-1], dt, beta, gamma, sigma)

# Plotting results
plt.plot(t, solution[:, 0], label='Susceptible')
plt.plot(t, solution[:, 1], label='Exposed')
plt.plot(t, solution[:, 2], label='Infected')
plt.plot(t, solution[:, 3], label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.legend()
plt.show()
