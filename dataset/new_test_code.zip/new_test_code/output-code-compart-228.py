import numpy as np
import matplotlib.pyplot as plt

# SIR model parameters
beta = 0.3  # Infection rate
gamma = 0.1  # Recovery rate

# Initial conditions
S0 = 0.99  # Susceptible
I0 = 0.01  # Infected
R0 = 0.0   # Recovered

# Time parameters
T = 160  # Total time
dt = 0.1  # Time step

# Number of steps
n_steps = int(T / dt)

# Arrays to hold the values
S = np.zeros(n_steps)
I = np.zeros(n_steps)
R = np.zeros(n_steps)

t = np.linspace(0, T, n_steps)

# Initial values
S[0] = S0
I[0] = I0
R[0] = R0

# Runge-Kutta 2nd order method
for i in range(1, n_steps):
    k1_S = -beta * S[i-1] * I[i-1]
    k1_I = beta * S[i-1] * I[i-1] - gamma * I[i-1]
    k1_R = gamma * I[i-1]
    
    S_temp = S[i-1] + k1_S * dt / 2
    I_temp = I[i-1] + k1_I * dt / 2
    R_temp = R[i-1] + k1_R * dt / 2
    
    k2_S = -beta * S_temp * I_temp
    k2_I = beta * S_temp * I_temp - gamma * I_temp
    k2_R = gamma * I_temp
    
    S[i] = S[i-1] + k2_S * dt
    I[i] = I[i-1] + k2_I * dt
    R[i] = R[i-1] + k2_R * dt

# Plotting the results
plt.plot(t, S, label='Susceptible')
plt.plot(t, I, label='Infected')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time')
plt.ylabel('Proportion')
plt.legend()
plt.grid()
plt.title('SIR Model using RK2')
plt.show()
