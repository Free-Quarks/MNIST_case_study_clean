
import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRHD model compartments
class SEIRHDModel:
    def __init__(self, beta, sigma, gamma, delta, alpha, mu):
        self.beta = beta    # Infection rate
        self.sigma = sigma  # Rate of progression from exposed to infectious
        self.gamma = gamma  # Recovery rate
        self.delta = delta  # Death rate
        self.alpha = alpha  # Hospitalization rate
        self.mu = mu        # Mortality rate in hospitals

    def derivatives(self, S, E, I, R, H, D, N):
        dSdt = -self.beta * S * I / N
        dEdt = self.beta * S * I / N - self.sigma * E
        dIdt = self.sigma * E - self.gamma * I - self.alpha * I - self.delta * I
        dRdt = self.gamma * I
        dHdt = self.alpha * I - self.mu * H
        dDdt = self.delta * I + self.mu * H
        return dSdt, dEdt, dIdt, dRdt, dHdt, dDdt

    def euler_step(self, S, E, I, R, H, D, N, dt):
        dSdt, dEdt, dIdt, dRdt, dHdt, dDdt = self.derivatives(S, E, I, R, H, D, N)
        S += dSdt * dt
        E += dEdt * dt
        I += dIdt * dt
        R += dRdt * dt
        H += dHdt * dt
        D += dDdt * dt
        return S, E, I, R, H, D

    def run(self, S0, E0, I0, R0, H0, D0, N, days, dt):
        S, E, I, R, H, D = S0, E0, I0, R0, H0, D0
        S_values, E_values, I_values, R_values, H_values, D_values = [], [], [], [], [], []
        
        for _ in range(int(days / dt)):
            S, E, I, R, H, D = self.euler_step(S, E, I, R, H, D, N, dt)
            S_values.append(S)
            E_values.append(E)
            I_values.append(I)
            R_values.append(R)
            H_values.append(H)
            D_values.append(D)
        
        return S_values, E_values, I_values, R_values, H_values, D_values

# Parameters
beta = 0.3
sigma = 1/5.2
gamma = 1/12.39
delta = 0.005
alpha = 0.15
mu = 0.03

# Initial conditions
S0 = 999999
E0 = 1
I0 = 0
R0 = 0
H0 = 0
D0 = 0
N = S0 + E0 + I0 + R0 + H0 + D0
days = 160
dt = 1

# Create a model instance
model = SEIRHDModel(beta, sigma, gamma, delta, alpha, mu)

# Run the model
S_values, E_values, I_values, R_values, H_values, D_values = model.run(S0, E0, I0, R0, H0, D0, N, days, dt)

# Plot the results
plt.figure(figsize=(12, 8))
plt.plot(S_values, label='Susceptible')
plt.plot(E_values, label='Exposed')
plt.plot(I_values, label='Infectious')
plt.plot(R_values, label='Recovered')
plt.plot(H_values, label='Hospitalized')
plt.plot(D_values, label='Dead')
plt.xlabel('Days')
plt.ylabel('Population')
plt.title('SEIRHD Model')
plt.legend()
plt.show()

