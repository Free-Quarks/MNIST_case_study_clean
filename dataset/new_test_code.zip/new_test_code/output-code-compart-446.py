import numpy as np

class SEIRHDModel:
    def __init__(self, beta, sigma, gamma, mu, delta, population, initial_conditions):
        self.beta = beta  # Transmission rate
        self.sigma = sigma  # Inverse of incubation period
        self.gamma = gamma  # Recovery rate
        self.mu = mu  # Mortality rate
        self.delta = delta  # Hospitalization rate
        self.population = population  # Total population

        # Initial conditions
        self.S, self.E, self.I, self.R, self.H, self.D = initial_conditions

    def step(self, dt):
        N = self.S + self.E + self.I + self.R + self.H  # Total non-deceased population

        # Differential equations
        dS = -self.beta * self.S * self.I / N
        dE = self.beta * self.S * self.I / N - self.sigma * self.E
        dI = self.sigma * self.E - (self.gamma + self.mu + self.delta) * self.I
        dR = self.gamma * self.I
        dH = self.delta * self.I
        dD = self.mu * self.I

        # Update compartments
        self.S += dS * dt
        self.E += dE * dt
        self.I += dI * dt
        self.R += dR * dt
        self.H += dH * dt
        self.D += dD * dt

    def run(self, days, dt=1):
        num_steps = int(days / dt)
        results = {
            'S': np.zeros(num_steps),
            'E': np.zeros(num_steps),
            'I': np.zeros(num_steps),
            'R': np.zeros(num_steps),
            'H': np.zeros(num_steps),
            'D': np.zeros(num_steps)
        }
        for t in range(num_steps):
            results['S'][t] = self.S
            results['E'][t] = self.E
            results['I'][t] = self.I
            results['R'][t] = self.R
            results['H'][t] = self.H
            results['D'][t] = self.D
            self.step(dt)
        return results

# Example usage
if __name__ == '__main__':
    beta = 0.3
    sigma = 1/5.2
    gamma = 1/2.3
    mu = 0.01
    delta = 0.05
    population = 10000
    initial_conditions = (9990, 10, 0, 0, 0, 0)

    model = SEIRHDModel(beta, sigma, gamma, mu, delta, population, initial_conditions)
    results = model.run(160)

    # Print the results
    for key, values in results.items():
        print(f'{key}: {values[-1]}')
