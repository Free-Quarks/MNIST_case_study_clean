import numpy as np
import matplotlib.pyplot as plt

# Define parameters
beta = 0.3  # transmission rate
sigma = 1/5.2  # incubation rate
gamma = 1/2.9  # recovery rate
mu = 0.001  # mortality rate
delta = 0.005  # hospitalization rate
rho = 0.002  # discharge rate

# Define initial conditions
S0 = 999  # susceptible
E0 = 1  # exposed
I0 = 0  # infected
R0 = 0  # recovered
H0 = 0  # hospitalized
D0 = 0  # deceased
initial_conditions = [S0, E0, I0, R0, H0, D0]

# Define time parameters
t = np.linspace(0, 160, 160)

# SEIRHD model equations
def seirhd_model(y, t, beta, sigma, gamma, mu, delta, rho):
    S, E, I, R, H, D = y
    dS_dt = -beta * S * I
    dE_dt = beta * S * I - sigma * E
    dI_dt = sigma * E - gamma * I - mu * I - delta * I
    dR_dt = gamma * I + rho * H
    dH_dt = delta * I - rho * H
    dD_dt = mu * I
    return [dS_dt, dE_dt, dI_dt, dR_dt, dH_dt, dD_dt]

# Runge-Kutta 2nd order method (RK2)
def rk2_step(func, y, t, dt, *params):
    k1 = func(y, t, *params)
    k2 = func([yi + dt * ki / 2 for yi, ki in zip(y, k1)], t + dt / 2, *params)
    return [yi + dt * ki for yi, ki in zip(y, k2)]

# Integrate the SEIRHD model equations
solution = [initial_conditions]
dt = t[1] - t[0]
for time in t[:-1]:
    next_step = rk2_step(seirhd_model, solution[-1], time, dt, beta, sigma, gamma, mu, delta, rho)
    solution.append(next_step)

solution = np.array(solution)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, solution[:, 0], label='Susceptible')
plt.plot(t, solution[:, 1], label='Exposed')
plt.plot(t, solution[:, 2], label='Infected')
plt.plot(t, solution[:, 3], label='Recovered')
plt.plot(t, solution[:, 4], label='Hospitalized')
plt.plot(t, solution[:, 5], label='Deceased')
plt.xlabel('Time (days)')
plt.ylabel('Population')
plt.title('SEIRHD Model using RK2 Method')
plt.legend()
plt.show()
