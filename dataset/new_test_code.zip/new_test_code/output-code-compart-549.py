import numpy as np
import matplotlib.pyplot as plt

# Define the SEIRHD model
class SEIRHDModel:
    def __init__(self, beta, sigma, gamma, delta, alpha, mu, population):
        self.beta = beta      # Transmission rate
        self.sigma = sigma    # Rate of progression from exposed to infectious
        self.gamma = gamma    # Recovery rate
        self.delta = delta    # Rate of progression from infectious to hospitalized
        self.alpha = alpha    # Death rate
        self.mu = mu          # Hospitalization discharge rate
        self.population = population
        
    def derivatives(self, y, t):
        S, E, I, R, H, D = y
        N = self.population
        dSdt = -self.beta * S * I / N
        dEdt = self.beta * S * I / N - self.sigma * E
        dIdt = self.sigma * E - (self.gamma + self.delta + self.alpha) * I
        dRdt = self.gamma * I
        dHdt = self.delta * I - self.mu * H
        dDdt = self.alpha * I
        return np.array([dSdt, dEdt, dIdt, dRdt, dHdt, dDdt])

    def rk3_step(self, y, t, dt):
        k1 = self.derivatives(y, t)
        k2 = self.derivatives(y + 0.5 * dt * k1, t + 0.5 * dt)
        k3 = self.derivatives(y - dt * k1 + 2 * dt * k2, t + dt)
        return y + (dt / 6) * (k1 + 4 * k2 + k3)

    def run_simulation(self, initial_conditions, t_max, dt):
        t_values = np.arange(0, t_max, dt)
        results = np.zeros((len(t_values), len(initial_conditions)))
        results[0] = initial_conditions
        for i in range(1, len(t_values)):
            results[i] = self.rk3_step(results[i-1], t_values[i-1], dt)
        return t_values, results

# Parameters
beta = 0.3
sigma = 0.2
gamma = 0.1
delta = 0.05
alpha = 0.02
mu = 0.01
population = 10000

# Initial conditions
initial_conditions = [9990, 10, 0, 0, 0, 0]  # S, E, I, R, H, D

# Simulation
model = SEIRHDModel(beta, sigma, gamma, delta, alpha, mu, population)
t_max = 160
dt = 1

# Run the simulation
t_values, results = model.run_simulation(initial_conditions, t_max, dt)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t_values, results[:, 0], label='Susceptible')
plt.plot(t_values, results[:, 1], label='Exposed')
plt.plot(t_values, results[:, 2], label='Infectious')
plt.plot(t_values, results[:, 3], label='Recovered')
plt.plot(t_values, results[:, 4], label='Hospitalized')
plt.plot(t_values, results[:, 5], label='Dead')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.title('SEIRHD Model Simulation')
plt.grid(True)
plt.show()
