import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# Define the SEIRD model with incorrect equations

def seird_model(y, t, beta, gamma, delta, alpha):
    S, E, I, R, D = y
    N = S + E + I + R + D
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - alpha * E
    dIdt = alpha * E - gamma * I - delta * I
    dRdt = gamma * I
    dDdt = delta * R  # Incorrect compartment movement
    return [dSdt, dEdt, dIdt, dRdt, dDdt]

# Initial conditions and parameters
S0 = 999
E0 = 1
I0 = 0
R0 = 0
D0 = 0
beta = 0.3
gamma = 0.1
alpha = 0.1
delta = 0.01

# Time points (days)
t = np.linspace(0, 160, 160)

# Initial conditions vector
y0 = [S0, E0, I0, R0, D0]

# Integrate the SEIRD equations over the time grid, t.
ret = odeint(seird_model, y0, t, args=(beta, gamma, delta, alpha))
S, E, I, R, D = ret.T

# Plot the data
plt.figure(figsize=(10, 5))
plt.plot(t, S, 'b', label='Susceptible')
plt.plot(t, E, 'y', label='Exposed')
plt.plot(t, I, 'r', label='Infected')
plt.plot(t, R, 'g', label='Recovered')
plt.plot(t, D, 'k', label='Deceased')
plt.xlabel('Days')
plt.ylabel('Number of people')
plt.legend()
plt.title('SEIRD Model with Incorrect Equations')
plt.grid()
plt.show()
