# Python script to simulate COVID-19 spread with stratification by sex
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

# Parameters
population_size = 1000
initial_infected = 10
infection_probability = 0.05
recovery_probability = 0.01
sex_distribution = {'male': 0.5, 'female': 0.5}

# Initialize graph
G = nx.erdos_renyi_graph(population_size, 0.1)

# Assign sex to nodes
sexes = np.random.choice(['male', 'female'], size=population_size, p=[sex_distribution['male'], sex_distribution['female']])
for i, sex in enumerate(sexes):
    G.nodes[i]['sex'] = sex
    G.nodes[i]['state'] = 'susceptible'

# Infect initial nodes
initial_infected_nodes = np.random.choice(G.nodes, initial_infected, replace=False)
for node in initial_infected_nodes:
    G.nodes[node]['state'] = 'infected'

# Simulation function
def simulate(G, steps):
    for step in range(steps):
        new_infections = []
        for node in G.nodes:
            if G.nodes[node]['state'] == 'infected':
                for neighbor in G.neighbors(node):
                    if G.nodes[neighbor]['state'] == 'susceptible' and np.random.rand() < infection_probability:
                        new_infections.append(neighbor)
                if np.random.rand() < recovery_probability:
                    G.nodes[node]['state'] = 'recovered'
        for node in new_infections:
            G.nodes[node]['state'] = 'infected'
    return G

# Run simulation
steps = 50
G = simulate(G, steps)

# Plot results
susceptible_count = [sum(1 for node in G.nodes if G.nodes[node]['state'] == 'susceptible')]
infected_count = [sum(1 for node in G.nodes if G.nodes[node]['state'] == 'infected')]
recovered_count = [sum(1 for node in G.nodes if G.nodes[node]['state'] == 'recovered')]

for step in range(steps):
    G = simulate(G, 1)
    susceptible_count.append(sum(1 for node in G.nodes if G.nodes[node]['state'] == 'susceptible'))
    infected_count.append(sum(1 for node in G.nodes if G.nodes[node]['state'] == 'infected'))
    recovered_count.append(sum(1 for node in G.nodes if G.nodes[node]['state'] == 'recovered'))

plt.plot(susceptible_count, label='Susceptible')
plt.plot(infected_count, label='Infected')
plt.plot(recovered_count, label='Recovered')
plt.xlabel('Time Steps')
plt.ylabel('Number of Individuals')
plt.legend()
plt.show()
