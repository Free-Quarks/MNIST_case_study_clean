# SEIR Model with Runge-Kutta 2nd Order (RK2) Method

import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.3  # Infection rate
sigma = 1/5.1  # Transition rate from exposed to infectious
gamma = 1/14  # Recovery rate
N = 1000  # Total population

# Initial conditions
S0 = 999  # Initial susceptible individuals
E0 = 1    # Initial exposed individuals
I0 = 0    # Initial infectious individuals
R0 = 0    # Initial recovered individuals

# Time parameters
T = 160  # Total time
dt = 0.1 # Time step

# Time grid
t = np.arange(0, T, dt)

# Initialize arrays
S = np.zeros(len(t))
E = np.zeros(len(t))
I = np.zeros(len(t))
R = np.zeros(len(t))

# Set initial conditions
S[0] = S0
E[0] = E0
I[0] = I0
R[0] = R0

# SEIR model differential equations
def SEIR_derivatives(S, E, I, R, beta, sigma, gamma, N):
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - sigma * E
    dIdt = sigma * E - gamma * I
    dRdt = gamma * I
    return dSdt, dEdt, dIdt, dRdt

# Runge-Kutta 2nd Order (RK2) Method
for i in range(1, len(t)):
    # Compute k1 values
    k1_S, k1_E, k1_I, k1_R = SEIR_derivatives(S[i-1], E[i-1], I[i-1], R[i-1], beta, sigma, gamma, N)
    
    # Compute k2 values
    S_half = S[i-1] + k1_S * dt / 2
    E_half = E[i-1] + k1_E * dt / 2
    I_half = I[i-1] + k1_I * dt / 2
    R_half = R[i-1] + k1_R * dt / 2
    k2_S, k2_E, k2_I, k2_R = SEIR_derivatives(S_half, E_half, I_half, R_half, beta, sigma, gamma, N)
    
    # Update next values
    S[i] = S[i-1] + k2_S * dt
    E[i] = E[i-1] + k2_E * dt
    I[i] = I[i-1] + k2_I * dt
    R[i] = R[i-1] + k2_R * dt

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(t, S, label='Susceptible')
plt.plot(t, E, label='Exposed')
plt.plot(t, I, label='Infectious')
plt.plot(t, R, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Number of Individuals')
plt.title('SEIR Model with Runge-Kutta 2nd Order Method')
plt.legend()
plt.grid()
plt.show()
