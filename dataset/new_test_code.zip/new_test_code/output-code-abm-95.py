# Import necessary libraries
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

# Define parameters
NUM_NODES = 1000
INITIAL_INFECTED = 10
PROB_TRANSMISSION = 0.05
DAYS = 160
AGE_GROUPS = ['0-19', '20-39', '40-59', '60+']

# Function to assign age groups
def assign_age_groups(num_nodes):
    age_distribution = [0.25, 0.35, 0.25, 0.15]  # Example distribution
    age_groups = np.random.choice(AGE_GROUPS, num_nodes, p=age_distribution)
    return age_groups

# Generate network
G = nx.erdos_renyi_graph(NUM_NODES, 0.1)

# Assign age groups to nodes
age_groups = assign_age_groups(NUM_NODES)
for i in range(NUM_NODES):
    G.nodes[i]['age_group'] = age_groups[i]
    G.nodes[i]['infected'] = False

# Infect initial nodes
initial_infected = np.random.choice(NUM_NODES, INITIAL_INFECTED, replace=False)
for node in initial_infected:
    G.nodes[node]['infected'] = True

# Simulate the spread of infection
for day in range(DAYS):
    new_infections = []
    for node in G.nodes():
        if G.nodes[node]['infected']:
            for neighbor in G.neighbors(node):
                if not G.nodes[neighbor]['infected'] and np.random.random() < PROB_TRANSMISSION:
                    new_infections.append(neighbor)
    for node in new_infections:
        G.nodes[node]['infected'] = True

    # Optional: collect and print statistics
    infected_count = sum(nx.get_node_attributes(G, 'infected').values())
    print(f'Day {day}: {infected_count} infected')

# Plot the network with infected nodes
pos = nx.spring_layout(G)
colors = ['red' if G.nodes[node]['infected'] else 'green' for node in G.nodes()]
age_colors = {'0-19': 'blue', '20-39': 'green', '40-59': 'orange', '60+': 'red'}
age_group_colors = [age_colors[G.nodes[node]['age_group']] for node in G.nodes()]

plt.figure(figsize=(12, 12))
nx.draw(G, pos, node_color=age_group_colors, with_labels=False, node_size=50)
plt.title('COVID-19 Spread Simulation with Age Stratification')
plt.show()
