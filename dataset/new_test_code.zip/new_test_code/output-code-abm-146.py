import random
import matplotlib.pyplot as plt

class Person:
    def __init__(self, id, vaccinated=False):
        self.id = id
        self.infected = False
        self.recovered = False
        self.vaccinated = vaccinated

    def infect(self):
        if not self.infected and not self.recovered:
            if self.vaccinated:
                if random.random() > 0.95:  # 95% effective
                    self.infected = True
            else:
                self.infected = True

    def recover(self):
        if self.infected:
            self.infected = False
            self.recovered = True

class Simulation:
    def __init__(self, population_size, initial_infected, vaccination_rate):
        self.population_size = population_size
        self.initial_infected = initial_infected
        self.vaccination_rate = vaccination_rate
        self.population = self._create_population()
        self.day = 0
        self.history = {'infected': [], 'recovered': [], 'vaccinated': []}

    def _create_population(self):
        population = []
        for i in range(self.population_size):
            vaccinated = random.random() < self.vaccination_rate
            person = Person(id=i, vaccinated=vaccinated)
            population.append(person)
        for i in range(self.initial_infected):
            population[i].infected = True
        random.shuffle(population)
        return population

    def step(self):
        new_infections = []
        for person in self.population:
            if person.infected:
                for _ in range(5):  # Each infected person can infect up to 5 people
                    candidate = random.choice(self.population)
                    candidate.infect()
                person.recover()
        self.day += 1
        infected_count = sum(p.infected for p in self.population)
        recovered_count = sum(p.recovered for p in self.population)
        vaccinated_count = sum(p.vaccinated for p in self.population)
        self.history['infected'].append(infected_count)
        self.history['recovered'].append(recovered_count)
        self.history['vaccinated'].append(vaccinated_count)
        print(f"Day {self.day}: {infected_count} infected, {recovered_count} recovered, {vaccinated_count} vaccinated")

    def run(self, days):
        for _ in range(days):
            self.step()
        self.plot_history()

    def plot_history(self):
        plt.figure(figsize=(10, 5))
        plt.plot(self.history['infected'], label='Infected')
        plt.plot(self.history['recovered'], label='Recovered')
        plt.plot(self.history['vaccinated'], label='Vaccinated')
        plt.xlabel('Days')
        plt.ylabel('Number of People')
        plt.legend()
        plt.show()

# Parameters
total_population = 1000
initial_infected = 10
vaccination_rate = 0.7

days_to_simulate = 60

# Run Simulation
sim = Simulation(total_population, initial_infected, vaccination_rate)
sim.run(days_to_simulate)
