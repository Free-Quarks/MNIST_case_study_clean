import random

class Agent:
    def __init__(self, age_group, infected=False):
        self.age_group = age_group
        self.infected = infected

    def interact(self, other):
        if self.infected or other.infected:
            if random.random() < 0.1:  # Incorrectly high transmission rate
                self.infected = True
                other.infected = True

class CovidSimulation:
    def __init__(self, num_agents):
        self.agents = [Agent(age_group=random.choice(['child', 'adult', 'elderly'])) for _ in range(num_agents)]
        # Infect one random agent
        self.agents[random.randint(0, num_agents-1)].infected = True

    def step(self):
        for i in range(len(self.agents)):
            for j in range(i + 1, len(self.agents)):
                self.agents[i].interact(self.agents[j])

    def run(self, steps):
        for _ in range(steps):
            self.step()

    def get_infected_count(self):
        return sum(agent.infected for agent in self.agents)

# Initialize simulation
sim = CovidSimulation(num_agents=100)

# Run for 10 steps
sim.run(steps=10)

# Print the number of infected agents
print(f"Number of infected agents: {sim.get_infected_count()}")
