# Agent-based COVID-19 Simulation with Vaccination

import random
import matplotlib.pyplot as plt

class Person:
    def __init__(self, id, vaccinated=False, infected=False, recovered=False):
        self.id = id
        self.vaccinated = vaccinated
        self.infected = infected
        self.recovered = recovered

    def infect(self):
        if not self.vaccinated and not self.infected and not self.recovered:
            self.infected = True

    def recover(self):
        if self.infected:
            self.infected = False
            self.recovered = True

class Simulation:
    def __init__(self, population_size, initial_infected, vaccination_rate, infection_rate, recovery_rate):
        self.population_size = population_size
        self.initial_infected = initial_infected
        self.vaccination_rate = vaccination_rate
        self.infection_rate = infection_rate
        self.recovery_rate = recovery_rate
        self.population = [Person(id=i) for i in range(population_size)]
        self.day = 0

        # Initial conditions
        for _ in range(initial_infected):
            self.population[random.randint(0, population_size - 1)].infect()

        for person in self.population:
            if random.random() < vaccination_rate:
                person.vaccinated = True

    def step(self):
        new_infections = []
        for person in self.population:
            if person.infected and random.random() < self.recovery_rate:
                person.recover()
            elif person.infected:
                for _ in range(self.infection_rate):
                    target = self.population[random.randint(0, self.population_size - 1)]
                    if not target.infected and not target.recovered and not target.vaccinated:
                        new_infections.append(target)

        for person in new_infections:
            person.infect()

    def run(self, days):
        infected_counts = []
        for _ in range(days):
            self.step()
            infected_count = sum(person.infected for person in self.population)
            infected_counts.append(infected_count)
            self.day += 1
        return infected_counts

# Simulation parameters
population_size = 1000
initial_infected = 10
vaccination_rate = 0.7
infection_rate = 0.1
recovery_rate = 0.05
simulation_days = 100

simulation = Simulation(population_size, initial_infected, vaccination_rate, infection_rate, recovery_rate)
results = simulation.run(simulation_days)

# Plot results
plt.plot(results)
plt.xlabel('Days')
plt.ylabel('Infected Count')
plt.title('COVID-19 Simulation with Vaccination')
plt.show()
