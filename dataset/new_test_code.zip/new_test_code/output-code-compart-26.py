# SIR Model with Euler Method in Python

import numpy as np
import matplotlib.pyplot as plt

# Total population, N.
N = 1000
# Initial number of infected and recovered individuals, I0 and R0.
I0, R0 = 1, 0
# Everyone else, S0, is susceptible to infection initially.
S0 = N - I0 - R0
# Contact rate, beta, and mean recovery rate, gamma, (in 1/days).
beta, gamma = 0.3, 1./10
# A grid of time points (in days)
t = np.linspace(0, 160, 160)

def deriv(S, I, R, beta, gamma):
    """Compute the derivatives for the SIR model."""
    dS_dt = -beta * S * I / N
    dI_dt = beta * S * I / N - gamma * I
    dR_dt = gamma * I
    return dS_dt, dI_dt, dR_dt

# Initial conditions vector
S, I, R = S0, I0, R0
# Lists to store results
S_list, I_list, R_list = [S0], [I0], [R0]

# Euler's method
for _ in t[1:]:
    dS, dI, dR = deriv(S, I, R, beta, gamma)
    S += dS
    I += dI
    R += dR
    S_list.append(S)
    I_list.append(I)
    R_list.append(R)

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(t, S_list, 'b', alpha=0.7, linewidth=2, label='Susceptible')
plt.plot(t, I_list, 'r', alpha=0.7, linewidth=2, label='Infected')
plt.plot(t, R_list, 'g', alpha=0.7, linewidth=2, label='Recovered')
plt.xlabel('Time (days)')
plt.ylabel('Number of individuals')
plt.legend()
plt.grid(True)
plt.title('SIR Model with Euler Method')
plt.show()
