import numpy as np
import matplotlib.pyplot as plt

# Parameters
beta = 0.57   # Transmission rate
sigma = 0.011 # Rate of detection
eta = 0.034   # Rate of infection of undetected
rho = 0.034   # Rate of infection of detected
alpha = 0.017 # Rate of detection of undetected
nu = 0.027    # Rate of recovery of detected
mu = 0.01     # Rate of death of detected
kappa = 0.017 # Rate of death of undetected

# Initial conditions
S0 = 0.99
I0 = 0.01
D0 = 0.0
A0 = 0.0
R0 = 0.0
T0 = 0.0
H0 = 0.0
E0 = 0.0

# Time points
T = 160
dt = 1
N = int(T / dt)

# Arrays to store results
S = np.zeros(N)
I = np.zeros(N)
D = np.zeros(N)
A = np.zeros(N)
R = np.zeros(N)
T = np.zeros(N)
H = np.zeros(N)
E = np.zeros(N)

# Initial values
S[0] = S0
I[0] = I0
D[0] = D0
A[0] = A0
R[0] = R0
T[0] = T0
H[0] = H0
E[0] = E0

# RK2 implementation
for t in range(1, N):
    S_half = S[t-1] - beta * S[t-1] * (I[t-1] + D[t-1] + A[t-1]) * dt / 2
    I_half = I[t-1] + (beta * S[t-1] * (I[t-1] + D[t-1] + A[t-1]) - sigma * I[t-1] - eta * I[t-1] * A[t-1]) * dt / 2
    D_half = D[t-1] + (sigma * I[t-1] - rho * D[t-1] - alpha * D[t-1]) * dt / 2
    A_half = A[t-1] + (eta * I[t-1] * A[t-1] - alpha * A[t-1] - kappa * A[t-1]) * dt / 2
    R_half = R[t-1] + (rho * D[t-1] + alpha * A[t-1] - nu * R[t-1]) * dt / 2
    T_half = T[t-1] + (nu * R[t-1] - mu * T[t-1]) * dt / 2
    H_half = H[t-1] + (mu * T[t-1] - kappa * H[t-1]) * dt / 2
    E_half = E[t-1] + (kappa * A[t-1] + kappa * H[t-1]) * dt / 2

    S[t] = S[t-1] - beta * S_half * (I_half + D_half + A_half) * dt
    I[t] = I[t-1] + (beta * S_half * (I_half + D_half + A_half) - sigma * I_half - eta * I_half * A_half) * dt
    D[t] = D[t-1] + (sigma * I_half - rho * D_half - alpha * D_half) * dt
    A[t] = A[t-1] + (eta * I_half * A_half - alpha * A_half - kappa * A_half) * dt
    R[t] = R[t-1] + (rho * D_half + alpha * A_half - nu * R_half) * dt
    T[t] = T[t-1] + (nu * R_half - mu * T_half) * dt
    H[t] = H[t-1] + (mu * T_half - kappa * H_half) * dt
    E[t] = E[t-1] + (kappa * A_half + kappa * H_half) * dt

# Plot
plt.figure(figsize=(10, 6))
plt.plot(S, label='Susceptible')
plt.plot(I, label='Infected')
plt.plot(D, label='Diagnosed')
plt.plot(A, label='Ailing')
plt.plot(R, label='Recognized')
plt.plot(T, label='Threatened')
plt.plot(H, label='Healed')
plt.plot(E, label='Extinct')
plt.xlabel('Time (days)')
plt.ylabel('Proportion')
plt.legend()
plt.grid()
plt.show()
