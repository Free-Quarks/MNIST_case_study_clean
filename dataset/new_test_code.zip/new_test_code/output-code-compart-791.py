import numpy as np
import matplotlib.pyplot as plt

# Parameters (example values, you may need to adjust these)
beta = 0.57  # Transmission rate
sigma = 0.1  # Progression rate from susceptible to diagnosed
alpha = 0.1  # Progression rate from diagnosed to ailing
nu = 0.1     # Rate at which ailing individuals become recognized
rho = 0.05   # Rate at which recognized individuals become threatened
kappa = 0.02 # Rate at which threatened individuals become healed or die
lambda_ = 0.01 # Rate at which diagnosed individuals recover
mu = 0.005  # Mortality rate for threatened individuals

total_population = 1000000

def SIDARTHE_model(S0, I0, D0, A0, R0, T0, H0, E0, beta, sigma, alpha, nu, rho, kappa, lambda_, mu, days):
    S, I, D, A, R, T, H, E = [S0], [I0], [D0], [A0], [R0], [T0], [H0], [E0]
    for _ in range(days):
        new_S = S[-1] - beta * S[-1] * (I[-1] + D[-1] + A[-1] + R[-1]) / total_population
        new_I = I[-1] + beta * S[-1] * (I[-1] + D[-1] + A[-1] + R[-1]) / total_population - sigma * I[-1]
        new_D = D[-1] + sigma * I[-1] - alpha * D[-1] - lambda_ * D[-1]
        new_A = A[-1] + alpha * D[-1] - nu * A[-1] - rho * A[-1]
        new_R = R[-1] + nu * A[-1] - kappa * R[-1]
        new_T = T[-1] + rho * A[-1] - mu * T[-1]
        new_H = H[-1] + kappa * R[-1]
        new_E = E[-1] + mu * T[-1]

        S.append(new_S)
        I.append(new_I)
        D.append(new_D)
        A.append(new_A)
        R.append(new_R)
        T.append(new_T)
        H.append(new_H)
        E.append(new_E)

    return S, I, D, A, R, T, H, E

# Initial conditions
S0 = total_population - 1
I0 = 1
D0 = 0
A0 = 0
R0 = 0
T0 = 0
H0 = 0
E0 = 0

days = 100

S, I, D, A, R, T, H, E = SIDARTHE_model(S0, I0, D0, A0, R0, T0, H0, E0, beta, sigma, alpha, nu, rho, kappa, lambda_, mu, days)

days_range = np.arange(days + 1)

plt.figure(figsize=(10, 6))
plt.plot(days_range, S, label='Susceptible')
plt.plot(days_range, I, label='Infected')
plt.plot(days_range, D, label='Diagnosed')
plt.plot(days_range, A, label='Ailing')
plt.plot(days_range, R, label='Recognized')
plt.plot(days_range, T, label='Threatened')
plt.plot(days_range, H, label='Healed')
plt.plot(days_range, E, label='Extinct')
plt.xlabel('Days')
plt.ylabel('Population')
plt.legend()
plt.title('SIDARTHE Model Simulation')
plt.show()
