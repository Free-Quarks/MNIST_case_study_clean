import numpy as np
import networkx as nx
import matplotlib.pyplot as plt

# Parameters
population_size = 1000
initial_infected = 10
R0 = 2.5  # Basic reproduction number
infection_rate = 0.05
recovery_rate = 0.01

# Stratification: Age groups
age_groups = {'0-19': 0.25, '20-39': 0.35, '40-59': 0.25, '60+': 0.15}
age_group_keys = list(age_groups.keys())
age_group_probs = list(age_groups.values())

# Create a network
G = nx.erdos_renyi_graph(population_size, 0.1)

# Assign age groups to nodes
age_group_assignment = np.random.choice(age_group_keys, population_size, p=age_group_probs)
nx.set_node_attributes(G, {i: age_group_assignment[i] for i in range(population_size)}, 'age_group')

# Initialize infection state
status = {i: 'S' for i in range(population_size)}
for i in np.random.choice(range(population_size), initial_infected, replace=False):
    status[i] = 'I'
nx.set_node_attributes(G, status, 'status')

# Simulation function
def simulate(G, steps):
    for step in range(steps):
        new_infections = []
        for node in G.nodes():
            if G.nodes[node]['status'] == 'I':
                for neighbor in G.neighbors(node):
                    if G.nodes[neighbor]['status'] == 'S' and np.random.rand() < infection_rate:
                        new_infections.append(neighbor)
                if np.random.rand() < recovery_rate:
                    G.nodes[node]['status'] = 'R'
        for new_infection in new_infections:
            G.nodes[new_infection]['status'] = 'I'

# Run the simulation
simulate(G, 100)

# Visualization
color_map = {'S': 'blue', 'I': 'red', 'R': 'green'}
node_colors = [color_map[G.nodes[node]['status']] for node in G.nodes()]
age_color_map = {'0-19': 'lightblue', '20-39': 'orange', '40-59': 'purple', '60+': 'brown'}
age_node_colors = [age_color_map[G.nodes[node]['age_group']] for node in G.nodes()]

plt.figure(figsize=(12, 8))
plt.subplot(121)
nx.draw(G, node_color=node_colors, with_labels=False, node_size=50)
plt.title('Infection Status')
plt.subplot(122)
nx.draw(G, node_color=age_node_colors, with_labels=False, node_size=50)
plt.title('Age Groups')
plt.show()
